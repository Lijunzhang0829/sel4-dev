"""Build a complete source index; lexical references are not proof dependencies."""
import hashlib
import json
from pathlib import Path
import re

from native import ROOT, save

TOKEN = re.compile(r"(?<![A-Za-z0-9_'])[A-Za-z_][A-Za-z0-9_']*")


def build(root=ROOT):
    index = {}
    for filename in ('definitions.json', 'generated-c-definitions.json', 'upstream-definitions.json'):
        data = json.loads((root / 'input' / filename).read_text())
        for d in data['definitions']:
            name = d['name']
            body = d.get('exact_command', d.get('body', ''))
            index.setdefault(name, []).append(dict(name=name, catalog=filename,
                file=d.get('source_file', d.get('file')), line=d.get('line'),
                body_sha256=hashlib.sha256(body.encode()).hexdigest(),
                references=sorted(set(TOKEN.findall(body)) - {name})))
    text = (root / 'input/c/binomial-heap.c').read_text()
    functions = {}
    matches = list(re.finditer(r'(?m)^(?:static\s+)?[A-Za-z_][^;{}\n]*\b(binomial_[a-z_]+)\s*\(', text))
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        region = text[m.start():end]
        functions[m[1]] = dict(file='c/binomial-heap.c',
            start_line=text.count('\n', 0, m.start()) + 1,
            end_line=text.count('\n', 0, end),
            region_sha256=hashlib.sha256(region.encode()).hexdigest())
    rows = []
    for t in json.loads((root / 'input/specs.json').read_text())['specs']:
        tokens = set(TOKEN.findall(t['statement']))
        direct = tokens & index.keys()
        closure, todo = set(), list(direct)
        all_tokens = set(tokens)
        while todo:
            name = todo.pop()
            if name in closure:
                continue
            closure.add(name)
            for d in index[name]:
                all_tokens.update(d['references'])
                todo.extend(set(d['references']) & index.keys() - closure)
        calls = lambda names: sorted({s[:-1] for s in names if s.endswith("'") and s[:-1] in functions})
        direct_calls, referenced_calls = calls(tokens), calls(all_tokens)
        rows.append(dict(id=t['id'], name=t['name'], role=t['role'],
            source_file=t['source_file'], line=t['line'],
            statement_sha256=hashlib.sha256(t['statement'].encode()).hexdigest(),
            environment_id=t['environment_id'],
            classification=('C_execution' if direct_calls else 'extracted_execution_interface'
                            if referenced_calls else 'representation_or_support_property'),
            direct_definitions=sorted(direct), definition_closure=sorted(closure),
            direct_C_calls=direct_calls, referenced_C_calls=referenced_calls,
            available_as_premise=False))
    result = dict(schema_version=1, entries=len(rows), contracts=rows,
        definition_index=index, C_functions=functions,
        c_sha256=hashlib.sha256(text.encode()).hexdigest(),
        relation='source references and definition expansion, not a human proof plan',
        contains_proofs=False, claims_all_referenced_C_functions_verified=False)
    save(root / 'audit/contract-bindings.json', result)
    return result


if __name__ == '__main__':
    result = build()
    print(json.dumps(dict(entries=result['entries'], C_functions=len(result['C_functions']))))

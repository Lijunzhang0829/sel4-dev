"""Validate and freeze the single current dataset, without starting generation."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from native import ROOT, save
from judge import strip_comments, verify_owned, verify_catalog, verify_semantic_sources
from contract_bindings import build as contract_bindings


def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def read(file):
    return json.loads(file.read_text())


def input_files(root):
    return {str(p.relative_to(root / 'input')): sha(p)
            for p in sorted((root / 'input').rglob('*'))
            if p.is_file() and p.name != 'manifest.json'}


def selection(root):
    entries = read(root / 'input/specs.json')['specs']
    targets = read(root / 'input/targets.json')['targets']
    background = read(root / 'input/background.json')['helpers']
    selected = read(root / 'input/contract-selection.json')
    if (len(entries) != 100 or len(targets) != 91 or len(background) != 9
            or [t for t in entries if t['generation_required']] != targets
            or [t for t in entries if not t['generation_required']] != background
            or selected['active_target_ids'] != [t['id'] for t in targets]
            or selected['background_declaration_ids'] != [t['id'] for t in background]
            or selected['disabled_target_ids'] != ['0054']
            or any(t['id'] == '0054' or t['available_as_premise'] for t in entries)):
        raise ValueError('current active selection changed')
    text = (root / 'input/isabelle/Contracts.thy').read_text()
    active = strip_comments(text)
    names = re.findall(r'(?m)^\s*lemma\s+([A-Za-z_][A-Za-z0-9_\']*)\s*:', active)
    if names != [t['name'] for t in entries] or len(re.findall(r'(?m)^oops\s*$', active)) != 100:
        raise ValueError('0054 is active or declaration selection differs')
    for t in entries:
        if active.count(t['statement']) != 1:
            raise ValueError('active exact statement changed: ' + t['id'])
        if t['line'] != text.count('\n', 0, text.index('lemma ' + t['name'] + ':')) + 1:
            raise ValueError('statement line changed')
    return entries, targets, background


def manifest_for(root):
    entries, targets, background = selection(root)
    files = input_files(root)
    return dict(schema_version=3, dataset='binomial', revision='current-001',
        publication_status='accepted', contract_source_file='isabelle/Contracts.thy',
        entry_count=len(entries), verification_target_count=len(targets),
        background_helper_count=len(background), ids=[t['id'] for t in entries],
        disabled_target_ids=['0054'], preserve_numbering=True,
        additional_semantic_imports=['Repair_Phase_Model', 'Environment_Parameters'],
        result_scope='owned-context-outcomes-v1',
        target_proofs_supplied=False, historical_outcomes_supplied=False,
        background_facts_imported=0, external_toolchain_required=True,
        input_files_sha256=files, dataset_binding=digest(files))


def preserved_source(root):
    snapshot = read(root / 'audit/source-snapshot.json')
    prior = root.parent / snapshot['path']
    previous = snapshot['input_files_sha256']
    if input_files(prior) != previous:
        raise ValueError('archived revision changed')
    for name, expected in previous.items():
        # Only declarations/selection metadata and the reproducible command path differ.
        if (name.startswith(('c/', 'parent/')) or name.endswith('.thy') and
                name != 'isabelle/Revised_Contracts.thy' or
                name in ('environment.json', 'environment-scopes.json', 'generated-c-definitions.json')):
            if sha(root / 'input' / name) != expected:
                raise ValueError('current C/model/environment differs from checked snapshot: ' + name)
    old = {t['id']: t for t in read(prior / 'input/specs.json')['specs']}
    entries, _, _ = selection(root)
    for t in entries:
        if (t['statement'], t['context'], t['environment_id']) != (
                old[t['id']]['statement'], old[t['id']]['context'], old[t['id']]['environment_id']):
            raise ValueError('retained contract or scope changed')
    if (root / 'audit/native-export-catalog.json').is_file():
        current_catalog = read(root / 'audit/native-export-catalog.json')
        prior_catalog = read(prior / 'audit/native-export-catalog.json')
        if (current_catalog['status'] != 'pass' or
                current_catalog['targets'] != {t['id']: prior_catalog['targets'][t['id']] for t in entries}):
            raise ValueError('retained native E/A/Q export changed')
    return dict(status='pass', path=snapshot['path'],
                dataset_binding=snapshot['dataset_binding'], input_unchanged=True,
                retained_native_E_A_Q_unchanged=True)


def native_evidence(root, report):
    native = report.get('native', report)
    if report['status'] != 'pass' or native['status'] != 'pass':
        raise ValueError('native acceptance unfinished')
    if sha(root / native['directory'] / 'check.log') != native['log_sha256']:
        raise ValueError('native log changed')
    for file in (root / 'input/isabelle').glob('*.thy'):
        if native['checked_sources'].get(file.name) != sha(file):
            raise ValueError('native evidence predates current source: ' + file.name)
    return native


def acceptance(root):
    entries, targets, background = selection(root)
    preserved = preserved_source(root)
    catalog = verify_semantic_sources(root)
    native_evidence(root, catalog)
    native_evidence(root, read(root / 'validation/declarations.json'))
    native_evidence(root, read(root / 'validation/environment-and-c.json'))
    controls = read(root / 'validation/protocol-controls.json')
    if controls['status'] != 'pass' or len(controls['cases']) != 5:
        raise ValueError('owned-context protocol controls unfinished')
    protocol_sha256 = sha(root / 'protocol/Owned_Context_Protocol.thy')
    for case in controls['cases']:
        if (not case['passed'] or case['native']['checked_sources'].get('Owned_Context_Protocol.thy')
                != protocol_sha256):
            raise ValueError('protocol control evidence is stale')
    parallel = read(root / 'validation/parallel-protocol.json')
    native_evidence(root, parallel)
    if parallel['native']['checked_sources'].get('Owned_Context_Protocol.thy') != protocol_sha256:
        raise ValueError('parallel protocol control is stale')
    if read(root / 'validation/selection-controls.json')['status'] != 'pass':
        raise ValueError('selection controls unfinished')
    if set(catalog['targets']) != {t['id'] for t in entries}:
        raise ValueError('scope export does not match the active declarations')
    report = read(root / 'validation/all-targets.json')
    native = native_evidence(root, report)
    if report['accepted'] != 91 or report['unresolved']:
        raise ValueError('not every active target has a checked outcome')
    byid = {t['id']: t for t in targets}
    records = {}; occurrences = {}
    for encoded in re.findall(r'^R2_CERTIFICATE ([0-9a-f]+)$',
                              (root / native['directory'] / 'check.log').read_text(), re.M):
        raw = bytes.fromhex(encoded).decode()
        identifier = ET.fromstring(raw).attrib['id']
        if identifier not in byid:
            raise ValueError('inactive certificate')
        expected = report['certificates'][identifier]
        receipt = verify_owned(raw, byid[identifier], expected['polarity'])
        verify_catalog(raw, byid[identifier], catalog)
        records[identifier] = receipt
        occurrences[identifier] = occurrences.get(identifier, 0) + 1
    if set(records) != set(byid):
        raise ValueError('missing active target certificate')
    if any(n != 2 for n in occurrences.values()):
        raise ValueError('predecessor/current certificate multiplicity changed')
    for identifier, receipt in records.items():
        if receipt['raw_sha256'] != report['certificates'][identifier]['raw_sha256']:
            raise ValueError('current certificate changed')
    positive = sorted(i for i, c in records.items() if c['polarity'] == 'positive')
    negative = sorted(i for i, c in records.items() if c['polarity'] == 'relative-negative')
    return dict(status='pass', targets=91, positive=positive, relative_negative=negative,
        unresolved=[], disabled=['0054'], background_declarations=9,
        source_preservation=preserved, native_directory=native['directory'],
        exact_scope_catalog_sha256=digest(catalog['targets']),
        certificates_sha256=digest(records), model_calls=0,
        preparation_only=True, new_LLM_experiment_score=False,
        whole_original_repository_verified=False)


def write_docs(root):
    entries, _, _ = selection(root)
    definitions = read(root / 'input/definitions.json')['definitions']
    names = {d['name'] for d in definitions}
    lines = ['# 当前数据集全部声明', '',
        '100 条活动目录声明：91 条生成目标、9 条背景目录声明。0054 已注释停用。背景声明未作为已证事实导入。', '']
    for t in entries:
        used = sorted(set(re.findall(r"\b[A-Za-z_][A-Za-z0-9_']*", t['statement'])) & names)
        lines += ['## ' + t['name'], '', t['meaning'], '',
            '角色：' + t['role'] + '；环境：`' + t['environment_id'] + '`。', '',
            '```isabelle', t['statement'], '```', '',
            '直接定义：' + ', '.join('`' + n + '`' for n in used) + '。', '']
    (root / 'ALL-SPECS.md').write_text('\n'.join(lines))
    lines = ['# 当前定义目录', '', 'C 翻译器定义见 input/generated-c-definitions.json。', '']
    for d in definitions:
        lines += ['## ' + d['name'], '',
            f"来源：`{d['source_file']}:{d['line']}`。", '',
            '```isabelle', d['exact_command'], '```', '']
    (root / 'DEFINITIONS.md').write_text('\n'.join(lines))


def main(verify_only=False):
    result = acceptance(ROOT)
    manifest = manifest_for(ROOT)
    if verify_only:
        frozen = read(ROOT / 'input/manifest.json')
        if frozen != manifest:
            raise ValueError('published manifest or input changed')
    else:
        save(ROOT / 'input/manifest.json', manifest)
        contract_bindings(ROOT)
        write_docs(ROOT)
        save(ROOT / 'audit/dataset-binding.json', dict(
            dataset_binding=manifest['dataset_binding'], manifest_sha256=sha(ROOT / 'input/manifest.json'),
            protocol_files_sha256={str(p.relative_to(ROOT)): sha(p)
                for p in sorted((ROOT / 'protocol').glob('*')) if p.is_file()},
            judge_files_sha256={str(p.relative_to(ROOT)): sha(p)
                for p in (ROOT / 'tools/native.py', ROOT / 'tools/judge.py')},
            acceptance=result))
        save(ROOT / 'audit/revision-state.json', dict(status='accepted', release_ready=True,
            generation_enabled=False, active_targets=91,
            proved=len(result['positive']), context_refuted=len(result['relative_negative']),
            unresolved=[], disabled=['0054'], background_declarations=9,
            new_experiment_started=False, fixed_global_environment='unbound'))
        save(ROOT / 'validation/acceptance.json', result)
        save(ROOT.parent / 'current-dataset.json', dict(schema_version=1,
            dataset='dataset', input_manifest='dataset/input/manifest.json',
            dataset_binding=manifest['dataset_binding'], active_targets=91,
            disabled=['0054'], historical_snapshots=['dataset-shuffled-001',
                'dataset-revised-002', 'dataset-revised-003', 'dataset-shuffled-002'],
            historical_snapshots_are_current=False))
    print(json.dumps(dict(status='pass', targets=91, positive=len(result['positive']),
        relative_negative=len(result['relative_negative']), unresolved=[], disabled=['0054'],
        dataset_binding=manifest['dataset_binding'], new_experiment_started=False)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-only', action='store_true')
    main(parser.parse_args().verify_only)

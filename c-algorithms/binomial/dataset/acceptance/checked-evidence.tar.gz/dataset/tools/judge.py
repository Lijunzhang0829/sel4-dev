"""Dataset-local trusted preparation judge; no production adapter is replaced."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from native import ROOT, check, save

FORBIDDEN = re.compile(r'\b(?:sorry|axioms|axiomatization|oracle|ML\w*|SML\w*|setup|local_setup|method_setup|attribute_setup|tactic|use|external_file|export_code|theory|context|locale|end|lemma|theorem|definition|declare|interpretation|sublocale|r2_capture|r2_refute|r2_prove|regen_refute\w*)\b')


def sha(raw):
    return hashlib.sha256(raw if isinstance(raw, bytes) else raw.encode()).hexdigest()


def digest(value):
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True))


def strip_comments(text):
    out = []; i = 0; depth = 0
    while i < len(text):
        if text[i:i+2] == '(*': depth += 1; i += 2
        elif text[i:i+2] == '*)':
            if not depth: raise ValueError('unmatched comment')
            depth -= 1; i += 2
        else:
            if not depth: out.append(text[i])
            i += 1
    if depth: raise ValueError('unclosed comment')
    return ''.join(out)


def proof_hygiene(body):
    plain = strip_comments(body)
    hit = FORBIDDEN.search(plain)
    if hit: raise ValueError('forbidden proof command: ' + hit[0])
    if not re.match(r'^\s*(by|proof|apply|using|unfolding)\b', plain):
        raise ValueError('complete proof body required')


def binding(target):
    return dict(id=target['id'], statement=target['statement'],
                context=target['context'], environment_id=target['environment_id'])


def declaration(target, prefix):
    return re.sub(r'^lemma\s+' + re.escape(target['name']), prefix,
                  target['statement'], count=1)


def owned_body(target, polarity, body):
    lines = [] if target['context'] == 'global' else ['context ' + target['context'] + ' begin']
    lines += [declaration(target, 'r2_capture ' + json.dumps(target['id']) + ' ' +
                         json.dumps(target['environment_id']) + ' captured')]
    if polarity == 'positive':
        lines += [declaration(target, 'r2_prove ' + json.dumps(target['id']) + ' checked_result')]
    else:
        lines += ['r2_refute ' + json.dumps(target['id']) + ' checked_result']
    lines += [body]
    if target['context'] != 'global': lines += ['end']
    return '\n'.join(lines)


def verify_owned(raw, target, polarity):
    receipt = ET.fromstring(raw)
    if receipt.tag != 'owned_context_certificate' or receipt.attrib != {'version':'3','id':target['id']}:
        raise ValueError('certificate target or protocol mismatch')
    fields = [c.tag for c in receipt]
    if len(fields) != len(set(fields)):
        raise ValueError('duplicate certificate fields')
    expected = dict(scope='owned-context', polarity=polarity,
        environment_id=target['environment_id'], skip_proof='false', oracles='0',
        hypotheses_within_environment='true', axioms_safe='true',
        environment_global_truth_established_by_certificate='false')
    for key, value in expected.items():
        if receipt.findtext(key) != value: raise ValueError('certificate scope/field mismatch: ' + key)
    for key in ['contract_body_term','negative_goal_term']:
        if not receipt.findtext(key): raise ValueError('missing mechanical target term')
    env = [x.text for x in receipt.find('environment')]
    residual = [x.text for x in receipt.find('residual_hypotheses')]
    if not set(residual) <= set(env): raise ValueError('contract hypothesis outside owned environment')
    if not list(receipt.find('proved')): raise ValueError('missing theorem')
    if polarity == 'relative-negative' and [x.text for x in receipt.find('proved')] != [receipt.findtext('negative_goal_term')]:
        raise ValueError('proved term differs from mechanical negation')
    return dict(scope='owned-context', environment_id=target['environment_id'],
                polarity=polarity, environment_assumptions=len(env),
                asserts_global_environment_truth=False, raw_sha256=sha(raw))



def verify_catalog(raw, target, catalog):
    receipt = ET.fromstring(raw)
    if catalog['status'] != 'pass':
        raise ValueError('native preparation catalog not accepted')
    fixed = catalog['targets'][target['id']]
    if (target['environment_id'] != fixed['environment_id'] or
            receipt.findtext('contract_body_term') != fixed['contract_body_term'] or
            [x.text for x in receipt.find('environment')] != fixed['environment_terms']):
        raise ValueError('native target/environment differs from the preparation export')


def verify_semantic_sources(root=ROOT):
    """A matching proposition AST alone does not bind definition bodies or C."""
    catalog = json.loads((root / 'audit/native-export-catalog.json').read_text())
    if catalog['status'] != 'pass':
        raise ValueError('native preparation catalog not accepted')
    for file in (root / 'input/isabelle').glob('*.thy'):
        if catalog['native']['checked_sources'].get(file.name) != sha(file.read_bytes()):
            raise ValueError('scope catalog predates semantic source: ' + file.name)
    translation = json.loads((root / 'validation/c-binding.json').read_text())
    if translation['status'] != 'pass':
        raise ValueError('native C binding not accepted')
    for name, expected in translation['compared_files'].items():
        if sha((root / 'input' / name).read_bytes()) != expected:
            raise ValueError('native C binding predates source: ' + name)
    return catalog


def judge(target, polarity, body, *, preparation=False, extra_sources=None, imports=None):
    state = json.loads((ROOT / 'audit/revision-state.json').read_text())
    if not preparation and not state['release_ready']:
        raise ValueError('revision not released; use explicit preparation mode')
    fixed = next((x for x in json.loads((ROOT / 'input/targets.json').read_text())['targets'] if x['id'] == target['id']), None)
    if fixed is None: raise ValueError('not a revision verification target')
    if binding(fixed) != binding(target):
        raise ValueError('target differs from the frozen revision contract')
    catalog = verify_semantic_sources()
    if (extra_sources or imports) and not preparation:
        raise ValueError('custom validation imports require preparation mode')
    proof_hygiene(body)
    label = 'Revision_Judgement_' + target['id'].replace('-', '_')
    imports = imports or ['Owned_Context_Protocol']
    extras = {'Owned_Context_Protocol': (ROOT / 'protocol/Owned_Context_Protocol.thy').read_text(), **(extra_sources or {})}
    if polarity == 'strict-negative':
        ml = (ROOT / 'protocol/Strict_Global_Protocol.ML').read_text().replace('REGEN_AUDIT_PATH',
                 json.dumps('/review-user/.isabelle/Isabelle2026/strict-receipt.xml'))
        head = 'keywords "regen_refute_capture" :: thy_decl and "regen_refute_exported" :: thy_goal\nbegin\nML \\<open>\n' + ml + '\n\\<close>\n'
        ctx = [] if target['context'] == 'global' else ['context ' + target['context'] + ' begin']
        inner = '\n'.join(ctx + [declaration(target, 'regen_refute_capture ' + json.dumps(target['id']) + ' captured')] + ['end' for _ in ctx])
        content = head + inner + '\nregen_refute_exported ' + json.dumps(target['id']) + ' checked_result\n' + body
    else:
        content = 'begin\n' + owned_body(target, polarity, body)
    source = 'theory ' + label + '\nimports ' + ' '.join(imports) + '\n' + content + '\nend\n'
    native = check(label, source, extra_sources=extras)
    directory = ROOT / native['directory']
    result = dict(status='unresolved', contract=binding(target), contract_sha256=digest(binding(target)),
        polarity=polarity, native=native, preparation=preparation, model_calls=0,
        production_score_changed=False, support_sha256=sha(extras['Owned_Context_Protocol']))
    if native['status'] == 'pass':
        if polarity == 'strict-negative':
            raw = (directory / 'native-user/strict-receipt.xml').read_text()
            receipt = ET.fromstring(raw)
            fields = dict(skip_proof='false',oracles='0',hypotheses='0',changed_axioms='false',exact_closed_negation='true',context_exported='true')
            if receipt.attrib != {'version':'2','contract_id':target['id']} or any(receipt.findtext(k) != v for k,v in fields.items()):
                raise ValueError('strict global certificate rejected')
            certificate = dict(scope='strict-global', polarity=polarity, raw_sha256=sha(raw))
        else:
            log = (directory / 'check.log').read_text()
            receipts = re.findall(r'^R2_CERTIFICATE ([0-9a-f]+)$', log, re.M)
            matching = [bytes.fromhex(x).decode() for x in receipts if ET.fromstring(bytes.fromhex(x)).attrib.get('id') == target['id']]
            if len(matching) != 1: raise ValueError('missing or duplicate native certificate')
            raw = matching[0]
            certificate = verify_owned(raw, target, polarity)
            verify_catalog(raw, target, catalog)
        (directory / 'certificate.xml').write_text(raw)
        result.update(status={'positive':'proved_in_environment','relative-negative':'refuted_in_environment',
                              'strict-negative':'refuted_global'}[polarity], certificate=certificate)
    save(directory / 'judgement.json', result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--target', required=True)
    parser.add_argument('--polarity', choices=['positive','relative-negative','strict-negative'], required=True)
    parser.add_argument('--proof-file', type=Path, required=True)
    parser.add_argument('--preparation', action='store_true')
    args = parser.parse_args()
    targets = json.loads((ROOT / 'input/targets.json').read_text())['targets']
    target = next(x for x in targets if x['id'] == args.target)
    result = judge(target, args.polarity, args.proof_file.read_text(), preparation=args.preparation)
    print(json.dumps({k:v for k,v in result.items() if k != 'native'}), flush=True)

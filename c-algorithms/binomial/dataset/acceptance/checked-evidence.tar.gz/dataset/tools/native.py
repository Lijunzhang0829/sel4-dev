"""Isolated native checks for this revision, outside experiment budgets."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def check(name, text, *, timeout=600, extra_sources=None):
    if not name.replace('_', '').isalnum():
        raise ValueError('invalid native theory name')
    stamp = str(time.time_ns())
    output = ROOT / 'validation' / (name + '-' + stamp)
    stage = output / 'source'
    stage.mkdir(parents=True)
    for p in (ROOT / 'input/isabelle').glob('*.thy'):
        shutil.copyfile(p, stage / p.name)
    for label, body in (extra_sources or {}).items():
        (stage / (label + '.thy')).write_text(body)
    (stage / (name + '.thy')).write_text(text)
    home = output / 'native-user'
    (home / 'etc').mkdir(parents=True, exist_ok=True)
    (home / 'etc/settings').write_text(
        'ML_OPTIONS="-H 256 --maxheap 4096 --stackspace 64 --gcthreads 2"\n'
        'ISABELLE_TOOL_JAVA_OPTIONS="-Djava.awt.headless=true -Xms128m -Xmx1g -Xss8m"\n')
    prototype = json.loads((BASE / 'dataset-shuffled-001/validation/native-check.json').read_text())['command']
    cmd = list(prototype)
    container = 'binomial-revision-' + stamp
    cmd[cmd.index('--name') + 1] = container
    for i, value in enumerate(cmd):
        if value.startswith('type=bind,'):
            if 'dst=/review,' in value:
                cmd[i] = f'type=bind,src={ROOT},dst=/review,readonly'
            elif 'dst=/review-user/.isabelle/Isabelle2026' in value:
                cmd[i] = f'type=bind,src={home},dst=/review-user/.isabelle/Isabelle2026'
    cmd[-1] = '/review/' + str((stage / name).relative_to(ROOT))
    start = time.monotonic()
    with (output / 'check.log').open('w') as stream:
        try:
            result = subprocess.run(cmd, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
        finally:
            subprocess.run(['docker', 'rm', '-f', container], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=30)
    record = dict(name=name, status='pass' if code == 0 else 'fail', returncode=code,
                  elapsed_seconds=time.monotonic() - start, timeout_seconds=timeout,
                  source_sha256=hashlib.sha256(text.encode()).hexdigest(),
                  checked_sources={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in stage.glob('*.thy')},
                  log_sha256=hashlib.sha256((output / 'check.log').read_bytes()).hexdigest(),
                  directory=str(output.relative_to(ROOT)), model_calls=0, command=cmd,
                  old_dataset_writes=0, production_experiment_writes=0)
    save(output / 'result.json', record)
    return record


if __name__ == '__main__':
    names = [x['name'] for x in json.loads((ROOT / 'input/specs.json').read_text())['specs']]
    items = ','.join(json.dumps(x) for x in names + ['spec_0054'])
    source = '''theory Current_Declaration_Check
 imports Contracts
begin
ML \\<open>
 val targets = [NAMES];
 val facts = Facts.dest_static true [] (Global_Theory.facts_of \\<^theory>) |> map fst;
 val leaked = filter (fn n => member (op =) targets (Long_Name.base_name n)) facts;
 val _ = if null leaked then () else error "unproved target fact exported";
 writeln "CURRENT_DECLARATIONS_PASS entries=COUNT disabled=0054 target_facts=0";
\\<close>
end
'''.replace('NAMES', items).replace('COUNT', str(len(names)))
    result = check('Current_Declaration_Check', source)
    save(ROOT / 'validation/declarations.json', result)
    print(json.dumps(result), flush=True)
    raise SystemExit(result['returncode'])

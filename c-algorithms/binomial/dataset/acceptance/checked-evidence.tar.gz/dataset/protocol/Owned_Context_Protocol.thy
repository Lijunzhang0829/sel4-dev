theory Owned_Context_Protocol
 imports Repair_Phase_Model
 keywords "r2_capture" :: thy_decl
   and "r2_refute" "r2_prove" :: thy_goal
begin

ML \<open>
local
val trusted_axioms = map #1 (Thm.all_axioms_of \<^theory>);
val trusted_defs = Theory.defs_of \<^theory>;
type captured = {id: string, environment_id: string, environment: term list,
                 body: term, owned_parameters: (string * typ) list};
structure Captured = Theory_Data
(
  type T = captured option;
  val empty = NONE;
  fun merge (NONE, other) = other
    | merge (other, NONE) = other
    | merge (SOME (a: captured), SOME b) =
        if #id a = #id b andalso #body a aconv #body b andalso
            eq_list (op aconv) (#environment a, #environment b)
        then SOME a else NONE;
);

fun hol_prop (Const ("Pure.imp", _) $ a $ b) = HOLogic.mk_imp (hol_prop a, hol_prop b)
  | hol_prop (Const ("Pure.all", _) $ Abs (x, T, b)) = HOLogic.all_const T $ Abs (x, T, hol_prop b)
  | hol_prop (Const ("Pure.conjunction", _) $ a $ b) = HOLogic.mk_conj (hol_prop a, hol_prop b)
  | hol_prop (Const ("Pure.eq", _) $ a $ b) = HOLogic.mk_eq (a, b)
  | hol_prop (Const ("HOL.Trueprop", _) $ p) = p
  | hol_prop _ = error "R2 unsupported meta proposition";

fun hex_char c =
  let val digits = "0123456789abcdef"; val i = Char.ord c
  in String.implode [String.sub (digits, i div 16), String.sub (digits, i mod 16)] end;
fun hex s = String.translate hex_char s;
fun term_xml t = hex (YXML.string_of_body (Term_XML.Encode.term_raw t));
fun field name value = XML.Elem ((name, []), [XML.Text value]);
fun same_terms xs ys = length xs = length ys andalso forall (fn x => exists (fn y => x aconv y) ys) xs;
fun environment ctxt = map Thm.term_of (Assumption.all_assms_of ctxt);

val long_keyword = Parse_Spec.includes >> K "" || Parse_Spec.long_statement_keyword;
val long_statement =
  Scan.optional (Parse_Spec.opt_thm_name ":" --| Scan.ahead long_keyword) Binding.empty_atts --
  Scan.optional Parse_Spec.includes [] -- Parse_Spec.long_statement
    >> (fn ((binding, includes), (elems, concl)) => (true, binding, includes, elems, concl));
val short_statement = Parse_Spec.statement -- Parse_Spec.if_statement -- Parse.for_fixes
  >> (fn ((shows, assumes), fixes) =>
    (false, Binding.empty_atts, [], [Element.Fixes fixes, Element.Assumes assumes], Element.Shows shows));

fun read_body (_, _, includes, elems, concl) owned =
  let
    val _ = if null includes then () else error "R2 includes unsupported";
    val _ = (case concl of Element.Shows _ => () | _ => error "R2 obtains unsupported");
    val (statements, target) = Expression.read_statement elems concl owned;
    val goals = maps (map fst o snd) statements;
    (* Only declaration-local assumptions enter A. The incoming context is E. *)
    val own_assumptions = map Thm.term_of (Assumption.local_assms_of target owned);
    val proposition = Logic.list_implies (own_assumptions, Logic.mk_conjunction_list goals);
    val exported = proposition |> Assumption.export_term target owned
      |> singleton (Variable.export_terms target owned);
    val ([imported], _) = Variable.import_terms true [exported] owned;
    val frees = Term.add_frees imported [];
    val parameters = filter (Variable.is_fixed owned o fst) frees;
    val variables = filter_out (Variable.is_fixed owned o fst) frees;
    val body = fold_rev (fn v => fn t => Logic.all (Free v) t) variables imported;
    val _ = if null (Term.add_vars body []) then () else error "R2 unclosed contract variables";
    val _ = Thm.cterm_of owned body;
  in (body, parameters) end;

fun capture id environment_id spec owned =
  let
    val (body, parameters) = read_body spec owned;
    val item: captured = {id=id, environment_id=environment_id,
                            environment=environment owned, body=body, owned_parameters=parameters};
    val _ = writeln ("R2_CAPTURE " ^ hex id ^ " " ^ term_xml body);
    val observation = XML.Elem (("owned_target_capture", [("version", "3"), ("id", id)]),
      [field "environment_id" environment_id, field "contract_body_term" (term_xml body),
       XML.Elem (("environment", []), map (field "assumption" o term_xml) (environment owned))]);
    val _ = writeln ("R2_SCOPE_CAPTURE " ^ hex (XML.string_of observation));
  in Local_Theory.background_theory (Captured.put (SOME item)) owned end;

fun saved id owned =
  let
    val item = (case Captured.get (Proof_Context.theory_of owned) of SOME item => item | NONE => error "R2 capture required");
    val _ = if #id item = id then () else error "R2 target identity changed";
    val _ = if same_terms (#environment item) (environment owned) then ()
      else error "R2 owned environment changed after capture";
    val _ = if forall (Variable.is_fixed owned o fst) (#owned_parameters item) then ()
      else error "R2 owned parameters changed";
  in item end;

fun safe_definitions thy =
  Defs.dest_constdefs [trusted_defs] (Theory.defs_of thy) |> map #2;

fun audit id polarity results owned =
  let
    val item = saved id owned;
    val thms = flat results;
    val _ = if null thms then error "R2 no theorem" else ();
    val _ = Thm.consolidate thms;
    val _ = if Thm_Deps.has_skip_proof thms then error "R2 skip proof" else ();
    val _ = if null (Thm_Deps.all_oracles thms) then () else error "R2 oracle";
    val env = #environment item;
    val residual = maps Thm.hyps_of thms;
    val _ = if forall (fn h => exists (fn e => h aconv e) env) residual then ()
      else error "R2 contract premise leaked into owned environment";
    val thy = Proof_Context.theory_of owned;
    val allowed = trusted_axioms @ safe_definitions thy;
    val _ = if forall (member (op =) allowed) (map #1 (Thm.all_axioms_of thy)) then ()
      else error "R2 nondefinitional axiom introduced";
    val body = #body item;
    val negative = HOLogic.mk_Trueprop (HOLogic.mk_not (hol_prop body));
    val _ = if polarity <> "relative-negative" then () else
      (case thms of [thm] => if Thm.full_prop_of thm aconv negative orelse
          Thm.full_prop_of thm aconv Logic.varify_global negative then ()
        else error "R2 theorem differs from mechanical negative goal"
      | _ => error "R2 expected one negative theorem");
    val receipt = XML.Elem (("owned_context_certificate", [("version", "3"), ("id", id)]),
      [field "polarity" polarity, field "scope" "owned-context",
       field "environment_id" (#environment_id item),
       field "contract_body_term" (term_xml body), field "negative_goal_term" (term_xml negative),
       XML.Elem (("environment", []), map (field "assumption" o term_xml) env),
       XML.Elem (("proved", []), map (field "proposition" o term_xml o Thm.full_prop_of) thms),
       XML.Elem (("residual_hypotheses", []), map (field "hypothesis" o term_xml) residual),
       field "skip_proof" "false", field "oracles" "0", field "hypotheses_within_environment" "true",
       field "axioms_safe" "true", field "environment_global_truth_established_by_certificate" "false"]);
    val _ = writeln ("R2_CERTIFICATE " ^ hex (XML.string_of receipt));
  in owned end;

fun positive id (spec as (long, binding, includes, elems, concl)) owned =
  let
    val item = saved id owned;
    val (body, _) = read_body spec owned;
    val _ = if body aconv #body item then () else error "R2 positive declaration differs from capture";
  in Specification.theorem_cmd {verbose=false, long=long, kind=Thm.theoremK} NONE
       (audit id "positive") binding includes elems concl owned end;

fun negative id binding owned =
  let
    val item = saved id owned;
    val goal = HOLogic.mk_Trueprop (HOLogic.mk_not (hol_prop (#body item)));
  in Specification.theorem {verbose=false, long=false, kind=Thm.theoremK} NONE
       (audit id "relative-negative") (binding, []) [] []
       (Element.Shows [(Binding.empty_atts, [(goal, [])])]) owned end;

val _ = Outer_Syntax.local_theory \<^command_keyword>\<open>r2_capture\<close>
  "capture A and Q relative to the fixed owned environment E"
  (Parse.name -- Parse.name -- (long_statement || short_statement)
    >> (fn ((id, env), spec) => capture id env spec));
val _ = Outer_Syntax.local_theory_to_proof \<^command_keyword>\<open>r2_refute\<close>
  "prove the mechanically constructed counterexample within the same owned context"
  (Parse.name -- Parse.binding >> (fn (id, name) => negative id name));
val _ = Outer_Syntax.local_theory_to_proof \<^command_keyword>\<open>r2_prove\<close>
  "prove a frozen positive declaration in its fixed owned context"
  (Parse.name -- (long_statement || short_statement) >> (fn (id, spec) => positive id spec));
in end
\<close>
end

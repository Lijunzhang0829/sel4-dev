theory Protocol_Good imports Owned_Context_Protocol begin
locale r2_fixture_environment = fixes n :: nat assumes positive_n: "0 < n"
context r2_fixture_environment begin
r2_capture "relative" "fixture-n" captured:
 "(x::nat) = n \<Longrightarrow> n < x"
r2_refute "relative" relative_negative
 by auto

r2_capture "positive" "fixture-n" captured:
 "n \<le> (x::nat) \<Longrightarrow> 0 < x"
r2_prove "positive" positive_result:
 "n \<le> (x::nat) \<Longrightarrow> 0 < x"
 using positive_n by linarith
end

r2_capture "long" "global" captured:
 assumes input: "x = (0::nat)" shows "x = 1"
r2_refute "long" long_negative
 by auto
end

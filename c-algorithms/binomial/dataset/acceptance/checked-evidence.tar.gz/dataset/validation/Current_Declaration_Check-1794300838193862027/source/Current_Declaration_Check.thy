theory Current_Declaration_Check
 imports Contracts
begin
ML \<open>
 val targets = ["spec_0001","spec_0002","spec_0003","spec_0004","spec_0005","spec_0006","spec_0007","spec_0008","spec_0009","spec_0010","spec_0011","spec_0012","spec_0013","spec_0014","spec_0015","spec_0016","spec_0017","spec_0018","spec_0019","spec_0020","spec_0021","spec_0022","spec_0023","spec_0024","spec_0025","spec_0026","spec_0027","spec_0028","spec_0029","spec_0030","spec_0031","spec_0032","spec_0033","spec_0034","spec_0035","spec_0036","spec_0037","spec_0038","spec_0039","spec_0040","spec_0041","spec_0042","spec_0043","spec_0044","spec_0045","spec_0046","spec_0047","spec_0048","spec_0049","spec_0050","spec_0051","spec_0052","spec_0053","spec_0055","spec_0056","spec_0057","spec_0058","spec_0059","spec_0060","spec_0061","spec_0062","spec_0063","spec_0064","spec_0065","spec_0066","spec_0067","spec_0068","spec_0069","spec_0070","spec_0071","spec_0072","spec_0073","spec_0074","spec_0075","spec_0076","spec_0077","spec_0078","spec_0079","spec_0080","spec_0081","spec_0082","spec_0083","spec_0084","spec_0085","spec_0086","spec_0087","spec_0088","spec_0089","spec_0090","spec_0091","spec_0092","spec_0093","spec_0094","spec_0095","spec_0096","spec_0097","spec_0098","spec_0099","spec_0100","spec_0101","spec_0054"];
 val facts = Facts.dest_static true [] (Global_Theory.facts_of \<^theory>) |> map fst;
 val leaked = filter (fn n => member (op =) targets (Long_Name.base_name n)) facts;
 val _ = if null leaked then () else error "unproved target fact exported";
 writeln "CURRENT_DECLARATIONS_PASS entries=100 disabled=0054 target_facts=0";
\<close>
end

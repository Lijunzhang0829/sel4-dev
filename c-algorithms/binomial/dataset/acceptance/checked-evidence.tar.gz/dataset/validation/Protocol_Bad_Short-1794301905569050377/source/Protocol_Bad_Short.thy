theory Protocol_Bad_Short imports Owned_Context_Protocol begin
r2_capture "tautology" "global" captured: "False \<Longrightarrow> False"
r2_refute "tautology" invalid_negative by simp
end

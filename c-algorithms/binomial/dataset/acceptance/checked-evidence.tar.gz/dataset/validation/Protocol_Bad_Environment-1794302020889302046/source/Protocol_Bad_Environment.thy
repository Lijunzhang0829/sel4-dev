theory Protocol_Bad_Environment imports Owned_Context_Protocol begin
r2_capture "tautology" "global" captured: "False \<Longrightarrow> False"
context assumes injected_contract_premise: False begin
r2_refute "tautology" invalid_negative by simp
end
end

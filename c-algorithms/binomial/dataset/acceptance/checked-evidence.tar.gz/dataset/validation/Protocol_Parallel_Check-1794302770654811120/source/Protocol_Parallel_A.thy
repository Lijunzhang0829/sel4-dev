theory Protocol_Parallel_A imports Owned_Context_Protocol begin
locale env_A = fixes n :: nat assumes positive_n: "0<n"
context env_A begin
r2_capture "capture-A" "env-A" captured:
 "(x::nat)=n \<Longrightarrow> n<x"
ML \<open>Time.sleep (Time.fromMilliseconds 600);\<close>
r2_refute "capture-A" accepted_A by auto
end
end

theory Protocol_Parallel_Check
imports Protocol_Parallel_A Protocol_Parallel_B
begin
ML \<open>
 val facts = @{thms env_A.accepted_A env_B.accepted_B};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "PARALLEL_PROTOCOL_TARGETS_PASS";
\<close>
end

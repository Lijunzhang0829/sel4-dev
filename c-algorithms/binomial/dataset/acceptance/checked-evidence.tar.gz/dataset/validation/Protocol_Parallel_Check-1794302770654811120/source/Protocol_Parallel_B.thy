theory Protocol_Parallel_B imports Owned_Context_Protocol begin
locale env_B = fixes n :: nat assumes positive_n: "0<n"
context env_B begin
r2_capture "capture-B" "env-B" captured:
 "(x::nat)=n \<Longrightarrow> n<x"
ML \<open>Time.sleep (Time.fromMilliseconds 600);\<close>
r2_refute "capture-B" accepted_B by auto
end
end

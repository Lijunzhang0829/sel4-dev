theory Protocol_Bad_Long imports Owned_Context_Protocol begin
r2_capture "tautology" "global" captured:
 assumes contract_premise: "False" shows "False"
r2_refute "tautology" invalid_negative by simp
end

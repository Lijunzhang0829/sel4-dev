theory Protocol_Bad_Positive imports Owned_Context_Protocol begin
r2_capture "frozen" "global" captured: "False"
r2_prove "frozen" different_statement: "True" by simp
end

theory Environment_And_C_Bridges
 imports Environment_Parameters Revised_Ownership_Model
begin
lemma r2_address_configuration_iff:
  "binomial_heap_input_global_addresses \<longleftrightarrow>
   r2_address_configuration [binomial_heap_input.free, binomial_heap_input.calloc, binomial_heap_input.malloc, binomial_heap_input.memcpy, binomial_heap_input.int_equal, binomial_heap_input.int_compare, binomial_heap_input.init'globals, binomial_heap_input.binomial_heap_cmp, binomial_heap_input.binomial_heap_new, binomial_heap_input.binomial_tree_unref, binomial_heap_input.binomial_heap_merge_undo, binomial_heap_input.binomial_tree_ref, binomial_heap_input.binomial_tree_merge, binomial_heap_input.binomial_heap_merge, binomial_heap_input.binomial_heap_pop, binomial_heap_input.calg_binomial_new, binomial_heap_input.binomial_heap_free, binomial_heap_input.binomial_heap_insert, binomial_heap_input.binomial_heap_num_entries] Binomial_Heap_C.\<G> Binomial_Heap_C.\<S>"
  by (simp add: binomial_heap_input_global_addresses_def r2_address_configuration_def)

lemma r2_address_configuration_possible:
  "\<exists>fs. r2_address_configuration fs {} audit_stack_addresses"
  apply (rule exI[where x="[Ptr 1, Ptr 2, Ptr 3, Ptr 4, Ptr 5, Ptr 6, Ptr 7, Ptr 8, Ptr 9, Ptr 10, Ptr 11, Ptr 12, Ptr 13, Ptr 14, Ptr 15, Ptr 16, Ptr 17, Ptr 18, Ptr 19]"])
  by (simp add: r2_address_configuration_def c_fnptr_guard_def)

lemma r2_address_configuration_null:
  "\<not>r2_address_configuration (replicate 19 NULL) {} audit_stack_addresses"
  by (simp add: r2_address_configuration_def c_fnptr_guard_def)



lemma reviewed_environment_equation:
 "Calg_Binomial_Reviewed_Stack \<longleftrightarrow>
  binomial_heap_input_global_addresses \<and> Binomial_Heap_C.\<S> = audit_stack_addresses"
 by (simp add: Calg_Binomial_Reviewed_Stack_def Calg_Binomial_Reviewed_Stack_axioms_def)

context binomial_heap_input_global_addresses begin
lemma r2_actual_insert_fragment:
 "binomial_heap_insert' h v = bn_ds_insert_with_finish h v"
 by (simp add: binomial_heap_insert'_def bn_ds_insert_with_finish_def bn_ds_insert_finish_def)

lemma r2_actual_pop_fragment:
 "binomial_heap_pop' h = bn_ds_pop_with_finishes h"
 by (simp add: binomial_heap_pop'_def bn_ds_pop_with_finishes_def bn_ds_pop_success_def bn_ds_pop_restore_def)

lemma r2_actual_merge_fragment:
 "binomial_heap_merge' h other = bn_ds_binomial_heap_merge_expanded h other"
 by (simp add: binomial_heap_merge'_def bn_ds_binomial_heap_merge_expanded_def bn_ds_carry_loop_def)
end

ML \<open>
 val facts = @{thms r2_address_configuration_iff r2_address_configuration_possible
   r2_address_configuration_null reviewed_environment_equation
   binomial_heap_input_global_addresses.r2_actual_insert_fragment
   binomial_heap_input_global_addresses.r2_actual_pop_fragment
   binomial_heap_input_global_addresses.r2_actual_merge_fragment};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "ENVIRONMENT_AND_C_BINDINGS_PASS";
\<close>
end

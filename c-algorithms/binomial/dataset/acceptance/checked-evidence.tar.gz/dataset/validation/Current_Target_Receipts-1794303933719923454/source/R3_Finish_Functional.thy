theory R3_Finish_Functional imports Repair_Phase_Model R3_Finish_Representation begin
context binomial_heap_input_global_addresses begin
lemma r3_release_array:
  fixes p :: "'a::mem_type ptr"
  assumes A: "allocator_wf (phantom_machine_state_' s)"
    and R: "vero_aux_release s D W t"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some n"
    and NW: "ptr_val p\<notin>W" and K: "size_of TYPE('a) * k \<le> n" and I: "i<k"
  shows "h_val (hrs_mem (t_hrs_' t)) (p +\<^sub>p int i) = h_val (hrs_mem (t_hrs_' s)) (p +\<^sub>p int i)"
proof -
  have SP: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n" by (rule c0008_prove[OF A L K I])
  have BF: "\<forall>x\<in>block_bytes (ptr_val p) n. hrs_mem (t_hrs_' t) x = hrs_mem (t_hrs_' s) x"
    using R L NW unfolding vero_aux_release_def by blast
  show ?thesis apply (rule vero_aux_stack_h_val_agree) using SP BF by blast
qed


lemma r3_release_key:
  assumes R: "vero_aux_release s D W t" and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and PAY: "bn_payload P v"
  shows "bn_key t v = bn_key s v"
proof -
  let ?p = "ptr_coerce v :: 32 signed word ptr"
  have G: "c_guard ?p" and B: "block_bytes (ptr_val ?p) 4 \<subseteq> P" using PAY by (auto simp: bn_payload_def)
  have SP: "ptr_span ?p \<subseteq> P"
    using B intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]] by (simp add: block_bytes_def)
  have H: "h_val (hrs_mem (t_hrs_' t)) ?p = h_val (hrs_mem (t_hrs_' s)) ?p"
    apply (rule vero_aux_stack_h_val_agree) using R PS SP unfolding vero_aux_release_def by blast
  show ?thesis by (simp only: bn_key_def H)
qed


lemma r3_forest_blocks:
 assumes L: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_ds_tree_layout s P T"
 shows "bn_ds_graph_blocks s (bn_ds_forest_nodes F) = set (concat (map (case_option [] (bn_blocks s)) F))"
 using vero_aux_forest_blocks[OF L]
 by (simp only: bn_ds_graph_blocks_def bn_ds_forest_nodes_def vero_aux_node_block_set)

lemma r3_extra_leaf_not_block:
 assumes G: "bn_ds_graph s P N edges slots held {}" and ST: "bn_ds_graph_storage s N slots"
 and PN: "p\<in>N" and NF: "p\<notin>bn_ds_forest_nodes F"
 and SUB: "bn_ds_forest_nodes F\<subseteq>N"
 shows "ptr_val p\<notin>bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
proof -
 have INJ: "ptr_val x=ptr_val p \<Longrightarrow> x=p" for x
  by (cases x; cases p) (simp add: ptr_val_def)
 have NODECASE: "ptr_val p\<notin>ptr_val ` bn_ds_forest_nodes F"
  using NF INJ by auto
 have CHILDCASE: "ptr_val p\<notin>{ptr_val (subtrees_C (bn_tree s q)) |q.
   q\<in>bn_ds_forest_nodes F \<and> order_C (bn_tree s q)\<noteq>0}"
 proof
  assume IN: "ptr_val p\<in>{ptr_val (subtrees_C (bn_tree s q)) |q.
   q\<in>bn_ds_forest_nodes F \<and> order_C (bn_tree s q)\<noteq>0}"
  obtain q where QF: "q\<in>bn_ds_forest_nodes F" and NZ: "order_C (bn_tree s q)\<noteq>0"
   and EQ: "ptr_val p=ptr_val (subtrees_C (bn_tree s q))" using IN by blast
  have QN: "q\<in>N" using QF SUB by blast
  have OUT: "ptr_val (subtrees_C (bn_tree s q))\<notin>ptr_val ` N"
   using ST QN NZ by (auto simp: bn_ds_graph_storage_def)
  have MEM: "ptr_val p\<in>ptr_val ` N" using PN by auto
  show False using MEM OUT EQ by simp
 qed
 show ?thesis using NODECASE CHILDCASE by (auto simp: bn_ds_graph_blocks_def)

qed

lemma r3_finish_functional:
 assumes FB: "bn_r2_finish_base s h P F N edges [slot] {#}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot=p"
 and LEAF: "bn_ds_tree_layout s P (BN p [])"
 and VALUE: "value_C (bn_tree s p)=v"
 and NUM: "unat (num_values_C (bn_heap s h))=size M"
 and BOUND: "size M+1<2^32"
 and MASS: "mset (bn_forest_values s F)=(if result=0 then M else add_mset v M)"
 and EFFECT: "if refcount_C (bn_tree s p)=1 then
   vero_aux_release (r2_dec (r3_count s h result) p) {ptr_val p} {ptr_val p} t
   else t=r2_dec (r3_count s h result) p"
 shows "bn_rep t h P F (if result=0 then M else add_mset v M) \<and> bn_owned t h F=bn_owned s h F"
proof -
 let ?nodes="bn_ds_forest_nodes F"
 let ?a="roots_C (bn_heap s h)"
 let ?slots="bn_ds_slots ?a (length F) @ [slot]"
 let ?D="if refcount_C (bn_tree s p)=1 then {ptr_val p} else {}"
 let ?W="{ptr_val h,ptr_val p}"
 let ?B="set (concat (map (case_option [] (bn_blocks s)) F))"
 have FV: "bn_ds_forest_view s h P F"
  and GR: "bn_ds_graph s P N edges ?slots {#} {}"
  and ST: "bn_ds_graph_storage s N ?slots"
  and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
  and HB: "ptr_val h\<notin>bn_ds_graph_blocks s N"
  and AB: "ptr_val ?a\<notin>bn_ds_graph_blocks s N"
  and OW: "distinct (bn_owned s h F)"
  using FB by (auto simp: bn_r2_finish_base_def bn_r2_graph_storage_def)
 have W: "allocator_wf (phantom_machine_state_' s)" and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
  using GR by (auto simp: bn_ds_graph_def)
 have GH: "c_guard h" using FV by (simp add: bn_ds_forest_view_def bn_review_header_view_def)
 have GP: "c_guard p" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
  using LEAF by auto
 have INVENT: "N=insert p ?nodes \<and> (\<forall>q\<in>N. unat (refcount_C (bn_tree s q)) =
  (if q\<in>?nodes then 1 else 0)+(if q=p then 1 else 0))"
  by (rule r2_finish_leaf_inventory[OF FB READ LEAF])
 have PN: "p\<in>N" and SUB: "?nodes\<subseteq>N" using INVENT by auto
 have PI: "ptr_val p\<in>ptr_val ` N" by (rule imageI[OF PN])
 have PB: "ptr_val p\<in>bn_ds_graph_blocks s N" using PI by (simp add: bn_ds_graph_blocks_def)
 have PH: "ptr_val p\<noteq>ptr_val h" and PA: "ptr_val p\<noteq>ptr_val ?a"
  using HB AB PB by auto
 have EFFECTS: "vero_aux_release s ?D ?W t \<and>
  bn_heap t h=(bn_heap s h)\<lparr>num_values_C:=(if result=0 then num_values_C (bn_heap s h) else num_values_C (bn_heap s h)+1)\<rparr>"
  by (rule r3_finish_effects[OF W GH GP LH LP PH EFFECT])
 have RELEASE: "vero_aux_release s ?D ?W t" and HEADER: "bn_heap t h=(bn_heap s h)\<lparr>num_values_C:=(if result=0 then num_values_C (bn_heap s h) else num_values_C (bn_heap s h)+1)\<rparr>"
  using EFFECTS by blast+
 have L: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_ds_tree_layout s P T"
  using FV by (auto simp: bn_ds_forest_view_def in_set_conv_nth)
 have GB: "bn_ds_graph_blocks s ?nodes=?B" by (rule r3_forest_blocks[OF L])
 have POUT: "p\<notin>?nodes \<Longrightarrow> ptr_val p\<notin>?B"
  using r3_extra_leaf_not_block[OF GR ST PN _ SUB] by (simp add: GB)
 have ALLOC: "\<forall>b\<in>?B. live_blocks (phantom_machine_state_' t) b=live_blocks (phantom_machine_state_' s) b"
 proof (cases "p\<in>?nodes")
  case True
  have RC: "unat (refcount_C (bn_tree s p))=2" using INVENT True by auto
  have NE: "refcount_C (bn_tree s p)\<noteq>1" using RC by auto
  show ?thesis using RELEASE NE by (auto simp: vero_aux_release_def)
 next
  case False
  then show ?thesis using RELEASE POUT by (auto simp: vero_aux_release_def)
 qed
 have NODE: "\<forall>q\<in>?nodes. value_C (bn_tree t q)=value_C (bn_tree s q) \<and>
  order_C (bn_tree t q)=order_C (bn_tree s q) \<and> subtrees_C (bn_tree t q)=subtrees_C (bn_tree s q) \<and>
  refcount_C (bn_tree t q)=1"
 proof (intro ballI)
  fix q assume QF: "q\<in>?nodes"
  have QN: "q\<in>N" using QF SUB by blast
  show "value_C (bn_tree t q)=value_C (bn_tree s q) \<and>
   order_C (bn_tree t q)=order_C (bn_tree s q) \<and> subtrees_C (bn_tree t q)=subtrees_C (bn_tree s q) \<and>
   refcount_C (bn_tree t q)=1"
  proof (cases "q=p")
   case True
   have RC: "unat (refcount_C (bn_tree s p))=2" using INVENT QF True by auto
   have TWO: "refcount_C (bn_tree s p)=(2::16 word)"
    using arg_cong[OF RC, where f="\<lambda>n. of_nat n :: 16 word"] by simp
   have T: "t=r2_dec (r3_count s h result) p" using EFFECT TWO by simp
   have U: "bn_tree (r3_count s h result) p=bn_tree s p" by (rule r3_count_node[OF W GH GP LH LP PH])
   show ?thesis by (simp add: True T r2_dec_fields[OF GP] U TWO)
  next
   case False
   have QG: "c_guard q" and QL: "live_blocks (phantom_machine_state_' s) (ptr_val q)=Some 24"
    using GR QN by (auto simp: bn_ds_graph_def)
   have QB: "ptr_val q\<in>bn_ds_graph_blocks s N"
    using imageI[OF QN, where f=ptr_val] by (auto simp: bn_ds_graph_blocks_def)
   have QH: "ptr_val q\<noteq>ptr_val h" using HB QB by auto
   have QP: "ptr_val q\<noteq>ptr_val p" using False by (cases q; cases p) (auto simp: ptr_val_def)
   have HQ: "bn_tree t q=bn_tree s q"
    unfolding bn_tree_def apply (rule r3_release_read[OF RELEASE QG QL]) using QH QP by auto
   have URC: "unat (refcount_C (bn_tree s q))=1" using INVENT QF QN False by auto
   have RC: "refcount_C (bn_tree s q)=1"
    using arg_cong[OF URC, where f="\<lambda>n. of_nat n :: 16 word"] by simp
   show ?thesis using HQ RC by simp
  qed
 qed
 have CHILD: "\<forall>q\<in>?nodes. \<forall>i<unat (order_C (bn_tree s q)).
  h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s q) +\<^sub>p int i)=
  h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s q) +\<^sub>p int i)"
 proof (intro ballI allI impI)
  fix q i assume QF: "q\<in>?nodes" and I: "i<unat (order_C (bn_tree s q))"
  have QN: "q\<in>N" using QF SUB by blast
  have NZ: "order_C (bn_tree s q)\<noteq>0" using I by auto
  have ORD: "unat (order_C (bn_tree s q))=length (edges q)"
   using GR QN unfolding bn_ds_graph_def by blast
  have AR: "if edges q=[] then subtrees_C (bn_tree s q)=NULL else
   c_guard (subtrees_C (bn_tree s q)) \<and>
   live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s q))) =
    Some (size_of TYPE(StrictC'_BinomialTree_C ptr)*length (edges q))"
   using GR QN unfolding bn_ds_graph_def by blast
  have NE: "edges q\<noteq>[]" using ORD I by auto
  have LIVE: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s q))) = Some (size_of TYPE(StrictC'_BinomialTree_C ptr)*unat (order_C (bn_tree s q)))"
   using AR NE ORD by simp
  have AH: "ptr_val (subtrees_C (bn_tree s q))\<noteq>ptr_val h"
   proof -
   have CB: "ptr_val (subtrees_C (bn_tree s q))\<in>bn_ds_graph_blocks s N"
    unfolding bn_ds_graph_blocks_def using QN NZ by blast
   show ?thesis using CB HB by auto
  qed
  have AP: "ptr_val (subtrees_C (bn_tree s q))\<noteq>ptr_val p"
   proof -
   have OUT: "ptr_val (subtrees_C (bn_tree s q))\<notin>ptr_val ` N"
    using ST QN NZ by (auto simp: bn_ds_graph_storage_def)
   show ?thesis using OUT PI by auto
  qed
  show "h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s q) +\<^sub>p int i)=h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s q) +\<^sub>p int i)"
   apply (rule r3_release_array[OF W RELEASE LIVE]) using AH AP I by auto
 qed
 have KEY: "\<forall>x. bn_payload P x \<longrightarrow> bn_key t x=bn_key s x"
  using r3_release_key[OF RELEASE PS] by blast
 have LAYOUT: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_ds_tree_layout t P T \<and>
    bn_values t T=bn_values s T \<and> bn_blocks t T=bn_blocks s T"
 proof (intro allI impI)
  fix T assume TF: "Some T\<in>set F"
  have LT: "bn_ds_tree_layout s P T" using TF L by blast
  have NS: "set (bn_ds_node_list T)\<subseteq>?nodes"
   using TF by (auto simp: vero_aux_forest_node_member)
  have BS: "set (bn_blocks s T)\<subseteq>?B" using TF by auto
  have AT: "\<forall>b\<in>set (bn_blocks s T). live_blocks (phantom_machine_state_' t) b=live_blocks (phantom_machine_state_' s) b"
   using ALLOC BS by blast
  have NT: "\<forall>q\<in>set (bn_ds_node_list T). value_C (bn_tree t q)=value_C (bn_tree s q) \<and>
   order_C (bn_tree t q)=order_C (bn_tree s q) \<and> subtrees_C (bn_tree t q)=subtrees_C (bn_tree s q)"
   using NODE NS by blast
  have CT: "\<forall>q\<in>set (bn_ds_node_list T). \<forall>i<unat (order_C (bn_tree s q)).
   h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s q) +\<^sub>p int i)=h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s q) +\<^sub>p int i)"
   using CHILD NS by blast
  show "bn_ds_tree_layout t P T \<and> bn_values t T=bn_values s T \<and> bn_blocks t T=bn_blocks s T"
   by (rule r2_layout_mod_refs[OF LT AT NT CT KEY])
 qed
 have VALID: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_valid t P T"
 proof (intro allI impI)
  fix T assume TF: "Some T\<in>set F"
  have LT: "bn_ds_tree_layout t P T" using LAYOUT TF by blast
  show "bn_valid t P T" apply (rule vero_aux_layout_valid_refs[OF LT])
   using NODE TF by (auto simp: vero_aux_forest_node_member)
 qed
 have ROOTDATA: "\<forall>i<length F. h_val (hrs_mem (t_hrs_' t)) (?a +\<^sub>p int i)=h_val (hrs_mem (t_hrs_' s)) (?a +\<^sub>p int i)"
 proof (intro allI impI)
  fix i assume I: "i<length F"
  have AN: "?a\<noteq>NULL" using FV I
   by (cases F) (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def dest: c_guard_NULL)
  obtain m where LIVE: "live_blocks (phantom_machine_state_' s) (ptr_val ?a)=Some m"
   and SIZE: "8*length F\<le>m" using FB AN by (auto simp: bn_r2_finish_base_def bn_ds_owned_array_def)
  have AH: "ptr_val ?a\<noteq>ptr_val h" using OW AN by (auto simp: bn_owned_def)
  show "h_val (hrs_mem (t_hrs_' t)) (?a +\<^sub>p int i)=h_val (hrs_mem (t_hrs_' s)) (?a +\<^sub>p int i)"
   apply (rule r3_release_array[OF W RELEASE LIVE]) using AH PA SIZE I by auto
 qed
 have VM: "map (case_option [] (bn_values t)) F=map (case_option [] (bn_values s)) F"
 proof (rule map_cong)
  show "F=F" by simp
  fix x assume X: "x\<in>set F"
  show "case_option [] (bn_values t) x=case_option [] (bn_values s) x"
   using LAYOUT X by (cases x) auto
 qed
 have BM: "map (case_option [] (bn_blocks t)) F=map (case_option [] (bn_blocks s)) F"
 proof (rule map_cong)
  show "F=F" by simp
  fix x assume X: "x\<in>set F"
  show "case_option [] (bn_blocks t) x=case_option [] (bn_blocks s) x"
   using LAYOUT X by (cases x) auto
 qed
 have VALUES: "bn_forest_values t F=bn_forest_values s F"
  by (simp only: bn_forest_values_def VM)
 have BLOCKS: "bn_owned t h F=bn_owned s h F"
  by (simp add: bn_owned_def HEADER BM)
 have NUMT: "unat (num_values_C (bn_heap t h))=size (if result=0 then M else add_mset v M)"
  using HEADER NUM BOUND by (cases "result=0") (simp_all add: unat_word_ariths)
 have WT: "allocator_wf (phantom_machine_state_' t)" and PST: "P\<subseteq>reserved_bytes (phantom_machine_state_' t)"
  using RELEASE PS by (auto simp: vero_aux_release_def)
 have LHT: "live_blocks (phantom_machine_state_' t) (ptr_val h)=Some 40"
  using RELEASE LH PH by (auto simp: vero_aux_release_def)
 have HF: "heap_type_C (bn_heap t h)=BINOMIAL_HEAP_TYPE_MIN \<and>
  compare_func_C (bn_heap t h)=binomial_heap_input.int_compare \<and>
  unat (roots_length_C (bn_heap t h))=length F \<and> length F\<le>32"
  using FV HEADER by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
 have RA: "if roots_C (bn_heap t h)=NULL then F=[] else
  c_guard (roots_C (bn_heap t h)) \<and>
  (\<exists>n. live_blocks (phantom_machine_state_' t) (ptr_val (roots_C (bn_heap t h)))=Some n \<and>
   size_of TYPE(StrictC'_BinomialTree_C ptr)*length F\<le>n)"
 proof (cases "?a=NULL")
  case True
  have FE: "F=[]" using FV True by (cases F)
   (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def dest: c_guard_NULL)
  show ?thesis using HEADER True FE by simp
 next
  case False
  have OA: "bn_ds_owned_array s ?a (length F)" using FB False by (simp add: bn_r2_finish_base_def)
  show ?thesis using OA False HEADER RELEASE PA
   by (auto simp: bn_ds_owned_array_def vero_aux_release_def)
 qed
 have RV: "\<forall>i<length F. c_guard (roots_C (bn_heap t h)+\<^sub>p int i) \<and>
  h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h)+\<^sub>p int i)=case_option NULL bn_root (F!i) \<and>
  (case F!i of None\<Rightarrow>True | Some T\<Rightarrow>bn_rank T=i \<and> bn_valid t P T)"
 proof (intro allI impI)
  fix i assume I: "i<length F"
  have G: "c_guard (?a+\<^sub>p int i)"
   and V: "h_val (hrs_mem (t_hrs_' s)) (?a+\<^sub>p int i)=case_option NULL bn_root (F!i)"
   and RK: "case F!i of None\<Rightarrow>True | Some T\<Rightarrow>bn_rank T=i"
   using FV I by (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def split: option.splits)
  have TV: "case F!i of None\<Rightarrow>True | Some T\<Rightarrow>bn_valid t P T"
   using VALID nth_mem[OF I] by (cases "F!i") auto
  show "c_guard (roots_C (bn_heap t h)+\<^sub>p int i) \<and>
   h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h)+\<^sub>p int i)=case_option NULL bn_root (F!i) \<and>
   (case F!i of None\<Rightarrow>True | Some T\<Rightarrow>bn_rank T=i \<and> bn_valid t P T)"
   using G V RK TV ROOTDATA I HEADER by (auto split: option.splits)
 qed
 show ?thesis using WT PST GH LHT HF RA RV OW BLOCKS VALUES MASS NUMT
  by (auto simp: bn_rep_def split: if_splits)
qed

end
end

theory R3_Finish_Representation imports Repair_Phase_Model R3_Insert_Execution R2_Finish_Effects begin
context binomial_heap_input_global_addresses begin

lemma r3_release_refl:
 "allocator_wf (phantom_machine_state_' s) \<Longrightarrow> vero_aux_release s {} {} s"
 by (simp add: vero_aux_release_def)

lemma r3_release_compose:
 assumes A: "vero_aux_release s D W u" and B: "vero_aux_release u E V t" and SUB: "D\<subseteq>W"
 shows "vero_aux_release s (D\<union>E) (W\<union>V) t"
proof -
 have META: "allocator_wf (phantom_machine_state_' t) \<and>
  reserved_bytes (phantom_machine_state_' t)=reserved_bytes (phantom_machine_state_' s) \<and>
  hrs_htd (t_hrs_' t)=hrs_htd (t_hrs_' s) \<and>
  (\<forall>q. live_blocks (phantom_machine_state_' t) q =
    (if q\<in>D\<union>E then None else live_blocks (phantom_machine_state_' s) q))"
  using A B by (auto simp: vero_aux_release_def)
 have RES: "\<forall>x\<in>reserved_bytes (phantom_machine_state_' s).
  hrs_mem (t_hrs_' t) x=hrs_mem (t_hrs_' s) x"
  using A B by (auto simp: vero_aux_release_def)
 have OTHER: "\<forall>q n. live_blocks (phantom_machine_state_' s) q=Some n \<longrightarrow>
  q\<notin>W\<union>V \<longrightarrow> (\<forall>x\<in>block_bytes q n. hrs_mem (t_hrs_' t) x=hrs_mem (t_hrs_' s) x)"
 proof (intro allI impI ballI)
  fix q n x assume LIVE: "live_blocks (phantom_machine_state_' s) q=Some n"
   and OUT: "q\<notin>W\<union>V" and X: "x\<in>block_bytes q n"
  have NOTD: "q\<notin>D" using OUT SUB by blast
  have LU: "live_blocks (phantom_machine_state_' u) q=Some n"
   using A LIVE NOTD by (auto simp: vero_aux_release_def)
  have ONE: "hrs_mem (t_hrs_' u) x=hrs_mem (t_hrs_' s) x"
   using A LIVE OUT X by (auto simp: vero_aux_release_def)
  have TWO: "hrs_mem (t_hrs_' t) x=hrs_mem (t_hrs_' u) x"
   using B LU OUT X by (auto simp: vero_aux_release_def)
  show "hrs_mem (t_hrs_' t) x=hrs_mem (t_hrs_' s) x" using ONE TWO by simp
 qed
 show ?thesis using META RES OTHER by (simp add: vero_aux_release_def)
qed

lemma r3_release_read:
 fixes q :: "'a::mem_type ptr"
 assumes R: "vero_aux_release s D W t" and G: "c_guard q"
 and LIVE: "live_blocks (phantom_machine_state_' s) (ptr_val q)=Some n"
 and SIZE: "size_of TYPE('a)\<le>n" and OUT: "ptr_val q\<notin>W"
 shows "h_val (hrs_mem (t_hrs_' t)) q = h_val (hrs_mem (t_hrs_' s)) q"
proof -
 have FRAME: "\<forall>a\<in>block_bytes (ptr_val q) n. hrs_mem (t_hrs_' t) a=hrs_mem (t_hrs_' s) a"
  using R LIVE OUT by (auto simp: vero_aux_release_def)
 have SP: "ptr_span q = block_bytes (ptr_val q) (size_of TYPE('a))"
  by (rule vero_aux_span_block[OF G])
 show ?thesis apply (rule vero_aux_stack_h_val_agree)
  using FRAME SIZE SP by (auto simp: block_bytes_def)
qed

lemma r3_update_release:
 fixes p :: "'a::mem_type ptr"
 assumes W: "allocator_wf (phantom_machine_state_' s)" and G: "c_guard p"
 and LIVE: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some (size_of TYPE('a))"
 shows "vero_aux_release s {} {ptr_val p}
  (t_hrs_'_update (hrs_mem_update (heap_update p v)) s)"
proof -
 have FRAME: "bytes_frame (block_bytes (ptr_val p) (size_of TYPE('a)))
   (hrs_mem (t_hrs_' s)) (heap_update p v (hrs_mem (t_hrs_' s)))"
  by (rule vero_aux_update_frame[OF G])
 show ?thesis using W LIVE FRAME
  by (auto simp: vero_aux_release_def hrs_mem_update_def hrs_mem_def hrs_htd_def
    case_prod_unfold allocator_wf_def bytes_frame_def; blast)
qed

lemma r3_count_release:
 assumes W: "allocator_wf (phantom_machine_state_' s)" and G: "c_guard h"
 and LIVE: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 shows "vero_aux_release s {} {ptr_val h} (r3_count s h result)"
proof (cases "result=0")
 case True
 then show ?thesis using W by (simp add: r3_count_def vero_aux_release_def)
next
 case False
 have L: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some (size_of TYPE(StrictC'_BinomialHeap_C))"
  using LIVE by simp
 show ?thesis using r3_update_release[OF W G L] False by (simp add: r3_count_def)
qed

lemma r3_dec_release:
 assumes W: "allocator_wf (phantom_machine_state_' s)" and G: "c_guard p"
 and LIVE: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 shows "vero_aux_release s {} {ptr_val p} (r2_dec s p)"
proof -
 have L: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some (size_of TYPE(StrictC'_BinomialTree_C))"
  using LIVE by simp
 show ?thesis using r3_update_release[OF W G L] by (simp add: r2_dec_def)
qed

lemma r3_finish_effects:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and GH: "c_guard h" and GP: "c_guard p"
 and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and NE: "ptr_val p\<noteq>ptr_val h"
 and EFFECT: "if refcount_C (bn_tree s p)=1 then
   vero_aux_release (r2_dec (r3_count s h result) p) {ptr_val p} {ptr_val p} t
   else t=r2_dec (r3_count s h result) p"
 shows "vero_aux_release s (if refcount_C (bn_tree s p)=1 then {ptr_val p} else {})
   {ptr_val h,ptr_val p} t \<and>
  bn_heap t h = (bn_heap s h)\<lparr>num_values_C:=
    (if result=0 then num_values_C (bn_heap s h) else num_values_C (bn_heap s h)+1)\<rparr>"
proof -
 let ?u="r3_count s h result"
 let ?d="r2_dec ?u p"
 let ?D="if refcount_C (bn_tree s p)=1 then {ptr_val p} else {}"
 have CU: "vero_aux_release s {} {ptr_val h} ?u" by (rule r3_count_release[OF W GH LH])
 have UW: "allocator_wf (phantom_machine_state_' ?u)"
  and UL: "live_blocks (phantom_machine_state_' ?u) (ptr_val p)=Some 24"
  using W LP by (simp_all add: r3_count_def)
 have UD: "vero_aux_release ?u {} {ptr_val p} ?d" by (rule r3_dec_release[OF UW GP UL])
 have SD: "vero_aux_release s {} {ptr_val h,ptr_val p} ?d"
  using r3_release_compose[OF CU UD] by (simp add: insert_commute)
 have DT: "vero_aux_release ?d ?D {ptr_val p} t"
  using EFFECT SD by (cases "refcount_C (bn_tree s p)=1") (auto simp: vero_aux_release_def)
 have ST: "vero_aux_release s ?D {ptr_val h,ptr_val p} t"
  using r3_release_compose[OF SD DT] by (simp add: insert_commute)
 have HL: "live_blocks (phantom_machine_state_' ?u) (ptr_val h)=Some 40"
  using LH by (simp add: r3_count_def)
 have HD: "bn_heap ?d h=bn_heap ?u h"
  unfolding bn_heap_def apply (rule r3_release_read[OF UD GH HL]) using NE by auto
 have LD: "live_blocks (phantom_machine_state_' ?d) (ptr_val h)=Some 40"
  using UD HL by (simp add: vero_aux_release_def)
 have HT: "bn_heap t h=bn_heap ?d h"
  unfolding bn_heap_def apply (rule r3_release_read[OF DT GH LD]) using NE by auto
 have HU: "bn_heap ?u h = (bn_heap s h)\<lparr>num_values_C:=
    (if result=0 then num_values_C (bn_heap s h) else num_values_C (bn_heap s h)+1)\<rparr>"
  by (cases "result=0"; simp add: r3_count_def bn_heap_def hrs_mem_update_def hrs_mem_def
    case_prod_unfold h_val_heap_update GH)
 show ?thesis using ST HD HT HU by simp
qed

ML \<open>
 val facts = @{thms r3_release_compose r3_release_read r3_update_release
   r3_count_release r3_dec_release r3_finish_effects};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "R3_FINISH_EFFECTS_PASS";
\<close>
end
end

theory Current_Preparation_5 imports Revision_Full_Preparation_Provider Revision_Callsite_Bridges Owned_Context_Protocol begin

context Calg_Binomial_Reviewed_Stack begin

r2_capture "0052" "reviewed-stack-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_pop' h) s (\<lambda>r t. bn_frame s h P F t \<and>
      (if r = NULL then (\<exists>F'. bn_rep t h P F' M) \<and>
        live_blocks (phantom_machine_state_' t) = live_blocks (phantom_machine_state_' s)
       else r \<in># M \<and> (\<forall>q \<in># M. bn_key s r \<le> bn_key s q) \<and>
         (\<exists>F'. bn_rep t h P F' (M - {#r#}) \<and> bn_storage_transition s h F t F')))"

r2_refute "0052" checked_0052

apply (simp only: not_all not_imp)
apply (rule exI[where x="{#Ptr 196,Ptr 192,Ptr 196#}"])
apply (rule exI[where x="[Some (BN (Ptr 64) []),Some (BN (Ptr 96) [BN (Ptr 128) []])]"])
apply (rule exI[where x="(block_bytes 192 8)"])
apply (rule exI[where x="(Ptr 16)"])
apply (rule exI[where x="(vero_aux_pop_state stack_byte_typing)"])
using vero_aux_pop_counterexample[where Q="(\<lambda>r t. bn_frame (vero_aux_pop_state stack_byte_typing) (Ptr 16) (block_bytes 192 8) [Some (BN (Ptr 64) []),Some (BN (Ptr 96) [BN (Ptr 128) []])] t \<and>
      (if r = NULL then (\<exists>F'. bn_rep t (Ptr 16) (block_bytes 192 8) F' {#Ptr 196,Ptr 192,Ptr 196#}) \<and>
        live_blocks (phantom_machine_state_' t) = live_blocks (phantom_machine_state_' (vero_aux_pop_state stack_byte_typing))
       else r \<in># {#Ptr 196,Ptr 192,Ptr 196#} \<and> (\<forall>q \<in># {#Ptr 196,Ptr 192,Ptr 196#}. bn_key (vero_aux_pop_state stack_byte_typing) r \<le> bn_key (vero_aux_pop_state stack_byte_typing) q) \<and>
         (\<exists>F'. bn_rep t (Ptr 16) (block_bytes 192 8) F' ({#Ptr 196,Ptr 192,Ptr 196#} - {#r#}) \<and> bn_storage_transition (vero_aux_pop_state stack_byte_typing) (Ptr 16) [Some (BN (Ptr 64) []),Some (BN (Ptr 96) [BN (Ptr 128) []])] t F')))"] by blast

end

end
theory Revision_Callsite_Bridges imports Repair_Phase_Model Revision_Witness_Provider Ownership_Facts begin

lemma r2_owned_array_slots:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
  and OA: "bn_ds_owned_array s a n" and OUT: "ptr_val a \<notin> B"
 shows "bn_r2_slots_supported s (bn_ds_slots a n) B"
proof (unfold bn_r2_slots_supported_def, intro ballI)
 fix q assume Q: "q \<in> set (bn_ds_slots a n)"
 obtain i where I: "i<n" and EQ: "q=a +\<^sub>p int i"
  using Q by (auto simp: bn_ds_slots_def)
 obtain m where L: "live_blocks (phantom_machine_state_' s) (ptr_val a)=Some m"
  and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr)*n \<le> m"
  using OA by (auto simp: bn_ds_owned_array_def)
 have SP: "ptr_span q \<subseteq> block_bytes (ptr_val a) m"
  unfolding EQ by (rule c0008_prove[OF W L SZ I])
 have G: "c_guard q" using OA I EQ by (auto simp: bn_ds_owned_array_def)
 show "bn_r2_slot_supported s q B" using L SZ OUT SP G
  by (auto simp: bn_r2_slot_supported_def bn_r2_span_supported_def)
qed

context binomial_heap_input_global_addresses begin
lemma r2_pop_merge_upgrade:
 assumes MP: "bn_ds_merge_pre t h fake P F' G [] held N edges"
 and R: "bn_rep entry h P F M"
 and A: "phantom_machine_state_' t = phantom_machine_state_' entry"
 and HH: "bn_heap t h = bn_heap entry h"
 and SP: "ptr_span fake \<subseteq> S"
 and SS: "S \<subseteq> reserved_bytes (phantom_machine_state_' entry)"
 shows "bn_r2_merge_pre t h fake P F' G [] held N edges"
proof -
 let ?a="roots_C (bn_heap t h)"
 let ?B="bn_ds_graph_blocks t N"
 have W: "allocator_wf (phantom_machine_state_' t)"
  using MP by (auto simp: bn_ds_merge_pre_def bn_ds_graph_def)
 have OUT: "ptr_val ?a \<notin> ?B" using MP by (simp add: bn_ds_merge_pre_def)
 have AS: "bn_r2_slots_supported t (bn_ds_slots ?a (length F')) ?B"
 proof (cases "?a=NULL")
  case True
  have "F'=[]" using MP True
   by (cases F') (auto simp: bn_ds_merge_pre_def bn_ds_forest_view_def
       bn_review_header_view_def bn_review_root_array_view_def dest: c_guard_NULL)
  then show ?thesis by (simp add: bn_ds_slots_def bn_r2_slots_supported_def)
 next
  case False
  have OA: "bn_ds_owned_array t ?a (length F')"
   using MP False by (simp add: bn_ds_merge_pre_def)
  show ?thesis by (rule r2_owned_array_slots[OF W OA OUT])
 qed
 have BORROW: "bn_r2_span_supported t (ptr_span fake)
  (insert (ptr_val h) (insert (ptr_val ?a) ?B))"
  using A SP SS by (auto simp: bn_r2_span_supported_def)
 have SEPARATE: "?a=NULL \<or> ptr_val ?a \<noteq> ptr_val h"
  using R by (auto simp: bn_rep_def bn_owned_def HH)
 show ?thesis using MP AS BORROW SEPARATE
  by (auto simp: bn_r2_merge_pre_def bn_ds_merge_pre_def bn_r2_graph_storage_def
    bn_r2_slots_supported_def)
qed

lemma r2_spec_0069_actual_pop_detach:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  c_guard fake \<Longrightarrow> root_ptr_valid (hrs_htd (t_hrs_' entry)) fake \<Longrightarrow>
  ptr_span fake \<subseteq> \<S> \<Longrightarrow> \<S> \<subseteq> reserved_bytes (phantom_machine_state_' entry) \<Longrightarrow>
  P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t.
   r = bn_root T \<and> phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry) \<and>
   (\<exists>N edges. bn_r2_merge_pre t h fake P (F[i := None]) (map Some (bn_ds_children T)) [] {#r#} N edges))"
proof -
  assume R: "bn_rep entry h P F M" and I: "i<length F" and FT: "F!i=Some T"
    and GF: "c_guard fake" and RPV: "root_ptr_valid (hrs_htd (t_hrs_' entry)) fake"
    and SP: "ptr_span fake\<subseteq>\<S>" and SS: "\<S>\<subseteq>reserved_bytes (phantom_machine_state_' entry)"
    and PS: "P\<inter>\<S>={}"
  obtain p cs where SHAPE: "T=BN p cs" by (cases T) auto
  have FTP: "F!i=Some (BN p cs)" using FT SHAPE by simp
  let ?u = "bn_review_clear_root entry h i"
  let ?v = "(bn_heap ?u fake)\<lparr>heap_type_C := heap_type_C (bn_heap ?u h),
    compare_func_C := compare_func_C (bn_heap ?u h), roots_C := subtrees_C (bn_tree ?u p),
    roots_length_C := UCAST(16 \<rightarrow> 32) (order_C (bn_tree ?u p))\<rparr>"
  let ?t = "t_hrs_'_update (hrs_mem_update (heap_update fake ?v)) ?u"
  let ?N = "bn_ds_forest_nodes F"
  let ?slots = "bn_ds_slots (roots_C (bn_heap entry h)) (length F)"
  note CORE = vero_aux_detach_core[OF R I FTP GF SP SS PS]
  have A: "phantom_machine_state_' ?t = phantom_machine_state_' entry"
    and HTD: "hrs_htd (t_hrs_' ?t) = hrs_htd (t_hrs_' entry)"
    and HH: "bn_heap ?t h = bn_heap entry h" and HF: "bn_heap ?t fake = ?v"
    and HU: "bn_heap ?u h = bn_heap entry h" and HPU: "bn_tree ?u p = bn_tree entry p"
    and RV: "bn_review_root_array_view ?t (roots_C (bn_heap entry h)) (F[i:=None])"
    and ALL: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid ?t P U"
    and HN: "\<forall>q\<in>?N. bn_tree ?t q = bn_tree entry q"
    and GT: "bn_ds_graph ?t P ?N (bn_ds_physical_edges entry) ?slots {#p#} {}"
    and ST: "bn_ds_graph_storage ?t ?N ?slots"
    and DIST: "distinct (concat (map (case_option [] (bn_blocks ?t)) (F[i:=None] @ map Some cs)))"
    and MASS: "length (bn_forest_values ?t (F[i:=None])) + length (bn_forest_values ?t (map Some cs)) < 2^32"
    using CORE by blast+
  have TFM: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FTP by simp
  have PN: "p\<in>?N" using TFM by (auto simp: vero_aux_forest_node_member)
  have HP: "bn_tree ?t p = bn_tree entry p" using HN PN by blast
  have VP: "bn_valid ?t P (BN p cs)" using ALL TFM by blast
  have V0: "bn_valid entry P (BN p cs)" using R I FTP by (auto simp: bn_rep_def)
  have ORDER: "unat (order_C (bn_tree entry p)) = length cs" using V0 by simp
  have FK: "heap_type_C (bn_heap ?t fake) = BINOMIAL_HEAP_TYPE_MIN" using HF HU R by (simp add: bn_rep_def)
  have FC: "compare_func_C (bn_heap ?t fake) = binomial_heap_input.int_compare" using HF HU R by (simp add: bn_rep_def)
  have FR: "roots_C (bn_heap ?t fake) = subtrees_C (bn_tree ?t p)" by (simp only: HF HP; simp add: HPU)
  have FL: "unat (roots_length_C (bn_heap ?t fake)) = length cs" by (simp only: HF; simp add: HPU ORDER unat_ucast_up_simp)
  have VH: "bn_ds_forest_view ?t h P (F[i:=None])" and VG: "bn_ds_forest_view ?t fake P (map Some cs)"
    using vero_aux_detach_views[OF R I FTP A HH GF SP SS FK FC FR FL RV VP ALL] by blast+
  have MP: "bn_ds_merge_pre ?t h fake P (F[i:=None]) (map Some cs) [] {#p#} ?N (bn_ds_physical_edges entry)"
    by (rule vero_aux_detach_merge_pre[OF R I FTP A HH SP SS HN VH VG GT ST DIST MASS])
  have MP2: "bn_r2_merge_pre ?t h fake P (F[i:=None]) (map Some cs) [] {#p#} ?N (bn_ds_physical_edges entry)"
   by (rule r2_pop_merge_upgrade[OF MP R A HH SP SS])
  have LEN: "length F\<le>32" and W: "allocator_wf (phantom_machine_state_' entry)"
    and LH: "live_blocks (phantom_machine_state_' entry) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using R by (auto simp: bn_rep_def)
  have IB: "i<2^32" using I LEN by (simp; arith)
  have IDX: "uint (of_nat i :: 32 word) = int i" using IB by (simp add: uint_nat unat_of_nat)
  have GS: "c_guard (roots_C (bn_heap entry h) +\<^sub>p uint (of_nat i :: 32 word))"
    using R I by (auto simp: bn_rep_def IDX)
  have VAL: "h_val (hrs_mem (t_hrs_' entry)) (roots_C (bn_heap entry h) +\<^sub>p uint (of_nat i :: 32 word)) = p"
    using R I FTP by (auto simp: bn_rep_def IDX)
  have GP: "c_guard p" and LP: "live_blocks (phantom_machine_state_' entry) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using V0 by auto
  have DH0: "ptr_span (h +\<^sub>p int 0) \<inter> ptr_span fake = {}"
    by (rule vero_aux_live_reserved_span[OF W LH _ _ SP SS, where k=1 and i=0]) simp_all
  have DP0: "ptr_span (p +\<^sub>p int 0) \<inter> ptr_span fake = {}"
    by (rule vero_aux_live_reserved_span[OF W LP _ _ SP SS, where k=1 and i=0]) simp_all
  have DH: "ptr_span h \<inter> ptr_span fake = {}" using DH0 by simp
  have DP: "ptr_span p \<inter> ptr_span fake = {}" using DP0 by simp
  have SEM: "bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t. r=p \<and> t=?t)"
    using vero_aux_detach_semantics[OF GS VAL GF GP DH DP]
    by (simp only: IDX bn_review_clear_root_def)
  show ?thesis
    apply (rule vero_aux_contract_weaken[OF SEM])
    using A HTD MP2 SHAPE by (auto; blast)
qed


lemma r2_spec_0015_consumer:
 "bn_r2_finish_base s h P F N edges [] {#} \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow>
  M = mset (bn_forest_values s F) \<Longrightarrow> bn_rep s h P F M"
 using c0012_prove
 by (auto simp: bn_r2_finish_base_def bn_ds_finish_base_def bn_r2_graph_storage_def)

lemma r2_insert_finish_slot_from_stack:
 "c_guard slot \<Longrightarrow> ptr_span slot \<subseteq> S \<Longrightarrow>
  S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
  bn_r2_slot_supported s slot (insert (ptr_val h) (bn_ds_graph_blocks s N))"
 by (rule r2_stack_slot_support)

lemma r2_insert_slot_from_actual_stack_allocs:
 assumes ALLOC: "(slot, d') \<in> stack_allocs 1 S TYPE(StrictC'_BinomialTree_C ptr) d"
 and RESERVED: "S \<subseteq> reserved_bytes (phantom_machine_state_' s)"
 shows "bn_r2_slot_supported s slot B"
proof -
 have G: "c_guard slot" by (rule stack_allocs_cases[OF ALLOC]) assumption
 have SP: "ptr_span slot \<subseteq> S"
  using stack_allocs_\<S>[OF ALLOC, where i=0] by simp
 show ?thesis by (rule r2_stack_slot_support[OF G SP RESERVED])
qed

lemma r2_rollback_external_owner_bridge:
 assumes PRE: "bn_r2_merge_pre s0 h other P F G ext held N edges"
 and TRANS: "bn_ds_storage_transition s0 (bn_ds_graph_blocks s0 N)
    s (insert (ptr_val a) (bn_ds_graph_blocks s N'))"
 shows "bn_r2_slots_supported s ext (insert (ptr_val a) (bn_ds_graph_blocks s N'))"
proof -
 have STRONG: "bn_r2_slots_supported s0 ext
  (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s0 h))) (bn_ds_graph_blocks s0 N)))"
  using PRE unfolding bn_r2_merge_pre_def by blast
 have PRE0: "bn_r2_slots_supported s0 ext (bn_ds_graph_blocks s0 N)"
 proof (unfold bn_r2_slots_supported_def, intro ballI)
  fix q assume Q: "q \<in> set ext"
  have G: "c_guard q" and S: "bn_r2_span_supported s0 (ptr_span q)
   (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s0 h))) (bn_ds_graph_blocks s0 N)))"
   using STRONG Q by (auto simp: bn_r2_slots_supported_def bn_r2_slot_supported_def)
  have W: "bn_r2_span_supported s0 (ptr_span q) (bn_ds_graph_blocks s0 N)"
   apply (rule r2_supported_monotone[OF S]) by auto
  show "bn_r2_slot_supported s0 q (bn_ds_graph_blocks s0 N)"
   using G W by (simp add: bn_r2_slot_supported_def)
 qed
 show ?thesis by (rule r2_slots_storage_transition[OF PRE0 TRANS])
qed

ML \<open>
 val facts = @{thms r2_owned_array_slots r2_pop_merge_upgrade
   r2_spec_0069_actual_pop_detach r2_spec_0015_consumer
   r2_insert_finish_slot_from_stack r2_insert_slot_from_actual_stack_allocs r2_rollback_external_owner_bridge};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "R2_CALLSITE_COMPONENTS_PASS full_pop_detach=0069";
\<close>
end
end

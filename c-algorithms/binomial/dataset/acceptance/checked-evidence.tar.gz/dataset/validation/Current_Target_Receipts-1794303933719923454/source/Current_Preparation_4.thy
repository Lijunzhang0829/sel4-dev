theory Current_Preparation_4 imports Revision_Full_Preparation_Provider Revision_Callsite_Bridges Owned_Context_Protocol begin

context binomial_heap_input_global_addresses begin

r2_capture "0001" "function-address-locale" captured:
  "c_guard h \<Longrightarrow>
   heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
   compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
   c_guard (ptr_coerce v :: 32 signed word ptr) \<Longrightarrow>
   runs_to (binomial_heap_cmp' h v v) s Q = Q (Result 0) s"

r2_prove "0001" checked_0001:
  "c_guard h \<Longrightarrow>
   heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
   compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
   c_guard (ptr_coerce v :: 32 signed word ptr) \<Longrightarrow>
   runs_to (binomial_heap_cmp' h v v) s Q = Q (Result 0) s"

by (fact c0001_prove)

end

r2_capture "0002" "global" captured:
  "fresh_block A p n \<Longrightarrow> live_blocks A q = Some m \<Longrightarrow>
    block_bytes p n \<inter> block_bytes q m = {}"

r2_prove "0002" checked_0002:
  "fresh_block A p n \<Longrightarrow> live_blocks A q = Some m \<Longrightarrow>
    block_bytes p n \<inter> block_bytes q m = {}"

by (fact c0002_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0004" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
  bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j)) \<Longrightarrow>
  bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>(i',j') t.
    t = s \<and> i' = i + 1 \<and>
    bn_review_scan_prefix s F (unat i') (if j' = 0xFFFFFFFF then None else Some (unat j')))"

r2_prove "0004" checked_0004:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
  bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j)) \<Longrightarrow>
  bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>(i',j') t.
    t = s \<and> i' = i + 1 \<and>
    bn_review_scan_prefix s F (unat i') (if j' = 0xFFFFFFFF then None else Some (unat j')))"

by (fact c0003_prove)

end

r2_capture "0009" "global" captured:
  "bn_stack_ready S s \<Longrightarrow>
   \<exists>p d q e.
     (p,d) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<and>
     (q,e) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialTree_C ptr) d"

r2_prove "0009" checked_0009:
  "bn_stack_ready S s \<Longrightarrow>
   \<exists>p d q e.
     (p,d) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<and>
     (q,e) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialTree_C ptr) d"

by (fact c0006_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0010" "function-address-locale" captured:
  "c_guard p \<Longrightarrow> 1 < unat (refcount_C (bn_tree s p)) \<Longrightarrow>
    bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) - 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

r2_prove "0010" checked_0010:
  "c_guard p \<Longrightarrow> 1 < unat (refcount_C (bn_tree s p)) \<Longrightarrow>
    bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) - 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

by (fact c0007_prove)

end

r2_capture "0011" "global" captured:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"

r2_prove "0011" checked_0011:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"

by (fact c0008_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0012" "function-address-locale" captured:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_contract calg_binomial_new' s (\<lambda>h t.
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        live_blocks (phantom_machine_state_' t) p = Some n \<and>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)) \<and>
      (if h = NULL then phantom_machine_state_' t = phantom_machine_state_' s else
        bn_rep t h P [] {#} \<and> roots_C (bn_heap t h) = NULL \<and>
        phantom_machine_state_' t = (phantom_machine_state_' s)\<lparr>live_blocks :=
          (live_blocks (phantom_machine_state_' s))(ptr_val h := Some (size_of TYPE(StrictC'_BinomialHeap_C)))\<rparr>))"

r2_prove "0012" checked_0012:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_contract calg_binomial_new' s (\<lambda>h t.
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        live_blocks (phantom_machine_state_' t) p = Some n \<and>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)) \<and>
      (if h = NULL then phantom_machine_state_' t = phantom_machine_state_' s else
        bn_rep t h P [] {#} \<and> roots_C (bn_heap t h) = NULL \<and>
        phantom_machine_state_' t = (phantom_machine_state_' s)\<lparr>live_blocks :=
          (live_blocks (phantom_machine_state_' s))(ptr_val h := Some (size_of TYPE(StrictC'_BinomialHeap_C)))\<rparr>))"

by (fact c0009_prove)

end

r2_capture "0013" "global" captured:
  "bn_valid s P T \<Longrightarrow> refcount_C (bn_tree s (bn_root T)) = 1"

r2_prove "0013" checked_0013:
  "bn_valid s P T \<Longrightarrow> refcount_C (bn_tree s (bn_root T)) = 1"

by (fact c0010_prove)

r2_capture "0014" "global" captured:
  "bn_rep s h P F M \<Longrightarrow>
    length F \<le> 32 \<and> unat (roots_length_C (bn_heap s h)) = length F"

r2_prove "0014" checked_0014:
  "bn_rep s h P F M \<Longrightarrow>
    length F \<le> 32 \<and> unat (roots_length_C (bn_heap s h)) = length F"

by (fact c0011_prove)

r2_capture "0015" "global" captured:
  "bn_r2_finish_base s h P F N edges [] {#} \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow>
  M = mset (bn_forest_values s F) \<Longrightarrow> bn_rep s h P F M"

r2_prove "0015" checked_0015:
  "bn_r2_finish_base s h P F N edges [] {#} \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow>
  M = mset (bn_forest_values s F) \<Longrightarrow> bn_rep s h P F M"

using c0012_prove by (auto simp: bn_r2_finish_base_def bn_ds_finish_base_def bn_r2_graph_storage_def)

context binomial_heap_input_global_addresses begin

r2_capture "0016" "function-address-locale" captured:
  "c_guard h \<Longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
    bn_payload P x \<Longrightarrow> bn_payload P y \<Longrightarrow>
    bn_contract (binomial_heap_cmp' h x y) s (\<lambda>r t.
      t = s \<and> ((r <s 0) \<longleftrightarrow> bn_key s x < bn_key s y) \<and>
      ((r = 0) \<longleftrightarrow> bn_key s x = bn_key s y))"

r2_prove "0016" checked_0016:
  "c_guard h \<Longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
    bn_payload P x \<Longrightarrow> bn_payload P y \<Longrightarrow>
    bn_contract (binomial_heap_cmp' h x y) s (\<lambda>r t.
      t = s \<and> ((r <s 0) \<longleftrightarrow> bn_key s x < bn_key s y) \<and>
      ((r = 0) \<longleftrightarrow> bn_key s x = bn_key s y))"

by (fact c0013_prove)

end

r2_capture "0017" "global" captured:
  "memcpy_ok A dst src 0 \<Longrightarrow> dst \<noteq> 0 \<and> src \<noteq> 0"

r2_prove "0017" checked_0017:
  "memcpy_ok A dst src 0 \<Longrightarrow> dst \<noteq> 0 \<and> src \<noteq> 0"

by (fact c0014_prove)

r2_capture "0018" "global" captured:
  "free_rel p hp A hp' B \<Longrightarrow> q \<noteq> p \<Longrightarrow>
    live_blocks B q = live_blocks A q"

r2_prove "0018" checked_0018:
  "free_rel p hp A hp' B \<Longrightarrow> q \<noteq> p \<Longrightarrow>
    live_blocks B q = live_blocks A q"

by (fact c0015_prove)

r2_capture "0020" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> W \<subseteq> V \<Longrightarrow> bytes_frame V hp hp'"

r2_prove "0020" checked_0020:
  "bytes_frame W hp hp' \<Longrightarrow> W \<subseteq> V \<Longrightarrow> bytes_frame V hp hp'"

by (fact c0016_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0021" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_contract (bn_ds_scan h) s (\<lambda>(i,j) t.
   t = s \<and> unat i = length F \<and> unat j < length F \<and>
   (\<exists>T. F ! unat j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
    (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)))"

r2_prove "0021" checked_0021:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_contract (bn_ds_scan h) s (\<lambda>(i,j) t.
   t = s \<and> unat i = length F \<and> unat j < length F \<and>
   (\<exists>T. F ! unat j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
    (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)))"

by (fact c0017_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0022" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
    \<exists>i T. i < length F \<and> F ! i = Some T \<and>
      value_C (bn_tree s (bn_root T)) \<in># M \<and>
      (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

r2_prove "0022" checked_0022:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
    \<exists>i T. i < length F \<and> F ! i = Some T \<and>
      value_C (bn_tree s (bn_root T)) \<in># M \<and>
      (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

by (fact c0018_prove)

end

r2_capture "0023" "global" captured:
  "bytes_frame W hp hp"

r2_prove "0023" checked_0023:
  "bytes_frame W hp hp"

by (fact c0019_prove)

r2_capture "0024" "global" captured:
  "c_guard (p :: 'a::mem_type ptr) \<Longrightarrow>
   c_guard (q :: 'b::mem_type ptr) \<Longrightarrow>
   ptr_span p \<inter> ptr_span q = {} \<Longrightarrow>
   h_val (heap_update p v m) q = h_val m q"

r2_prove "0024" checked_0024:
  "c_guard (p :: 'a::mem_type ptr) \<Longrightarrow>
   c_guard (q :: 'b::mem_type ptr) \<Longrightarrow>
   ptr_span p \<inter> ptr_span q = {} \<Longrightarrow>
   h_val (heap_update p v m) q = h_val m q"

by (fact c0020_prove)

r2_capture "0025" "global" captured:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow>
   allocator_wf (A\<lparr>live_blocks := (live_blocks A)(p := Some n)\<rparr>)"

r2_prove "0025" checked_0025:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow>
   allocator_wf (A\<lparr>live_blocks := (live_blocks A)(p := Some n)\<rparr>)"

by (fact c0021_prove)

r2_capture "0026" "global" captured:
  "malloc_rel n hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    live_blocks B p = Some n \<and> reserved_bytes B = reserved_bytes A \<and>
    (\<forall>q. q \<noteq> p \<longrightarrow> live_blocks B q = live_blocks A q)"

r2_prove "0026" checked_0026:
  "malloc_rel n hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    live_blocks B p = Some n \<and> reserved_bytes B = reserved_bytes A \<and>
    (\<forall>q. q \<noteq> p \<longrightarrow> live_blocks B q = live_blocks A q)"

by (fact c0022_prove)

r2_capture "0027" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> a \<notin> W \<Longrightarrow> hp' a = hp a"

r2_prove "0027" checked_0027:
  "bytes_frame W hp hp' \<Longrightarrow> a \<notin> W \<Longrightarrow> hp' a = hp a"

by (fact c0023_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0029" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_free' h) s (\<lambda>r t.
    bn_frame s h P F t \<and> allocator_wf (phantom_machine_state_' t) \<and>
    live_blocks (phantom_machine_state_' t) =
      (\<lambda>p. if p \<in> set (bn_owned s h F) then None else live_blocks (phantom_machine_state_' s) p))"

r2_prove "0029" checked_0029:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_free' h) s (\<lambda>r t.
    bn_frame s h P F t \<and> allocator_wf (phantom_machine_state_' t) \<and>
    live_blocks (phantom_machine_state_' t) =
      (\<lambda>p. if p \<in> set (bn_owned s h F) then None else live_blocks (phantom_machine_state_' s) p))"

by (fact c0024_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0030" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    (\<And>p. \<not> fresh_block (phantom_machine_state_' s) p (size_of TYPE(StrictC'_BinomialTree_C))) \<Longrightarrow>
    bn_contract (binomial_heap_insert' h v) s (\<lambda>r t.
      r = 0 \<and> bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

r2_prove "0030" checked_0030:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    (\<And>p. \<not> fresh_block (phantom_machine_state_' s) p (size_of TYPE(StrictC'_BinomialTree_C))) \<Longrightarrow>
    bn_contract (binomial_heap_insert' h v) s (\<lambda>r t.
      r = 0 \<and> bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

by (fact c0025_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0031" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_review_scan_prefix s F 0 None"

r2_prove "0031" checked_0031:
  "bn_rep s h P F M \<Longrightarrow> bn_review_scan_prefix s F 0 None"

by (fact c0026_prove)

end

r2_capture "0032" "global" captured:
  "length (bn_values s (BN p cs)) = Suc (sum_list (map (\<lambda>T. length (bn_values s T)) cs))"

r2_prove "0032" checked_0032:
  "length (bn_values s (BN p cs)) = Suc (sum_list (map (\<lambda>T. length (bn_values s T)) cs))"

by (fact c0027_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0035" "function-address-locale" captured:
  "runs_to (malloc' n >>= k) s Q \<Longrightarrow>
   malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) p m A \<Longrightarrow>
   runs_to (k (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. m)) s)
       \<lparr>phantom_machine_state_' := A\<rparr>) Q"

r2_prove "0035" checked_0035:
  "runs_to (malloc' n >>= k) s Q \<Longrightarrow>
   malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) p m A \<Longrightarrow>
   runs_to (k (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. m)) s)
       \<lparr>phantom_machine_state_' := A\<rparr>) Q"

by (fact c0029_prove)

end

r2_capture "0036" "global" captured:
  "calloc_rel item_count item_width hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    i < item_count * item_width \<Longrightarrow> hp' (p + of_nat i) = 0"

r2_prove "0036" checked_0036:
  "calloc_rel item_count item_width hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    i < item_count * item_width \<Longrightarrow> hp' (p + of_nat i) = 0"

by (fact c0030_prove)

r2_capture "0037" "global" captured:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   S \<subseteq> reserved_bytes A \<Longrightarrow> bytes_frame S hp hp' \<Longrightarrow>
   h_val hp' (p +\<^sub>p int i) = h_val hp (p +\<^sub>p int i)"

r2_prove "0037" checked_0037:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   S \<subseteq> reserved_bytes A \<Longrightarrow> bytes_frame S hp hp' \<Longrightarrow>
   h_val hp' (p +\<^sub>p int i) = h_val hp (p +\<^sub>p int i)"

by (fact c0031_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0038" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_review_scan_prefix s F (length F) (Some j) \<Longrightarrow>
  \<exists>T. F ! j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
   (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

r2_prove "0038" checked_0038:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_review_scan_prefix s F (length F) (Some j) \<Longrightarrow>
  \<exists>T. F ! j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
   (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

by (fact c0032_prove)

end

r2_capture "0039" "global" captured:
  "bn_rep s h P F {#} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_rep t h P F {#}"

r2_prove "0039" checked_0039:
  "bn_rep s h P F {#} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_rep t h P F {#}"

by (fact c0033_prove)

r2_capture "0040" "global" captured:
  "i < length F \<Longrightarrow>
    mset (bn_forest_values s (F[i := None])) +
      mset (case_option [] (bn_values s) (F ! i)) = mset (bn_forest_values s F)"

r2_prove "0040" checked_0040:
  "i < length F \<Longrightarrow>
    mset (bn_forest_values s (F[i := None])) +
      mset (case_option [] (bn_values s) (F ! i)) = mset (bn_forest_values s F)"

by (fact c0034_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0041" "function-address-locale" captured:
  "runs_to (malloc' n) s Q \<Longrightarrow>
   fresh_block (phantom_machine_state_' s) p (unat n) \<Longrightarrow>
   Q (Result (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' s))) s)
       \<lparr>phantom_machine_state_' :=
         (phantom_machine_state_' s)\<lparr>live_blocks :=
           (live_blocks (phantom_machine_state_' s))(p := Some (unat n))\<rparr>\<rparr>)"

r2_prove "0041" checked_0041:
  "runs_to (malloc' n) s Q \<Longrightarrow>
   fresh_block (phantom_machine_state_' s) p (unat n) \<Longrightarrow>
   Q (Result (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' s))) s)
       \<lparr>phantom_machine_state_' :=
         (phantom_machine_state_' s)\<lparr>live_blocks :=
           (live_blocks (phantom_machine_state_' s))(p := Some (unat n))\<rparr>\<rparr>)"

by (fact c0035_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0044" "function-address-locale" captured:
  "stack_allocs 1 \<S> TYPE('a::mem_type) (hrs_htd (t_hrs_' s)) \<noteq> {} \<Longrightarrow>
   (\<And>p d v bs.
      (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
      length bs = size_of TYPE('a) \<Longrightarrow>
      bn_contract ((c :: 'a ptr \<Rightarrow> ('e::default, 'b, globals) spec_monad) p)
        (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))
        (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE('a) \<longrightarrow>
          Q r (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)))) \<Longrightarrow>
   bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) c) s Q"

r2_prove "0044" checked_0044:
  "stack_allocs 1 \<S> TYPE('a::mem_type) (hrs_htd (t_hrs_' s)) \<noteq> {} \<Longrightarrow>
   (\<And>p d v bs.
      (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
      length bs = size_of TYPE('a) \<Longrightarrow>
      bn_contract ((c :: 'a ptr \<Rightarrow> ('e::default, 'b, globals) spec_monad) p)
        (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))
        (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE('a) \<longrightarrow>
          Q r (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)))) \<Longrightarrow>
   bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) c) s Q"

by (fact c0037_prove)

end

r2_capture "0045" "global" captured:
  "free_rel 0 hp A hp' B \<Longrightarrow> hp' = hp \<and> B = A"

r2_prove "0045" checked_0045:
  "free_rel 0 hp A hp' B \<Longrightarrow> hp' = hp \<and> B = A"

by (fact c0038_prove)

r2_capture "0046" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> P \<inter> W = {} \<Longrightarrow>
    \<forall>a \<in> P. hp' a = hp a"

r2_prove "0046" checked_0046:
  "bytes_frame W hp hp' \<Longrightarrow> P \<inter> W = {} \<Longrightarrow>
    \<forall>a \<in> P. hp' a = hp a"

by (fact c0039_prove)

r2_capture "0047" "global" captured:
  "hd (bn_values s T) = value_C (bn_tree s (bn_root T))"

r2_prove "0047" checked_0047:
  "hd (bn_values s T) = value_C (bn_tree s (bn_root T))"

by (fact c0040_prove)

r2_capture "0049" "global" captured:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   P \<inter> S = {} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_frame s h P F t"

r2_prove "0049" checked_0049:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   P \<inter> S = {} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_frame s h P F t"

by (fact c0042_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0050" "function-address-locale" captured:
  "\<not> runs_to (memcpy' dst NULL n >>= k) s Q"

r2_prove "0050" checked_0050:
  "\<not> runs_to (memcpy' dst NULL n >>= k) s Q"

by (fact c0043_prove)

end

r2_capture "0051" "global" captured:
  "bn_rep s h P F M \<Longrightarrow> distinct (bn_owned s h F) \<and>
    ptr_val h \<in> set (bn_owned s h F)"

r2_prove "0051" checked_0051:
  "bn_rep s h P F M \<Longrightarrow> distinct (bn_owned s h F) \<and>
    ptr_val h \<in> set (bn_owned s h F)"

by (fact c0044_prove)

r2_capture "0055" "global" captured:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q) \<Longrightarrow>
   bn_contract (f >>= g) s Q"

r2_prove "0055" checked_0055:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q) \<Longrightarrow>
   bn_contract (f >>= g) s Q"

by (fact c0048_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0056" "function-address-locale" captured:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_valid s P T \<Longrightarrow> distinct (bn_blocks s T) \<Longrightarrow>
    bn_contract (binomial_tree_unref' (bn_root T)) s (\<lambda>r t.
      allocator_wf (phantom_machine_state_' t) \<and>
      reserved_bytes (phantom_machine_state_' t) = reserved_bytes (phantom_machine_state_' s) \<and>
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      live_blocks (phantom_machine_state_' t) =
        (\<lambda>p. if p \<in> set (bn_blocks s T) then None else live_blocks (phantom_machine_state_' s) p) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        p \<notin> set (bn_blocks s T) \<longrightarrow>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)))"

r2_prove "0056" checked_0056:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_valid s P T \<Longrightarrow> distinct (bn_blocks s T) \<Longrightarrow>
    bn_contract (binomial_tree_unref' (bn_root T)) s (\<lambda>r t.
      allocator_wf (phantom_machine_state_' t) \<and>
      reserved_bytes (phantom_machine_state_' t) = reserved_bytes (phantom_machine_state_' s) \<and>
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      live_blocks (phantom_machine_state_' t) =
        (\<lambda>p. if p \<in> set (bn_blocks s T) then None else live_blocks (phantom_machine_state_' s) p) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        p \<notin> set (bn_blocks s T) \<longrightarrow>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)))"

by (fact c0049_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0057" "function-address-locale" captured:
  "bn_valid s P T \<Longrightarrow> q \<in> set (bn_values s T) \<Longrightarrow>
    bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q"

r2_prove "0057" checked_0057:
  "bn_valid s P T \<Longrightarrow> q \<in> set (bn_values s T) \<Longrightarrow>
    bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q"

by (fact c0050_prove)

end

r2_capture "0058" "global" captured:
  "ptr_val (bn_root T) \<in> set (bn_blocks s T)"

r2_prove "0058" checked_0058:
  "ptr_val (bn_root T) \<in> set (bn_blocks s T)"

by (fact c0051_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0060" "function-address-locale" captured:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  bn_ds_restore (bn_review_clear_root entry h i) s \<Longrightarrow>
  bn_contract (bn_ds_pop_restore h (of_nat i) (bn_root T)) s (\<lambda>r t.
   r = NULL \<and> bn_rep t h P F M \<and> bn_frame entry h P F t \<and>
   phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry))"

r2_prove "0060" checked_0060:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  bn_ds_restore (bn_review_clear_root entry h i) s \<Longrightarrow>
  bn_contract (bn_ds_pop_restore h (of_nat i) (bn_root T)) s (\<lambda>r t.
   r = NULL \<and> bn_rep t h P F M \<and> bn_frame entry h P F t \<and>
   phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry))"

by (fact c0052_prove)

end

r2_capture "0061" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame V hp' hp'' \<Longrightarrow>
    bytes_frame (W \<union> V) hp hp''"

r2_prove "0061" checked_0061:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame V hp' hp'' \<Longrightarrow>
    bytes_frame (W \<union> V) hp hp''"

by (fact c0053_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0064" "function-address-locale" captured:
  "runs_to (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) f) s Q \<Longrightarrow>
   ((p :: 'a::xmem_type ptr),d) \<in>
     stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
   runs_to (f p) (s\<lparr>t_hrs_' := (hrs_mem (t_hrs_' s), d)\<rparr>) (\<lambda>_ _. True)"

r2_prove "0064" checked_0064:
  "runs_to (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) f) s Q \<Longrightarrow>
   ((p :: 'a::xmem_type ptr),d) \<in>
     stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
   runs_to (f p) (s\<lparr>t_hrs_' := (hrs_mem (t_hrs_' s), d)\<rparr>) (\<lambda>_ _. True)"

by (fact c0056_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0065" "function-address-locale" captured:
  "bn_contract (binomial_tree_ref' NULL) s (\<lambda>r t. t = s)"

r2_prove "0065" checked_0065:
  "bn_contract (binomial_tree_ref' NULL) s (\<lambda>r t. t = s)"

by (fact c0057_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0066" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV)
    (\<lambda>(p :: StrictC'_BinomialHeap_C ptr). return p)) s
    (\<lambda>p t. bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

r2_prove "0066" checked_0066:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV)
    (\<lambda>(p :: StrictC'_BinomialHeap_C ptr). return p)) s
    (\<lambda>p t. bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

by (fact c0058_prove)

end

r2_capture "0067" "global" captured:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> \<exists>u. (t,u) \<in> R) \<Longrightarrow>
   (\<And>v t u. P v t \<Longrightarrow> (t,u) \<in> R \<Longrightarrow> Q v u) \<Longrightarrow>
   bn_contract (on_exit f R) s Q"

r2_prove "0067" checked_0067:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> \<exists>u. (t,u) \<in> R) \<Longrightarrow>
   (\<And>v t u. P v t \<Longrightarrow> (t,u) \<in> R \<Longrightarrow> Q v u) \<Longrightarrow>
   bn_contract (on_exit f R) s Q"

by (fact c0059_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0069" "function-address-locale" captured:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  c_guard fake \<Longrightarrow> root_ptr_valid (hrs_htd (t_hrs_' entry)) fake \<Longrightarrow>
  ptr_span fake \<subseteq> \<S> \<Longrightarrow> \<S> \<subseteq> reserved_bytes (phantom_machine_state_' entry) \<Longrightarrow>
  P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t.
   r = bn_root T \<and> phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry) \<and>
   (\<exists>N edges. bn_r2_merge_pre t h fake P (F[i := None]) (map Some (bn_ds_children T)) [] {#r#} N edges))"

r2_prove "0069" checked_0069:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  c_guard fake \<Longrightarrow> root_ptr_valid (hrs_htd (t_hrs_' entry)) fake \<Longrightarrow>
  ptr_span fake \<subseteq> \<S> \<Longrightarrow> \<S> \<subseteq> reserved_bytes (phantom_machine_state_' entry) \<Longrightarrow>
  P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t.
   r = bn_root T \<and> phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry) \<and>
   (\<exists>N edges. bn_r2_merge_pre t h fake P (F[i := None]) (map Some (bn_ds_children T)) [] {#r#} N edges))"

using r2_spec_0069_actual_pop_detach by blast

end

context binomial_heap_input_global_addresses begin

r2_capture "0070" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = None \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r = (i + 1,j) \<and> t = s)"

r2_prove "0070" checked_0070:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = None \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r = (i + 1,j) \<and> t = s)"

by (fact c0062_prove)

end

r2_capture "0071" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame W hp' hp'' \<Longrightarrow>
    bytes_frame W hp hp''"

r2_prove "0071" checked_0071:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame W hp' hp'' \<Longrightarrow>
    bytes_frame W hp hp''"

by (fact c0063_prove)

r2_capture "0072" "global" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_ds_forest_view s h P F"

r2_prove "0072" checked_0072:
  "bn_rep s h P F M \<Longrightarrow> bn_ds_forest_view s h P F"

by (fact c0064_prove)

r2_capture "0073" "global" captured:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow> live_blocks A p = None"

r2_prove "0073" checked_0073:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow> live_blocks A p = None"

by (fact c0065_prove)

r2_capture "0074" "global" captured:
  "bn_valid s P T \<Longrightarrow> bn_ds_tree_layout s P T"

r2_prove "0074" checked_0074:
  "bn_valid s P T \<Longrightarrow> bn_ds_tree_layout s P T"

by (fact c0066_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0075" "function-address-locale" captured:
  "bn_rep s h P F {#} \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_pop' h) s (\<lambda>r t.
      r = NULL \<and> bn_rep t h P F {#} \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

r2_prove "0075" checked_0075:
  "bn_rep s h P F {#} \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_pop' h) s (\<lambda>r t.
      r = NULL \<and> bn_rep t h P F {#} \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

by (fact c0067_prove)

end

r2_capture "0076" "global" captured:
  "malloc_rel n hp A 0 hp' B \<Longrightarrow> hp' = hp \<and> B = A"

r2_prove "0076" checked_0076:
  "malloc_rel n hp A 0 hp' B \<Longrightarrow> hp' = hp \<and> B = A"

by (fact c0068_prove)

r2_capture "0077" "global" captured:
  "mset (bn_forest_values s (F @ G)) = mset (bn_forest_values s F) + mset (bn_forest_values s G)"

r2_prove "0077" checked_0077:
  "mset (bn_forest_values s (F @ G)) = mset (bn_forest_values s F) + mset (bn_forest_values s G)"

by (fact c0069_prove)

r2_capture "0078" "global" captured:
  "bn_values s T \<noteq> []"

r2_prove "0078" checked_0078:
  "bn_values s T \<noteq> []"

by (fact c0070_prove)

r2_capture "0080" "global" captured:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract f s Q"

r2_prove "0080" checked_0080:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract f s Q"

by (fact c0071_prove)

r2_capture "0081" "global" captured:
  "bn_valid s P T \<Longrightarrow> unat (order_C (bn_tree s (bn_root T))) = bn_rank T"

r2_prove "0081" checked_0081:
  "bn_valid s P T \<Longrightarrow> unat (order_C (bn_tree s (bn_root T))) = bn_rank T"

by (fact c0072_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0084" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = Some T \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,0xFFFFFFFF)) s
     (\<lambda>r t. r = (i + 1,i) \<and> t = s)"

r2_prove "0084" checked_0084:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = Some T \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,0xFFFFFFFF)) s
     (\<lambda>r t. r = (i + 1,i) \<and> t = s)"

by (fact c0075_prove)

end

r2_capture "0085" "global" captured:
  "ptr_span (p :: 'a::mem_type ptr) \<subseteq> S \<Longrightarrow>
   length bs = size_of TYPE('a) \<Longrightarrow>
   bytes_frame S hp (heap_update_padding p v bs hp) \<and>
   bytes_frame S hp (heap_update_list (ptr_val p) bs hp)"

r2_prove "0085" checked_0085:
  "ptr_span (p :: 'a::mem_type ptr) \<subseteq> S \<Longrightarrow>
   length bs = size_of TYPE('a) \<Longrightarrow>
   bytes_frame S hp (heap_update_padding p v bs hp) \<and>
   bytes_frame S hp (heap_update_list (ptr_val p) bs hp)"

by (fact c0076_prove)

r2_capture "0086" "global" captured:
  "R s \<noteq> {} \<Longrightarrow>
   (\<And>v t. (v,t) \<in> R s \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract (assume_result_and_state R) s Q"

r2_prove "0086" checked_0086:
  "R s \<noteq> {} \<Longrightarrow>
   (\<And>v t. (v,t) \<in> R s \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract (assume_result_and_state R) s Q"

by (fact c0077_prove)

context binomial_heap_input_global_addresses begin

r2_capture "0087" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_num_entries' h) s
    (\<lambda>r t. unat r = size M \<and> t = s)"

r2_prove "0087" checked_0087:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_num_entries' h) s
    (\<lambda>r t. unat r = size M \<and> t = s)"

by (fact c0078_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0088" "function-address-locale" captured:
  "c_guard p \<Longrightarrow> unat (refcount_C (bn_tree s p)) < 65535 \<Longrightarrow>
    bn_contract (binomial_tree_ref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) + 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

r2_prove "0088" checked_0088:
  "c_guard p \<Longrightarrow> unat (refcount_C (bn_tree s p)) < 65535 \<Longrightarrow>
    bn_contract (binomial_tree_ref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) + 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

by (fact c0079_prove)

end

context binomial_heap_input_global_addresses begin

r2_capture "0008" "function-address-locale" captured:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow> c_guard h \<Longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_valid s P (BN p []) \<Longrightarrow> bn_valid s P (BN q []) \<Longrightarrow> p \<noteq> q \<Longrightarrow>
    live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C)) \<Longrightarrow>
    ptr_val h \<noteq> ptr_val p \<Longrightarrow> ptr_val h \<noteq> ptr_val q \<Longrightarrow>
    bn_contract (binomial_tree_merge' h p q) s (\<lambda>r t. True)"

r2_refute "0008" checked_0008

using vero_aux_closed_c0005_iff binomial_heap_input_global_addresses_axioms unfolding vero_aux_closed_c0005_def by blast

end

context Calg_Binomial_Reviewed_Stack begin

r2_capture "0033" "reviewed-stack-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_payload P v \<Longrightarrow>
    size M + 1 < 2 ^ 32 \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_insert' h v) s (\<lambda>r t.
      bn_frame s h P F t \<and>
      (if r = 0 then (\<exists>F'. bn_rep t h P F' M) \<and>
        live_blocks (phantom_machine_state_' t) = live_blocks (phantom_machine_state_' s)
       else \<exists>F'. bn_rep t h P F' (add_mset v M) \<and> bn_storage_transition s h F t F'))"

r2_refute "0033" checked_0033

using vero_aux_closed_c0028_iff Calg_Binomial_Reviewed_Stack_axioms unfolding vero_aux_closed_c0028_def by blast

end
end

theory Current_Preparation_3 imports Revision_Full_Preparation_Provider Ownership_Facts Owned_Context_Protocol begin
context binomial_heap_input_global_addresses begin
lemma r3_leaf_tree_merge_pre:
 "bn_r2_tree_merge_pre vero_aux_leaf_merge_state (Ptr 16) (block_bytes 192 4)
   (BN (Ptr 64) []) (BN (Ptr 96) []) {Ptr 64,Ptr 96} (\<lambda>_. []) [] {#Ptr 64,Ptr 96#}"
 using vero_aux_leaf_tree_merge_pre
 by (auto simp: bn_r2_tree_merge_pre_def bn_ds_tree_merge_pre_def bn_r2_graph_storage_def bn_r2_slots_supported_def)

lemma r3_pair_pre:
 "bn_r2_merge_pre vero_aux_pair_state (Ptr 16) (Ptr 512) (block_bytes 192 4)
   [Some (BN (Ptr 64) [])] [Some (BN (Ptr 96) [])] [] {#Ptr 96#} {Ptr 64,Ptr 96} (\<lambda>_. [])"
proof -
 let ?s="vero_aux_pair_state"
 have OLD: "bn_ds_merge_pre ?s (Ptr 16) (Ptr 512) (block_bytes 192 4)
   [Some (BN (Ptr 64) [])] [Some (BN (Ptr 96) [])] [] {#Ptr 96#} {Ptr 64,Ptr 96} (\<lambda>_. [])"
  by (rule vero_aux_pair_pre)
 have HH: "bn_heap ?s (Ptr 16)=vero_aux_pair_header (Ptr 560)"
  and HP: "bn_tree ?s (Ptr 64)=vero_aux_leaf_merge_tree"
  and HQ: "bn_tree ?s (Ptr 96)=vero_aux_leaf_merge_tree"
  using vero_aux_pair_fields by blast+
 have GB: "bn_ds_graph_blocks ?s {Ptr 64,Ptr 96}={64,96}"
  by (auto simp: bn_ds_graph_blocks_def HP HQ vero_aux_leaf_merge_tree_def)
 have GS: "c_guard (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)"
  and GO: "c_guard (Ptr 512 :: StrictC'_BinomialHeap_C ptr)"
  using vero_aux_pair_guards by blast+
 have SS: "ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)=block_bytes 560 8"
  using vero_aux_span_block[OF GS] by simp
 have SO: "ptr_span (Ptr 512 :: StrictC'_BinomialHeap_C ptr)=block_bytes 512 40"
  using vero_aux_span_block[OF GO] by simp
 have SLOT: "bn_r2_slot_supported ?s (Ptr 560) {64,96}"
  unfolding bn_r2_slot_supported_def apply (rule conjI[OF GS])
  unfolding bn_r2_span_supported_def apply (rule disjI2)
  apply (rule exI[where x=560]) apply (rule exI[where x=8])
  apply (simp only: SS)
  by (simp add: vero_aux_pair_state_def vero_aux_pair_allocator_def)
 have BORROW: "bn_r2_span_supported ?s (ptr_span (Ptr 512 :: StrictC'_BinomialHeap_C ptr)) {16,560,64,96}"
  unfolding bn_r2_span_supported_def apply (rule disjI2)
  apply (rule exI[where x=512]) apply (rule exI[where x=40])
  apply (simp only: SO)
  by (simp add: vero_aux_pair_state_def vero_aux_pair_allocator_def)
 show ?thesis using OLD SLOT BORROW
  by (auto simp: bn_r2_merge_pre_def bn_ds_merge_pre_def bn_r2_graph_storage_def bn_r2_slots_supported_def
   HH GB vero_aux_pair_header_def vero_aux_leaf_merge_header_def bn_ds_slots_def)
qed
lemma r3_carry_initial:

  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (NULL,0,0,vals) s"



proof -
  assume PRE: "bn_r2_merge_pre s0 h other P F G ext held N edges"
    and LEN: "n = max (length F) (length G) + 1"
    and AL: "bn_ds_roots_allocation s0 s a n"
  let ?A = "phantom_machine_state_' s0"
  let ?B = "phantom_machine_state_' s"
  let ?slots = "bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext"
  have FV: "bn_ds_forest_view s0 h P F" and GV: "bn_ds_forest_view s0 other P G"
    and GR: "bn_ds_graph s0 P N edges ?slots held {}"
    and ST: "bn_ds_graph_storage s0 N ?slots"
    using PRE by (auto simp: bn_r2_merge_pre_def bn_r2_graph_storage_def)
  have MAL: "malloc_rel (8*n) (hrs_mem (t_hrs_' s0)) ?A (ptr_val a) (hrs_mem (t_hrs_' s)) ?B"
    and AN: "a \<noteq> NULL" and HT: "hrs_htd (t_hrs_' s) = hrs_htd (t_hrs_' s0)"
    using AL by (auto simp: bn_ds_roots_allocation_def)
  have PN: "ptr_val a \<noteq> 0" using AN by (cases a) (simp add: ptr_val_def)
  have W: "allocator_wf ?A" and FR: "fresh_block ?A (ptr_val a) (8*n)"
    and BA: "?B = ?A\<lparr>live_blocks := (live_blocks ?A)(ptr_val a := Some (8*n))\<rparr>"
    using MAL PN by (auto simp: malloc_rel_def)
  have WB: "allocator_wf ?B" and RES: "reserved_bytes ?B = reserved_bytes ?A"
    and LIVE: "\<forall>q m. live_blocks ?A q = Some m \<longrightarrow> live_blocks ?B q = Some m"
    and BF: "\<forall>x \<in> readable_bytes ?A. hrs_mem (t_hrs_' s) x = hrs_mem (t_hrs_' s0) x"
    and SUB: "readable_bytes ?A \<subseteq> readable_bytes ?B"
    using vero_aux_malloc_extension[OF MAL] by blast+
  have HH: "bn_heap s h = bn_heap s0 h"
  proof -
    have GH: "c_guard h" and BH: "block_bytes (ptr_val h) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq> readable_bytes ?A"
      using FV by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
    show ?thesis unfolding bn_heap_def by (rule vero_aux_readable_guarded_value[OF GH BH BF])
  qed
  have HO: "bn_heap s other = bn_heap s0 other"
  proof -
    have GO: "c_guard other" and BO: "block_bytes (ptr_val other) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq> readable_bytes ?A"
      using GV by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
    show ?thesis unfolding bn_heap_def by (rule vero_aux_readable_guarded_value[OF GO BO BF])
  qed
  have RF: "bn_review_root_array_view s (roots_C (bn_heap s0 h)) F"
    apply (rule vero_aux_array_view_extension[OF _ _ BF])
    using FV by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
  have RG: "bn_review_root_array_view s (roots_C (bn_heap s0 other)) G"
    apply (rule vero_aux_array_view_extension[OF _ _ BF])
    using GV by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
  have GT: "bn_ds_graph s P N edges ?slots held {}" and STT: "bn_ds_graph_storage s N ?slots"
    and HN: "\<forall>p \<in> N. bn_tree s p = bn_tree s0 p"
    using vero_aux_graph_extension[OF GR ST WB RES LIVE BF SUB] by blast+
  have GB: "bn_ds_graph_blocks s N = bn_ds_graph_blocks s0 N"
    using HN by (auto simp: bn_ds_graph_blocks_def HN[rule_format])
  have OLD: "bn_r3_old_node_fields s0 N s N"
    using HN by (auto simp: bn_r3_old_node_fields_def HN[rule_format])
  have NL: "live_blocks ?A (ptr_val a) = None" by (rule vero_aux_new_not_live[OF W FR])
  have LA: "live_blocks ?B (ptr_val a) = Some (8*n)" by (simp add: BA)
  have TRAN: "bn_ds_storage_transition s0 (bn_ds_graph_blocks s0 N) s (insert (ptr_val a) (bn_ds_graph_blocks s N))"
    using RES LIVE BF NL BA
    by (auto simp: bn_ds_storage_transition_def GB readable_bytes_def;
      metis (mono_tags, lifting) UN_I UnI2 domI option.sel)

  have SUPPORT0: "bn_r2_slots_supported s0 ?slots (bn_ds_graph_blocks s0 N)"
    using PRE by (auto simp: bn_r2_merge_pre_def bn_r2_graph_storage_def)
  have SUPPORT1: "bn_r2_slots_supported s ?slots (insert (ptr_val a) (bn_ds_graph_blocks s N))"
    by (rule r2_slots_storage_transition[OF SUPPORT0 TRAN])
  have SUPPORT: "bn_r2_slots_supported s ?slots (bn_ds_graph_blocks s N)"
    using SUPPORT1 by (auto simp: bn_r2_slots_supported_def bn_r2_slot_supported_def bn_r2_span_supported_def)
  have STT2: "bn_r2_graph_storage s N ?slots"
    using STT SUPPORT by (simp add: bn_r2_graph_storage_def)
  show ?thesis
    unfolding bn_r2_carry_inv_def
    apply (rule exI[where x="NULL :: StrictC'_BinomialTree_C ptr"])
    apply (rule exI[where x="0 :: 32 word"])
    apply (rule exI[where x="0 :: 32 word"])
    apply (rule exI[where x=vals])
    apply (rule exI[where x="[] :: bn_shape option list"])
    apply (rule exI[where x="None :: bn_shape option"])
    apply (rule exI[where x=N])
    apply (rule exI[where x=edges])
    using HH HO RF RG GT STT2 OLD LA TRAN HT
    by (auto simp: bn_review_root_array_view_def bn_forest_values_def bn_ds_slots_def)
qed
lemma r3_pair_initial_inv:
 "bn_r2_carry_inv vero_aux_pair_state (Ptr 16) (Ptr 512) (block_bytes 192 4)
   [Some (BN (Ptr 64) [])] [Some (BN (Ptr 96) [])] [] {#Ptr 96#} {Ptr 64,Ptr 96}
   (Ptr 256) 2 (NULL,0,0,vals) vero_aux_pair_alloc_state"
 by (rule r3_carry_initial[OF r3_pair_pre _ vero_aux_pair_allocation]) simp
end
definition r3_closed_c0004 :: bool where
 "r3_closed_c0004 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h P T U N edges slots held. bn_r2_tree_merge_pre s h P T U N edges slots held \<longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s (\<lambda>r t.
    if r = NULL then bn_ds_restore s t else
    (\<exists>V N' edges'. bn_root V = r \<and> bn_rank V = bn_rank T + 1 \<and>
      bn_ds_tree_layout t P V \<and> distinct (bn_blocks t V) \<and>
      mset (bn_values t V) = mset (bn_values s T) + mset (bn_values s U) \<and>
      refcount_C (bn_tree t r) = 0 \<and>
      bn_ds_graph t P N' edges' slots held {r} \<and> bn_r2_graph_storage t N' slots \<and>
      N' = insert r N \<and> bn_r3_old_node_fields s N t N' \<and>
      bn_ds_storage_transition s (bn_ds_graph_blocks s N) t (bn_ds_graph_blocks t N')) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a))))"

lemma r3_closed_c0004_iff:
 "r3_closed_c0004 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "r3_closed_c0004"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s h P T U N edges slots held. bn_r2_tree_merge_pre s h P T U N edges slots held \<longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s (\<lambda>r t.
    if r = NULL then bn_ds_restore s t else
    (\<exists>V N' edges'. bn_root V = r \<and> bn_rank V = bn_rank T + 1 \<and>
      bn_ds_tree_layout t P V \<and> distinct (bn_blocks t V) \<and>
      mset (bn_values t V) = mset (bn_values s T) + mset (bn_values s U) \<and>
      refcount_C (bn_tree t r) = 0 \<and>
      bn_ds_graph t P N' edges' slots held {r} \<and> bn_r2_graph_storage t N' slots \<and>
      N' = insert r N \<and> bn_r3_old_node_fields s N t N' \<and>
      bn_ds_storage_transition s (bn_ds_graph_blocks s N) t (bn_ds_graph_blocks t N')) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a))"
      using H A by (simp add: r3_closed_c0004_def)
    note PRE = binomial_heap_input_global_addresses.r3_leaf_tree_merge_pre[OF A]
    have RUN: "bn_contract (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96)) binomial_heap_input_global_addresses.vero_aux_leaf_merge_state (\<lambda>r t. True)"
      by (rule binomial_heap_input_global_addresses.vero_aux_contract_weaken[OF A C[rule_format, OF PRE, simplified]]) simp
    show False using RUN binomial_heap_input_global_addresses.vero_aux_leaf_merge_failure[OF A] by blast
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "r3_closed_c0004" by (simp add: r3_closed_c0004_def)
qed

definition r3_closed_c0041 :: bool where
 "r3_closed_c0041 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h other P F G ext held N edges. bn_r2_merge_pre s h other P F G ext held N edges \<longrightarrow>
  bn_contract (binomial_heap_merge' h other) s (\<lambda>r t.
   if r = 0 then bn_ds_restore s t
   else bn_r2_merge_success s h P F G ext held N t)))"

lemma r3_closed_c0041_iff:
 "r3_closed_c0041 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "r3_closed_c0041"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s h other P F G ext held N edges. bn_r2_merge_pre s h other P F G ext held N edges \<longrightarrow>
  bn_contract (binomial_heap_merge' h other) s (\<lambda>r t.
   if r = 0 then bn_ds_restore s t
   else bn_r2_merge_success s h P F G ext held N t)"
      using H A by (simp add: r3_closed_c0041_def)
    note PRE = binomial_heap_input_global_addresses.r3_pair_pre[OF A]
    have RUN: "bn_contract (binomial_heap_merge' (Ptr 16) (Ptr 512)) binomial_heap_input_global_addresses.vero_aux_pair_state (\<lambda>r t. True)"
      by (rule binomial_heap_input_global_addresses.vero_aux_contract_weaken[OF A C[rule_format, OF PRE, simplified]]) simp
    show False using RUN by (simp add: bn_contract_def binomial_heap_input_global_addresses.vero_aux_pair_heap_merge_failure[OF A])
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "r3_closed_c0041" by (simp add: r3_closed_c0041_def)
qed

definition r3_closed_c0054 :: bool where
 "r3_closed_c0054 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s0 h other P F G ext held N edges n a bn_carry i len vals s. bn_r2_merge_pre s0 h other P F G ext held N edges \<longrightarrow>
  n = max (length F) (length G) + 1 \<longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<longrightarrow>
  unat i < n \<longrightarrow>
  runs_to (binomial_heap_input_global_addresses.bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s
   (\<lambda>r t. case r of Result state \<Rightarrow>
       bn_r2_carry_inv s0 h other P F G ext held N a n state t \<and>
       (\<exists>c l vs. state = (c,i+1,l,vs))
     | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (binomial_heap_input_global_addresses.bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s r t)))"

lemma r3_closed_c0054_iff:
 "r3_closed_c0054 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "r3_closed_c0054"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s0 h other P F G ext held N edges n a bn_carry i len vals s. bn_r2_merge_pre s0 h other P F G ext held N edges \<longrightarrow>
  n = max (length F) (length G) + 1 \<longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<longrightarrow>
  unat i < n \<longrightarrow>
  runs_to (binomial_heap_input_global_addresses.bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s
   (\<lambda>r t. case r of Result state \<Rightarrow>
       bn_r2_carry_inv s0 h other P F G ext held N a n state t \<and>
       (\<exists>c l vs. state = (c,i+1,l,vs))
     | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (binomial_heap_input_global_addresses.bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s r t)"
      using H A by (simp add: r3_closed_c0054_def)
    note PRE = binomial_heap_input_global_addresses.r3_pair_pre[OF A]
    have N: "(2::nat)=max (length [Some (BN (Ptr 64) [])]) (length [Some (BN (Ptr 96) [])])+1" by simp
    note INV = binomial_heap_input_global_addresses.r3_pair_initial_inv[OF A, where vals=undefined]
    have I: "unat (0::32 word)<2" by simp
    note STEP = C[rule_format, OF PRE N INV I]
    show False using STEP
      by (simp add: binomial_heap_input_global_addresses.vero_aux_pair_carry_step_failure[OF A])
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "r3_closed_c0054" by (simp add: r3_closed_c0054_def)
qed

definition r3_closed_c0060 :: bool where
 "r3_closed_c0060 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s0 h other P F G ext held N edges n s a vals. bn_r2_merge_pre s0 h other P F G ext held N edges \<longrightarrow>
  n = max (length F) (length G) + 1 \<longrightarrow>
  bn_ds_roots_allocation s0 s a n \<longrightarrow>
  runs_to (binomial_heap_input_global_addresses.bn_ds_carry_loop h other (of_nat n) a vals) s
    (\<lambda>r t. case r of Result result \<Rightarrow> bn_r2_carry_done s0 h P F G ext held N a n result t
      | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (binomial_heap_input_global_addresses.bn_ds_carry_loop h other (of_nat n) a vals) s r t)))"

lemma r3_closed_c0060_iff:
 "r3_closed_c0060 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "r3_closed_c0060"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s0 h other P F G ext held N edges n s a vals. bn_r2_merge_pre s0 h other P F G ext held N edges \<longrightarrow>
  n = max (length F) (length G) + 1 \<longrightarrow>
  bn_ds_roots_allocation s0 s a n \<longrightarrow>
  runs_to (binomial_heap_input_global_addresses.bn_ds_carry_loop h other (of_nat n) a vals) s
    (\<lambda>r t. case r of Result result \<Rightarrow> bn_r2_carry_done s0 h P F G ext held N a n result t
      | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (binomial_heap_input_global_addresses.bn_ds_carry_loop h other (of_nat n) a vals) s r t)"
      using H A by (simp add: r3_closed_c0060_def)
    note PRE = binomial_heap_input_global_addresses.r3_pair_pre[OF A]
    have N: "(2::nat)=max (length [Some (BN (Ptr 64) [])]) (length [Some (BN (Ptr 96) [])])+1" by simp
    note ALLOC = binomial_heap_input_global_addresses.vero_aux_pair_allocation[OF A]
    note LOOP = C[rule_format, OF PRE N ALLOC]
    show False using LOOP
      by (simp add: binomial_heap_input_global_addresses.vero_aux_pair_carry_loop_failure[OF A])
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "r3_closed_c0060" by (simp add: r3_closed_c0060_def)
qed


definition r3_closed_c0073 :: bool where
 "r3_closed_c0073 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h P T U N edges slots held. bn_r2_tree_merge_pre s h P T U N edges slots held \<longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s
    (\<lambda>r t. r = NULL \<longrightarrow> bn_ds_restore s t)))"

lemma r3_closed_c0073_iff:
 "r3_closed_c0073 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "r3_closed_c0073"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s h P T U N edges slots held. bn_r2_tree_merge_pre s h P T U N edges slots held \<longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s
    (\<lambda>r t. r = NULL \<longrightarrow> bn_ds_restore s t)"
      using H A by (simp add: r3_closed_c0073_def)
    note PRE = binomial_heap_input_global_addresses.r3_leaf_tree_merge_pre[OF A]
    have RUN: "bn_contract (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96)) binomial_heap_input_global_addresses.vero_aux_leaf_merge_state (\<lambda>r t. True)"
      by (rule binomial_heap_input_global_addresses.vero_aux_contract_weaken[OF A C[rule_format, OF PRE, simplified]]) simp
    show False using RUN binomial_heap_input_global_addresses.vero_aux_leaf_merge_failure[OF A] by blast
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "r3_closed_c0073" by (simp add: r3_closed_c0073_def)
qed


context binomial_heap_input_global_addresses begin
r2_capture "0063" "function-address-locale" captured:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (NULL,0,0,vals) s"
r2_prove "0063" checked_0063:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (NULL,0,0,vals) s"
by (fact r3_carry_initial)
r2_capture "0007" "function-address-locale" captured:
  "bn_r2_tree_merge_pre s h P T U N edges slots held \<Longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s (\<lambda>r t.
    if r = NULL then bn_ds_restore s t else
    (\<exists>V N' edges'. bn_root V = r \<and> bn_rank V = bn_rank T + 1 \<and>
      bn_ds_tree_layout t P V \<and> distinct (bn_blocks t V) \<and>
      mset (bn_values t V) = mset (bn_values s T) + mset (bn_values s U) \<and>
      refcount_C (bn_tree t r) = 0 \<and>
      bn_ds_graph t P N' edges' slots held {r} \<and> bn_r2_graph_storage t N' slots \<and>
      N' = insert r N \<and> bn_r3_old_node_fields s N t N' \<and>
      bn_ds_storage_transition s (bn_ds_graph_blocks s N) t (bn_ds_graph_blocks t N')) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a))"
r2_refute "0007" checked_0007
using r3_closed_c0004_iff binomial_heap_input_global_addresses_axioms unfolding r3_closed_c0004_def by blast
r2_capture "0048" "function-address-locale" captured:
  "bn_r2_merge_pre s h other P F G ext held N edges \<Longrightarrow>
  bn_contract (binomial_heap_merge' h other) s (\<lambda>r t.
   if r = 0 then bn_ds_restore s t
   else bn_r2_merge_success s h P F G ext held N t)"
r2_refute "0048" checked_0048
using r3_closed_c0041_iff binomial_heap_input_global_addresses_axioms unfolding r3_closed_c0041_def by blast
r2_capture "0062" "function-address-locale" captured:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<Longrightarrow>
  unat i < n \<Longrightarrow>
  runs_to (bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s
   (\<lambda>r t. case r of Result state \<Rightarrow>
       bn_r2_carry_inv s0 h other P F G ext held N a n state t \<and>
       (\<exists>c l vs. state = (c,i+1,l,vs))
     | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s r t)"
r2_refute "0062" checked_0062
using r3_closed_c0054_iff binomial_heap_input_global_addresses_axioms unfolding r3_closed_c0054_def by blast
r2_capture "0068" "function-address-locale" captured:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  runs_to (bn_ds_carry_loop h other (of_nat n) a vals) s
    (\<lambda>r t. case r of Result result \<Rightarrow> bn_r2_carry_done s0 h P F G ext held N a n result t
      | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (bn_ds_carry_loop h other (of_nat n) a vals) s r t)"
r2_refute "0068" checked_0068
using r3_closed_c0060_iff binomial_heap_input_global_addresses_axioms unfolding r3_closed_c0060_def by blast
r2_capture "0082" "function-address-locale" captured:
  "bn_r2_tree_merge_pre s h P T U N edges slots held \<Longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s
    (\<lambda>r t. r = NULL \<longrightarrow> bn_ds_restore s t)"
r2_refute "0082" checked_0082
using r3_closed_c0073_iff binomial_heap_input_global_addresses_axioms unfolding r3_closed_c0073_def by blast
end
end

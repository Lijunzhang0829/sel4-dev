theory R3_Finish_Contract imports Repair_Phase_Model R3_Finish_Functional begin
context binomial_heap_input_global_addresses begin
lemma r3_finish_storage:
 assumes FB: "bn_r2_finish_base s h P F N edges [slot] {#}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot=p"
 and LEAF: "bn_ds_tree_layout s P (BN p [])"
 and BLOCKS: "bn_owned t h F=bn_owned s h F"
 and EFFECT: "if refcount_C (bn_tree s p)=1 then
   vero_aux_release (r2_dec (r3_count s h result) p) {ptr_val p} {ptr_val p} t
   else t=r2_dec (r3_count s h result) p"
 shows "bn_ds_storage_transition s
   (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
   t (set (bn_owned t h F)) \<and> hrs_htd (t_hrs_' t)=hrs_htd (t_hrs_' s)"
proof -
 let ?nodes="bn_ds_forest_nodes F"
 let ?a="roots_C (bn_heap s h)"
 let ?forest="set (concat (map (case_option [] (bn_blocks s)) F))"
 let ?B="insert (ptr_val h) (insert (ptr_val ?a) (bn_ds_graph_blocks s N))"
 let ?C="set (bn_owned s h F)"
 let ?D="if refcount_C (bn_tree s p)=1 then {ptr_val p} else {}"
 have FV: "bn_ds_forest_view s h P F"
  and GR: "bn_ds_graph s P N edges (bn_ds_slots ?a (length F)@[slot]) {#} {}"
  and ST: "bn_ds_graph_storage s N (bn_ds_slots ?a (length F)@[slot])"
  and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
  and HB: "ptr_val h\<notin>bn_ds_graph_blocks s N"
  and AB: "ptr_val ?a\<notin>bn_ds_graph_blocks s N"
  using FB by (auto simp: bn_r2_finish_base_def bn_r2_graph_storage_def)
 have W: "allocator_wf (phantom_machine_state_' s)" using GR by (simp add: bn_ds_graph_def)
 have GH: "c_guard h" using FV by (simp add: bn_ds_forest_view_def bn_review_header_view_def)
 have GP: "c_guard p" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
  and ORDER: "order_C (bn_tree s p)=0" using LEAF by (auto simp: unat_eq_zero)
 have INV: "N=insert p ?nodes \<and> (\<forall>q\<in>N. unat (refcount_C (bn_tree s q))=
   (if q\<in>?nodes then 1 else 0)+(if q=p then 1 else 0))"
  by (rule r2_finish_leaf_inventory[OF FB READ LEAF])
 have PN: "p\<in>N" and SUB: "?nodes\<subseteq>N" using INV by auto
 have PI: "ptr_val p\<in>ptr_val ` N" by (rule imageI[OF PN])
 have PB: "ptr_val p\<in>bn_ds_graph_blocks s N" using PI by (auto simp: bn_ds_graph_blocks_def)
 have PH: "ptr_val p\<noteq>ptr_val h" and PA: "ptr_val p\<noteq>ptr_val ?a" using PB HB AB by auto
 have RELEASE: "vero_aux_release s ?D {ptr_val h,ptr_val p} t"
  using r3_finish_effects[OF W GH GP LH LP PH EFFECT] by blast
 have L: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_ds_tree_layout s P T"
  using FV by (auto simp: bn_ds_forest_view_def in_set_conv_nth)
 have GB: "bn_ds_graph_blocks s ?nodes=?forest" by (rule r3_forest_blocks[OF L])
 have NN: "N=insert p ?nodes" using INV by blast
 have ADD: "bn_ds_graph_blocks s (insert p ?nodes)=insert (ptr_val p) (bn_ds_graph_blocks s ?nodes)"
  using ORDER by (auto simp: bn_ds_graph_blocks_def)
 have BN: "bn_ds_graph_blocks s N=insert (ptr_val p) ?forest"
  by (simp only: NN ADD GB)
 have BEQ: "?B=insert (ptr_val ?a) (insert (ptr_val p) ?C)"
  by (auto simp: BN bn_owned_def)
 have OUT: "p\<notin>?nodes \<Longrightarrow> ptr_val p\<notin>?forest"
  using r3_extra_leaf_not_block[OF GR ST PN _ SUB] by (simp add: GB)
 have PC: "ptr_val p\<in>?C \<longleftrightarrow> p\<in>?nodes"
 proof
  assume "ptr_val p\<in>?C"
  then have "ptr_val p\<in>?forest" using PH PA by (auto simp: bn_owned_def split: if_splits)
  then show "p\<in>?nodes" using OUT by blast
 next
  assume IN: "p\<in>?nodes"
  have "ptr_val p\<in>ptr_val ` ?nodes" by (rule imageI[OF IN])
  then have "ptr_val p\<in>bn_ds_graph_blocks s ?nodes" by (auto simp: bn_ds_graph_blocks_def)
  then show "ptr_val p\<in>?C" by (auto simp: GB bn_owned_def)
 qed
 have DEQ: "?D=(if p\<in>?nodes then {} else {ptr_val p})"
 proof (cases "p\<in>?nodes")
  case True
  have "unat (refcount_C (bn_tree s p))=2" using INV True by auto
  then have "refcount_C (bn_tree s p)\<noteq>1" by auto
  then show ?thesis using True by simp
 next
  case False
  have RC: "unat (refcount_C (bn_tree s p))=1" using INV False by auto
  have "refcount_C (bn_tree s p)=1"
   using arg_cong[OF RC, where f="\<lambda>n. of_nat n :: 16 word"] by simp
  then show ?thesis using False by simp
 qed
 have ZERO: "live_blocks (phantom_machine_state_' s) 0=None"
  using W by (cases "live_blocks (phantom_machine_state_' s) 0") (auto simp: allocator_wf_def block_ok_def)
 have LIVE: "\<forall>q. q\<notin>?C \<longrightarrow> live_blocks (phantom_machine_state_' t) q=
   (if q\<in>?B then None else live_blocks (phantom_machine_state_' s) q)"
  using RELEASE PC ZERO unfolding vero_aux_release_def
  by (auto simp: BEQ DEQ bn_owned_def split: if_splits)
 have MEM: "\<forall>q n. live_blocks (phantom_machine_state_' s) q=Some n \<longrightarrow> q\<notin>?B \<longrightarrow>
   (\<forall>x\<in>block_bytes q n. hrs_mem (t_hrs_' t) x=hrs_mem (t_hrs_' s) x)"
  using RELEASE BEQ by (auto simp: vero_aux_release_def)
 show ?thesis using RELEASE LIVE MEM BLOCKS BEQ
  by (auto simp: bn_ds_storage_transition_def vero_aux_release_def)
qed

lemma r3_spec_0042:
  "bn_r2_finish_base s h P G N edges [slot] {#} \<Longrightarrow>
  bn_r2_slot_supported s slot (insert (ptr_val h) (bn_ds_graph_blocks s N)) \<Longrightarrow>
  c_guard slot \<Longrightarrow> h_val (hrs_mem (t_hrs_' s)) slot = tree \<Longrightarrow>
  bn_ds_tree_layout s P (BN tree []) \<Longrightarrow> value_C (bn_tree s tree) = v \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow> size M + 1 < 2^32 \<Longrightarrow>
  mset (bn_forest_values s G) = (if result = 0 then M else add_mset v M) \<Longrightarrow>
  bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
    r = result \<and> bn_rep t h P G (if result = 0 then M else add_mset v M) \<and>
    bn_ds_storage_transition s
      (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
      t (set (bn_owned t h G)) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"
proof -
 assume FB: "bn_r2_finish_base s h P G N edges [slot] {#}"
  and SLOT: "bn_r2_slot_supported s slot (insert (ptr_val h) (bn_ds_graph_blocks s N))"
  and GS: "c_guard slot" and READ: "h_val (hrs_mem (t_hrs_' s)) slot=tree"
  and LEAF: "bn_ds_tree_layout s P (BN tree [])" and VALUE: "value_C (bn_tree s tree)=v"
  and NUM: "unat (num_values_C (bn_heap s h))=size M" and BOUND: "size M+1<2^32"
  and MASS: "mset (bn_forest_values s G)=(if result=0 then M else add_mset v M)"
 have W: "allocator_wf (phantom_machine_state_' s)" and GH: "c_guard h"
  and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
  and HB: "ptr_val h\<notin>bn_ds_graph_blocks s N"
  using FB by (auto simp: bn_r2_finish_base_def bn_ds_graph_def bn_ds_forest_view_def bn_review_header_view_def)
 have GP: "c_guard tree" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val tree)=Some 24"
  and ORDER: "order_C (bn_tree s tree)=0" and ARRAY: "subtrees_C (bn_tree s tree)=NULL"
  using LEAF by (auto simp: unat_eq_zero)
 have INV: "N=insert tree (bn_ds_forest_nodes G) \<and> (\<forall>q\<in>N. unat (refcount_C (bn_tree s q))=
   (if q\<in>bn_ds_forest_nodes G then 1 else 0)+(if q=tree then 1 else 0))"
  by (rule r2_finish_leaf_inventory[OF FB READ LEAF])
 have POS: "0<unat (refcount_C (bn_tree s tree))" using INV by auto
 have PI: "ptr_val tree\<in>ptr_val ` N" using INV by auto
 have PB: "ptr_val tree\<in>bn_ds_graph_blocks s N" using PI by (auto simp: bn_ds_graph_blocks_def)
 have NE: "ptr_val tree\<noteq>ptr_val h" using HB PB by auto
 have SLOT0: "bn_r2_slot_supported s slot {ptr_val h}"
  using SLOT by (auto simp: bn_r2_slot_supported_def bn_r2_span_supported_def)
 note EXEC = r3_insert_execution[OF W GH GP LH LP NE SLOT0 READ ORDER ARRAY POS, where result=result]
 show ?thesis
 proof (rule vero_aux_contract_weaken[OF EXEC])
  fix r t assume RT: "r=result \<and> (if refcount_C (bn_tree s tree)=1 then
    vero_aux_release (r2_dec (r3_count s h result) tree) {ptr_val tree} {ptr_val tree} t
    else t=r2_dec (r3_count s h result) tree)"
  have EFFECT: "if refcount_C (bn_tree s tree)=1 then
    vero_aux_release (r2_dec (r3_count s h result) tree) {ptr_val tree} {ptr_val tree} t
    else t=r2_dec (r3_count s h result) tree" using RT by blast
  note REP = r3_finish_functional[OF FB READ LEAF VALUE NUM BOUND MASS EFFECT]
  have BLOCKS: "bn_owned t h G=bn_owned s h G" using REP by blast
  note STORAGE = r3_finish_storage[OF FB READ LEAF BLOCKS EFFECT]
  show "r=result \<and> bn_rep t h P G (if result=0 then M else add_mset v M) \<and>
   bn_ds_storage_transition s (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
    t (set (bn_owned t h G)) \<and> hrs_htd (t_hrs_' t)=hrs_htd (t_hrs_' s)"
   using RT REP STORAGE by blast
 qed
qed
ML \<open>
 val thms = @{thms r3_finish_storage r3_spec_0042};
 val _ = if Thm_Deps.has_skip_proof thms then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles thms) then () else error "oracle";
 writeln "R3_FULL_0042_PASS";
\<close>
end
end

theory Current_Preparation_2 imports R3_Finish_Contract R3_Consumer_Bridges Owned_Context_Protocol begin

context binomial_heap_input_global_addresses begin

r2_capture "0042" "function-address-locale" captured:
  "bn_r2_finish_base s h P G N edges [slot] {#} \<Longrightarrow>
  bn_r2_slot_supported s slot (insert (ptr_val h) (bn_ds_graph_blocks s N)) \<Longrightarrow>
  c_guard slot \<Longrightarrow> h_val (hrs_mem (t_hrs_' s)) slot = tree \<Longrightarrow>
  bn_ds_tree_layout s P (BN tree []) \<Longrightarrow> value_C (bn_tree s tree) = v \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow> size M + 1 < 2^32 \<Longrightarrow>
  mset (bn_forest_values s G) = (if result = 0 then M else add_mset v M) \<Longrightarrow>
  bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
    r = result \<and> bn_rep t h P G (if result = 0 then M else add_mset v M) \<and>
    bn_ds_storage_transition s
      (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
      t (set (bn_owned t h G)) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

r2_prove "0042" checked_0042:
  "bn_r2_finish_base s h P G N edges [slot] {#} \<Longrightarrow>
  bn_r2_slot_supported s slot (insert (ptr_val h) (bn_ds_graph_blocks s N)) \<Longrightarrow>
  c_guard slot \<Longrightarrow> h_val (hrs_mem (t_hrs_' s)) slot = tree \<Longrightarrow>
  bn_ds_tree_layout s P (BN tree []) \<Longrightarrow> value_C (bn_tree s tree) = v \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow> size M + 1 < 2^32 \<Longrightarrow>
  mset (bn_forest_values s G) = (if result = 0 then M else add_mset v M) \<Longrightarrow>
  bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
    r = result \<and> bn_rep t h P G (if result = 0 then M else add_mset v M) \<and>
    bn_ds_storage_transition s
      (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
      t (set (bn_owned t h G)) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

by (fact r3_spec_0042)

end

r2_capture "0053" "global" captured:
  "bn_rep s h P F M \<Longrightarrow>
  bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {} \<and>
  bn_r2_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"

r2_prove "0053" checked_0053:
  "bn_rep s h P F M \<Longrightarrow>
  bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {} \<and>
  bn_r2_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"

by (fact r3_spec_0053)

context binomial_heap_input_global_addresses begin

r2_capture "0083" "function-address-locale" captured:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<Longrightarrow>
  unat i = n \<Longrightarrow>
  bn_r2_carry_done s0 h P F G ext held N a n (bn_carry,i,len,vals) s"

r2_prove "0083" checked_0083:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<Longrightarrow>
  unat i = n \<Longrightarrow>
  bn_r2_carry_done s0 h P F G ext held N a n (bn_carry,i,len,vals) s"

by (fact r3_spec_0083)

end

end
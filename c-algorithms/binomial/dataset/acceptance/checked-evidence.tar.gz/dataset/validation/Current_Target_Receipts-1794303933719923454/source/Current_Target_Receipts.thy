theory Current_Target_Receipts imports Current_Preparation_1 Current_Preparation_2 Current_Preparation_3 Current_Preparation_4 Current_Preparation_5 Owned_Context_Protocol begin

context binomial_heap_input_global_addresses begin

r2_capture "0001" "function-address-locale" captured:
  "c_guard h \<Longrightarrow>
   heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
   compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
   c_guard (ptr_coerce v :: 32 signed word ptr) \<Longrightarrow>
   runs_to (binomial_heap_cmp' h v v) s Q = Q (Result 0) s"

r2_prove "0001" current_checked_0001:
  "c_guard h \<Longrightarrow>
   heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
   compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
   c_guard (ptr_coerce v :: 32 signed word ptr) \<Longrightarrow>
   runs_to (binomial_heap_cmp' h v v) s Q = Q (Result 0) s"

by (fact checked_0001)

end

r2_capture "0002" "global" captured:
  "fresh_block A p n \<Longrightarrow> live_blocks A q = Some m \<Longrightarrow>
    block_bytes p n \<inter> block_bytes q m = {}"

r2_prove "0002" current_checked_0002:
  "fresh_block A p n \<Longrightarrow> live_blocks A q = Some m \<Longrightarrow>
    block_bytes p n \<inter> block_bytes q m = {}"

by (fact checked_0002)

context binomial_heap_input_global_addresses begin

r2_capture "0004" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
  bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j)) \<Longrightarrow>
  bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>(i',j') t.
    t = s \<and> i' = i + 1 \<and>
    bn_review_scan_prefix s F (unat i') (if j' = 0xFFFFFFFF then None else Some (unat j')))"

r2_prove "0004" current_checked_0004:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
  bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j)) \<Longrightarrow>
  bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>(i',j') t.
    t = s \<and> i' = i + 1 \<and>
    bn_review_scan_prefix s F (unat i') (if j' = 0xFFFFFFFF then None else Some (unat j')))"

by (fact checked_0004)

end

context binomial_heap_input_global_addresses begin

r2_capture "0007" "function-address-locale" captured:
  "bn_r2_tree_merge_pre s h P T U N edges slots held \<Longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s (\<lambda>r t.
    if r = NULL then bn_ds_restore s t else
    (\<exists>V N' edges'. bn_root V = r \<and> bn_rank V = bn_rank T + 1 \<and>
      bn_ds_tree_layout t P V \<and> distinct (bn_blocks t V) \<and>
      mset (bn_values t V) = mset (bn_values s T) + mset (bn_values s U) \<and>
      refcount_C (bn_tree t r) = 0 \<and>
      bn_ds_graph t P N' edges' slots held {r} \<and> bn_r2_graph_storage t N' slots \<and>
      N' = insert r N \<and> bn_r3_old_node_fields s N t N' \<and>
      bn_ds_storage_transition s (bn_ds_graph_blocks s N) t (bn_ds_graph_blocks t N')) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a))"

r2_refute "0007" current_checked_0007

by (fact checked_0007)

end

context binomial_heap_input_global_addresses begin

r2_capture "0008" "function-address-locale" captured:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow> c_guard h \<Longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_valid s P (BN p []) \<Longrightarrow> bn_valid s P (BN q []) \<Longrightarrow> p \<noteq> q \<Longrightarrow>
    live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C)) \<Longrightarrow>
    ptr_val h \<noteq> ptr_val p \<Longrightarrow> ptr_val h \<noteq> ptr_val q \<Longrightarrow>
    bn_contract (binomial_tree_merge' h p q) s (\<lambda>r t. True)"

r2_refute "0008" current_checked_0008

by (fact checked_0008)

end

r2_capture "0009" "global" captured:
  "bn_stack_ready S s \<Longrightarrow>
   \<exists>p d q e.
     (p,d) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<and>
     (q,e) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialTree_C ptr) d"

r2_prove "0009" current_checked_0009:
  "bn_stack_ready S s \<Longrightarrow>
   \<exists>p d q e.
     (p,d) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<and>
     (q,e) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialTree_C ptr) d"

by (fact checked_0009)

context binomial_heap_input_global_addresses begin

r2_capture "0010" "function-address-locale" captured:
  "c_guard p \<Longrightarrow> 1 < unat (refcount_C (bn_tree s p)) \<Longrightarrow>
    bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) - 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

r2_prove "0010" current_checked_0010:
  "c_guard p \<Longrightarrow> 1 < unat (refcount_C (bn_tree s p)) \<Longrightarrow>
    bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) - 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

by (fact checked_0010)

end

r2_capture "0011" "global" captured:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"

r2_prove "0011" current_checked_0011:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"

by (fact checked_0011)

context binomial_heap_input_global_addresses begin

r2_capture "0012" "function-address-locale" captured:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_contract calg_binomial_new' s (\<lambda>h t.
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        live_blocks (phantom_machine_state_' t) p = Some n \<and>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)) \<and>
      (if h = NULL then phantom_machine_state_' t = phantom_machine_state_' s else
        bn_rep t h P [] {#} \<and> roots_C (bn_heap t h) = NULL \<and>
        phantom_machine_state_' t = (phantom_machine_state_' s)\<lparr>live_blocks :=
          (live_blocks (phantom_machine_state_' s))(ptr_val h := Some (size_of TYPE(StrictC'_BinomialHeap_C)))\<rparr>))"

r2_prove "0012" current_checked_0012:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_contract calg_binomial_new' s (\<lambda>h t.
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        live_blocks (phantom_machine_state_' t) p = Some n \<and>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)) \<and>
      (if h = NULL then phantom_machine_state_' t = phantom_machine_state_' s else
        bn_rep t h P [] {#} \<and> roots_C (bn_heap t h) = NULL \<and>
        phantom_machine_state_' t = (phantom_machine_state_' s)\<lparr>live_blocks :=
          (live_blocks (phantom_machine_state_' s))(ptr_val h := Some (size_of TYPE(StrictC'_BinomialHeap_C)))\<rparr>))"

by (fact checked_0012)

end

r2_capture "0013" "global" captured:
  "bn_valid s P T \<Longrightarrow> refcount_C (bn_tree s (bn_root T)) = 1"

r2_prove "0013" current_checked_0013:
  "bn_valid s P T \<Longrightarrow> refcount_C (bn_tree s (bn_root T)) = 1"

by (fact checked_0013)

r2_capture "0014" "global" captured:
  "bn_rep s h P F M \<Longrightarrow>
    length F \<le> 32 \<and> unat (roots_length_C (bn_heap s h)) = length F"

r2_prove "0014" current_checked_0014:
  "bn_rep s h P F M \<Longrightarrow>
    length F \<le> 32 \<and> unat (roots_length_C (bn_heap s h)) = length F"

by (fact checked_0014)

r2_capture "0015" "global" captured:
  "bn_r2_finish_base s h P F N edges [] {#} \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow>
  M = mset (bn_forest_values s F) \<Longrightarrow> bn_rep s h P F M"

r2_prove "0015" current_checked_0015:
  "bn_r2_finish_base s h P F N edges [] {#} \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow>
  M = mset (bn_forest_values s F) \<Longrightarrow> bn_rep s h P F M"

by (fact checked_0015)

context binomial_heap_input_global_addresses begin

r2_capture "0016" "function-address-locale" captured:
  "c_guard h \<Longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
    bn_payload P x \<Longrightarrow> bn_payload P y \<Longrightarrow>
    bn_contract (binomial_heap_cmp' h x y) s (\<lambda>r t.
      t = s \<and> ((r <s 0) \<longleftrightarrow> bn_key s x < bn_key s y) \<and>
      ((r = 0) \<longleftrightarrow> bn_key s x = bn_key s y))"

r2_prove "0016" current_checked_0016:
  "c_guard h \<Longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
    bn_payload P x \<Longrightarrow> bn_payload P y \<Longrightarrow>
    bn_contract (binomial_heap_cmp' h x y) s (\<lambda>r t.
      t = s \<and> ((r <s 0) \<longleftrightarrow> bn_key s x < bn_key s y) \<and>
      ((r = 0) \<longleftrightarrow> bn_key s x = bn_key s y))"

by (fact checked_0016)

end

r2_capture "0017" "global" captured:
  "memcpy_ok A dst src 0 \<Longrightarrow> dst \<noteq> 0 \<and> src \<noteq> 0"

r2_prove "0017" current_checked_0017:
  "memcpy_ok A dst src 0 \<Longrightarrow> dst \<noteq> 0 \<and> src \<noteq> 0"

by (fact checked_0017)

r2_capture "0018" "global" captured:
  "free_rel p hp A hp' B \<Longrightarrow> q \<noteq> p \<Longrightarrow>
    live_blocks B q = live_blocks A q"

r2_prove "0018" current_checked_0018:
  "free_rel p hp A hp' B \<Longrightarrow> q \<noteq> p \<Longrightarrow>
    live_blocks B q = live_blocks A q"

by (fact checked_0018)

r2_capture "0020" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> W \<subseteq> V \<Longrightarrow> bytes_frame V hp hp'"

r2_prove "0020" current_checked_0020:
  "bytes_frame W hp hp' \<Longrightarrow> W \<subseteq> V \<Longrightarrow> bytes_frame V hp hp'"

by (fact checked_0020)

context binomial_heap_input_global_addresses begin

r2_capture "0021" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_contract (bn_ds_scan h) s (\<lambda>(i,j) t.
   t = s \<and> unat i = length F \<and> unat j < length F \<and>
   (\<exists>T. F ! unat j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
    (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)))"

r2_prove "0021" current_checked_0021:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_contract (bn_ds_scan h) s (\<lambda>(i,j) t.
   t = s \<and> unat i = length F \<and> unat j < length F \<and>
   (\<exists>T. F ! unat j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
    (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)))"

by (fact checked_0021)

end

context binomial_heap_input_global_addresses begin

r2_capture "0022" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
    \<exists>i T. i < length F \<and> F ! i = Some T \<and>
      value_C (bn_tree s (bn_root T)) \<in># M \<and>
      (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

r2_prove "0022" current_checked_0022:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
    \<exists>i T. i < length F \<and> F ! i = Some T \<and>
      value_C (bn_tree s (bn_root T)) \<in># M \<and>
      (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

by (fact checked_0022)

end

r2_capture "0023" "global" captured:
  "bytes_frame W hp hp"

r2_prove "0023" current_checked_0023:
  "bytes_frame W hp hp"

by (fact checked_0023)

r2_capture "0024" "global" captured:
  "c_guard (p :: 'a::mem_type ptr) \<Longrightarrow>
   c_guard (q :: 'b::mem_type ptr) \<Longrightarrow>
   ptr_span p \<inter> ptr_span q = {} \<Longrightarrow>
   h_val (heap_update p v m) q = h_val m q"

r2_prove "0024" current_checked_0024:
  "c_guard (p :: 'a::mem_type ptr) \<Longrightarrow>
   c_guard (q :: 'b::mem_type ptr) \<Longrightarrow>
   ptr_span p \<inter> ptr_span q = {} \<Longrightarrow>
   h_val (heap_update p v m) q = h_val m q"

by (fact checked_0024)

r2_capture "0025" "global" captured:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow>
   allocator_wf (A\<lparr>live_blocks := (live_blocks A)(p := Some n)\<rparr>)"

r2_prove "0025" current_checked_0025:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow>
   allocator_wf (A\<lparr>live_blocks := (live_blocks A)(p := Some n)\<rparr>)"

by (fact checked_0025)

r2_capture "0026" "global" captured:
  "malloc_rel n hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    live_blocks B p = Some n \<and> reserved_bytes B = reserved_bytes A \<and>
    (\<forall>q. q \<noteq> p \<longrightarrow> live_blocks B q = live_blocks A q)"

r2_prove "0026" current_checked_0026:
  "malloc_rel n hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    live_blocks B p = Some n \<and> reserved_bytes B = reserved_bytes A \<and>
    (\<forall>q. q \<noteq> p \<longrightarrow> live_blocks B q = live_blocks A q)"

by (fact checked_0026)

r2_capture "0027" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> a \<notin> W \<Longrightarrow> hp' a = hp a"

r2_prove "0027" current_checked_0027:
  "bytes_frame W hp hp' \<Longrightarrow> a \<notin> W \<Longrightarrow> hp' a = hp a"

by (fact checked_0027)

context binomial_heap_input_global_addresses begin

r2_capture "0029" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_free' h) s (\<lambda>r t.
    bn_frame s h P F t \<and> allocator_wf (phantom_machine_state_' t) \<and>
    live_blocks (phantom_machine_state_' t) =
      (\<lambda>p. if p \<in> set (bn_owned s h F) then None else live_blocks (phantom_machine_state_' s) p))"

r2_prove "0029" current_checked_0029:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_free' h) s (\<lambda>r t.
    bn_frame s h P F t \<and> allocator_wf (phantom_machine_state_' t) \<and>
    live_blocks (phantom_machine_state_' t) =
      (\<lambda>p. if p \<in> set (bn_owned s h F) then None else live_blocks (phantom_machine_state_' s) p))"

by (fact checked_0029)

end

context binomial_heap_input_global_addresses begin

r2_capture "0030" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    (\<And>p. \<not> fresh_block (phantom_machine_state_' s) p (size_of TYPE(StrictC'_BinomialTree_C))) \<Longrightarrow>
    bn_contract (binomial_heap_insert' h v) s (\<lambda>r t.
      r = 0 \<and> bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

r2_prove "0030" current_checked_0030:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    (\<And>p. \<not> fresh_block (phantom_machine_state_' s) p (size_of TYPE(StrictC'_BinomialTree_C))) \<Longrightarrow>
    bn_contract (binomial_heap_insert' h v) s (\<lambda>r t.
      r = 0 \<and> bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

by (fact checked_0030)

end

context binomial_heap_input_global_addresses begin

r2_capture "0031" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_review_scan_prefix s F 0 None"

r2_prove "0031" current_checked_0031:
  "bn_rep s h P F M \<Longrightarrow> bn_review_scan_prefix s F 0 None"

by (fact checked_0031)

end

r2_capture "0032" "global" captured:
  "length (bn_values s (BN p cs)) = Suc (sum_list (map (\<lambda>T. length (bn_values s T)) cs))"

r2_prove "0032" current_checked_0032:
  "length (bn_values s (BN p cs)) = Suc (sum_list (map (\<lambda>T. length (bn_values s T)) cs))"

by (fact checked_0032)

context Calg_Binomial_Reviewed_Stack begin

r2_capture "0033" "reviewed-stack-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_payload P v \<Longrightarrow>
    size M + 1 < 2 ^ 32 \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_insert' h v) s (\<lambda>r t.
      bn_frame s h P F t \<and>
      (if r = 0 then (\<exists>F'. bn_rep t h P F' M) \<and>
        live_blocks (phantom_machine_state_' t) = live_blocks (phantom_machine_state_' s)
       else \<exists>F'. bn_rep t h P F' (add_mset v M) \<and> bn_storage_transition s h F t F'))"

r2_refute "0033" current_checked_0033

by (fact checked_0033)

end

context binomial_heap_input_global_addresses begin

r2_capture "0035" "function-address-locale" captured:
  "runs_to (malloc' n >>= k) s Q \<Longrightarrow>
   malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) p m A \<Longrightarrow>
   runs_to (k (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. m)) s)
       \<lparr>phantom_machine_state_' := A\<rparr>) Q"

r2_prove "0035" current_checked_0035:
  "runs_to (malloc' n >>= k) s Q \<Longrightarrow>
   malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) p m A \<Longrightarrow>
   runs_to (k (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. m)) s)
       \<lparr>phantom_machine_state_' := A\<rparr>) Q"

by (fact checked_0035)

end

r2_capture "0036" "global" captured:
  "calloc_rel item_count item_width hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    i < item_count * item_width \<Longrightarrow> hp' (p + of_nat i) = 0"

r2_prove "0036" current_checked_0036:
  "calloc_rel item_count item_width hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    i < item_count * item_width \<Longrightarrow> hp' (p + of_nat i) = 0"

by (fact checked_0036)

r2_capture "0037" "global" captured:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   S \<subseteq> reserved_bytes A \<Longrightarrow> bytes_frame S hp hp' \<Longrightarrow>
   h_val hp' (p +\<^sub>p int i) = h_val hp (p +\<^sub>p int i)"

r2_prove "0037" current_checked_0037:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   S \<subseteq> reserved_bytes A \<Longrightarrow> bytes_frame S hp hp' \<Longrightarrow>
   h_val hp' (p +\<^sub>p int i) = h_val hp (p +\<^sub>p int i)"

by (fact checked_0037)

context binomial_heap_input_global_addresses begin

r2_capture "0038" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_review_scan_prefix s F (length F) (Some j) \<Longrightarrow>
  \<exists>T. F ! j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
   (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

r2_prove "0038" current_checked_0038:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_review_scan_prefix s F (length F) (Some j) \<Longrightarrow>
  \<exists>T. F ! j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
   (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

by (fact checked_0038)

end

r2_capture "0039" "global" captured:
  "bn_rep s h P F {#} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_rep t h P F {#}"

r2_prove "0039" current_checked_0039:
  "bn_rep s h P F {#} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_rep t h P F {#}"

by (fact checked_0039)

r2_capture "0040" "global" captured:
  "i < length F \<Longrightarrow>
    mset (bn_forest_values s (F[i := None])) +
      mset (case_option [] (bn_values s) (F ! i)) = mset (bn_forest_values s F)"

r2_prove "0040" current_checked_0040:
  "i < length F \<Longrightarrow>
    mset (bn_forest_values s (F[i := None])) +
      mset (case_option [] (bn_values s) (F ! i)) = mset (bn_forest_values s F)"

by (fact checked_0040)

context binomial_heap_input_global_addresses begin

r2_capture "0041" "function-address-locale" captured:
  "runs_to (malloc' n) s Q \<Longrightarrow>
   fresh_block (phantom_machine_state_' s) p (unat n) \<Longrightarrow>
   Q (Result (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' s))) s)
       \<lparr>phantom_machine_state_' :=
         (phantom_machine_state_' s)\<lparr>live_blocks :=
           (live_blocks (phantom_machine_state_' s))(p := Some (unat n))\<rparr>\<rparr>)"

r2_prove "0041" current_checked_0041:
  "runs_to (malloc' n) s Q \<Longrightarrow>
   fresh_block (phantom_machine_state_' s) p (unat n) \<Longrightarrow>
   Q (Result (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' s))) s)
       \<lparr>phantom_machine_state_' :=
         (phantom_machine_state_' s)\<lparr>live_blocks :=
           (live_blocks (phantom_machine_state_' s))(p := Some (unat n))\<rparr>\<rparr>)"

by (fact checked_0041)

end

context binomial_heap_input_global_addresses begin

r2_capture "0042" "function-address-locale" captured:
  "bn_r2_finish_base s h P G N edges [slot] {#} \<Longrightarrow>
  bn_r2_slot_supported s slot (insert (ptr_val h) (bn_ds_graph_blocks s N)) \<Longrightarrow>
  c_guard slot \<Longrightarrow> h_val (hrs_mem (t_hrs_' s)) slot = tree \<Longrightarrow>
  bn_ds_tree_layout s P (BN tree []) \<Longrightarrow> value_C (bn_tree s tree) = v \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow> size M + 1 < 2^32 \<Longrightarrow>
  mset (bn_forest_values s G) = (if result = 0 then M else add_mset v M) \<Longrightarrow>
  bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
    r = result \<and> bn_rep t h P G (if result = 0 then M else add_mset v M) \<and>
    bn_ds_storage_transition s
      (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
      t (set (bn_owned t h G)) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

r2_prove "0042" current_checked_0042:
  "bn_r2_finish_base s h P G N edges [slot] {#} \<Longrightarrow>
  bn_r2_slot_supported s slot (insert (ptr_val h) (bn_ds_graph_blocks s N)) \<Longrightarrow>
  c_guard slot \<Longrightarrow> h_val (hrs_mem (t_hrs_' s)) slot = tree \<Longrightarrow>
  bn_ds_tree_layout s P (BN tree []) \<Longrightarrow> value_C (bn_tree s tree) = v \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow> size M + 1 < 2^32 \<Longrightarrow>
  mset (bn_forest_values s G) = (if result = 0 then M else add_mset v M) \<Longrightarrow>
  bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
    r = result \<and> bn_rep t h P G (if result = 0 then M else add_mset v M) \<and>
    bn_ds_storage_transition s
      (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
      t (set (bn_owned t h G)) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

by (fact checked_0042)

end

context binomial_heap_input_global_addresses begin

r2_capture "0044" "function-address-locale" captured:
  "stack_allocs 1 \<S> TYPE('a::mem_type) (hrs_htd (t_hrs_' s)) \<noteq> {} \<Longrightarrow>
   (\<And>p d v bs.
      (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
      length bs = size_of TYPE('a) \<Longrightarrow>
      bn_contract ((c :: 'a ptr \<Rightarrow> ('e::default, 'b, globals) spec_monad) p)
        (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))
        (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE('a) \<longrightarrow>
          Q r (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)))) \<Longrightarrow>
   bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) c) s Q"

r2_prove "0044" current_checked_0044:
  "stack_allocs 1 \<S> TYPE('a::mem_type) (hrs_htd (t_hrs_' s)) \<noteq> {} \<Longrightarrow>
   (\<And>p d v bs.
      (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
      length bs = size_of TYPE('a) \<Longrightarrow>
      bn_contract ((c :: 'a ptr \<Rightarrow> ('e::default, 'b, globals) spec_monad) p)
        (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))
        (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE('a) \<longrightarrow>
          Q r (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)))) \<Longrightarrow>
   bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) c) s Q"

by (fact checked_0044)

end

r2_capture "0045" "global" captured:
  "free_rel 0 hp A hp' B \<Longrightarrow> hp' = hp \<and> B = A"

r2_prove "0045" current_checked_0045:
  "free_rel 0 hp A hp' B \<Longrightarrow> hp' = hp \<and> B = A"

by (fact checked_0045)

r2_capture "0046" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> P \<inter> W = {} \<Longrightarrow>
    \<forall>a \<in> P. hp' a = hp a"

r2_prove "0046" current_checked_0046:
  "bytes_frame W hp hp' \<Longrightarrow> P \<inter> W = {} \<Longrightarrow>
    \<forall>a \<in> P. hp' a = hp a"

by (fact checked_0046)

r2_capture "0047" "global" captured:
  "hd (bn_values s T) = value_C (bn_tree s (bn_root T))"

r2_prove "0047" current_checked_0047:
  "hd (bn_values s T) = value_C (bn_tree s (bn_root T))"

by (fact checked_0047)

context binomial_heap_input_global_addresses begin

r2_capture "0048" "function-address-locale" captured:
  "bn_r2_merge_pre s h other P F G ext held N edges \<Longrightarrow>
  bn_contract (binomial_heap_merge' h other) s (\<lambda>r t.
   if r = 0 then bn_ds_restore s t
   else bn_r2_merge_success s h P F G ext held N t)"

r2_refute "0048" current_checked_0048

by (fact checked_0048)

end

r2_capture "0049" "global" captured:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   P \<inter> S = {} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_frame s h P F t"

r2_prove "0049" current_checked_0049:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   P \<inter> S = {} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_frame s h P F t"

by (fact checked_0049)

context binomial_heap_input_global_addresses begin

r2_capture "0050" "function-address-locale" captured:
  "\<not> runs_to (memcpy' dst NULL n >>= k) s Q"

r2_prove "0050" current_checked_0050:
  "\<not> runs_to (memcpy' dst NULL n >>= k) s Q"

by (fact checked_0050)

end

r2_capture "0051" "global" captured:
  "bn_rep s h P F M \<Longrightarrow> distinct (bn_owned s h F) \<and>
    ptr_val h \<in> set (bn_owned s h F)"

r2_prove "0051" current_checked_0051:
  "bn_rep s h P F M \<Longrightarrow> distinct (bn_owned s h F) \<and>
    ptr_val h \<in> set (bn_owned s h F)"

by (fact checked_0051)

context Calg_Binomial_Reviewed_Stack begin

r2_capture "0052" "reviewed-stack-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_pop' h) s (\<lambda>r t. bn_frame s h P F t \<and>
      (if r = NULL then (\<exists>F'. bn_rep t h P F' M) \<and>
        live_blocks (phantom_machine_state_' t) = live_blocks (phantom_machine_state_' s)
       else r \<in># M \<and> (\<forall>q \<in># M. bn_key s r \<le> bn_key s q) \<and>
         (\<exists>F'. bn_rep t h P F' (M - {#r#}) \<and> bn_storage_transition s h F t F')))"

r2_refute "0052" current_checked_0052

by (fact checked_0052)

end

r2_capture "0053" "global" captured:
  "bn_rep s h P F M \<Longrightarrow>
  bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {} \<and>
  bn_r2_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"

r2_prove "0053" current_checked_0053:
  "bn_rep s h P F M \<Longrightarrow>
  bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {} \<and>
  bn_r2_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"

by (fact checked_0053)

r2_capture "0055" "global" captured:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q) \<Longrightarrow>
   bn_contract (f >>= g) s Q"

r2_prove "0055" current_checked_0055:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q) \<Longrightarrow>
   bn_contract (f >>= g) s Q"

by (fact checked_0055)

context binomial_heap_input_global_addresses begin

r2_capture "0056" "function-address-locale" captured:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_valid s P T \<Longrightarrow> distinct (bn_blocks s T) \<Longrightarrow>
    bn_contract (binomial_tree_unref' (bn_root T)) s (\<lambda>r t.
      allocator_wf (phantom_machine_state_' t) \<and>
      reserved_bytes (phantom_machine_state_' t) = reserved_bytes (phantom_machine_state_' s) \<and>
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      live_blocks (phantom_machine_state_' t) =
        (\<lambda>p. if p \<in> set (bn_blocks s T) then None else live_blocks (phantom_machine_state_' s) p) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        p \<notin> set (bn_blocks s T) \<longrightarrow>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)))"

r2_prove "0056" current_checked_0056:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_valid s P T \<Longrightarrow> distinct (bn_blocks s T) \<Longrightarrow>
    bn_contract (binomial_tree_unref' (bn_root T)) s (\<lambda>r t.
      allocator_wf (phantom_machine_state_' t) \<and>
      reserved_bytes (phantom_machine_state_' t) = reserved_bytes (phantom_machine_state_' s) \<and>
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      live_blocks (phantom_machine_state_' t) =
        (\<lambda>p. if p \<in> set (bn_blocks s T) then None else live_blocks (phantom_machine_state_' s) p) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        p \<notin> set (bn_blocks s T) \<longrightarrow>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)))"

by (fact checked_0056)

end

context binomial_heap_input_global_addresses begin

r2_capture "0057" "function-address-locale" captured:
  "bn_valid s P T \<Longrightarrow> q \<in> set (bn_values s T) \<Longrightarrow>
    bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q"

r2_prove "0057" current_checked_0057:
  "bn_valid s P T \<Longrightarrow> q \<in> set (bn_values s T) \<Longrightarrow>
    bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q"

by (fact checked_0057)

end

r2_capture "0058" "global" captured:
  "ptr_val (bn_root T) \<in> set (bn_blocks s T)"

r2_prove "0058" current_checked_0058:
  "ptr_val (bn_root T) \<in> set (bn_blocks s T)"

by (fact checked_0058)

context binomial_heap_input_global_addresses begin

r2_capture "0060" "function-address-locale" captured:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  bn_ds_restore (bn_review_clear_root entry h i) s \<Longrightarrow>
  bn_contract (bn_ds_pop_restore h (of_nat i) (bn_root T)) s (\<lambda>r t.
   r = NULL \<and> bn_rep t h P F M \<and> bn_frame entry h P F t \<and>
   phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry))"

r2_prove "0060" current_checked_0060:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  bn_ds_restore (bn_review_clear_root entry h i) s \<Longrightarrow>
  bn_contract (bn_ds_pop_restore h (of_nat i) (bn_root T)) s (\<lambda>r t.
   r = NULL \<and> bn_rep t h P F M \<and> bn_frame entry h P F t \<and>
   phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry))"

by (fact checked_0060)

end

r2_capture "0061" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame V hp' hp'' \<Longrightarrow>
    bytes_frame (W \<union> V) hp hp''"

r2_prove "0061" current_checked_0061:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame V hp' hp'' \<Longrightarrow>
    bytes_frame (W \<union> V) hp hp''"

by (fact checked_0061)

context binomial_heap_input_global_addresses begin

r2_capture "0062" "function-address-locale" captured:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<Longrightarrow>
  unat i < n \<Longrightarrow>
  runs_to (bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s
   (\<lambda>r t. case r of Result state \<Rightarrow>
       bn_r2_carry_inv s0 h other P F G ext held N a n state t \<and>
       (\<exists>c l vs. state = (c,i+1,l,vs))
     | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s r t)"

r2_refute "0062" current_checked_0062

by (fact checked_0062)

end

context binomial_heap_input_global_addresses begin

r2_capture "0063" "function-address-locale" captured:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (NULL,0,0,vals) s"

r2_prove "0063" current_checked_0063:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (NULL,0,0,vals) s"

by (fact checked_0063)

end

context binomial_heap_input_global_addresses begin

r2_capture "0064" "function-address-locale" captured:
  "runs_to (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) f) s Q \<Longrightarrow>
   ((p :: 'a::xmem_type ptr),d) \<in>
     stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
   runs_to (f p) (s\<lparr>t_hrs_' := (hrs_mem (t_hrs_' s), d)\<rparr>) (\<lambda>_ _. True)"

r2_prove "0064" current_checked_0064:
  "runs_to (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) f) s Q \<Longrightarrow>
   ((p :: 'a::xmem_type ptr),d) \<in>
     stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
   runs_to (f p) (s\<lparr>t_hrs_' := (hrs_mem (t_hrs_' s), d)\<rparr>) (\<lambda>_ _. True)"

by (fact checked_0064)

end

context binomial_heap_input_global_addresses begin

r2_capture "0065" "function-address-locale" captured:
  "bn_contract (binomial_tree_ref' NULL) s (\<lambda>r t. t = s)"

r2_prove "0065" current_checked_0065:
  "bn_contract (binomial_tree_ref' NULL) s (\<lambda>r t. t = s)"

by (fact checked_0065)

end

context binomial_heap_input_global_addresses begin

r2_capture "0066" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV)
    (\<lambda>(p :: StrictC'_BinomialHeap_C ptr). return p)) s
    (\<lambda>p t. bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

r2_prove "0066" current_checked_0066:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV)
    (\<lambda>(p :: StrictC'_BinomialHeap_C ptr). return p)) s
    (\<lambda>p t. bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

by (fact checked_0066)

end

r2_capture "0067" "global" captured:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> \<exists>u. (t,u) \<in> R) \<Longrightarrow>
   (\<And>v t u. P v t \<Longrightarrow> (t,u) \<in> R \<Longrightarrow> Q v u) \<Longrightarrow>
   bn_contract (on_exit f R) s Q"

r2_prove "0067" current_checked_0067:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> \<exists>u. (t,u) \<in> R) \<Longrightarrow>
   (\<And>v t u. P v t \<Longrightarrow> (t,u) \<in> R \<Longrightarrow> Q v u) \<Longrightarrow>
   bn_contract (on_exit f R) s Q"

by (fact checked_0067)

context binomial_heap_input_global_addresses begin

r2_capture "0068" "function-address-locale" captured:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  runs_to (bn_ds_carry_loop h other (of_nat n) a vals) s
    (\<lambda>r t. case r of Result result \<Rightarrow> bn_r2_carry_done s0 h P F G ext held N a n result t
      | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (bn_ds_carry_loop h other (of_nat n) a vals) s r t)"

r2_refute "0068" current_checked_0068

by (fact checked_0068)

end

context binomial_heap_input_global_addresses begin

r2_capture "0069" "function-address-locale" captured:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  c_guard fake \<Longrightarrow> root_ptr_valid (hrs_htd (t_hrs_' entry)) fake \<Longrightarrow>
  ptr_span fake \<subseteq> \<S> \<Longrightarrow> \<S> \<subseteq> reserved_bytes (phantom_machine_state_' entry) \<Longrightarrow>
  P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t.
   r = bn_root T \<and> phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry) \<and>
   (\<exists>N edges. bn_r2_merge_pre t h fake P (F[i := None]) (map Some (bn_ds_children T)) [] {#r#} N edges))"

r2_prove "0069" current_checked_0069:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  c_guard fake \<Longrightarrow> root_ptr_valid (hrs_htd (t_hrs_' entry)) fake \<Longrightarrow>
  ptr_span fake \<subseteq> \<S> \<Longrightarrow> \<S> \<subseteq> reserved_bytes (phantom_machine_state_' entry) \<Longrightarrow>
  P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t.
   r = bn_root T \<and> phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry) \<and>
   (\<exists>N edges. bn_r2_merge_pre t h fake P (F[i := None]) (map Some (bn_ds_children T)) [] {#r#} N edges))"

by (fact checked_0069)

end

context binomial_heap_input_global_addresses begin

r2_capture "0070" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = None \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r = (i + 1,j) \<and> t = s)"

r2_prove "0070" current_checked_0070:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = None \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r = (i + 1,j) \<and> t = s)"

by (fact checked_0070)

end

r2_capture "0071" "global" captured:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame W hp' hp'' \<Longrightarrow>
    bytes_frame W hp hp''"

r2_prove "0071" current_checked_0071:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame W hp' hp'' \<Longrightarrow>
    bytes_frame W hp hp''"

by (fact checked_0071)

r2_capture "0072" "global" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_ds_forest_view s h P F"

r2_prove "0072" current_checked_0072:
  "bn_rep s h P F M \<Longrightarrow> bn_ds_forest_view s h P F"

by (fact checked_0072)

r2_capture "0073" "global" captured:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow> live_blocks A p = None"

r2_prove "0073" current_checked_0073:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow> live_blocks A p = None"

by (fact checked_0073)

r2_capture "0074" "global" captured:
  "bn_valid s P T \<Longrightarrow> bn_ds_tree_layout s P T"

r2_prove "0074" current_checked_0074:
  "bn_valid s P T \<Longrightarrow> bn_ds_tree_layout s P T"

by (fact checked_0074)

context binomial_heap_input_global_addresses begin

r2_capture "0075" "function-address-locale" captured:
  "bn_rep s h P F {#} \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_pop' h) s (\<lambda>r t.
      r = NULL \<and> bn_rep t h P F {#} \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

r2_prove "0075" current_checked_0075:
  "bn_rep s h P F {#} \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_pop' h) s (\<lambda>r t.
      r = NULL \<and> bn_rep t h P F {#} \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

by (fact checked_0075)

end

r2_capture "0076" "global" captured:
  "malloc_rel n hp A 0 hp' B \<Longrightarrow> hp' = hp \<and> B = A"

r2_prove "0076" current_checked_0076:
  "malloc_rel n hp A 0 hp' B \<Longrightarrow> hp' = hp \<and> B = A"

by (fact checked_0076)

r2_capture "0077" "global" captured:
  "mset (bn_forest_values s (F @ G)) = mset (bn_forest_values s F) + mset (bn_forest_values s G)"

r2_prove "0077" current_checked_0077:
  "mset (bn_forest_values s (F @ G)) = mset (bn_forest_values s F) + mset (bn_forest_values s G)"

by (fact checked_0077)

r2_capture "0078" "global" captured:
  "bn_values s T \<noteq> []"

r2_prove "0078" current_checked_0078:
  "bn_values s T \<noteq> []"

by (fact checked_0078)

r2_capture "0080" "global" captured:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract f s Q"

r2_prove "0080" current_checked_0080:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract f s Q"

by (fact checked_0080)

r2_capture "0081" "global" captured:
  "bn_valid s P T \<Longrightarrow> unat (order_C (bn_tree s (bn_root T))) = bn_rank T"

r2_prove "0081" current_checked_0081:
  "bn_valid s P T \<Longrightarrow> unat (order_C (bn_tree s (bn_root T))) = bn_rank T"

by (fact checked_0081)

context binomial_heap_input_global_addresses begin

r2_capture "0082" "function-address-locale" captured:
  "bn_r2_tree_merge_pre s h P T U N edges slots held \<Longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s
    (\<lambda>r t. r = NULL \<longrightarrow> bn_ds_restore s t)"

r2_refute "0082" current_checked_0082

by (fact checked_0082)

end

context binomial_heap_input_global_addresses begin

r2_capture "0083" "function-address-locale" captured:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<Longrightarrow>
  unat i = n \<Longrightarrow>
  bn_r2_carry_done s0 h P F G ext held N a n (bn_carry,i,len,vals) s"

r2_prove "0083" current_checked_0083:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<Longrightarrow>
  unat i = n \<Longrightarrow>
  bn_r2_carry_done s0 h P F G ext held N a n (bn_carry,i,len,vals) s"

by (fact checked_0083)

end

context binomial_heap_input_global_addresses begin

r2_capture "0084" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = Some T \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,0xFFFFFFFF)) s
     (\<lambda>r t. r = (i + 1,i) \<and> t = s)"

r2_prove "0084" current_checked_0084:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = Some T \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,0xFFFFFFFF)) s
     (\<lambda>r t. r = (i + 1,i) \<and> t = s)"

by (fact checked_0084)

end

r2_capture "0085" "global" captured:
  "ptr_span (p :: 'a::mem_type ptr) \<subseteq> S \<Longrightarrow>
   length bs = size_of TYPE('a) \<Longrightarrow>
   bytes_frame S hp (heap_update_padding p v bs hp) \<and>
   bytes_frame S hp (heap_update_list (ptr_val p) bs hp)"

r2_prove "0085" current_checked_0085:
  "ptr_span (p :: 'a::mem_type ptr) \<subseteq> S \<Longrightarrow>
   length bs = size_of TYPE('a) \<Longrightarrow>
   bytes_frame S hp (heap_update_padding p v bs hp) \<and>
   bytes_frame S hp (heap_update_list (ptr_val p) bs hp)"

by (fact checked_0085)

r2_capture "0086" "global" captured:
  "R s \<noteq> {} \<Longrightarrow>
   (\<And>v t. (v,t) \<in> R s \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract (assume_result_and_state R) s Q"

r2_prove "0086" current_checked_0086:
  "R s \<noteq> {} \<Longrightarrow>
   (\<And>v t. (v,t) \<in> R s \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract (assume_result_and_state R) s Q"

by (fact checked_0086)

context binomial_heap_input_global_addresses begin

r2_capture "0087" "function-address-locale" captured:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_num_entries' h) s
    (\<lambda>r t. unat r = size M \<and> t = s)"

r2_prove "0087" current_checked_0087:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_num_entries' h) s
    (\<lambda>r t. unat r = size M \<and> t = s)"

by (fact checked_0087)

end

context binomial_heap_input_global_addresses begin

r2_capture "0088" "function-address-locale" captured:
  "c_guard p \<Longrightarrow> unat (refcount_C (bn_tree s p)) < 65535 \<Longrightarrow>
    bn_contract (binomial_tree_ref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) + 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

r2_prove "0088" current_checked_0088:
  "c_guard p \<Longrightarrow> unat (refcount_C (bn_tree s p)) < 65535 \<Longrightarrow>
    bn_contract (binomial_tree_ref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) + 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

by (fact checked_0088)

end

r2_capture "0089" "global" captured:
 assumes G: "bn_ds_graph s P N edges slots held pending"
 and PN: "p \<in> N" and QE: "q \<in> set (edges p)"
 shows "q \<in> N \<and> unat (order_C (bn_tree s q)) < unat (order_C (bn_tree s p))"

r2_prove "0089" current_checked_0089:
 assumes G: "bn_ds_graph s P N edges slots held pending"
 and PN: "p \<in> N" and QE: "q \<in> set (edges p)"
 shows "q \<in> N \<and> unat (order_C (bn_tree s q)) < unat (order_C (bn_tree s p))"

by (rule checked_0089[OF assms])

r2_capture "0090" "global" captured:
 "bn_ds_graph s P N edges slots held pending \<Longrightarrow>
  acyclic {(x,y). x \<in> N \<and> y \<in> set (edges x)}"

r2_prove "0090" current_checked_0090:
 "bn_ds_graph s P N edges slots held pending \<Longrightarrow>
  acyclic {(x,y). x \<in> N \<and> y \<in> set (edges x)}"

by (fact checked_0090)

r2_capture "0091" "global" captured:
 assumes G: "bn_ds_graph s P N edges slots held {}" and PN: "p \<in> N"
 shows "0 < unat (refcount_C (bn_tree s p))"

r2_prove "0091" current_checked_0091:
 assumes G: "bn_ds_graph s P N edges slots held {}" and PN: "p \<in> N"
 shows "0 < unat (refcount_C (bn_tree s p))"

by (rule checked_0091[OF assms])

r2_capture "0092" "global" captured:
 "bn_ds_graph s P N edges (xs @ ys @ zs) held pending =
  bn_ds_graph s P N edges (ys @ xs @ zs) held pending"

r2_prove "0092" current_checked_0092:
 "bn_ds_graph s P N edges (xs @ ys @ zs) held pending =
  bn_ds_graph s P N edges (ys @ xs @ zs) held pending"

by (fact checked_0092)

r2_capture "0093" "global" captured:
 assumes support: "bn_r2_span_supported s W B"
 and transition: "bn_ds_storage_transition s B t C"
 shows "bn_r2_span_supported t W C"

r2_prove "0093" current_checked_0093:
 assumes support: "bn_r2_span_supported s W B"
 and transition: "bn_ds_storage_transition s B t C"
 shows "bn_r2_span_supported t W C"

by (rule checked_0093[OF assms])

r2_capture "0094" "global" captured:
 assumes ENTRY: "bn_r3_rollback_entry s0 h other P F G ext held N0 e0 a n i bn_carry s N edges"
 shows "unat i < 33 \<and> bn_ds_owned_array s a (unat i+1) \<and>
  bn_ds_graph s P N edges
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext))
    (held + mset (filter (\<lambda>p. p\<noteq>NULL) [bn_carry])) {} \<and>
  bn_r2_graph_storage s N
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)) \<and>
  bn_r2_slots_supported s (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)
    (insert (ptr_val a) (bn_ds_graph_blocks s N)) \<and>
  ptr_val a\<notin>bn_ds_graph_blocks s N"

r2_prove "0094" current_checked_0094:
 assumes ENTRY: "bn_r3_rollback_entry s0 h other P F G ext held N0 e0 a n i bn_carry s N edges"
 shows "unat i < 33 \<and> bn_ds_owned_array s a (unat i+1) \<and>
  bn_ds_graph s P N edges
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext))
    (held + mset (filter (\<lambda>p. p\<noteq>NULL) [bn_carry])) {} \<and>
  bn_r2_graph_storage s N
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)) \<and>
  bn_r2_slots_supported s (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)
    (insert (ptr_val a) (bn_ds_graph_blocks s N)) \<and>
  ptr_val a\<notin>bn_ds_graph_blocks s N"

by (rule checked_0094[OF assms])

context binomial_heap_input_global_addresses begin

r2_capture "0095" "function-address-locale" captured:
 "bn_r3_carry_loop_step h other n a state = bn_ds_carry_loop_step h other n a state"

r2_prove "0095" current_checked_0095:
 "bn_r3_carry_loop_step h other n a state = bn_ds_carry_loop_step h other n a state"

by (fact checked_0095)

end

context binomial_heap_input_global_addresses begin

r2_capture "0096" "function-address-locale" captured:
 assumes G: "c_guard p" and R: "1 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t. t = r2_dec s p)"

r2_prove "0096" current_checked_0096:
 assumes G: "c_guard p" and R: "1 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t. t = r2_dec s p)"

by (rule checked_0096[OF assms])

end

context binomial_heap_input_global_addresses begin

r2_capture "0097" "function-address-locale" captured:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and G: "c_guard p" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and ORDER: "order_C (bn_tree s p)=0" and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
   if refcount_C (bn_tree s p)=1 then
     bn_r3_release (r2_dec s p) {ptr_val p} {ptr_val p} t
   else t=r2_dec s p)"

r2_prove "0097" current_checked_0097:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and G: "c_guard p" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and ORDER: "order_C (bn_tree s p)=0" and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
   if refcount_C (bn_tree s p)=1 then
     bn_r3_release (r2_dec s p) {ptr_val p} {ptr_val p} t
   else t=r2_dec s p)"

by (rule checked_0097[OF assms])

end

r2_capture "0098" "global" captured:
 assumes FB: "bn_r2_finish_base s h P F N edges [slot] {#}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot = tree"
 and LEAF: "bn_ds_tree_layout s P (BN tree [])"
 shows "N = insert tree (bn_ds_forest_nodes F) \<and>
  (\<forall>q\<in>N. unat (refcount_C (bn_tree s q)) =
    (if q\<in>bn_ds_forest_nodes F then 1 else 0) + (if q=tree then 1 else 0))"

r2_prove "0098" current_checked_0098:
 assumes FB: "bn_r2_finish_base s h P F N edges [slot] {#}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot = tree"
 and LEAF: "bn_ds_tree_layout s P (BN tree [])"
 shows "N = insert tree (bn_ds_forest_nodes F) \<and>
  (\<forall>q\<in>N. unat (refcount_C (bn_tree s q)) =
    (if q\<in>bn_ds_forest_nodes F then 1 else 0) + (if q=tree then 1 else 0))"

by (rule checked_0098[OF assms])

context binomial_heap_input_global_addresses begin

r2_capture "0099" "function-address-locale" captured:
  assumes L: "bn_ds_tree_layout s P T"
    and A: "\<forall>b\<in>set (bn_blocks s T). live_blocks (phantom_machine_state_' t) b = live_blocks (phantom_machine_state_' s) b"
    and HN: "\<forall>p \<in> set (bn_ds_node_list T). value_C (bn_tree t p)=value_C (bn_tree s p) \<and>
      order_C (bn_tree t p)=order_C (bn_tree s p) \<and> subtrees_C (bn_tree t p)=subtrees_C (bn_tree s p)"
    and HE: "\<forall>p \<in> set (bn_ds_node_list T). \<forall>i<unat (order_C (bn_tree s p)).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and KEY: "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key t v = bn_key s v"
  shows "bn_ds_tree_layout t P T \<and> bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"

r2_prove "0099" current_checked_0099:
  assumes L: "bn_ds_tree_layout s P T"
    and A: "\<forall>b\<in>set (bn_blocks s T). live_blocks (phantom_machine_state_' t) b = live_blocks (phantom_machine_state_' s) b"
    and HN: "\<forall>p \<in> set (bn_ds_node_list T). value_C (bn_tree t p)=value_C (bn_tree s p) \<and>
      order_C (bn_tree t p)=order_C (bn_tree s p) \<and> subtrees_C (bn_tree t p)=subtrees_C (bn_tree s p)"
    and HE: "\<forall>p \<in> set (bn_ds_node_list T). \<forall>i<unat (order_C (bn_tree s p)).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and KEY: "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key t v = bn_key s v"
  shows "bn_ds_tree_layout t P T \<and> bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"

by (rule checked_0099[OF assms])

end

context binomial_heap_input_global_addresses begin

r2_capture "0100" "function-address-locale" captured:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and GH: "c_guard h" and GP: "c_guard p"
 and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and NE: "ptr_val p\<noteq>ptr_val h"
 and SLOT: "bn_r2_slot_supported s slot {ptr_val h}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot=p"
 and ORDER: "order_C (bn_tree s p)=0"
 and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
  r=result \<and> (if refcount_C (bn_tree s p)=1 then
   bn_r3_release (r2_dec (r3_count s h result) p) {ptr_val p} {ptr_val p} t
  else t=r2_dec (r3_count s h result) p))"

r2_prove "0100" current_checked_0100:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and GH: "c_guard h" and GP: "c_guard p"
 and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and NE: "ptr_val p\<noteq>ptr_val h"
 and SLOT: "bn_r2_slot_supported s slot {ptr_val h}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot=p"
 and ORDER: "order_C (bn_tree s p)=0"
 and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
  r=result \<and> (if refcount_C (bn_tree s p)=1 then
   bn_r3_release (r2_dec (r3_count s h result) p) {ptr_val p} {ptr_val p} t
  else t=r2_dec (r3_count s h result) p))"

by (rule checked_0100[OF assms])

end

r2_capture "0101" "global" captured:
 "bn_r3_old_node_fields s N t M = bn_ds_old_node_fields s N t M"

r2_prove "0101" current_checked_0101:
 "bn_r3_old_node_fields s N t M = bn_ds_old_node_fields s N t M"

by (fact checked_0101)

end
theory R3_Insert_Execution imports Repair_Phase_Model R2_Leaf_Unref Revision_Callsite_Bridges begin
context binomial_heap_input_global_addresses begin



lemma r3_count_node:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and GH: "c_guard h" and GP: "c_guard p"
 and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and NE: "ptr_val p\<noteq>ptr_val h"
 shows "bn_tree (r3_count s h result) p = bn_tree s p"
proof -
 have D: "ptr_span p \<inter> ptr_span h = {}"
  using vero_aux_live_spans_disjoint[OF W LP LH NE, where kp=1 and kq=1 and i=0 and j=0]
  by simp
 show ?thesis by (simp add: r3_count_def bn_tree_def hrs_mem_update_def hrs_mem_def
   case_prod_unfold h_val_heap_update_disjoint[OF D])
qed

lemma r3_count_slot:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and GH: "c_guard h"
 and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 and SLOT: "bn_r2_slot_supported s slot {ptr_val h}"
 shows "h_val (hrs_mem (t_hrs_' (r3_count s h result))) slot = h_val (hrs_mem (t_hrs_' s)) slot"
proof -
 have DIS: "ptr_span slot \<inter> block_bytes (ptr_val h) 40 = {}"
  using r2_supported_disjoint_block[OF W _ LH, where B="{ptr_val h}"] SLOT
  by (auto simp: bn_r2_slot_supported_def)
 have SP: "ptr_span h = block_bytes (ptr_val h) 40"
  using vero_aux_span_block[OF GH] by simp
 have D: "ptr_span slot \<inter> ptr_span h = {}" using DIS SP by simp
 show ?thesis by (simp add: r3_count_def hrs_mem_update_def hrs_mem_def case_prod_unfold
   h_val_heap_update_disjoint[OF D])
qed

lemma r3_insert_execution:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and GH: "c_guard h" and GP: "c_guard p"
 and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and NE: "ptr_val p\<noteq>ptr_val h"
 and SLOT: "bn_r2_slot_supported s slot {ptr_val h}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot=p"
 and ORDER: "order_C (bn_tree s p)=0"
 and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
  r=result \<and> (if refcount_C (bn_tree s p)=1 then
   vero_aux_release (r2_dec (r3_count s h result) p) {ptr_val p} {ptr_val p} t
  else t=r2_dec (r3_count s h result) p))"
proof -
 let ?u="r3_count s h result"
 have NODE: "bn_tree ?u p=bn_tree s p" by (rule r3_count_node[OF W GH GP LH LP NE])
 have WA: "allocator_wf (phantom_machine_state_' ?u)"
  and LA: "live_blocks (phantom_machine_state_' ?u) (ptr_val p)=Some 24"
  using W LP by (simp_all add: r3_count_def)
 have O: "order_C (bn_tree ?u p)=0" and A: "subtrees_C (bn_tree ?u p)=NULL"
  and P: "0<unat (refcount_C (bn_tree ?u p))"
  using ORDER ARRAY POS NODE by simp_all
 have UNREF: "bn_contract (binomial_tree_unref' p) ?u (\<lambda>r t.
  if refcount_C (bn_tree s p)=1 then
   vero_aux_release (r2_dec ?u p) {ptr_val p} {ptr_val p} t else t=r2_dec ?u p)"
  using r2_unref_leaf[OF WA GP LA O A P] NODE by simp
 have CELL: "h_val (hrs_mem (t_hrs_' ?u)) slot=p"
  using r3_count_slot[OF W GH LH SLOT] READ by simp
 have UPD: "num_values_C_update (\<lambda>a. a+1) r = r\<lparr>num_values_C:=num_values_C r+1\<rparr>"
  for r :: StrictC'_BinomialHeap_C by (cases r) simp
 have STATE: "t_hrs_'_update (\<lambda>a. hrs_mem_update
  (heap_update h (num_values_C_update (\<lambda>a. a+1) (h_val (hrs_mem a) h))) a) s =
  t_hrs_'_update (hrs_mem_update (heap_update h
   ((bn_heap s h)\<lparr>num_values_C:=num_values_C (bn_heap s h)+1\<rparr>))) s"
  by (rule globals.equality; simp add: UPD bn_heap_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
 have COUNT: "bn_contract (unless (result=0)
  (modify (t_hrs_'_update (\<lambda>a. hrs_mem_update
   (heap_update h (num_values_C_update (\<lambda>a. a+1) (h_val (hrs_mem a) h))) a))))
   s (\<lambda>r t. t=?u)"
  by (cases "result=0")
   (auto simp: bn_contract_def r3_count_def bn_heap_def condition_to_unless[symmetric]
     runs_to_condition_iff reaches_condition_iff runs_to_modify_iff reaches_modify
     reaches_return[abs_def] fun_eq_iff STATE)
 show ?thesis unfolding bn_ds_insert_finish_def
 proof (rule vero_aux_contract_bind[OF COUNT])
  fix u t assume EQ: "t=?u"
  show "bn_contract (do {
     tree \<leftarrow> gets (\<lambda>u. h_val (hrs_mem (t_hrs_' u)) slot);
     binomial_tree_unref' tree; return result}) t (\<lambda>r v.
    r=result \<and> (if refcount_C (bn_tree s p)=1 then
     vero_aux_release (r2_dec ?u p) {ptr_val p} {ptr_val p} v else v=r2_dec ?u p))"
   unfolding EQ
   apply (rule vero_aux_gets_prefix)
   apply (simp only: CELL)
   apply (rule vero_aux_contract_bind[OF UNREF])
   apply (rule vero_aux_return_contract)
   by simp
 qed
qed

ML \<open>
 val facts = @{thms r3_count_node r3_count_slot r3_insert_execution};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "R3_INSERT_EXECUTION_PASS";
\<close>
end
end

theory Current_Preparation_1 imports R2_Rollback_Phases R3_Insert_Execution R2_Finish_Effects Owned_Context_Protocol begin

r2_capture "0101" "global" captured:
 "bn_r3_old_node_fields s N t M = bn_ds_old_node_fields s N t M"

r2_prove "0101" checked_0101:
 "bn_r3_old_node_fields s N t M = bn_ds_old_node_fields s N t M"

proof -
 have REC: "(x=y\<lparr>refcount_C:=refcount_C x\<rparr>) =
  (value_C x=value_C y \<and> order_C x=order_C y \<and> subtrees_C x=subtrees_C y)"
  for x y :: StrictC'_BinomialTree_C by (cases x; cases y) auto
 show ?thesis by (simp only: bn_r3_old_node_fields_def bn_ds_old_node_fields_def REC)
qed

r2_capture "0089" "global" captured:
 assumes G: "bn_ds_graph s P N edges slots held pending"
 and PN: "p \<in> N" and QE: "q \<in> set (edges p)"
 shows "q \<in> N \<and> unat (order_C (bn_tree s q)) < unat (order_C (bn_tree s p))"

r2_prove "0089" checked_0089:
 assumes G: "bn_ds_graph s P N edges slots held pending"
 and PN: "p \<in> N" and QE: "q \<in> set (edges p)"
 shows "q \<in> N \<and> unat (order_C (bn_tree s q)) < unat (order_C (bn_tree s p))"

using assms r2_graph_edge_rank by blast

r2_capture "0090" "global" captured:
 "bn_ds_graph s P N edges slots held pending \<Longrightarrow>
  acyclic {(x,y). x \<in> N \<and> y \<in> set (edges x)}"

r2_prove "0090" checked_0090:
 "bn_ds_graph s P N edges slots held pending \<Longrightarrow>
  acyclic {(x,y). x \<in> N \<and> y \<in> set (edges x)}"

using r2_graph_acyclic by blast

r2_capture "0091" "global" captured:
 assumes G: "bn_ds_graph s P N edges slots held {}" and PN: "p \<in> N"
 shows "0 < unat (refcount_C (bn_tree s p))"

r2_prove "0091" checked_0091:
 assumes G: "bn_ds_graph s P N edges slots held {}" and PN: "p \<in> N"
 shows "0 < unat (refcount_C (bn_tree s p))"

using assms r2_graph_reference_positive by blast

r2_capture "0092" "global" captured:
 "bn_ds_graph s P N edges (xs @ ys @ zs) held pending =
  bn_ds_graph s P N edges (ys @ xs @ zs) held pending"

r2_prove "0092" checked_0092:
 "bn_ds_graph s P N edges (xs @ ys @ zs) held pending =
  bn_ds_graph s P N edges (ys @ xs @ zs) held pending"

using r2_graph_slots_swap by blast

r2_capture "0093" "global" captured:
 assumes support: "bn_r2_span_supported s W B"
 and transition: "bn_ds_storage_transition s B t C"
 shows "bn_r2_span_supported t W C"

r2_prove "0093" checked_0093:
 assumes support: "bn_r2_span_supported s W B"
 and transition: "bn_ds_storage_transition s B t C"
 shows "bn_r2_span_supported t W C"

using assms r2_supported_storage_transition by blast

r2_capture "0094" "global" captured:
 assumes ENTRY: "bn_r3_rollback_entry s0 h other P F G ext held N0 e0 a n i bn_carry s N edges"
 shows "unat i < 33 \<and> bn_ds_owned_array s a (unat i+1) \<and>
  bn_ds_graph s P N edges
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext))
    (held + mset (filter (\<lambda>p. p\<noteq>NULL) [bn_carry])) {} \<and>
  bn_r2_graph_storage s N
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)) \<and>
  bn_r2_slots_supported s (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)
    (insert (ptr_val a) (bn_ds_graph_blocks s N)) \<and>
  ptr_val a\<notin>bn_ds_graph_blocks s N"

r2_prove "0094" checked_0094:
 assumes ENTRY: "bn_r3_rollback_entry s0 h other P F G ext held N0 e0 a n i bn_carry s N edges"
 shows "unat i < 33 \<and> bn_ds_owned_array s a (unat i+1) \<and>
  bn_ds_graph s P N edges
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext))
    (held + mset (filter (\<lambda>p. p\<noteq>NULL) [bn_carry])) {} \<and>
  bn_r2_graph_storage s N
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)) \<and>
  bn_r2_slots_supported s (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)
    (insert (ptr_val a) (bn_ds_graph_blocks s N)) \<and>
  ptr_val a\<notin>bn_ds_graph_blocks s N"

using assms r3_rollback_entry_premises by blast

context binomial_heap_input_global_addresses begin

r2_capture "0095" "function-address-locale" captured:
 "bn_r3_carry_loop_step h other n a state = bn_ds_carry_loop_step h other n a state"

r2_prove "0095" checked_0095:
 "bn_r3_carry_loop_step h other n a state = bn_ds_carry_loop_step h other n a state"

using r3_actual_carry_failure_cut by blast

end

context binomial_heap_input_global_addresses begin

r2_capture "0096" "function-address-locale" captured:
 assumes G: "c_guard p" and R: "1 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t. t = r2_dec s p)"

r2_prove "0096" checked_0096:
 assumes G: "c_guard p" and R: "1 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t. t = r2_dec s p)"

using assms r2_unref_retained by blast

end

context binomial_heap_input_global_addresses begin

r2_capture "0097" "function-address-locale" captured:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and G: "c_guard p" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and ORDER: "order_C (bn_tree s p)=0" and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
   if refcount_C (bn_tree s p)=1 then
     bn_r3_release (r2_dec s p) {ptr_val p} {ptr_val p} t
   else t=r2_dec s p)"

r2_prove "0097" checked_0097:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and G: "c_guard p" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and ORDER: "order_C (bn_tree s p)=0" and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
   if refcount_C (bn_tree s p)=1 then
     bn_r3_release (r2_dec s p) {ptr_val p} {ptr_val p} t
   else t=r2_dec s p)"

using assms by (rule r2_unref_leaf[unfolded vero_aux_release_def, folded bn_r3_release_def]; assumption)

end

r2_capture "0098" "global" captured:
 assumes FB: "bn_r2_finish_base s h P F N edges [slot] {#}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot = tree"
 and LEAF: "bn_ds_tree_layout s P (BN tree [])"
 shows "N = insert tree (bn_ds_forest_nodes F) \<and>
  (\<forall>q\<in>N. unat (refcount_C (bn_tree s q)) =
    (if q\<in>bn_ds_forest_nodes F then 1 else 0) + (if q=tree then 1 else 0))"

r2_prove "0098" checked_0098:
 assumes FB: "bn_r2_finish_base s h P F N edges [slot] {#}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot = tree"
 and LEAF: "bn_ds_tree_layout s P (BN tree [])"
 shows "N = insert tree (bn_ds_forest_nodes F) \<and>
  (\<forall>q\<in>N. unat (refcount_C (bn_tree s q)) =
    (if q\<in>bn_ds_forest_nodes F then 1 else 0) + (if q=tree then 1 else 0))"

using assms r2_finish_leaf_inventory by blast

context binomial_heap_input_global_addresses begin

r2_capture "0099" "function-address-locale" captured:
  assumes L: "bn_ds_tree_layout s P T"
    and A: "\<forall>b\<in>set (bn_blocks s T). live_blocks (phantom_machine_state_' t) b = live_blocks (phantom_machine_state_' s) b"
    and HN: "\<forall>p \<in> set (bn_ds_node_list T). value_C (bn_tree t p)=value_C (bn_tree s p) \<and>
      order_C (bn_tree t p)=order_C (bn_tree s p) \<and> subtrees_C (bn_tree t p)=subtrees_C (bn_tree s p)"
    and HE: "\<forall>p \<in> set (bn_ds_node_list T). \<forall>i<unat (order_C (bn_tree s p)).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and KEY: "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key t v = bn_key s v"
  shows "bn_ds_tree_layout t P T \<and> bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"

r2_prove "0099" checked_0099:
  assumes L: "bn_ds_tree_layout s P T"
    and A: "\<forall>b\<in>set (bn_blocks s T). live_blocks (phantom_machine_state_' t) b = live_blocks (phantom_machine_state_' s) b"
    and HN: "\<forall>p \<in> set (bn_ds_node_list T). value_C (bn_tree t p)=value_C (bn_tree s p) \<and>
      order_C (bn_tree t p)=order_C (bn_tree s p) \<and> subtrees_C (bn_tree t p)=subtrees_C (bn_tree s p)"
    and HE: "\<forall>p \<in> set (bn_ds_node_list T). \<forall>i<unat (order_C (bn_tree s p)).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and KEY: "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key t v = bn_key s v"
  shows "bn_ds_tree_layout t P T \<and> bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"

using assms r2_layout_mod_refs by blast

end

context binomial_heap_input_global_addresses begin

r2_capture "0100" "function-address-locale" captured:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and GH: "c_guard h" and GP: "c_guard p"
 and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and NE: "ptr_val p\<noteq>ptr_val h"
 and SLOT: "bn_r2_slot_supported s slot {ptr_val h}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot=p"
 and ORDER: "order_C (bn_tree s p)=0"
 and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
  r=result \<and> (if refcount_C (bn_tree s p)=1 then
   bn_r3_release (r2_dec (r3_count s h result) p) {ptr_val p} {ptr_val p} t
  else t=r2_dec (r3_count s h result) p))"

r2_prove "0100" checked_0100:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and GH: "c_guard h" and GP: "c_guard p"
 and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h)=Some 40"
 and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and NE: "ptr_val p\<noteq>ptr_val h"
 and SLOT: "bn_r2_slot_supported s slot {ptr_val h}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot=p"
 and ORDER: "order_C (bn_tree s p)=0"
 and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (bn_ds_insert_finish h slot result) s (\<lambda>r t.
  r=result \<and> (if refcount_C (bn_tree s p)=1 then
   bn_r3_release (r2_dec (r3_count s h result) p) {ptr_val p} {ptr_val p} t
  else t=r2_dec (r3_count s h result) p))"

using assms by (rule r3_insert_execution[unfolded vero_aux_release_def, folded bn_r3_release_def]; assumption)

end

end
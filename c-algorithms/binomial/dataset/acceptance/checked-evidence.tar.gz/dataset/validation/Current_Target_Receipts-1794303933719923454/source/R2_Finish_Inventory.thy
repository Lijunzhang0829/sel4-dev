theory R2_Finish_Inventory imports Repair_Phase_Model Revision_Witness_Provider R2_Graph_Progress begin
lemma r2_graph_nodes_of_forest_handles:
  assumes L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    and GR: "bn_ds_graph s P N edges slots held {}"
    and RH: "bn_ds_slot_handles s slots + held =
      mset (concat (map (case_option [] (\<lambda>T. [bn_root T])) F))"
  shows "N = bn_ds_forest_nodes F"
proof -
  let ?roots = "concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
  let ?nodes = "bn_ds_forest_nodes F"
  have RN: "set ?roots \<subseteq> N"
    using GR by (simp add: bn_ds_graph_def RH)
  have RT: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<in> N"
    using RN by (auto split: option.splits)
  have SUB: "?nodes \<subseteq> N"
    using L RT vero_aux_layout_graph_nodes[OF _ _ GR]
    by (auto simp: vero_aux_forest_node_member; blast)
  have ROOTS: "set ?roots \<subseteq> ?nodes"
    using vero_aux_nodes_root by (auto simp: vero_aux_forest_node_member split: option.splits; blast)
  have CLOSED: "\<forall>p \<in> ?nodes. set (bn_ds_physical_edges s p) \<subseteq> ?nodes"
  proof (intro ballI)
    fix p assume PN: "p \<in> ?nodes"
    obtain T where TF: "Some T \<in> set F" and PT: "p \<in> set (bn_ds_node_list T)"
      using PN by (auto simp: vero_aux_forest_node_member)
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    show "set (bn_ds_physical_edges s p) \<subseteq> ?nodes"
      using vero_aux_layout_edges_closed[OF LT] PT TF by (auto simp: vero_aux_forest_node_member; blast)
  qed
  have BACK: "N \<subseteq> ?nodes"
  proof
    fix p assume PN: "p \<in> N"
    have NR: "N = {p. \<exists>r \<in> set ?roots.
      (r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*}"
      using GR by (simp add: bn_ds_graph_def RH)
    have IN: "p \<in> {p. \<exists>r \<in> set ?roots.
      (r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*}"
      using PN NR by blast
    obtain r where RR: "r \<in> set ?roots"
      and RP: "(r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*"
      using IN by blast
    show "p \<in> ?nodes"
      apply (rule vero_aux_rtrancl_closed[OF RP])
       using ROOTS RR apply blast
      using CLOSED vero_aux_graph_physical[OF GR] by (auto; blast)
  qed
  show ?thesis using SUB BACK by blast
qed


lemma r2_finish_leaf_inventory:
 assumes FB: "bn_r2_finish_base s h P F N edges [slot] {#}"
 and READ: "h_val (hrs_mem (t_hrs_' s)) slot = tree"
 and LEAF: "bn_ds_tree_layout s P (BN tree [])"
 shows "N = insert tree (bn_ds_forest_nodes F) \<and>
  (\<forall>q\<in>N. unat (refcount_C (bn_tree s q)) =
    (if q\<in>bn_ds_forest_nodes F then 1 else 0) + (if q=tree then 1 else 0))"
proof -
 let ?a="roots_C (bn_heap s h)"
 let ?H="F @ [Some (BN tree [])]"
 let ?roots="concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
 let ?nodes="concat (map (case_option [] bn_ds_node_list) F)"
 let ?slots="bn_ds_slots ?a (length F) @ [slot]"
 have FV: "bn_ds_forest_view s h P F"
  and GR: "bn_ds_graph s P N edges ?slots {#} {}"
  and DB: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
  using FB by (auto simp: bn_r2_finish_base_def bn_owned_def)
 have L: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_ds_tree_layout s P T"
  using FV by (auto simp: bn_ds_forest_view_def in_set_conv_nth)
 have LH: "\<forall>T. Some T\<in>set ?H \<longrightarrow> bn_ds_tree_layout s P T"
  using L LEAF by auto
 have NN: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_root T\<noteq>NULL"
  using L by (metis bn_root.simps bn_ds_tree_layout.simps c_guard_NULL bn_shape.exhaust)
 have TN: "tree\<noteq>NULL" using LEAF by (auto dest: c_guard_NULL)
 have VIEW: "bn_review_root_array_view s ?a F"
  using FV by (simp add: bn_ds_forest_view_def bn_review_header_view_def)
 have ROOT: "bn_ds_slot_handles s (bn_ds_slots ?a (length F)) = mset ?roots"
  by (rule vero_aux_root_array_handles[OF VIEW NN])
 have APP: "bn_ds_slot_handles s (xs @ ys) = bn_ds_slot_handles s xs + bn_ds_slot_handles s ys" for xs ys
  by (simp add: bn_ds_slot_handles_def)
 have RH: "bn_ds_slot_handles s ?slots + {#} =
    mset (concat (map (case_option [] (\<lambda>T. [bn_root T])) ?H))"
  by (simp only: APP ROOT; simp add: bn_ds_slot_handles_def READ TN add_ac)
 have N: "N = insert tree (bn_ds_forest_nodes F)"
  using r2_graph_nodes_of_forest_handles[OF LH GR RH]
  by (simp add: bn_ds_forest_nodes_def)
 have FIN: "finite (bn_ds_forest_nodes F)"
  by (simp add: bn_ds_forest_nodes_def)
 have EDGES: "edges tree = []"
  using N LEAF r2_graph_leaf_edges[OF GR, of tree] by (auto simp: unat_eq_zero)
 have DN: "distinct ?nodes" by (rule vero_aux_forest_distinct_nodes[OF DB])
 have COUNT: "count (mset ?nodes) q = (if q\<in>bn_ds_forest_nodes F then 1 else 0)" for q
  using DN by (simp add: distinct_count_atmost_1 bn_ds_forest_nodes_def)
 have FORM: "unat (refcount_C (bn_tree s q)) =
    (if q\<in>bn_ds_forest_nodes F then 1 else 0) + (if q=tree then 1 else 0)" if Q: "q\<in>N" for q
 proof -
  have REF: "unat (refcount_C (bn_tree s q)) =
    count (bn_ds_slot_handles s ?slots) q + (\<Sum>x\<in>N. count (mset (edges x)) q)"
   using GR Q by (simp add: bn_ds_graph_def)
  have SUM: "(\<Sum>x\<in>N. count (mset (edges x)) q) =
    (\<Sum>x\<in>bn_ds_forest_nodes F. count (mset (edges x)) q)"
   by (cases "tree\<in>bn_ds_forest_nodes F") (auto simp: N FIN EDGES insert_absorb)
  have EQ: "map (\<lambda>x. count (mset (edges x)) q) ?nodes =
    map (\<lambda>x. count (mset (bn_ds_physical_edges s x)) q) ?nodes"
   using N vero_aux_graph_physical[OF GR]
   by (auto intro!: map_cong simp: bn_ds_forest_nodes_def)
  have SUMEQ: "(\<Sum>x\<in>bn_ds_forest_nodes F. count (mset (edges x)) q) =
    sum_list (map (\<lambda>x. count (mset (bn_ds_physical_edges s x)) q) ?nodes)"
   using sum_list_distinct_conv_sum_set[OF DN, where f="\<lambda>x. count (mset (edges x)) q"]
   by (simp only: bn_ds_forest_nodes_def EQ)
  have RC: "count (bn_ds_slot_handles s ?slots) q = count (mset ?roots) q + (if tree=q then 1 else 0)"
   using RH by simp
  show ?thesis using vero_aux_forest_edge_count[OF L, of q] REF SUM SUMEQ RC COUNT[of q]
   by (cases "q=tree"; simp_all; arith)
 qed
 show ?thesis using N FORM by blast
qed

ML \<open>
 val facts = @{thms r2_graph_nodes_of_forest_handles r2_finish_leaf_inventory};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "R2_FINISH_INVENTORY_PASS";
\<close>
end

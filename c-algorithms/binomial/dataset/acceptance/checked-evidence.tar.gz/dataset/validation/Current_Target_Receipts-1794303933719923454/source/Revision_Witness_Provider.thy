theory Revision_Witness_Provider

 imports Repair_Phase_Model Revised_Ownership_Model

begin



lemma vero_aux_live_readable:
  "live_blocks A p = Some n \<Longrightarrow> block_bytes p n \<subseteq> readable_bytes A"
  by (auto simp: readable_bytes_def)

context binomial_heap_input_global_addresses begin

lemma c0001_prove:
  "c_guard h \<Longrightarrow>
   heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
   compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
   c_guard (ptr_coerce v :: 32 signed word ptr) \<Longrightarrow>
   runs_to (binomial_heap_cmp' h v v) s Q = Q (Result 0) s"
by (simp add: binomial_heap_cmp'_def bn_heap_def runs_to_bind_iff runs_to_condition_iff runs_to_gets_iff \<P>_fun_ptr_simps int_compare'_def)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_contract_weaken:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract f s Q"
by (auto simp: bn_contract_def runs_to_def_old; blast)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_guard_bounds:
  fixes p :: "'a::mem_type ptr"
  assumes N: "ptr_val p\<noteq>0" and B: "unat (ptr_val p)+size_of TYPE('a)\<le>2^64"
    and A: "align_of TYPE('a) dvd unat (ptr_val p)"
  shows "c_guard p"
proof -
  have NG: "0\<notin>{ptr_val p..+size_of TYPE('a)}"
    using intvl_no_overflow_nat'[where a="ptr_val p" and b="size_of TYPE('a)" and x=0] B N
    by (simp add: unat_eq_zero)
  show ?thesis using A NG by (simp add: c_guard_def ptr_aligned_def c_null_guard_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_span_block:
  fixes p :: "'a::mem_type ptr"
  assumes G: "c_guard p"
  shows "ptr_span p = block_bytes (ptr_val p) (size_of TYPE('a))"
  using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]]
  by (simp add: block_bytes_def)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_separated_spans:
  fixes p :: "'a::mem_type ptr" and q :: "'b::mem_type ptr"
  assumes GP: "c_guard p" and GQ: "c_guard q"
    and D: "unat (ptr_val p)+size_of TYPE('a) \<le> unat (ptr_val q) \<or>
      unat (ptr_val q)+size_of TYPE('b) \<le> unat (ptr_val p)"
  shows "ptr_span p \<inter> ptr_span q = {}"
  using D by (simp only: vero_aux_span_block[OF GP] vero_aux_span_block[OF GQ];
    auto simp: block_bytes_def; arith)

end

context binomial_heap_input_global_addresses begin

definition vero_aux_leaf_merge_header :: StrictC'_BinomialHeap_C where
  "vero_aux_leaf_merge_header = ZERO(StrictC'_BinomialHeap_C)\<lparr>heap_type_C:=BINOMIAL_HEAP_TYPE_MIN,
    compare_func_C:=binomial_heap_input.int_compare, num_values_C:=0,
    roots_C:=NULL, roots_length_C:=0\<rparr>"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_leaf_merge_tree :: StrictC'_BinomialTree_C where
  "vero_aux_leaf_merge_tree = ZERO(StrictC'_BinomialTree_C)\<lparr>value_C:=Ptr 192, order_C:=0, refcount_C:=1, subtrees_C:=NULL\<rparr>"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_leaf_merge_mem :: heap_mem where
  "vero_aux_leaf_merge_mem = heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr) vero_aux_leaf_merge_header
    (heap_update (Ptr 64 :: StrictC'_BinomialTree_C ptr) vero_aux_leaf_merge_tree
      (heap_update (Ptr 96 :: StrictC'_BinomialTree_C ptr) vero_aux_leaf_merge_tree (\<lambda>_. 0)))"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_leaf_merge_allocator :: calg_allocator where
  "vero_aux_leaf_merge_allocator = \<lparr>
    live_blocks=(\<lambda>q. if q=16 then Some 40 else if q=64 \<or> q=96 then Some 24 else None),
    reserved_bytes=block_bytes 192 4\<rparr>"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_leaf_merge_state :: globals where
  "vero_aux_leaf_merge_state = (undefined::globals)\<lparr>
    t_hrs_' := (vero_aux_leaf_merge_mem, undefined),
    phantom_machine_state_' := vero_aux_leaf_merge_allocator\<rparr>"

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_leaf_merge_guards:
  "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 160 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 192 :: 32 signed word ptr)"
  by (intro conjI; rule vero_aux_guard_bounds) simp_all

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_leaf_merge_fields:
  "bn_heap vero_aux_leaf_merge_state (Ptr 16) = vero_aux_leaf_merge_header \<and>
   bn_tree vero_aux_leaf_merge_state (Ptr 64) = vero_aux_leaf_merge_tree \<and>
   bn_tree vero_aux_leaf_merge_state (Ptr 96) = vero_aux_leaf_merge_tree"
proof -
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GP: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and GQ: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    using vero_aux_leaf_merge_guards by blast+
  have PH: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (simp only: vero_aux_span_block[OF GP] vero_aux_span_block[OF GH]; auto simp: block_bytes_def)
  have QH: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (simp only: vero_aux_span_block[OF GQ] vero_aux_span_block[OF GH]; auto simp: block_bytes_def)
  have QP: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (simp only: vero_aux_span_block[OF GQ] vero_aux_span_block[OF GP]; auto simp: block_bytes_def)
  have HH: "bn_heap vero_aux_leaf_merge_state (Ptr 16) = vero_aux_leaf_merge_header"
    using GH by (simp add: vero_aux_leaf_merge_state_def vero_aux_leaf_merge_mem_def bn_heap_def hrs_mem_def h_val_heap_update)
  have HP: "bn_tree vero_aux_leaf_merge_state (Ptr 64) = vero_aux_leaf_merge_tree"
    using GP by (simp add: vero_aux_leaf_merge_state_def vero_aux_leaf_merge_mem_def bn_tree_def hrs_mem_def h_val_heap_update_disjoint[OF PH] h_val_heap_update)
  have HQ: "bn_tree vero_aux_leaf_merge_state (Ptr 96) = vero_aux_leaf_merge_tree"
    using GQ by (simp add: vero_aux_leaf_merge_state_def vero_aux_leaf_merge_mem_def bn_tree_def hrs_mem_def h_val_heap_update_disjoint[OF QH] h_val_heap_update_disjoint[OF QP] h_val_heap_update)
  show ?thesis using HH HP HQ by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_leaf_merge_allocator_wf:
  "allocator_wf vero_aux_leaf_merge_allocator"
  by (auto simp: vero_aux_leaf_merge_allocator_def allocator_wf_def block_ok_def block_bytes_def split: if_splits; arith)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_leaf_merge_pre:
  "allocator_wf (phantom_machine_state_' vero_aux_leaf_merge_state) \<and>
    c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
    heap_type_C (bn_heap vero_aux_leaf_merge_state (Ptr 16)) = BINOMIAL_HEAP_TYPE_MIN \<and>
    compare_func_C (bn_heap vero_aux_leaf_merge_state (Ptr 16)) = binomial_heap_input.int_compare \<and>
    block_bytes 192 4 \<subseteq> reserved_bytes (phantom_machine_state_' vero_aux_leaf_merge_state) \<and>
    bn_valid vero_aux_leaf_merge_state (block_bytes 192 4) (BN (Ptr 64) []) \<and>
    bn_valid vero_aux_leaf_merge_state (block_bytes 192 4) (BN (Ptr 96) []) \<and>
    (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<noteq> Ptr 96 \<and>
    live_blocks (phantom_machine_state_' vero_aux_leaf_merge_state) (ptr_val (Ptr 16 :: StrictC'_BinomialHeap_C ptr)) = Some (size_of TYPE(StrictC'_BinomialHeap_C)) \<and>
    ptr_val (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<noteq> ptr_val (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<and>
    ptr_val (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<noteq> ptr_val (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
  using vero_aux_leaf_merge_guards vero_aux_leaf_merge_fields vero_aux_leaf_merge_allocator_wf
  by (simp add: vero_aux_leaf_merge_state_def vero_aux_leaf_merge_allocator_def vero_aux_leaf_merge_header_def vero_aux_leaf_merge_tree_def bn_payload_def)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_leaf_merge_fresh:
  "fresh_block vero_aux_leaf_merge_allocator 128 24 \<and>
   fresh_block (vero_aux_leaf_merge_allocator\<lparr>live_blocks := (live_blocks vero_aux_leaf_merge_allocator)(128:=Some 24)\<rparr>) 160 8"
  by (auto simp: vero_aux_leaf_merge_allocator_def fresh_block_def block_ok_def block_bytes_def split: if_splits; arith)

end

context binomial_heap_input_global_addresses begin

definition vero_aux_merge_after_second where
  "vero_aux_merge_after_second p q r allocated =
do {
       modify
        (t_hrs_'_update
          (\<lambda>a.
              hrs_mem_update
               (heap_update r
                 (subtrees_C_update
                   (\<lambda>a.
                       PTR_COERCE
                        (unit \<rightarrow> StrictC'_BinomialTree_C ptr)
                        allocated)
                   (h_val (hrs_mem a) r)))
               a));
       condition (\<lambda>s.
                     subtrees_C (h_val (hrs_mem (t_hrs_' s)) r) =
                     NULL)
         (do {
            ret \<leftarrow>
              free'
               (PTR_COERCE(StrictC'_BinomialTree_C \<rightarrow> unit)
                 r);
            return NULL
          })
         (do {
            dest \<leftarrow>
              gets
               (\<lambda>xq.
                   PTR_COERCE
                    (StrictC'_BinomialTree_C ptr \<rightarrow> unit)
                    (subtrees_C (h_val (hrs_mem (t_hrs_' xq)) r)));
            src \<leftarrow>
              gets
               (\<lambda>xr.
                   PTR_COERCE
                    (StrictC'_BinomialTree_C ptr \<rightarrow> unit)
                    (subtrees_C (h_val (hrs_mem (t_hrs_' xr)) p)));
            count \<leftarrow>
              gets
               (\<lambda>xs.
                   word_of_nat (size_of TYPE(StrictC'_BinomialTree_C ptr)) *
                   UCAST(16 \<rightarrow> 64)
                    (order_C (h_val (hrs_mem (t_hrs_' xs)) p)));
            ret \<leftarrow> memcpy' dest src count;
            guard
             (\<lambda>s.
                 c_guard
                  (subtrees_C
                    (h_val (hrs_mem (t_hrs_' s)) r) +\<^sub>p
                   sint
                    (UCAST(16 \<rightarrow> 32 signed)
                      (order_C (h_val (hrs_mem (t_hrs_' s)) r)) -
                     1)));
            guard
             (\<lambda>s.
                 - INT_MAX - 1
                 < uint (order_C (h_val (hrs_mem (t_hrs_' s)) r)));
            guard
             (\<lambda>s.
                 uint (order_C (h_val (hrs_mem (t_hrs_' s)) r))
                 \<le> INT_MAX + 1);
            modify
             (t_hrs_'_update
               (\<lambda>a.
                   hrs_mem_update
                    (heap_update
                      (subtrees_C (h_val (hrs_mem a) r) +\<^sub>p
                       sint
                        (UCAST(16 \<rightarrow> 32 signed)
                          (order_C (h_val (hrs_mem a) r)) -
                         1))
                      q)
                    a));
            i \<leftarrow>
              whileLoop (\<lambda>i s.
                            i <s UCAST(16 \<rightarrow> 32 signed)
                                  (order_C
                                    (h_val (hrs_mem (t_hrs_' s)) r)))
                (\<lambda>i.
                    do {
                      guard
                       (\<lambda>s.
                           c_guard
                            (subtrees_C
                              (h_val (hrs_mem (t_hrs_' s))
                                r) +\<^sub>p
                             sint i));
                      tree \<leftarrow>
                        gets
                         (\<lambda>xx.
                             h_val (hrs_mem (t_hrs_' xx))
                              (subtrees_C
                                (h_val (hrs_mem (t_hrs_' xx))
                                  r) +\<^sub>p
                               sint i));
                      ret \<leftarrow> binomial_tree_ref' tree;
                      guard (\<lambda>s. 0 \<le> 2147483649 + sint i);
                      guard (\<lambda>s. sint i < INT_MAX);
                      return (i + 1)
                    })
               0;
            return r
          })
}"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_merge_after_first where
  "vero_aux_merge_after_first p q r =
condition (\<lambda>s. r = NULL)
    (return NULL)
    (do {
       guard (\<lambda>s. c_guard r);
       modify
        (t_hrs_'_update
          (\<lambda>a.
              hrs_mem_update
               (heap_update r
                 (refcount_C_update (\<lambda>a. 0)
                   (h_val (hrs_mem a) r)))
               a));
       guard
        (\<lambda>s.
            uint (order_C (h_val (hrs_mem (t_hrs_' s)) p)) < INT_MAX);
       guard (\<lambda>s. c_guard p);
       modify
        (t_hrs_'_update
          (\<lambda>a.
              hrs_mem_update
               (heap_update r
                 (order_C_update
                   (\<lambda>b. order_C (h_val (hrs_mem a) p) + 1)
                   (h_val (hrs_mem a) r)))
               a));
       modify
        (t_hrs_'_update
          (\<lambda>a.
              hrs_mem_update
               (heap_update r
                 (value_C_update
                   (\<lambda>b. value_C (h_val (hrs_mem a) p))
                   (h_val (hrs_mem a) r)))
               a));
       size \<leftarrow>
         gets
          (\<lambda>xm.
              word_of_nat (size_of TYPE(StrictC'_BinomialTree_C ptr)) *
              UCAST(16 \<rightarrow> 64)
               (order_C (h_val (hrs_mem (t_hrs_' xm)) r)));
       allocated \<leftarrow> malloc' size;
       vero_aux_merge_after_second p q r allocated
     })"

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_merge_factor:
  "binomial_tree_merge' h p q =
do {
  guard (\<lambda>s. c_guard p);
  guard (\<lambda>s. c_guard q);
  data1 \<leftarrow>
    gets (\<lambda>xb. value_C (h_val (hrs_mem (t_hrs_' xb)) p));
  data2 \<leftarrow>
    gets (\<lambda>xc. value_C (h_val (hrs_mem (t_hrs_' xc)) q));
  ret'int'1 \<leftarrow> binomial_heap_cmp' h data1 data2;
  (tree1, tree2) \<leftarrow>
    return
     (if 0 <s ret'int'1 then (q, p)
      else (p, q));
  ret'ptr_to_void'1 \<leftarrow>
    malloc' (word_of_nat (size_of TYPE(StrictC'_BinomialTree_C)));
  new_tree \<leftarrow>
    return
     (PTR_COERCE(unit \<rightarrow> StrictC'_BinomialTree_C)
       ret'ptr_to_void'1);
  vero_aux_merge_after_first tree1 tree2 new_tree
}"
  by (simp only: binomial_tree_merge'_def vero_aux_merge_after_first_def vero_aux_merge_after_second_def)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_merge_selected_runs_to:
  assumes GP: "c_guard p" and GQ: "c_guard q" and GH: "c_guard h"
    and MIN: "heap_type_C (bn_heap s h)=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap s h)=binomial_heap_input.int_compare"
    and PV: "value_C (bn_tree s p)=v" and QV: "value_C (bn_tree s q)=v"
    and GV: "c_guard (ptr_coerce v :: 32 signed word ptr)"
  shows "runs_to (binomial_tree_merge' h p q) s Q =
    runs_to (do {a \<leftarrow> malloc' 24; vero_aux_merge_after_first p q (ptr_coerce a)}) s Q"
  by (simp add: vero_aux_merge_factor runs_to_bind_iff runs_to_guard_iff runs_to_gets_iff
    GP GQ PV[unfolded bn_tree_def] QV[unfolded bn_tree_def] c0001_prove[OF GH MIN CMP GV] split: prod.splits)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_malloc_bindD:
  fixes K :: "unit ptr \<Rightarrow> (unit, 'a, globals) spec_monad"
  assumes RT: "runs_to (do {p \<leftarrow> malloc' n; K p}) s Q"
    and REL: "malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) (ptr_val p) hp A"
  shows "runs_to (K p) ((t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>) Q"
  using RT REL
  by (auto simp: malloc'_def runs_to_bind_iff runs_to_guard_iff runs_to_assume_result_and_state_iff)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_merge_after_second_fails:
  assumes GR: "c_guard r" and D: "ptr_span p \<inter> ptr_span r = {}"
    and Z: "subtrees_C (bn_tree s p)=NULL" and NN: "allocated\<noteq>NULL"
  shows "\<not>runs_to (vero_aux_merge_after_second p q r allocated) s Q"
  using GR Z NN
  by (simp add: vero_aux_merge_after_second_def bn_tree_def memcpy'_def memcpy_ok_def
    runs_to_bind_iff runs_to_modify_iff runs_to_condition_iff runs_to_gets_iff runs_to_guard_iff
    hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update h_val_heap_update_disjoint[OF D])

end

context binomial_heap_input_global_addresses begin

definition vero_aux_merge_mid where
  "vero_aux_merge_mid s p r = t_hrs_'_update (hrs_mem_update (heap_update r
    ((bn_tree s r)\<lparr>refcount_C:=0, order_C:=1, value_C:=value_C (bn_tree s p)\<rparr>))) s"

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_merge_mid_fields:
  assumes D: "ptr_span p \<inter> ptr_span r = {}"
  shows "bn_tree (vero_aux_merge_mid s p r) p = bn_tree s p \<and>
    phantom_machine_state_' (vero_aux_merge_mid s p r) = phantom_machine_state_' s"
  by (simp add: vero_aux_merge_mid_def bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update_disjoint[OF D])

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_merge_after_firstD:
  assumes RT: "runs_to (vero_aux_merge_after_first p q r) s Q"
    and GR: "c_guard r" and GP: "c_guard p" and D: "ptr_span p \<inter> ptr_span r = {}"
    and OP: "order_C (bn_tree s p)=0"
  shows "runs_to (do {a \<leftarrow> malloc' 8; vero_aux_merge_after_second p q r a}) (vero_aux_merge_mid s p r) Q"
proof -
  let ?f = "\<lambda>a. hrs_mem_update (heap_update r (value_C_update (\<lambda>_. value_C (h_val (hrs_mem a) p)) (h_val (hrs_mem a) r))) a"
  let ?g = "\<lambda>a. hrs_mem_update (heap_update r (order_C_update (\<lambda>_. order_C (h_val (hrs_mem a) p)+1) (h_val (hrs_mem a) r))) a"
  let ?h = "\<lambda>a. hrs_mem_update (heap_update r (refcount_C_update (\<lambda>_. 0) (h_val (hrs_mem a) r))) a"
  have E: "t_hrs_'_update (?f \<circ> ?g \<circ> ?h) s = vero_aux_merge_mid s p r"
    by (rule globals.equality; simp add: vero_aux_merge_mid_def bn_tree_def GR OP[unfolded bn_tree_def hrs_mem_def]
      hrs_mem_update_def hrs_mem_def case_prod_unfold comp_def h_val_heap_update h_val_heap_update_disjoint[OF D] heap_update_collapse)
  have NN: "r\<noteq>NULL" using GR by (auto dest: c_guard_NULL)
  have RAW: "runs_to (do {a \<leftarrow> malloc' 8; vero_aux_merge_after_second p q r a}) (t_hrs_'_update (?f \<circ> ?g \<circ> ?h) s) Q"
    using RT GR GP OP NN
    by (simp add: vero_aux_merge_after_first_def bn_tree_def
      runs_to_bind_iff runs_to_guard_iff runs_to_modify_iff runs_to_gets_iff runs_to_condition_iff
      hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update h_val_heap_update_disjoint[OF D]
      heap_update_collapse INT_MAX_def)
  show ?thesis using RAW by (simp only: E)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_merge_after_first_fails:
  fixes b :: "unit ptr"
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and GR: "c_guard r" and GP: "c_guard p" and D: "ptr_span p \<inter> ptr_span r = {}"
    and OP: "order_C (bn_tree s p)=0" and Z: "subtrees_C (bn_tree s p)=NULL"
    and F: "fresh_block (phantom_machine_state_' s) (ptr_val b) 8"
  shows "\<not>runs_to (vero_aux_merge_after_first p q r) s Q"
proof
  assume RT: "runs_to (vero_aux_merge_after_first p q r) s Q"
  let ?m = "vero_aux_merge_mid s p r"
  have RM: "runs_to (do {a \<leftarrow> malloc' 8; vero_aux_merge_after_second p q r a}) ?m Q"
    by (rule vero_aux_merge_after_firstD[OF RT GR GP D OP])
  have AM: "phantom_machine_state_' ?m = phantom_machine_state_' s"
    and PM: "bn_tree ?m p = bn_tree s p" using vero_aux_merge_mid_fields[OF D] by blast+
  let ?A = "(phantom_machine_state_' ?m)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' ?m))(ptr_val b:=Some 8)\<rparr>"
  have REL: "malloc_rel (unat (8::64 word)) (hrs_mem (t_hrs_' ?m)) (phantom_machine_state_' ?m) (ptr_val b) (hrs_mem (t_hrs_' ?m)) ?A"
    using W F by (simp add: AM malloc_rel_def bytes_frame_def)
  let ?u = "(t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' ?m))) ?m)\<lparr>phantom_machine_state_' := ?A\<rparr>"
  have R2: "runs_to (vero_aux_merge_after_second p q r b) ?u Q"
    by (rule vero_aux_malloc_bindD[OF RM REL])
  have TU: "bn_tree ?u p = bn_tree ?m p"
    by (simp add: bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have ZU: "subtrees_C (bn_tree ?u p)=NULL" by (simp only: TU PM Z)
  have NZ: "ptr_val b\<noteq>0" using F by (simp add: fresh_block_def block_ok_def)
  have NN: "b\<noteq>NULL" using NZ by auto
  have FAIL: "\<not>runs_to (vero_aux_merge_after_second p q r b) ?u Q"
    by (rule vero_aux_merge_after_second_fails[OF GR D ZU NN])
  show False using FAIL R2 by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_leaf_merge_runs_to_fails:
  fixes r :: "StrictC'_BinomialTree_C ptr" and b :: "unit ptr"
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and GP: "c_guard p" and GQ: "c_guard q" and GH: "c_guard h"
    and MIN: "heap_type_C (bn_heap s h)=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap s h)=binomial_heap_input.int_compare"
    and PV: "value_C (bn_tree s p)=v" and QV: "value_C (bn_tree s q)=v"
    and GV: "c_guard (ptr_coerce v :: 32 signed word ptr)"
    and GR: "c_guard r" and D: "ptr_span p \<inter> ptr_span r = {}"
    and OP: "order_C (bn_tree s p)=0" and Z: "subtrees_C (bn_tree s p)=NULL"
    and F1: "fresh_block (phantom_machine_state_' s) (ptr_val r) 24"
    and F2: "fresh_block ((phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val r:=Some 24)\<rparr>) (ptr_val b) 8"
  shows "\<not>runs_to (binomial_tree_merge' h p q) s Q"
proof
  assume RT: "runs_to (binomial_tree_merge' h p q) s Q"
  have RM: "runs_to (do {a \<leftarrow> malloc' 24; vero_aux_merge_after_first p q (ptr_coerce a)}) s Q"
    using RT by (simp only: vero_aux_merge_selected_runs_to[OF GP GQ GH MIN CMP PV QV GV])
  let ?A = "(phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val r:=Some 24)\<rparr>"
  have REL: "malloc_rel (unat (24::64 word)) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s)
      (ptr_val (ptr_coerce r :: unit ptr)) (hrs_mem (t_hrs_' s)) ?A"
    using W F1 by (simp add: malloc_rel_def bytes_frame_def)
  let ?u = "(t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' s))) s)\<lparr>phantom_machine_state_' := ?A\<rparr>"
  have R1: "runs_to (vero_aux_merge_after_first p q r) ?u Q"
    using vero_aux_malloc_bindD[OF RM REL] by (simp only: ptr_coerce_idem ptr_coerce_id)
  have AU: "phantom_machine_state_' ?u = ?A" by simp
  have TU: "bn_tree ?u p = bn_tree s p"
    by (simp add: bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have WA: "allocator_wf ?A" using W F1 by (auto simp: allocator_wf_def fresh_block_def Int_commute)
  have WU: "allocator_wf (phantom_machine_state_' ?u)" by (simp only: AU WA)
  have FU: "fresh_block (phantom_machine_state_' ?u) (ptr_val b) 8" using F2 by (simp only: AU)
  have OU: "order_C (bn_tree ?u p)=0" by (simp only: TU OP)
  have ZU: "subtrees_C (bn_tree ?u p)=NULL" by (simp only: TU Z)
  have FAIL: "\<not>runs_to (vero_aux_merge_after_first p q r) ?u Q"
    by (rule vero_aux_merge_after_first_fails[OF WU GR GP D OU ZU FU])
  show False using FAIL R1 by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_leaf_merge_fails:
  fixes r :: "StrictC'_BinomialTree_C ptr" and b :: "unit ptr"
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and GP: "c_guard p" and GQ: "c_guard q" and GH: "c_guard h"
    and MIN: "heap_type_C (bn_heap s h)=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap s h)=binomial_heap_input.int_compare"
    and PV: "value_C (bn_tree s p)=v" and QV: "value_C (bn_tree s q)=v"
    and GV: "c_guard (ptr_coerce v :: 32 signed word ptr)"
    and GR: "c_guard r" and D: "ptr_span p \<inter> ptr_span r = {}"
    and OP: "order_C (bn_tree s p)=0" and Z: "subtrees_C (bn_tree s p)=NULL"
    and F1: "fresh_block (phantom_machine_state_' s) (ptr_val r) 24"
    and F2: "fresh_block ((phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val r:=Some 24)\<rparr>) (ptr_val b) 8"
  shows "\<not>bn_contract (binomial_tree_merge' h p q) s Q"
  using vero_aux_leaf_merge_runs_to_fails[OF W GP GQ GH MIN CMP PV QV GV GR D OP Z F1 F2]
  by (simp add: bn_contract_def)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_leaf_merge_failure:
  "\<not>bn_contract (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96)) vero_aux_leaf_merge_state Q"
proof -
  let ?s = "vero_aux_leaf_merge_state"
  have W: "allocator_wf (phantom_machine_state_' ?s)"
    and GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and MIN: "heap_type_C (bn_heap ?s (Ptr 16))=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap ?s (Ptr 16))=binomial_heap_input.int_compare"
    using vero_aux_leaf_merge_pre by blast+
  have GP: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and GQ: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    and GR: "c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr)"
    and GV0: "c_guard (Ptr 192 :: 32 signed word ptr)"
    using vero_aux_leaf_merge_guards by blast+
  have GV: "c_guard (ptr_coerce (Ptr 192 :: unit ptr) :: 32 signed word ptr)" using GV0 by simp
  have HP: "bn_tree ?s (Ptr 64)=vero_aux_leaf_merge_tree"
    and HQ: "bn_tree ?s (Ptr 96)=vero_aux_leaf_merge_tree"
    using vero_aux_leaf_merge_fields by blast+
  have PV: "value_C (bn_tree ?s (Ptr 64))=(Ptr 192 :: unit ptr)"
    and QV: "value_C (bn_tree ?s (Ptr 96))=(Ptr 192 :: unit ptr)"
    and OP: "order_C (bn_tree ?s (Ptr 64))=0"
    and Z: "subtrees_C (bn_tree ?s (Ptr 64))=NULL"
    by (simp add: HP HQ vero_aux_leaf_merge_tree_def)+
  have D: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) = {}"
    by (simp only: vero_aux_span_block[OF GP] vero_aux_span_block[OF GR]; auto simp: block_bytes_def)
  have F1: "fresh_block (phantom_machine_state_' ?s) (ptr_val (Ptr 128 :: StrictC'_BinomialTree_C ptr)) 24"
    and F2: "fresh_block ((phantom_machine_state_' ?s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' ?s))(ptr_val (Ptr 128 :: StrictC'_BinomialTree_C ptr):=Some 24)\<rparr>) (ptr_val (Ptr 160 :: unit ptr)) 8"
    using vero_aux_leaf_merge_fresh by (auto simp: vero_aux_leaf_merge_state_def)
  show ?thesis by (rule vero_aux_leaf_merge_fails[OF W GP GQ GH MIN CMP PV QV GV GR D OP Z F1 F2])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_update_frame:
  fixes p :: "'a::mem_type ptr"
  assumes G: "c_guard p"
  shows "bytes_frame (block_bytes (ptr_val p) (size_of TYPE('a))) hp (heap_update p v hp)"
proof -
  have SP: "ptr_span p = block_bytes (ptr_val p) (size_of TYPE('a))"
    using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]]
    by (simp add: block_bytes_def)
  show ?thesis unfolding bytes_frame_def heap_update_def
    by (auto intro!: heap_update_nmem_same simp: SP)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_refcount_dec:
  "refcount_C_update (\<lambda>a. a - 1) x = x\<lparr>refcount_C := refcount_C x - 1\<rparr>"
  by (cases x) simp

end

lemma c0008_prove:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"
proof -
  assume A: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and K: "size_of TYPE('a) * k \<le> n" and I: "i < k"
  have B: "unat (ptr_val p) + n \<le> 2^64"
    using A L unfolding allocator_wf_def block_ok_def by blast
  show ?thesis
  proof
    fix x assume X: "x \<in> ptr_span (p +\<^sub>p int i)"
    obtain j where J: "j < size_of TYPE('a)"
      and E: "x = ptr_val p + of_nat (i * size_of TYPE('a) + j)"
      using X by (auto simp: intvl_def ptr_add_def algebra_simps)
    have M: "(i+1) * size_of TYPE('a) \<le> k * size_of TYPE('a)"
      using I by (intro mult_le_mono1) simp
    have N: "i * size_of TYPE('a) + j < n" using J M K by (simp only: algebra_simps; arith)
    have C: "unat (ptr_val p) + (i * size_of TYPE('a) + j) < 2^64"
      using B N by arith
    have D: "i * size_of TYPE('a) + j < 2^64" using C by arith
    have U: "unat x = unat (ptr_val p) + (i * size_of TYPE('a) + j)"
      using C D by (simp only: E unat_word_ariths unat_of_nat; simp_all)
    show "x \<in> block_bytes (ptr_val p) n"
      using N by (simp add: block_bytes_def U)
  qed
qed

context binomial_heap_input_global_addresses begin

lemma vero_aux_contract_bind:
  "bn_contract f s P \<Longrightarrow> (\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q) \<Longrightarrow> bn_contract (f >>= g) s Q"
proof -
  assume F: "bn_contract f s P"
    and G: "\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q"
  have FR: "runs_to f s (\<lambda>r t. \<exists>v. r = Result v \<and> P v t)"
    using F by (simp add: bn_contract_def)
  have RUN: "runs_to (f >>= g) s (\<lambda>r t. \<exists>v. r = Result v \<and> Q v t)"
    apply (rule runs_to_bind)
    apply (rule runs_to_weaken[OF FR])
    using G by (auto simp: bn_contract_def)
  obtain v t where FV: "reaches f s (Result v) t"
    using F by (auto simp: bn_contract_def)
  have PV: "P v t" using runs_toD2[OF FR FV] by (simp add: Result_eq_Result)
  obtain w u where GW: "reaches (g v) t (Result w) u"
    using G[OF PV] by (auto simp: bn_contract_def)
  have SU: "succeeds (f >>= g) s" using RUN by (auto simp: runs_to_def_old)
  have REACH: "reaches (f >>= g) s (Result w) u"
    apply (simp only: reaches_bind)
    apply (rule conjI[OF SU])
    apply (rule exI[where x="Result v"])
    apply (rule exI[where x=t])
    using FV GW by simp
  show ?thesis using RUN REACH by (auto simp: bn_contract_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_zero_pointer: "ZERO('a::mem_type ptr) = NULL"
  by (simp add: zero_def from_bytes_def typ_info_ptr size_of_ptr update_ti_t_def word_rcat_def)

end

lemma vero_aux_concat_subseq:
  "(\<And>x. x \<in> set xs \<Longrightarrow> subseq (f x) (g x)) \<Longrightarrow>
    subseq (concat (map f xs)) (concat (map g xs))"
  by (induction xs) (auto intro: list_emb_append_mono)

lemma vero_aux_nodes_blocks_subseq:
  "subseq (map ptr_val (bn_ds_node_list T)) (bn_blocks s T)"
proof (induction T)
  case (BN p cs)
  have H: "subseq (concat (map (\<lambda>T. map ptr_val (bn_ds_node_list T)) cs))
      (concat (map (bn_blocks s) cs))"
    by (rule vero_aux_concat_subseq) (rule BN.IH)
  show ?case using H by (cases cs) (auto simp: map_concat o_def intro: list_emb_Cons)
qed

lemma vero_aux_nodes_root: "bn_root T \<in> set (bn_ds_node_list T)"
  by (cases T) simp

lemma vero_aux_layout_physical:
  assumes L: "bn_ds_tree_layout s P (BN p cs)"
  shows "bn_ds_physical_edges s p = map bn_root cs"
proof -
  have LEN: "unat (order_C (bn_tree s p)) = length cs"
    and AR: "\<forall>i<length cs. h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i) = bn_root (cs ! i)"
    using L by auto
  show ?thesis
    unfolding bn_ds_physical_edges_def bn_ds_slots_def LEN
    apply (rule nth_equalityI)
     apply simp
    using AR by (simp add: o_def)
qed

lemma vero_aux_layout_valid_refs:
  assumes L: "bn_ds_tree_layout s P T"
    and REF: "\<forall>p \<in> set (bn_ds_node_list T). refcount_C (bn_tree s p) = 1"
  shows "bn_valid s P T"
  using L REF
  by (induction T) (auto simp: list_all_iff)

lemma vero_aux_graph_physical:
  assumes GR: "bn_ds_graph s P N edges slots held pending" and PN: "p \<in> N"
  shows "edges p = bn_ds_physical_edges s p"
proof -
  have LEN: "unat (order_C (bn_tree s p)) = length (edges p)"
    and AR: "\<forall>i<length (edges p). h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i) = edges p ! i"
    using GR PN by (auto simp: bn_ds_graph_def)
  show ?thesis
    unfolding bn_ds_physical_edges_def bn_ds_slots_def LEN
    apply (rule nth_equalityI)
     apply simp
    using AR by (simp add: o_def)
qed

lemma vero_aux_layout_graph_nodes:
  assumes L: "bn_ds_tree_layout s P T"
    and ROOT: "bn_root T \<in> N"
    and GR: "bn_ds_graph s P N edges slots held pending"
  shows "set (bn_ds_node_list T) \<subseteq> N"
  using L ROOT
proof (induction T)
  case (BN p cs)
  have PN: "p \<in> N" using BN.prems by simp
  have ED: "edges p = map bn_root cs"
    using vero_aux_graph_physical[OF GR PN] vero_aux_layout_physical[OF BN.prems(1)] by simp
  have EN: "set (edges p) \<subseteq> N" using GR PN unfolding bn_ds_graph_def by blast
  have CN: "\<forall>T \<in> set cs. bn_root T \<in> N"
    using EN by (auto simp: ED)
  have CHILD: "\<forall>T \<in> set cs. set (bn_ds_node_list T) \<subseteq> N"
    using BN.IH BN.prems CN by (auto simp: list_all_iff)
  show ?case using CHILD PN by auto
qed

lemma vero_aux_layout_edges_closed:
  assumes L: "bn_ds_tree_layout s P T"
  shows "\<forall>p \<in> set (bn_ds_node_list T). set (bn_ds_physical_edges s p) \<subseteq> set (bn_ds_node_list T)"
  using L
proof (induction T)
  case (BN p cs)
  have ED: "bn_ds_physical_edges s p = map bn_root cs" by (rule vero_aux_layout_physical[OF BN.prems])
  have CHILD: "\<forall>T \<in> set cs. \<forall>q \<in> set (bn_ds_node_list T).
    set (bn_ds_physical_edges s q) \<subseteq> set (bn_ds_node_list T)"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  show ?case using CHILD vero_aux_nodes_root
    by (auto simp: ED; blast)
qed

lemma vero_aux_count_concat:
  "count (mset (concat (map f xs))) p = sum_list (map (\<lambda>x. count (mset (f x)) p) xs)"
  by (induction xs) simp_all

lemma vero_aux_sum_concat:
  "sum_list (map f (concat (map g xs))) = sum_list (map (\<lambda>x. sum_list (map f (g x))) xs)"
  by (induction xs) simp_all

lemma vero_aux_count_map:
  "count (mset (map f xs)) p = sum_list (map (\<lambda>x. if f x = p then 1 else 0) xs)"
  by (induction xs) auto

lemma vero_aux_layout_edge_count:
  assumes L: "bn_ds_tree_layout s P T"
  shows "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) x) (bn_ds_node_list T)) +
    (if bn_root T = x then 1 else 0) = count (mset (bn_ds_node_list T)) x"
  using L
proof (induction T)
  case (BN p cs)
  let ?f = "\<lambda>q. count (mset (bn_ds_physical_edges s q)) x"
  have ED: "bn_ds_physical_edges s p = map bn_root cs" by (rule vero_aux_layout_physical[OF BN.prems])
  have IH: "\<forall>T \<in> set cs. sum_list (map ?f (bn_ds_node_list T)) +
      (if bn_root T = x then 1 else 0) = count (mset (bn_ds_node_list T)) x"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  have MAP: "map (\<lambda>T. sum_list (map ?f (bn_ds_node_list T)) + (if bn_root T = x then 1 else 0)) cs =
      map (\<lambda>T. count (mset (bn_ds_node_list T)) x) cs"
    using IH by (auto intro!: map_cong)
  have SUM: "sum_list (map (\<lambda>T. sum_list (map ?f (bn_ds_node_list T))) cs) +
      sum_list (map (\<lambda>T. if bn_root T = x then 1 else 0) cs) =
      sum_list (map (\<lambda>T. count (mset (bn_ds_node_list T)) x) cs)"
    using arg_cong[OF MAP, where f=sum_list] by (simp only: sum_list_addf)
  show ?case using SUM
    by (simp del: mset_map add: ED vero_aux_count_concat vero_aux_sum_concat vero_aux_count_map algebra_simps)
qed

lemma vero_aux_forest_distinct_nodes:
  assumes D: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
  shows "distinct (concat (map (case_option [] bn_ds_node_list) F))"
proof -
  have EACH: "\<And>U. U \<in> set F \<Longrightarrow>
    subseq (map ptr_val (case_option [] bn_ds_node_list U)) (case_option [] (bn_blocks s) U)"
    by (case_tac U) (simp_all add: vero_aux_nodes_blocks_subseq)
  have SS: "subseq (map ptr_val (concat (map (case_option [] bn_ds_node_list) F)))
      (concat (map (case_option [] (bn_blocks s)) F))"
    using vero_aux_concat_subseq[OF EACH] by (simp add: map_concat o_def)
  have "distinct (map ptr_val (concat (map (case_option [] bn_ds_node_list) F)))"
    using SS D by (metis in_set_subseqs subseqs_distinctD)
  thus ?thesis by (simp add: distinct_map)
qed

lemma vero_aux_root_array_values:
  assumes V: "bn_review_root_array_view s a F"
  shows "map (h_val (hrs_mem (t_hrs_' s))) (bn_ds_slots a (length F)) = map (case_option NULL bn_root) F"
  using V unfolding bn_review_root_array_view_def bn_ds_slots_def
  by (intro nth_equalityI) (auto simp: o_def)

lemma vero_aux_root_array_handles:
  assumes V: "bn_review_root_array_view s a F"
    and NN: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<noteq> NULL"
  shows "bn_ds_slot_handles s (bn_ds_slots a (length F)) =
    mset (concat (map (case_option [] (\<lambda>T. [bn_root T])) F))"
proof -
  have E: "filter (\<lambda>p. p \<noteq> NULL) (map (case_option NULL bn_root) F) =
      concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
    using NN by (induction F) (auto split: option.splits)
  show ?thesis by (simp only: bn_ds_slot_handles_def vero_aux_root_array_values[OF V] E)
qed

lemma vero_aux_forest_edge_count:
  assumes L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
  shows "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) x)
      (concat (map (case_option [] bn_ds_node_list) F))) +
    count (mset (concat (map (case_option [] (\<lambda>T. [bn_root T])) F))) x =
    count (mset (concat (map (case_option [] bn_ds_node_list) F))) x"
  using L
proof (induction F)
  case Nil
  then show ?case by simp
next
  case (Cons U F)
  have IH: "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) x)
      (concat (map (case_option [] bn_ds_node_list) F))) +
    count (mset (concat (map (case_option [] (\<lambda>T. [bn_root T])) F))) x =
    count (mset (concat (map (case_option [] bn_ds_node_list) F))) x"
    using Cons.IH Cons.prems by auto
  show ?case
  proof (cases U)
    case None
    then show ?thesis using IH by simp
  next
    case (Some T)
    have LT: "bn_ds_tree_layout s P T" using Cons.prems Some by simp
    have E: "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) x) (bn_ds_node_list T)) +
      (if bn_root T = x then 1 else 0) = count (mset (bn_ds_node_list T)) x"
      by (rule vero_aux_layout_edge_count[OF LT])
    show ?thesis
    proof (cases "bn_root T = x")
      case True
      show ?thesis using IH E True Some by (simp; arith)
    next
      case False
      show ?thesis using IH E False Some by (simp; arith)
    qed
  qed
qed

lemma vero_aux_forest_node_member:
  "p \<in> bn_ds_forest_nodes F \<longleftrightarrow> (\<exists>T. Some T \<in> set F \<and> p \<in> set (bn_ds_node_list T))"
  by (auto simp: bn_ds_forest_nodes_def split: option.splits)

lemma vero_aux_rtrancl_closed:
  assumes RP: "(r,p) \<in> E\<^sup>*" and R: "r \<in> X"
    and STEP: "\<And>a b. a \<in> X \<Longrightarrow> (a,b) \<in> E \<Longrightarrow> b \<in> X"
  shows "p \<in> X"
  using RP R by (induction rule: rtrancl_induct) (auto intro: STEP)

lemma vero_aux_forest_graph_nodes:
  assumes FV: "bn_ds_forest_view s h P F"
    and GR: "bn_ds_graph s P N edges (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {}"
  shows "N = bn_ds_forest_nodes F"
proof -
  let ?slots = "bn_ds_slots (roots_C (bn_heap s h)) (length F)"
  let ?roots = "concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
  let ?nodes = "bn_ds_forest_nodes F"
  have L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    using FV by (auto simp: bn_ds_forest_view_def in_set_conv_nth)
  have NN: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<noteq> NULL"
  proof (intro allI impI)
    fix T assume "Some T \<in> set F"
    then have "bn_ds_tree_layout s P T" using L by blast
    then show "bn_root T \<noteq> NULL" by (cases T) (auto dest: c_guard_NULL)
  qed
  have RV: "bn_review_root_array_view s (roots_C (bn_heap s h)) F"
    using FV by (simp add: bn_ds_forest_view_def bn_review_header_view_def)
  have RH: "bn_ds_slot_handles s ?slots = mset ?roots" by (rule vero_aux_root_array_handles[OF RV NN])
  have RN: "set ?roots \<subseteq> N"
    using GR by (simp add: bn_ds_graph_def RH)
  have RT: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<in> N"
    using RN by (auto split: option.splits)
  have SUB: "?nodes \<subseteq> N"
    using L RT vero_aux_layout_graph_nodes[OF _ _ GR]
    by (auto simp: vero_aux_forest_node_member; blast)
  have ROOTS: "set ?roots \<subseteq> ?nodes"
    using vero_aux_nodes_root by (auto simp: vero_aux_forest_node_member split: option.splits; blast)
  have CLOSED: "\<forall>p \<in> ?nodes. set (bn_ds_physical_edges s p) \<subseteq> ?nodes"
  proof (intro ballI)
    fix p assume PN: "p \<in> ?nodes"
    obtain T where TF: "Some T \<in> set F" and PT: "p \<in> set (bn_ds_node_list T)"
      using PN by (auto simp: vero_aux_forest_node_member)
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    show "set (bn_ds_physical_edges s p) \<subseteq> ?nodes"
      using vero_aux_layout_edges_closed[OF LT] PT TF by (auto simp: vero_aux_forest_node_member; blast)
  qed
  have BACK: "N \<subseteq> ?nodes"
  proof
    fix p assume PN: "p \<in> N"
    have NR: "N = {p. \<exists>r \<in> set ?roots.
      (r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*}"
      using GR by (simp add: bn_ds_graph_def RH)
    have IN: "p \<in> {p. \<exists>r \<in> set ?roots.
      (r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*}"
      using PN NR by blast
    obtain r where RR: "r \<in> set ?roots"
      and RP: "(r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*"
      using IN by blast
    show "p \<in> ?nodes"
      apply (rule vero_aux_rtrancl_closed[OF RP])
       using ROOTS RR apply blast
      using CLOSED vero_aux_graph_physical[OF GR] by (auto; blast)
  qed
  show ?thesis using SUB BACK by blast
qed

lemma c0012_prove:
  "bn_ds_finish_base s h P F N edges [] {#} \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow>
  M = mset (bn_forest_values s F) \<Longrightarrow> bn_rep s h P F M"
proof -
  assume FB: "bn_ds_finish_base s h P F N edges [] {#}"
    and NUM: "unat (num_values_C (bn_heap s h)) = size M"
    and MASS: "M = mset (bn_forest_values s F)"
  let ?slots = "bn_ds_slots (roots_C (bn_heap s h)) (length F)"
  let ?nodes = "concat (map (case_option [] bn_ds_node_list) F)"
  let ?roots = "concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
  have FV: "bn_ds_forest_view s h P F" and GR: "bn_ds_graph s P N edges ?slots {#} {}"
    and DB: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
    using FB by (auto simp: bn_ds_finish_base_def bn_owned_def)
  have NEQ: "N = set ?nodes" using vero_aux_forest_graph_nodes[OF FV GR] by (simp add: bn_ds_forest_nodes_def)
  have DN: "distinct ?nodes" by (rule vero_aux_forest_distinct_nodes[OF DB])
  have L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    using FV by (auto simp: bn_ds_forest_view_def in_set_conv_nth)
  have NN: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<noteq> NULL"
  proof (intro allI impI)
    fix T assume "Some T \<in> set F"
    then have "bn_ds_tree_layout s P T" using L by blast
    then show "bn_root T \<noteq> NULL" by (cases T) (auto dest: c_guard_NULL)
  qed
  have RV: "bn_review_root_array_view s (roots_C (bn_heap s h)) F"
    using FV by (simp add: bn_ds_forest_view_def bn_review_header_view_def)
  have RH: "bn_ds_slot_handles s ?slots = mset ?roots" by (rule vero_aux_root_array_handles[OF RV NN])
  have REFS: "\<forall>p \<in> N. refcount_C (bn_tree s p) = 1"
  proof (intro ballI)
    fix p assume PN: "p \<in> N"
    have MAP: "map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) p) ?nodes =
      map (\<lambda>q. count (mset (edges q)) p) ?nodes"
      using vero_aux_graph_physical[OF GR] NEQ by (auto intro!: map_cong)
    have SUM: "sum_list (map (\<lambda>q. count (mset (edges q)) p) ?nodes) =
      (\<Sum>q \<in> N. count (mset (edges q)) p)"
      using sum_list_distinct_conv_sum_set[OF DN, where f="\<lambda>q. count (mset (edges q)) p"] by (simp only: NEQ)
    have ONE: "count (mset ?nodes) p = 1" using DN PN NEQ by (simp add: distinct_count_atmost_1)
    have COUNT: "count (bn_ds_slot_handles s ?slots) p + (\<Sum>q \<in> N. count (mset (edges q)) p) = 1"
      using vero_aux_forest_edge_count[OF L, where x=p]
      by (simp only: MAP SUM ONE RH add.commute)
    have RC: "unat (refcount_C (bn_tree s p)) = count (bn_ds_slot_handles s ?slots) p +
      (\<Sum>q \<in> N. count (mset (edges q)) p)"
      using GR PN by (simp add: bn_ds_graph_def)
    show "refcount_C (bn_tree s p) = 1" using RC COUNT by (simp add: unat_eq_1)
  qed
  have VALID: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid s P T"
  proof (intro allI impI)
    fix T assume TF: "Some T \<in> set F"
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    show "bn_valid s P T"
      apply (rule vero_aux_layout_valid_refs[OF LT])
      using TF REFS NEQ by (auto simp: bn_ds_forest_nodes_def[symmetric] vero_aux_forest_node_member)
  qed
  have EMPTY: "roots_C (bn_heap s h) = NULL \<Longrightarrow> F=[]"
    using RV by (cases F) (auto simp: bn_review_root_array_view_def dest: c_guard_NULL)
  have W: "allocator_wf (phantom_machine_state_' s)"
    and PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    using GR by (auto simp: bn_ds_graph_def)
  show ?thesis using FB FV RV W PS EMPTY VALID NUM MASS
    by (auto simp: bn_rep_def bn_ds_finish_base_def bn_ds_forest_view_def bn_review_header_view_def
      bn_review_root_array_view_def bn_ds_owned_array_def split: option.splits dest: nth_mem)
qed

context binomial_heap_input_global_addresses begin

lemma vero_aux_contract_while:
  fixes m :: "'a \<Rightarrow> nat"
  assumes STEP: "\<And>a. I a \<Longrightarrow> C a s \<Longrightarrow>
      bn_contract (B a) s (\<lambda>b t. t=s \<and> I b \<and> m b < m a)"
    and EXIT: "\<And>a. I a \<Longrightarrow> \<not> C a s \<Longrightarrow> Q a s"
    and INIT: "I a"
  shows "bn_contract (whileLoop C B a) s Q"
  using INIT
proof (induction a rule: measure_induct_rule[of m])
  case (less a)
  show ?case
  proof (cases "C a s")
    case False
    show ?thesis
      apply (subst whileLoop_unroll)
      using EXIT[OF less.prems False] False
      by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff reaches_return[abs_def])
  next
    case True
    have ST: "bn_contract (B a) s (\<lambda>b t. t=s \<and> I b \<and> m b < m a)"
      by (rule STEP[OF less.prems True])
    have BC: "bn_contract (B a >>= whileLoop C B) s Q"
    proof (rule vero_aux_contract_bind[OF ST])
      fix b t assume BT: "t=s \<and> I b \<and> m b < m a"
      have D: "m b < m a" and IB: "I b" using BT by auto
      have LOOP: "bn_contract (whileLoop C B b) s Q" by (rule less.IH[OF D IB])
      show "bn_contract (whileLoop C B b) t Q" using LOOP BT by simp
    qed
    show ?thesis
      apply (subst whileLoop_unroll)
      using BC True by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff)
  qed
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_free_allocator:
  "allocator_wf A \<Longrightarrow> allocator_wf (A\<lparr>live_blocks := (live_blocks A)(p:=None)\<rparr>)"
  by (auto simp: allocator_wf_def)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_free_contract:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and G: "p=NULL \<or> (\<exists>n. live_blocks (phantom_machine_state_' s) (ptr_val p) = Some n)"
  shows "bn_contract (free' p) s (\<lambda>r t. \<exists>hp A.
    free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A \<and>
    t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>)"
proof -
  have Z: "ptr_val p=0 \<longleftrightarrow> p=NULL" by (cases p) (simp add: ptr_val_def)
  have EX: "\<exists>hp A. free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A"
    using W G Z by (auto simp: free_rel_def bytes_frame_def)
  show ?thesis using W G EX
    by (auto simp: bn_contract_def free'_def runs_to_bind_iff runs_to_guard_iff
      runs_to_assume_result_and_state_iff reaches_bind reaches_guard reaches_assume_result_and_state
      succeeds_runs_to_iff)
qed

end

context binomial_heap_input_global_addresses begin

definition vero_aux_release where
  "vero_aux_release s D W t \<longleftrightarrow>
    allocator_wf (phantom_machine_state_' t) \<and>
    reserved_bytes (phantom_machine_state_' t) = reserved_bytes (phantom_machine_state_' s) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>q. live_blocks (phantom_machine_state_' t) q =
      (if q\<in>D then None else live_blocks (phantom_machine_state_' s) q)) \<and>
    (\<forall>x\<in>reserved_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) x = hrs_mem (t_hrs_' s) x) \<and>
    (\<forall>q n. live_blocks (phantom_machine_state_' s) q = Some n \<longrightarrow> q\<notin>W \<longrightarrow>
      (\<forall>x\<in>block_bytes q n. hrs_mem (t_hrs_' t) x = hrs_mem (t_hrs_' s) x))"

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_free_release:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some n"
  shows "bn_contract (free' p) s (\<lambda>r t. vero_aux_release s {ptr_val p} {ptr_val p} t)"
proof -
  have PN: "ptr_val p\<noteq>0" using W L by (auto simp: allocator_wf_def block_ok_def)
  have FC: "bn_contract (free' p) s (\<lambda>r t. \<exists>hp A.
    free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A \<and>
    t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>)"
    apply (rule vero_aux_free_contract[OF W]) using L by blast
  show ?thesis
  proof (rule vero_aux_contract_weaken[OF FC])
    fix r t assume POST: "\<exists>hp A. free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A \<and>
      t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>"
    obtain hp A where FR: "free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A"
      and T: "t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>"
      using POST by blast
    have AE: "A = (phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val p:=None)\<rparr>"
      and BF: "bytes_frame (block_bytes (ptr_val p) n) (hrs_mem (t_hrs_' s)) hp"
      using FR PN L by (auto simp: free_rel_def)
    have WA: "allocator_wf A" using vero_aux_free_allocator[OF W] by (simp only: AE)
    have RES: "\<forall>x\<in>reserved_bytes (phantom_machine_state_' s). hp x = hrs_mem (t_hrs_' s) x"
      using W L BF by (auto simp: allocator_wf_def bytes_frame_def; blast)
    have OTHER: "\<forall>q m. live_blocks (phantom_machine_state_' s) q = Some m \<longrightarrow> q\<noteq>ptr_val p \<longrightarrow>
      (\<forall>x\<in>block_bytes q m. hp x = hrs_mem (t_hrs_' s) x)"
      using W L BF by (auto simp: allocator_wf_def bytes_frame_def; blast)
    show "vero_aux_release s {ptr_val p} {ptr_val p} t"
      using WA RES OTHER by (simp add: vero_aux_release_def T AE hrs_mem_update_def hrs_mem_def hrs_htd_def case_prod_unfold)
  qed
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_stack_h_val_agree:
  "(\<And>a. a \<in> ptr_span p \<Longrightarrow> hp' a = hp a) \<Longrightarrow> h_val hp' p = h_val hp p"
  by (unfold h_val_def; rule arg_cong; rule heap_list_h_eq2; assumption)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_guard_prefix:
  "G s \<Longrightarrow> bn_contract B s Q \<Longrightarrow> bn_contract (do {guard G; B}) s Q"
  by (auto simp: bn_contract_def runs_to_bind_iff runs_to_guard_iff reaches_bind reaches_guard succeeds_runs_to_iff; erule runs_to_weaken; simp)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_gets_prefix:
  "bn_contract (B (f s)) s Q \<Longrightarrow> bn_contract (gets f >>= B) s Q"
  by (auto simp: bn_contract_def runs_to_bind_iff runs_to_gets_iff reaches_bind reaches_gets succeeds_runs_to_iff; erule runs_to_weaken; simp)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_return_contract:
  "Q v s \<Longrightarrow> bn_contract (return v) s Q"
  by (simp add: bn_contract_def reaches_return[abs_def])

end

context binomial_heap_input_global_addresses begin

definition vero_aux_unref_body where
  "vero_aux_unref_body p (i :: 32 signed word) = do {
    guard (\<lambda>s. c_guard (subtrees_C (bn_tree s p) +\<^sub>p sint i));
    child \<leftarrow> gets (\<lambda>s. h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p sint i));
    ret \<leftarrow> binomial_tree_unref' child;
    guard (\<lambda>s. 0 \<le> 2147483649 + sint i);
    guard (\<lambda>s. sint i < INT_MAX);
    return (i+1)
  }"

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_unref_null:
  "bn_contract (binomial_tree_unref' NULL) s (\<lambda>r t. t=s)"
  apply (subst binomial_tree_unref'.simps)
  by (simp add: bn_contract_def reaches_return[abs_def])

end

context binomial_heap_input_global_addresses begin

definition vero_aux_unref_tail where
  "vero_aux_unref_tail p = do {
    i \<leftarrow> whileLoop (\<lambda>i s. i <s (ucast (order_C (bn_tree s p)) :: 32 signed word)) (vero_aux_unref_body p) 0;
    a \<leftarrow> gets (\<lambda>s. ptr_coerce (subtrees_C (bn_tree s p)));
    free' a;
    free' (ptr_coerce p)
  }"

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_unref_equation:
  "binomial_tree_unref' p = unless (p=NULL) (do {
    guard (\<lambda>s. c_guard p);
    guard (\<lambda>s. -INT_MAX-1 < uint (refcount_C (bn_tree s p)));
    guard (\<lambda>s. uint (refcount_C (bn_tree s p)) \<le> INT_MAX+1);
    modify (\<lambda>s. t_hrs_'_update (hrs_mem_update (heap_update p ((bn_tree s p)\<lparr>refcount_C:=refcount_C (bn_tree s p)-1\<rparr>))) s);
    condition (\<lambda>s. (ucast (refcount_C (bn_tree s p)) :: 32 signed word)=0) (vero_aux_unref_tail p) skip
  })"
proof -
  have E: "t_hrs_'_update (\<lambda>a. hrs_mem_update (heap_update p (refcount_C_update (\<lambda>x. x-1) (h_val (hrs_mem a) p))) a) =
    (\<lambda>s. t_hrs_'_update (hrs_mem_update (heap_update p ((bn_tree s p)\<lparr>refcount_C:=refcount_C (bn_tree s p)-1\<rparr>))) s)"
    by (rule ext; rule globals.equality; simp add: bn_tree_def vero_aux_refcount_dec)
  show ?thesis
    apply (subst binomial_tree_unref'.simps)
    by (simp only: E vero_aux_unref_tail_def vero_aux_unref_body_def[abs_def] bn_tree_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_stack_live_array:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   S \<subseteq> reserved_bytes A \<Longrightarrow> bytes_frame S hp hp' \<Longrightarrow>
   h_val hp' (p +\<^sub>p int i) = h_val hp (p +\<^sub>p int i)"



proof -
  assume A: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and K: "size_of TYPE('a) * k \<le> n" and I: "i < k"
    and S: "S \<subseteq> reserved_bytes A" and F: "bytes_frame S hp hp'"
  have B: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"
    using c0008_prove[OF A L K I] .
  have D: "block_bytes (ptr_val p) n \<inter> reserved_bytes A = {}"
    using A L unfolding allocator_wf_def by blast
  show ?thesis
    apply (rule vero_aux_stack_h_val_agree)
    using B D S F by (auto simp: bytes_frame_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_stack_live_h_val:
  fixes p :: "'a::mem_type ptr"
  assumes W: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and SZ: "size_of TYPE('a) \<le> n" and SS: "S \<subseteq> reserved_bytes A"
    and BF: "bytes_frame S hp hp'"
  shows "h_val hp' p = h_val hp p"
proof -
  have "h_val hp' (p +\<^sub>p int 0) = h_val hp (p +\<^sub>p int 0)"
    by (rule vero_aux_stack_live_array[OF W L, where k=1 and i=0 and S=S]) (simp_all add: SZ SS BF)
  thus ?thesis by simp
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_payload_key_frame:
  assumes V: "bn_payload P v" and PS: "P \<inter> S = {}"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
  shows "bn_key t v = bn_key s v"
proof -
  let ?p = "ptr_coerce v :: 32 signed word ptr"
  have G: "c_guard ?p" and B: "block_bytes (ptr_val ?p) 4 \<subseteq> P"
    using V by (auto simp: bn_payload_def)
  have SP: "ptr_span ?p \<subseteq> P"
    using B intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]]
    by (simp add: block_bytes_def)
  have HV: "h_val (hrs_mem (t_hrs_' t)) ?p = h_val (hrs_mem (t_hrs_' s)) ?p"
    apply (rule vero_aux_stack_h_val_agree)
    using SP PS BF by (auto simp: bytes_frame_def)
  show ?thesis by (simp add: bn_key_def HV)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_valid_reserved_frame:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and SS: "S \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and PS: "P \<inter> S = {}"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
    and V: "bn_valid s P T"
  shows "bn_valid t P T \<and> bn_values t T = bn_values s T \<and>
    bn_blocks t T = bn_blocks s T \<and>
    (\<forall>v \<in> set (bn_values s T). bn_key t v = bn_key s v)"
  using V
proof (induction T)
  case (BN p cs)
  have L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using BN.prems by simp
  have TP: "bn_tree t p = bn_tree s p"
    unfolding bn_tree_def by (rule vero_aux_stack_live_h_val[OF W L _ SS BF]) simp
  have CHILD: "\<forall>U \<in> set cs. bn_valid t P U \<and> bn_values t U = bn_values s U \<and>
    bn_blocks t U = bn_blocks s U \<and> (\<forall>v \<in> set (bn_values s U). bn_key t v = bn_key s v)"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  have VC: "map (bn_values t) cs = map (bn_values s) cs"
    using CHILD by (auto intro!: map_cong)
  have BC: "map (bn_blocks t) cs = map (bn_blocks s) cs"
    using CHILD by (auto intro!: map_cong)
  have PAY: "bn_payload P (value_C (bn_tree s p))" using BN.prems by simp
  have KC: "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
    by (rule vero_aux_payload_key_frame[OF PAY PS BF])
  have ARR: "\<forall>i < length cs. h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
  proof (intro allI impI)
    fix i assume I: "i < length cs"
    have NE: "cs \<noteq> []" using I by auto
    have AL: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
      Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length cs)"
      using BN.prems NE by simp
    show "h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
      by (rule vero_aux_stack_live_array[OF W AL _ I SS BF]) simp
  qed
  show ?case using BN.prems CHILD TP VC BC KC ARR A
    by (auto simp: list_all_iff VC BC)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_pointer_low32_zero:
  "h_val (heap_update (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296) hp)
    (Ptr 32 :: 32 word ptr) = 0"
  by (simp add: h_val_def heap_update_def to_bytes_def from_bytes_def typ_info_ptr
    typ_info_word word_tag_def update_ti_t_def word_rcat_def word_rsplit_def
    bin_rsplit_def bin_rsplit_aux.simps; simp add: heap_list.simps numeral_eq_Suc)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_pointer_low32_increment:
  "h_val (heap_update (Ptr 32 :: 32 word ptr) 1
      (heap_update (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296) hp))
    (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = Ptr 4294967297"
  by (simp add: h_val_def heap_update_def to_bytes_def from_bytes_def typ_info_ptr
    typ_info_word word_tag_def update_ti_t_def word_rcat_def word_rsplit_def
    bin_rsplit_def bin_rsplit_aux.simps; simp add: heap_list.simps numeral_eq_Suc)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_header_slot_alias:
  assumes Z: "num_values_C (h_val hp (Ptr 16 :: StrictC'_BinomialHeap_C ptr))=0"
  shows "h_val (heap_update (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296) hp)
    (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = h_val hp (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
proof -
  have G32: "c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have G16: "c_guard (Ptr 16 :: 32 signed word ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have G24: "c_guard (Ptr 24 :: unit ptr ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have G40: "c_guard (Ptr 40 :: StrictC'_BinomialTree_C ptr ptr ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have G48: "c_guard (Ptr 48 :: 32 word ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have D16: "ptr_span (Ptr 16 :: 32 signed word ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G16 G32]) simp
  have D24: "ptr_span (Ptr 24 :: unit ptr ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G24 G32]) simp
  have D40: "ptr_span (Ptr 40 :: StrictC'_BinomialTree_C ptr ptr ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G40 G32]) simp
  have D48: "ptr_span (Ptr 48 :: 32 word ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G48 G32]) simp
  show ?thesis using Z
    by (simp add: StrictC'_BinomialHeap_C_h_val_unfold field_lvalue_def
      h_val_heap_update_disjoint[OF D16] h_val_heap_update_disjoint[OF D24]
      h_val_heap_update_disjoint[OF D40] h_val_heap_update_disjoint[OF D48]
      vero_aux_pointer_low32_zero)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_unref_unguarded:
  "p\<noteq>NULL \<Longrightarrow> \<not>c_guard p \<Longrightarrow> \<not>runs_to (binomial_tree_unref' p) s Q"
  by (simp add: vero_aux_unref_equation condition_to_unless[symmetric]
    runs_to_condition_iff runs_to_bind_iff runs_to_guard_iff)

end

context binomial_heap_input_global_addresses begin

definition vero_aux_finish_alias_header where
  "vero_aux_finish_alias_header = vero_aux_leaf_merge_header\<lparr>roots_C:=Ptr 64,roots_length_C:=1\<rparr>"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_finish_alias_tree where
  "vero_aux_finish_alias_tree = vero_aux_leaf_merge_tree\<lparr>value_C:=Ptr 96,refcount_C:=2\<rparr>"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_finish_alias_mem :: heap_mem where
  "vero_aux_finish_alias_mem =
    heap_update (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296)
    (heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr) vero_aux_finish_alias_header
    (heap_update (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) vero_aux_finish_alias_tree
    (heap_update (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296) (\<lambda>_. 0))))"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_finish_alias_allocator :: calg_allocator where
  "vero_aux_finish_alias_allocator = \<lparr>
    live_blocks=(\<lambda>q. if q=16 then Some 40 else if q=64 then Some 8 else if q=4294967296 then Some 24 else None),
    reserved_bytes=block_bytes 96 4\<rparr>"

end

context binomial_heap_input_global_addresses begin

definition vero_aux_finish_alias_state :: globals where
  "vero_aux_finish_alias_state = (undefined :: globals)\<lparr>
    t_hrs_' := (vero_aux_finish_alias_mem, undefined), phantom_machine_state_' := vero_aux_finish_alias_allocator\<rparr>"

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_finish_alias_guards:
  "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 96 :: 32 signed word ptr)"
  by (intro conjI; rule vero_aux_guard_bounds) simp_all

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_finish_alias_fields:
  "bn_heap vero_aux_finish_alias_state (Ptr 16)=vero_aux_finish_alias_header \<and>
   bn_tree vero_aux_finish_alias_state (Ptr 4294967296)=vero_aux_finish_alias_tree \<and>
   h_val (hrs_mem (t_hrs_' vero_aux_finish_alias_state)) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296 \<and>
   h_val (hrs_mem (t_hrs_' vero_aux_finish_alias_state)) (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296"
proof -
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and G32: "c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)"
    and G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr)"
    and GT: "c_guard (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr)"
    using vero_aux_finish_alias_guards by blast+
  have D4294967296_32: "ptr_span (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF GT G32]) simp
  have D4294967296_16: "ptr_span (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF GT G16]) simp
  have D64_32: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G32]) simp
  have D64_16: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G16]) simp
  have D64_4294967296: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 GT]) simp

  have HEADER: "h_val vero_aux_finish_alias_mem (Ptr 16 :: StrictC'_BinomialHeap_C ptr)=vero_aux_finish_alias_header"
    unfolding vero_aux_finish_alias_mem_def
    by (subst vero_aux_header_slot_alias; simp add: h_val_heap_update vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def)
  have HH: "bn_heap vero_aux_finish_alias_state (Ptr 16)=vero_aux_finish_alias_header"
    by (simp add: bn_heap_def vero_aux_finish_alias_state_def hrs_mem_def HEADER)
  show ?thesis
    apply (rule conjI[OF HH])
    by (simp add: bn_tree_def vero_aux_finish_alias_state_def hrs_mem_def
      vero_aux_finish_alias_mem_def h_val_heap_update
      h_val_heap_update_disjoint[OF D4294967296_32] h_val_heap_update_disjoint[OF D4294967296_16] h_val_heap_update_disjoint[OF D64_32] h_val_heap_update_disjoint[OF D64_16] h_val_heap_update_disjoint[OF D64_4294967296])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_finish_alias_allocator_wf:
  "allocator_wf vero_aux_finish_alias_allocator"
  by (auto simp: vero_aux_finish_alias_allocator_def allocator_wf_def block_ok_def block_bytes_def split: if_splits; arith)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_num_increment_at_32:
  "heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr)
      (num_values_C_update (\<lambda>x. x+1) (h_val hp (Ptr 16))) hp =
    heap_update (Ptr 32 :: 32 word ptr) (num_values_C (h_val hp (Ptr 16 :: StrictC'_BinomialHeap_C ptr))+1) hp"
proof -
  have G: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    using vero_aux_finish_alias_guards by blast
  have UPD: "num_values_C_update (\<lambda>x. x+1) r =
    num_values_C_update (\<lambda>_. num_values_C r+1) r" for r
    by (cases r) simp
  show ?thesis
    using StrictC'_BinomialHeap_C_heap_update_fields(3)[OF G,
      where h=hp and v="num_values_C (h_val hp (Ptr 16 :: StrictC'_BinomialHeap_C ptr))+1"]
    by (simp add: field_lvalue_def UPD)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_finish_alias_pre:
  "bn_ds_finish_base vero_aux_finish_alias_state (Ptr 16) (block_bytes 96 4)
    [Some (BN (Ptr 4294967296) [])] {Ptr 4294967296} (\<lambda>_. []) [Ptr 32] {#} \<and>
   c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   h_val (hrs_mem (t_hrs_' vero_aux_finish_alias_state)) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296 \<and>
   bn_ds_tree_layout vero_aux_finish_alias_state (block_bytes 96 4) (BN (Ptr 4294967296) []) \<and>
   value_C (bn_tree vero_aux_finish_alias_state (Ptr 4294967296))=Ptr 96 \<and>
   unat (num_values_C (bn_heap vero_aux_finish_alias_state (Ptr 16)))=0 \<and>
   mset (bn_forest_values vero_aux_finish_alias_state [Some (BN (Ptr 4294967296) [])])={#Ptr 96#}"
proof -
  let ?s = "vero_aux_finish_alias_state"
  let ?P = "block_bytes 96 4"
  let ?T = "BN (Ptr 4294967296) []"
  have AS: "phantom_machine_state_' ?s=vero_aux_finish_alias_allocator"
    by (simp add: vero_aux_finish_alias_state_def)
  have HH: "bn_heap ?s (Ptr 16)=vero_aux_finish_alias_header"
    and HT: "bn_tree ?s (Ptr 4294967296)=vero_aux_finish_alias_tree"
    and S32: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296"
    and S64: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296"
    using vero_aux_finish_alias_fields by blast+
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GS: "c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)"
    and GR: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr)"
    and GT: "c_guard (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr)"
    and GV: "c_guard (Ptr 96 :: 32 signed word ptr)"
    using vero_aux_finish_alias_guards by blast+
  have RH: "block_bytes 16 40 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    and RR: "block_bytes 64 8 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    by (rule vero_aux_live_readable; simp add: AS vero_aux_finish_alias_allocator_def)+
  have RS: "block_bytes 32 8 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    by (rule subset_trans[OF _ RH]; auto simp: block_bytes_def)
  have LT: "bn_ds_tree_layout ?s ?P ?T"
    using GT GV by (simp add: HT AS vero_aux_finish_alias_allocator_def
      vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def bn_payload_def)
  have FV: "bn_ds_forest_view ?s (Ptr 16) ?P [Some ?T]"
    using GH GR RH RR LT
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def
      HH S64 vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def)
  have GRAPH: "bn_ds_graph ?s ?P {Ptr 4294967296} (\<lambda>_. []) [Ptr 64,Ptr 32] {#} {}"
    using vero_aux_finish_alias_allocator_wf GT GV GS GR
    by (auto simp: bn_ds_graph_def bn_ds_slot_handles_def AS HT S64 S32
      vero_aux_finish_alias_allocator_def vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def bn_payload_def)
  have ST: "bn_ds_graph_storage ?s {Ptr 4294967296} [Ptr 64,Ptr 32]"
    using RS RR by (auto simp: bn_ds_graph_storage_def HT vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def)
  have GB: "bn_ds_graph_blocks ?s {Ptr 4294967296}={4294967296}"
    by (auto simp: bn_ds_graph_blocks_def HT vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def)
  have OW: "bn_ds_owned_array ?s (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) 1"
    using GR by (auto simp: bn_ds_owned_array_def AS vero_aux_finish_alias_allocator_def)
  have BASE: "bn_ds_finish_base ?s (Ptr 16) ?P [Some ?T] {Ptr 4294967296} (\<lambda>_. []) [Ptr 32] {#}"
    using FV GRAPH ST GB OW
    by (auto simp: bn_ds_finish_base_def HH HT bn_ds_slots_def bn_owned_def AS
      vero_aux_finish_alias_allocator_def vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def
      vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def)
  show ?thesis using BASE GS S32 LT
    by (simp add: HH HT vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def
      vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def bn_forest_values_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_finish_alias_failure:
  "\<not>runs_to (bn_ds_insert_finish (Ptr 16) (Ptr 32) 1) vero_aux_finish_alias_state Q"
proof -
  let ?s = "vero_aux_finish_alias_state"
  let ?upd = "t_hrs_'_update (\<lambda>a. hrs_mem_update
    (heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr)
      (num_values_C_update (\<lambda>x. x+1) (h_val (hrs_mem a) (Ptr 16)))) a)"
  have Z: "num_values_C (bn_heap ?s (Ptr 16))=0"
    using vero_aux_finish_alias_fields
    by (simp add: vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def)
  have SLOT0: "h_val (hrs_mem (t_hrs_' (?upd ?s))) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) =
    h_val (heap_update (Ptr 32 :: 32 word ptr) 1 (hrs_mem (t_hrs_' ?s)))
      (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)"
    by (simp add: hrs_mem_update_def hrs_mem_def case_prod_unfold vero_aux_num_increment_at_32
      Z[unfolded bn_heap_def hrs_mem_def])
  have SLOT: "h_val (hrs_mem (t_hrs_' (?upd ?s))) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967297"
    using SLOT0 by (simp add: vero_aux_finish_alias_state_def vero_aux_finish_alias_mem_def hrs_mem_def
      vero_aux_pointer_low32_increment)
  have BAD: "\<And>u R. \<not>runs_to (binomial_tree_unref' (Ptr 4294967297)) u R"
    by (rule vero_aux_unref_unguarded) (simp_all add: c_guard_def ptr_aligned_def)
  show ?thesis
    by (simp add: bn_ds_insert_finish_def condition_to_unless[symmetric] runs_to_condition_iff
      runs_to_bind_iff runs_to_modify_iff runs_to_gets_iff SLOT[simplified] BAD)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_detach_semantics:
  fixes i :: "32 word" and s u :: globals and v :: "StrictC'_BinomialHeap_C"
    and h fake :: "StrictC'_BinomialHeap_C ptr" and tree :: "StrictC'_BinomialTree_C ptr"
  defines "u \<equiv> t_hrs_'_update (hrs_mem_update (heap_update (roots_C (bn_heap s h) +\<^sub>p uint i) NULL)) s"
    and "v \<equiv> (bn_heap u fake)\<lparr>heap_type_C := heap_type_C (bn_heap u h),
      compare_func_C := compare_func_C (bn_heap u h), roots_C := subtrees_C (bn_tree u tree),
      roots_length_C := UCAST(16 \<rightarrow> 32) (order_C (bn_tree u tree))\<rparr>"
  assumes G: "c_guard (roots_C (bn_heap s h) +\<^sub>p uint i)"
    and VAL: "h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint i) = tree"
    and GF: "c_guard fake" and GT: "c_guard tree"
    and DH: "ptr_span h \<inter> ptr_span fake = {}" and DT: "ptr_span tree \<inter> ptr_span fake = {}"
  shows "bn_contract (bn_ds_pop_detach h fake i) s
    (\<lambda>r t. r=tree \<and> t=t_hrs_'_update (hrs_mem_update (heap_update fake v)) u)"
  using G VAL GF GT
  by (auto simp: bn_contract_def bn_ds_pop_detach_def u_def v_def bn_heap_def bn_tree_def
    hrs_mem_def hrs_mem_update_def case_prod_unfold heap_update_collapse
    h_val_heap_update_disjoint[OF DH] h_val_heap_update_disjoint[OF DT]
    runs_to_bind_iff runs_to_guard_iff runs_to_gets_iff runs_to_modify_iff
    reaches_bind reaches_guard reaches_gets reaches_modify reaches_return[abs_def] succeeds_runs_to_iff)

end

lemma vero_aux_valid_layout:
  "bn_valid s P T \<Longrightarrow> bn_ds_tree_layout s P T"
  by (induction T) (auto simp: list_all_iff)

lemma vero_aux_rep_forest_view:
  "bn_rep s h P F M \<Longrightarrow> bn_ds_forest_view s h P F"



proof -
  assume R: "bn_rep s h P F M"
  have H: "block_bytes (ptr_val h) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq>
       readable_bytes (phantom_machine_state_' s)"
    apply (rule vero_aux_live_readable)
    using R by (simp add: bn_rep_def)
  have ARR: "block_bytes (ptr_val (roots_C (bn_heap s h))) (8 * length F) \<subseteq>
       readable_bytes (phantom_machine_state_' s)"
  proof (cases "roots_C (bn_heap s h) = NULL")
    case True
    have "F = []" using R True by (simp add: bn_rep_def)
    thus ?thesis by (auto simp: block_bytes_def)
  next
    case False
    obtain n where L: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
      and N: "8 * length F \<le> n"
      using R False by (auto simp: bn_rep_def)
    have B: "block_bytes (ptr_val (roots_C (bn_heap s h))) (8 * length F) \<subseteq>
        block_bytes (ptr_val (roots_C (bn_heap s h))) n"
      using N by (auto simp: block_bytes_def)
    show ?thesis by (rule subset_trans[OF B vero_aux_live_readable[OF L]])
  qed
  show ?thesis using R H ARR
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def bn_rep_def
      split: option.splits intro: vero_aux_valid_layout)
qed

definition vero_aux_node_blocks where
  "vero_aux_node_blocks s p = ptr_val p #
    (if order_C (bn_tree s p) = 0 then [] else [ptr_val (subtrees_C (bn_tree s p))])"

lemma vero_aux_concat_map_flat:
  "concat (map f (concat (map g xs))) = concat (map (\<lambda>x. concat (map f (g x))) xs)"
  by (induction xs) simp_all

lemma vero_aux_layout_blocks:
  assumes L: "bn_ds_tree_layout s P T"
  shows "bn_blocks s T = concat (map (vero_aux_node_blocks s) (bn_ds_node_list T))"
  using L
proof (induction T)
  case (BN p cs)
  have CHILD: "map (bn_blocks s) cs = map (\<lambda>T. concat (map (vero_aux_node_blocks s) (bn_ds_node_list T))) cs"
    using BN.IH BN.prems by (auto simp: list_all_iff intro!: map_cong)
  have ZERO: "order_C (bn_tree s p) = 0 \<longleftrightarrow> cs=[]"
    using BN.prems by (simp add: unat_eq_zero[symmetric])
  show ?case by (simp add: vero_aux_node_blocks_def[abs_def] ZERO CHILD vero_aux_concat_map_flat)
qed

lemma vero_aux_forest_blocks:
  assumes L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
  shows "concat (map (case_option [] (bn_blocks s)) F) =
    concat (map (vero_aux_node_blocks s) (concat (map (case_option [] bn_ds_node_list) F)))"
  using L by (induction F) (auto simp: vero_aux_layout_blocks split: option.splits)

lemma vero_aux_distinct_components:
  "distinct (concat (map f xs)) \<Longrightarrow> x \<in> set xs \<Longrightarrow> distinct (f x)"
  by (auto simp: distinct_concat_iff)

lemma vero_aux_disjoint_components:
  "distinct (concat (map f xs)) \<Longrightarrow> x \<in> set xs \<Longrightarrow> y \<in> set xs \<Longrightarrow> x \<noteq> y \<Longrightarrow>
    set (f x) \<inter> set (f y) = {}"
proof (induction xs)
  case Nil
  then show ?case by simp
next
  case (Cons z zs)
  have D: "distinct (concat (map f zs))"
    and DIS: "set (f z) \<inter> set (concat (map f zs)) = {}"
    using Cons.prems(1) by auto
  have MEM: "\<And>v. v \<in> set zs \<Longrightarrow> set (f v) \<subseteq> set (concat (map f zs))" by auto
  show ?case using Cons.prems Cons.IH D DIS MEM by (auto; blast)
qed

lemma vero_aux_value_root_member:
  "value_C (bn_tree s (bn_root T)) \<in> set (bn_values s T)"
  by (cases T) simp

definition vero_aux_node_ok where
  "vero_aux_node_ok s P p \<longleftrightarrow> (let es = bn_ds_physical_edges s p in
    c_guard p \<and>
    live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C)) \<and>
    bn_payload P (value_C (bn_tree s p)) \<and>
    unat (order_C (bn_tree s p)) = length es \<and> refcount_C (bn_tree s p) = 1 \<and>
    map (\<lambda>q. unat (order_C (bn_tree s q))) es = [0..<length es] \<and>
    (if es=[] then subtrees_C (bn_tree s p) = NULL else
      c_guard (subtrees_C (bn_tree s p)) \<and>
      live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
        Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length es)) \<and>
    (\<forall>i<length es. c_guard (subtrees_C (bn_tree s p) +\<^sub>p int i) \<and>
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i) = es ! i) \<and>
    (\<forall>q \<in> set es. bn_key s (value_C (bn_tree s p)) \<le> bn_key s (value_C (bn_tree s q))))"

lemma vero_aux_valid_node_fields:
  assumes V: "bn_valid s P T"
  shows "\<forall>p \<in> set (bn_ds_node_list T). vero_aux_node_ok s P p"
  using V
proof (induction T)
  case (BN p cs)
  have L: "bn_ds_tree_layout s P (BN p cs)" by (rule vero_aux_valid_layout[OF BN.prems])
  have ED: "bn_ds_physical_edges s p = map bn_root cs" by (rule vero_aux_layout_physical[OF L])
  have CV: "\<forall>T \<in> set cs. bn_valid s P T" using BN.prems by (simp add: list_all_iff)
  have CR: "\<forall>T \<in> set cs. unat (order_C (bn_tree s (bn_root T))) = bn_rank T"
  proof (intro ballI)
    fix T assume "T \<in> set cs"
    then have "bn_valid s P T" using CV by blast
    then show "unat (order_C (bn_tree s (bn_root T))) = bn_rank T" by (cases T) auto
  qed
  have MP: "map (\<lambda>T. unat (order_C (bn_tree s (bn_root T)))) cs = map bn_rank cs"
    using CR by (auto intro!: map_cong)
  have KEY: "\<forall>T \<in> set cs. bn_key s (value_C (bn_tree s p)) \<le> bn_key s (value_C (bn_tree s (bn_root T)))"
    using BN.prems vero_aux_value_root_member by (auto simp: list_all_iff; blast)
  have ROOT: "vero_aux_node_ok s P p"
    using BN.prems KEY MP by (auto simp: vero_aux_node_ok_def Let_def ED map_map o_def MP)
  have CHILD: "\<forall>T \<in> set cs. \<forall>q \<in> set (bn_ds_node_list T). vero_aux_node_ok s P q"
    using BN.IH CV by blast
  show ?case using ROOT CHILD by auto
qed

lemma vero_aux_layout_reachable:
  assumes L: "bn_ds_tree_layout s P T"
    and SUB: "set (bn_ds_node_list T) \<subseteq> N"
  shows "\<forall>p \<in> set (bn_ds_node_list T).
    (bn_root T,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (bn_ds_physical_edges s q)}\<^sup>*"
  using L SUB
proof (induction T)
  case (BN p cs)
  let ?E = "{(q,r). q \<in> N \<and> r \<in> set (bn_ds_physical_edges s q)}"
  have PN: "p \<in> N" using BN.prems by auto
  have ED: "bn_ds_physical_edges s p = map bn_root cs" by (rule vero_aux_layout_physical[OF BN.prems(1)])
  have CHILD: "\<forall>T \<in> set cs. \<forall>q \<in> set (bn_ds_node_list T). (bn_root T,q) \<in> ?E\<^sup>*"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  have STEP: "\<forall>T \<in> set cs. (p,bn_root T) \<in> ?E"
    using PN ED by auto
  show ?case
  proof (intro ballI)
    fix q assume Q: "q \<in> set (bn_ds_node_list (BN p cs))"
    show "(bn_root (BN p cs),q) \<in> ?E\<^sup>*"
    proof (cases "q=p")
      case True
      then show ?thesis by simp
    next
      case False
      obtain U where UC: "U \<in> set cs" and QU: "q \<in> set (bn_ds_node_list U)" using Q False by auto
      have S: "(p,bn_root U) \<in> ?E" using STEP UC by blast
      have C: "(bn_root U,q) \<in> ?E\<^sup>*" using CHILD UC QU by blast
      show ?thesis using rtrancl_trans[OF r_into_rtrancl[OF S] C] by simp
    qed
  qed
qed

lemma vero_aux_slots_distinct:
  fixes a :: "StrictC'_BinomialTree_C ptr ptr"
  assumes N: "n \<le> 32"
  shows "distinct (bn_ds_slots a n)"
proof -
  have INJ: "inj_on (\<lambda>i. a +\<^sub>p int i) {0..<n}"
  proof (rule inj_onI)
    fix i j assume I: "i \<in> {0..<n}" and J: "j \<in> {0..<n}"
      and E: "a +\<^sub>p int i = a +\<^sub>p int j"
    have WI: "8*i < 2^64" using I N by (simp; arith)
    have WJ: "8*j < 2^64" using J N by (simp; arith)
    have WE: "(of_nat (8*i) :: 64 word) = of_nat (8*j)" using E by (simp add: ptr_add_def algebra_simps)
    have UI: "unat (of_nat (8*i) :: 64 word) = 8*i"
      apply (rule unat_of_nat_eq) using WI by simp
    have UJ: "unat (of_nat (8*j) :: 64 word) = 8*j"
      apply (rule unat_of_nat_eq) using WJ by simp
    have "8*i = 8*j" using arg_cong[OF WE, where f=unat] by (simp only: UI UJ)
    then show "i=j" by arith
  qed
  show ?thesis using INJ by (simp add: bn_ds_slots_def distinct_map)
qed

lemma vero_aux_live_spans_disjoint:
  fixes p :: "'a::mem_type ptr" and q :: "'b::mem_type ptr"
  assumes W: "allocator_wf A" and LP: "live_blocks A (ptr_val p) = Some np"
    and LQ: "live_blocks A (ptr_val q) = Some nq" and NE: "ptr_val p \<noteq> ptr_val q"
    and KP: "size_of TYPE('a) * kp \<le> np" and KQ: "size_of TYPE('b) * kq \<le> nq"
    and I: "i<kp" and J: "j<kq"
  shows "ptr_span (p +\<^sub>p int i) \<inter> ptr_span (q +\<^sub>p int j) = {}"
proof -
  have SP: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) np" by (rule c0008_prove[OF W LP KP I])
  have SQ: "ptr_span (q +\<^sub>p int j) \<subseteq> block_bytes (ptr_val q) nq" by (rule c0008_prove[OF W LQ KQ J])
  have DIS: "block_bytes (ptr_val p) np \<inter> block_bytes (ptr_val q) nq = {}"
    using W LP LQ NE unfolding allocator_wf_def by blast
  show ?thesis using SP SQ DIS by blast
qed

lemma vero_aux_live_slot_readable:
  fixes p :: "'a::mem_type ptr"
  assumes W: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and K: "size_of TYPE('a) * k \<le> n" and I: "i<k"
    and G: "c_guard (p +\<^sub>p int i)"
  shows "block_bytes (ptr_val (p +\<^sub>p int i)) (size_of TYPE('a)) \<subseteq> readable_bytes A"
proof -
  have SP: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n" by (rule c0008_prove[OF W L K I])
  have EQ: "block_bytes (ptr_val (p +\<^sub>p int i)) (size_of TYPE('a)) = ptr_span (p +\<^sub>p int i)"
    using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]] by (simp add: block_bytes_def)
  show ?thesis unfolding EQ by (rule subset_trans[OF SP vero_aux_live_readable[OF L]])
qed

lemma vero_aux_rep_graph:
  assumes R: "bn_rep s h P F M"
  shows "bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {}"
proof -
  let ?N = "bn_ds_forest_nodes F"
  let ?nodes = "concat (map (case_option [] bn_ds_node_list) F)"
  let ?roots = "concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
  let ?slots = "bn_ds_slots (roots_C (bn_heap s h)) (length F)"
  let ?E = "{(q,r). q \<in> ?N \<and> r \<in> set (bn_ds_physical_edges s q)}"
  have NEQ: "?N = set ?nodes" by (simp add: bn_ds_forest_nodes_def)
  have V: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid s P T"
    using R by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    using V vero_aux_valid_layout by blast
  have NN: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<noteq> NULL"
  proof (intro allI impI)
    fix T assume "Some T \<in> set F"
    then have "bn_valid s P T" using V by blast
    then show "bn_root T \<noteq> NULL" by (cases T) (auto dest: c_guard_NULL)
  qed
  have SV: "map (h_val (hrs_mem (t_hrs_' s))) ?slots = map (case_option NULL bn_root) F"
    using R unfolding bn_rep_def bn_ds_slots_def
    by (intro nth_equalityI) (auto simp: o_def)
  have FIL: "filter (\<lambda>p. p \<noteq> NULL) (map (case_option NULL bn_root) F) = ?roots"
    using NN by (induction F) (auto split: option.splits)
  have RH: "bn_ds_slot_handles s ?slots = mset ?roots"
    by (simp only: bn_ds_slot_handles_def SV FIL)
  have ROOTS: "set ?roots \<subseteq> ?N"
    using vero_aux_nodes_root by (auto simp: NEQ split: option.splits)
  have CLOSED: "\<And>p. p \<in> ?N \<Longrightarrow> set (bn_ds_physical_edges s p) \<subseteq> ?N"
  proof -
    fix p assume PN: "p \<in> ?N"
    obtain T where TF: "Some T \<in> set F" and PT: "p \<in> set (bn_ds_node_list T)"
      using PN by (auto simp: vero_aux_forest_node_member)
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    have SUB: "set (bn_ds_node_list T) \<subseteq> ?N" using TF by (auto simp: vero_aux_forest_node_member)
    show "set (bn_ds_physical_edges s p) \<subseteq> ?N"
      using vero_aux_layout_edges_closed[OF LT] PT SUB by blast
  qed
  have REACH: "?N = {p. \<exists>r \<in> set ?roots. (r,p) \<in> ?E\<^sup>*}"
  proof (rule set_eqI, rule iffI)
    fix p assume PN: "p \<in> ?N"
    obtain T where TF: "Some T \<in> set F" and PT: "p \<in> set (bn_ds_node_list T)"
      using PN by (auto simp: vero_aux_forest_node_member)
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    have SUB: "set (bn_ds_node_list T) \<subseteq> ?N" using TF by (auto simp: vero_aux_forest_node_member)
    have PATH: "(bn_root T,p) \<in> ?E\<^sup>*" using vero_aux_layout_reachable[OF LT SUB] PT by blast
    have RT: "bn_root T \<in> set ?roots" using TF by auto
    show "p \<in> {p. \<exists>r \<in> set ?roots. (r,p) \<in> ?E\<^sup>*}" using PATH RT by blast
  next
    fix p assume "p \<in> {p. \<exists>r \<in> set ?roots. (r,p) \<in> ?E\<^sup>*}"
    then obtain r where RT: "r \<in> set ?roots" and PATH: "(r,p) \<in> ?E\<^sup>*" by blast
    have RN: "r \<in> ?N" using ROOTS RT by blast
    show "p \<in> ?N" apply (rule vero_aux_rtrancl_closed[OF PATH RN]) using CLOSED by auto
  qed
  have DB: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
    using R by (auto simp: bn_rep_def bn_owned_def)
  have DN: "distinct ?nodes" by (rule vero_aux_forest_distinct_nodes[OF DB])
  have COUNT: "\<And>p. p \<in> ?N \<Longrightarrow> count (bn_ds_slot_handles s ?slots) p +
      (\<Sum>q \<in> ?N. count (mset (bn_ds_physical_edges s q)) p) = 1"
  proof -
    fix p assume PN: "p \<in> ?N"
    have SUM: "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) p) ?nodes) =
      (\<Sum>q \<in> ?N. count (mset (bn_ds_physical_edges s q)) p)"
      using sum_list_distinct_conv_sum_set[OF DN, where f="\<lambda>q. count (mset (bn_ds_physical_edges s q)) p"] by (simp only: NEQ)
    have ONE: "count (mset ?nodes) p = 1" using DN PN NEQ by (simp add: distinct_count_atmost_1)
    show "count (bn_ds_slot_handles s ?slots) p + (\<Sum>q \<in> ?N. count (mset (bn_ds_physical_edges s q)) p) = 1"
      using vero_aux_forest_edge_count[OF L, where x=p] by (simp only: SUM ONE RH add.commute)
  qed
  have OK: "\<forall>p \<in> ?N. vero_aux_node_ok s P p"
    using V vero_aux_valid_node_fields by (auto simp: vero_aux_forest_node_member; blast)
  have W: "allocator_wf (phantom_machine_state_' s)" and PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and LEN: "length F \<le> 32" using R by (auto simp: bn_rep_def)
  have DS: "distinct ?slots" by (rule vero_aux_slots_distinct[OF LEN])
  have SG: "\<forall>a \<in> set ?slots. c_guard a" using R by (auto simp: bn_rep_def bn_ds_slots_def)
  show ?thesis
    unfolding bn_ds_graph_def
    apply (rule conjI[OF W])
    apply (rule conjI[OF PS])
    apply (rule conjI)
     apply (simp only: NEQ finite_set)
    apply (rule conjI[OF DS])
    apply (rule conjI[OF SG])
    apply (rule conjI)
     using ROOTS apply (simp only: RH add.right_neutral set_mset_mset)
    apply (rule conjI)
     apply simp
    apply (rule conjI)
     apply (simp only: RH add.right_neutral set_mset_mset Un_empty_right)
     apply (rule REACH)
    using OK CLOSED COUNT
    by (auto simp: vero_aux_node_ok_def Let_def)

qed

lemma vero_aux_rep_storage:
  assumes R: "bn_rep s h P F M"
  shows "bn_ds_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"
proof -
  let ?A = "phantom_machine_state_' s"
  let ?a = "roots_C (bn_heap s h)"
  let ?N = "bn_ds_forest_nodes F"
  let ?nodes = "concat (map (case_option [] bn_ds_node_list) F)"
  let ?blocks = "concat (map (case_option [] (bn_blocks s)) F)"
  let ?slots = "bn_ds_slots ?a (length F)"
  have NEQ: "?N = set ?nodes" by (simp add: bn_ds_forest_nodes_def)
  have W: "allocator_wf ?A" and DB: "distinct ?blocks"
    using R by (auto simp: bn_rep_def bn_owned_def)
  have V: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid s P T"
    using R by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    using V vero_aux_valid_layout by blast
  have OK: "\<forall>p \<in> ?N. vero_aux_node_ok s P p"
    using V vero_aux_valid_node_fields by (auto simp: vero_aux_forest_node_member; blast)
  have BEQ: "?blocks = concat (map (vero_aux_node_blocks s) ?nodes)" by (rule vero_aux_forest_blocks[OF L])
  have DC: "\<And>p. p \<in> ?N \<Longrightarrow> distinct (vero_aux_node_blocks s p)"
    using vero_aux_distinct_components[of "vero_aux_node_blocks s" ?nodes] DB by (simp only: BEQ NEQ)
  have DD: "\<And>p q. p \<in> ?N \<Longrightarrow> q \<in> ?N \<Longrightarrow> p \<noteq> q \<Longrightarrow>
    set (vero_aux_node_blocks s p) \<inter> set (vero_aux_node_blocks s q) = {}"
    using vero_aux_disjoint_components[of "vero_aux_node_blocks s" ?nodes] DB by (simp only: BEQ NEQ; blast)
  have AB: "\<And>p. p \<in> ?N \<Longrightarrow> order_C (bn_tree s p) \<noteq> 0 \<Longrightarrow>
    ptr_val (subtrees_C (bn_tree s p)) \<in> set ?blocks"
    by (auto simp: BEQ NEQ vero_aux_node_blocks_def)
  have AN: "\<And>p. p \<in> ?N \<Longrightarrow> order_C (bn_tree s p) \<noteq> 0 \<Longrightarrow>
    ptr_val (subtrees_C (bn_tree s p)) \<notin> ptr_val ` ?N"
  proof -
    fix p assume PN: "p \<in> ?N" and NZ: "order_C (bn_tree s p) \<noteq> 0"
    show "ptr_val (subtrees_C (bn_tree s p)) \<notin> ptr_val ` ?N"
    proof
      assume "ptr_val (subtrees_C (bn_tree s p)) \<in> ptr_val ` ?N"
      then obtain q where QN: "q \<in> ?N" and EQ: "ptr_val (subtrees_C (bn_tree s p)) = ptr_val q" by blast
      show False
      proof (cases "p=q")
        case True
        show False using DC[OF PN] NZ EQ True by (simp add: vero_aux_node_blocks_def)
      next
        case False
        show False using DD[OF PN QN False] NZ EQ by (auto simp: vero_aux_node_blocks_def)
      qed
    qed
  qed
  have AA: "\<And>p q. p \<in> ?N \<Longrightarrow> q \<in> ?N \<Longrightarrow> p \<noteq> q \<Longrightarrow>
    order_C (bn_tree s p) \<noteq> 0 \<Longrightarrow> order_C (bn_tree s q) \<noteq> 0 \<Longrightarrow>
    subtrees_C (bn_tree s p) \<noteq> subtrees_C (bn_tree s q)"
  proof -
    fix p q assume PN: "p \<in> ?N" and QN: "q \<in> ?N" and NE: "p \<noteq> q"
      and PZ: "order_C (bn_tree s p) \<noteq> 0" and QZ: "order_C (bn_tree s q) \<noteq> 0"
    show "subtrees_C (bn_tree s p) \<noteq> subtrees_C (bn_tree s q)"
      using DD[OF PN QN NE] PZ QZ by (auto simp: vero_aux_node_blocks_def)
  qed
  have SG: "\<forall>i<length F. c_guard (?a +\<^sub>p int i)" using R by (simp add: bn_rep_def)
  have SR: "\<forall>x \<in> set ?slots. block_bytes (ptr_val x) (size_of TYPE(StrictC'_BinomialTree_C ptr)) \<subseteq> readable_bytes ?A"
  proof (cases "F=[]")
    case True then show ?thesis by (simp add: bn_ds_slots_def)
  next
    case False
    have NN: "?a \<noteq> NULL" using R False by (auto simp: bn_rep_def)
    obtain n where AL: "live_blocks ?A (ptr_val ?a) = Some n"
      and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F \<le> n"
      using R NN by (auto simp: bn_rep_def)
    show ?thesis using vero_aux_live_slot_readable[OF W AL SZ] SG by (auto simp: bn_ds_slots_def)
  qed
  have AS: "\<And>p. p \<in> ?N \<Longrightarrow> order_C (bn_tree s p) \<noteq> 0 \<Longrightarrow>
    set ?slots \<inter> set (bn_ds_slots (subtrees_C (bn_tree s p)) (unat (order_C (bn_tree s p)))) = {}"
  proof -
    fix p assume PN: "p \<in> ?N" and NZ: "order_C (bn_tree s p) \<noteq> 0"
    let ?b = "subtrees_C (bn_tree s p)"
    let ?k = "unat (order_C (bn_tree s p))"
    show "set ?slots \<inter> set (bn_ds_slots ?b ?k) = {}"
    proof (cases "F=[]")
      case True then show ?thesis by (simp add: bn_ds_slots_def)
    next
      case False
      have NN: "?a \<noteq> NULL" using R False by (auto simp: bn_rep_def)
      obtain n where AL: "live_blocks ?A (ptr_val ?a) = Some n"
        and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F \<le> n"
        using R NN by (auto simp: bn_rep_def)
      have FREE: "ptr_val ?a \<notin> set ?blocks" using R NN by (simp add: bn_rep_def bn_owned_def)
      have NE: "ptr_val ?a \<noteq> ptr_val ?b"
      proof
        assume E: "ptr_val ?a = ptr_val ?b"
        have IN: "ptr_val ?a \<in> set ?blocks" using AB[OF PN NZ] by (simp only: E)
        show False using FREE IN by contradiction
      qed
      have NP: "vero_aux_node_ok s P p" using OK PN by blast
      have LEN: "length (bn_ds_physical_edges s p) = ?k" using NP by (simp add: vero_aux_node_ok_def Let_def)
      have ES: "bn_ds_physical_edges s p \<noteq> []" using NZ LEN by (auto simp: unat_eq_zero)
      have BL: "live_blocks ?A (ptr_val ?b) = Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * ?k)"
        using NP ES LEN by (simp add: vero_aux_node_ok_def Let_def)
      show ?thesis
      proof (rule equals0I)
        fix x assume X: "x \<in> set ?slots \<inter> set (bn_ds_slots ?b ?k)"
        obtain i j where I: "i<length F" and J: "j<?k"
          and XI: "x = ?a +\<^sub>p int i" and XJ: "x = ?b +\<^sub>p int j"
          using X by (auto simp: bn_ds_slots_def)
        have DIS: "ptr_span (?a +\<^sub>p int i) \<inter> ptr_span (?b +\<^sub>p int j) = {}"
          by (rule vero_aux_live_spans_disjoint[OF W AL BL NE SZ order_refl I J])
          have MEM: "ptr_val x \<in> ptr_span x" by (rule intvl_self) simp
        have EMPTY: "ptr_span x = {}" using DIS
          by (simp only: XI[symmetric] XJ[symmetric] Int_absorb)
        show False using MEM by (simp only: EMPTY; simp)
      qed
    qed
  qed
  show ?thesis using SR AN AA AS by (auto simp: bn_ds_graph_storage_def)
qed

lemma c0046_prove:
  "bn_rep s h P F M \<Longrightarrow>
  bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {} \<and>
  bn_ds_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"
proof -
  assume R: "bn_rep s h P F M"
  show ?thesis
    by (rule conjI[OF vero_aux_rep_graph[OF R] vero_aux_rep_storage[OF R]])
qed

context binomial_heap_input_global_addresses begin

lemma vero_aux_undo_zero_release:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and G: "c_guard a" and Z: "h_val (hrs_mem (t_hrs_' s)) a = NULL"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val a)=Some n"
  shows "bn_contract (do {binomial_heap_merge_undo' a 0; binomial_tree_unref' NULL}) s
    (\<lambda>r t. vero_aux_release s {ptr_val a} {ptr_val a} t)"
proof -
  let ?B = "\<lambda>i::32 word. do {
    guard (\<lambda>u. c_guard (a +\<^sub>p uint i));
    p \<leftarrow> gets (\<lambda>u. h_val (hrs_mem (t_hrs_' u)) (a +\<^sub>p uint i));
    ret \<leftarrow> binomial_tree_unref' p;
    return (i+1)}"
  have B0: "bn_contract (?B 0) s (\<lambda>j t. j=1 \<and> t=s)"
    apply simp
    apply (rule vero_aux_guard_prefix)
     apply (rule G)
    apply (rule vero_aux_gets_prefix)
    apply (simp only: Z)
    apply (rule vero_aux_contract_bind[OF vero_aux_unref_null])
    apply (rule vero_aux_return_contract) by simp
  have LOOP: "bn_contract (whileLoop (\<lambda>i u. i\<le>(0::32 word)) ?B 0) s (\<lambda>j t. t=s)"
  proof (rule vero_aux_contract_while[where I="\<lambda>i. i=0 \<or> i=1" and m="\<lambda>i. if i=0 then 1 else 0"])
    fix i assume I: "i=0 \<or> i=1" and C: "i\<le>(0::32 word)"
    have E: "i=0" using C by simp
    show "bn_contract (?B i) s (\<lambda>j t. t=s \<and> (j=0 \<or> j=1) \<and> (if j=0 then (1::nat) else 0) < (if i=0 then 1 else 0))"
      unfolding E apply (rule vero_aux_contract_weaken[OF B0]) by auto
  qed simp_all
  have LP: "live_blocks (phantom_machine_state_' s) (ptr_val (ptr_coerce a :: unit ptr))=Some n" using L by simp
  have FREE: "bn_contract (free' (ptr_coerce a)) s (\<lambda>r t. vero_aux_release s {ptr_val a} {ptr_val a} t)"
    using vero_aux_free_release[OF W LP] by simp
  have UNDO: "bn_contract (binomial_heap_merge_undo' a 0) s (\<lambda>r t. vero_aux_release s {ptr_val a} {ptr_val a} t)"
    unfolding binomial_heap_merge_undo'_def
    apply (rule vero_aux_contract_bind[OF LOOP]) using FREE by simp
  show ?thesis
    apply (rule vero_aux_contract_bind[OF UNDO])
    subgoal for r t
      apply (rule vero_aux_contract_weaken[OF vero_aux_unref_null]) by simp
    done
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_undo_external_storage_lost:
  assumes R: "vero_aux_release s {ptr_val a} {ptr_val a} t"
    and LIVE: "live_blocks (phantom_machine_state_' s) = (\<lambda>q. if q=ptr_val a then Some n else None)"
    and RES: "reserved_bytes (phantom_machine_state_' s)={}"
  shows "\<not>bn_ds_graph_storage t N [b]"
proof -
  have LT: "live_blocks (phantom_machine_state_' t) = (\<lambda>_. None)"
    using R LIVE by (auto simp: vero_aux_release_def fun_eq_iff)
  have RT: "readable_bytes (phantom_machine_state_' t) = {}"
    using R RES LT by (simp add: vero_aux_release_def readable_bytes_def)
  have NONEMPTY: "ptr_val b\<in>block_bytes (ptr_val b) (size_of TYPE(StrictC'_BinomialTree_C ptr))"
    by (simp add: block_bytes_def)
  show ?thesis using NONEMPTY by (auto simp: bn_ds_graph_storage_def RT)
qed

end

context binomial_heap_input_global_addresses begin

definition vero_aux_undo_alias_state :: globals where
  "vero_aux_undo_alias_state = (undefined::globals)\<lparr>
    t_hrs_' := ((\<lambda>_. 0), undefined),
    phantom_machine_state_' := \<lparr>live_blocks = (\<lambda>q. if q=16 then Some 16 else None), reserved_bytes={}\<rparr>\<rparr>"

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_zero_memory_pointer:
  "h_val (\<lambda>_. 0) (p :: 'a::mem_type ptr ptr) = NULL"
proof -
  have H0: "\<And>n a. heap_list (\<lambda>_. 0) n a = replicate n 0"
    by (intro nth_equalityI) (auto simp: heap_list_nth)
  have H: "heap_list (\<lambda>_. 0) 8 (ptr_val p) = replicate 8 0" by (rule H0)
  have "h_val (\<lambda>_. 0) p = ZERO('a ptr)" by (simp add: h_val_def zero_def H)
  then show ?thesis by (simp add: vero_aux_zero_pointer)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_undo_alias_pre:
  "bn_ds_owned_array vero_aux_undo_alias_state (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr) 1 \<and>
   bn_ds_graph vero_aux_undo_alias_state {} {} (\<lambda>_. []) [Ptr 16, Ptr 24] {#} {} \<and>
   bn_ds_graph_storage vero_aux_undo_alias_state {} [Ptr 16, Ptr 24] \<and>
   ptr_val (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr) \<notin> bn_ds_graph_blocks vero_aux_undo_alias_state {}"
proof -
  let ?s = "vero_aux_undo_alias_state"
  have W: "allocator_wf (phantom_machine_state_' ?s)"
    by (auto simp: vero_aux_undo_alias_state_def allocator_wf_def block_ok_def split: if_splits)
  have NG16: "0\<notin>{(16::addr)..+8}"
    using intvl_no_overflow_nat'[where a="16::addr" and b=8 and x=0] by simp
  have NG24: "0\<notin>{(24::addr)..+8}"
    using intvl_no_overflow_nat'[where a="24::addr" and b=8 and x=0] by simp
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr)"
    using NG16 by (simp add: c_guard_def ptr_aligned_def c_null_guard_def ptr_val_def)
  have G24: "c_guard (Ptr 24 :: StrictC'_BinomialTree_C ptr ptr)"
    using NG24 by (simp add: c_guard_def ptr_aligned_def c_null_guard_def ptr_val_def)
  have H16: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr) = NULL"
    by (simp add: vero_aux_undo_alias_state_def hrs_mem_def vero_aux_zero_memory_pointer)
  have H24: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 24 :: StrictC'_BinomialTree_C ptr ptr) = NULL"
    by (simp add: vero_aux_undo_alias_state_def hrs_mem_def vero_aux_zero_memory_pointer)
  have READ: "readable_bytes (phantom_machine_state_' ?s) = block_bytes 16 16"
    by (auto simp: vero_aux_undo_alias_state_def readable_bytes_def split: if_splits)
  have B16: "block_bytes (16::addr) 8 \<subseteq> block_bytes 16 16"
    and B24: "block_bytes (24::addr) 8 \<subseteq> block_bytes 16 16"
    by (auto simp: block_bytes_def)
  have OA: "bn_ds_owned_array ?s (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr) 1"
    using G16 by (auto simp: bn_ds_owned_array_def vero_aux_undo_alias_state_def)
  have GR: "bn_ds_graph ?s {} {} (\<lambda>_. []) [Ptr 16, Ptr 24] {#} {}"
    using W G16 G24 H16 H24 by (simp add: bn_ds_graph_def bn_ds_slot_handles_def)
  have ST: "bn_ds_graph_storage ?s {} [Ptr 16, Ptr 24]"
    using B16 B24 by (simp add: bn_ds_graph_storage_def READ)
  show ?thesis using OA GR ST by (simp add: bn_ds_graph_blocks_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_undo_alias_failure:
  "\<not> bn_contract (do {binomial_heap_merge_undo' (Ptr 16) 0; binomial_tree_unref' NULL}) vero_aux_undo_alias_state
    (\<lambda>r t. \<exists>N. bn_ds_graph_storage t N [Ptr 24])"
proof
  let ?s = "vero_aux_undo_alias_state"
  let ?a = "Ptr 16 :: StrictC'_BinomialTree_C ptr ptr"
  let ?f = "do {binomial_heap_merge_undo' ?a 0; binomial_tree_unref' NULL}"
  assume C: "bn_contract ?f ?s (\<lambda>r t. \<exists>N. bn_ds_graph_storage t N [Ptr 24])"
  have W: "allocator_wf (phantom_machine_state_' ?s)" and G: "c_guard ?a"
    using vero_aux_undo_alias_pre by (auto simp: bn_ds_owned_array_def bn_ds_graph_def)
  have Z: "h_val (hrs_mem (t_hrs_' ?s)) ?a=NULL"
    by (simp add: vero_aux_undo_alias_state_def hrs_mem_def vero_aux_zero_memory_pointer)
  have L: "live_blocks (phantom_machine_state_' ?s) (ptr_val ?a)=Some 16"
    by (simp add: vero_aux_undo_alias_state_def)
  have EXEC: "bn_contract ?f ?s (\<lambda>r t. vero_aux_release ?s {ptr_val ?a} {ptr_val ?a} t)"
    by (rule vero_aux_undo_zero_release[OF W G Z L])
  obtain r t where REACH: "reaches ?f ?s (Result r) t" using C by (auto simp: bn_contract_def)
  have RT: "vero_aux_release ?s {ptr_val ?a} {ptr_val ?a} t"
    using EXEC REACH by (auto simp: bn_contract_def runs_to_def_old)
  have POST: "\<exists>N. bn_ds_graph_storage t N [Ptr 24]"
    using C REACH by (auto simp: bn_contract_def runs_to_def_old)
  have LIVE: "live_blocks (phantom_machine_state_' ?s) = (\<lambda>q. if q=ptr_val ?a then Some 16 else None)"
    and RES: "reserved_bytes (phantom_machine_state_' ?s)={}"
    by (simp_all add: vero_aux_undo_alias_state_def)
  have "\<And>N. \<not>bn_ds_graph_storage t N [Ptr 24]"
    by (rule vero_aux_undo_external_storage_lost[OF RT LIVE RES])
  then show False using POST by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_guarded_array_bound:
  fixes p :: "'a::mem_type ptr"
  assumes G: "\<forall>i<n. c_guard (p +\<^sub>p int i)"
  shows "unat (ptr_val p) + n * size_of TYPE('a) \<le> 2^64"
  using G
proof (induction n)
  case 0
  then show ?case using unat_lt2p[of "ptr_val p"] by simp
next
  case (Suc n)
  have OLD: "unat (ptr_val p) + n * size_of TYPE('a) \<le> 2^64"
    using Suc.IH Suc.prems by auto
  have GN: "c_guard (p +\<^sub>p int n)" using Suc.prems by simp
  have B: "unat (ptr_val (p +\<^sub>p int n)) + size_of TYPE('a) \<le> 2^64"
    using c_guard_no_wrap'[OF GN] by (simp add: addr_card_def card_word)
  have E: "unat (ptr_val (p +\<^sub>p int n)) = (unat (ptr_val p) + n * size_of TYPE('a)) mod 2^64"
    by (simp add: ptr_add_def unat_word_ariths unat_of_nat mod_add_left_eq mod_add_right_eq mod_mult_left_eq mod_mult_right_eq)
  have LT: "unat (ptr_val p) + n * size_of TYPE('a) < 2^64"
  proof (rule ccontr)
    assume "\<not> unat (ptr_val p) + n * size_of TYPE('a) < 2^64"
    then have EQ: "unat (ptr_val p) + n * size_of TYPE('a) = 2^64" using OLD by arith
    have ZERO: "ptr_val (p +\<^sub>p int n) = 0" using E EQ by (simp add: unat_eq_zero)
    have NN: "p +\<^sub>p int n \<noteq> NULL" using GN by (rule c_guard_NULL)
    show False using ZERO NN by (cases "p +\<^sub>p int n") (simp add: ptr_val_def)
  qed
  have U: "unat (ptr_val (p +\<^sub>p int n)) = unat (ptr_val p) + n * size_of TYPE('a)"
    using E LT by simp
  show ?case using B by (simp add: U algebra_simps)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_guarded_array_disjoint:
  fixes p :: "'a::mem_type ptr"
  assumes G: "\<forall>k<n. c_guard (p +\<^sub>p int k)"
    and I: "i<n" and J: "j<n" and NE: "i\<noteq>j"
  shows "ptr_span (p +\<^sub>p int i) \<inter> ptr_span (p +\<^sub>p int j) = {}"
proof -
  have B: "unat (ptr_val p) + n * size_of TYPE('a) \<le> 2^64"
    by (rule vero_aux_guarded_array_bound[OF G])
  have GP: "c_guard p" using G I by (drule_tac x=0 in spec) simp
  have NN: "ptr_val p \<noteq> 0" using GP by (cases p) (auto simp: ptr_val_def dest: c_guard_NULL)
  have Z: "0 \<notin> {ptr_val p ..+ n * size_of TYPE('a)}"
    using intvl_no_overflow_nat'[where a="ptr_val p" and b="n * size_of TYPE('a)" and x=0] B NN
    by (simp add: unat_eq_zero)
  show ?thesis by (rule ptr_span_no_overflow_indexes_disjoint[OF Z I J NE])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_graph_rehandle:
  assumes GR: "bn_ds_graph s P N edges slots held pending"
    and ST: "bn_ds_graph_storage s N slots"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and HN: "\<forall>p \<in> N. bn_tree t p = bn_tree s p"
    and KN: "\<forall>p \<in> N. bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
    and HE: "\<forall>p \<in> N. \<forall>i<length (edges p).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and SH: "bn_ds_slot_handles t slots + held' = bn_ds_slot_handles s slots + held"
  shows "bn_ds_graph t P N edges slots held' pending \<and> bn_ds_graph_storage t N slots"
proof -
  have EN: "\<forall>p \<in> N. set (edges p) \<subseteq> N" using GR by (simp add: bn_ds_graph_def)
  have RK: "\<forall>p \<in> N. map (\<lambda>q. unat (order_C (bn_tree t q))) (edges p) =
    map (\<lambda>q. unat (order_C (bn_tree s q))) (edges p)"
    using HN EN by (auto intro!: map_cong; metis subsetD)
  have ORDER: "\<forall>p \<in> N. \<forall>q \<in> set (edges p).
    bn_key t (value_C (bn_tree t p)) \<le> bn_key t (value_C (bn_tree t q))"
  proof (intro ballI)
    fix p q assume PN: "p \<in> N" and QE: "q \<in> set (edges p)"
    have QN: "q \<in> N" using EN PN QE by blast
    have OLD: "bn_key s (value_C (bn_tree s p)) \<le> bn_key s (value_C (bn_tree s q))"
      using GR PN QE unfolding bn_ds_graph_def by blast
    show "bn_key t (value_C (bn_tree t p)) \<le> bn_key t (value_C (bn_tree t q))"
      by (simp only: HN[rule_format, OF PN] HN[rule_format, OF QN]
        KN[rule_format, OF PN] KN[rule_format, OF QN]; rule OLD)
  qed
  have GT: "bn_ds_graph t P N edges slots held' pending"
    using GR A HN HE KN EN RK ORDER
    by (auto simp: bn_ds_graph_def SH HN[rule_format] KN[rule_format] RK[rule_format])
  have STT: "bn_ds_graph_storage t N slots"
    using ST HN A by (auto simp: bn_ds_graph_storage_def HN[rule_format])
  show ?thesis using GT STT by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_layout_payloads:
  "bn_ds_tree_layout s P T \<Longrightarrow> \<forall>v \<in> set (bn_values s T). bn_payload P v"
  by (induction T) (auto simp: list_all_iff)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_layout_fields:
  assumes L: "bn_ds_tree_layout s P T"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and HN: "\<forall>p \<in> set (bn_ds_node_list T). bn_tree t p = bn_tree s p"
    and HE: "\<forall>p \<in> set (bn_ds_node_list T). \<forall>i<unat (order_C (bn_tree s p)).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and KEY: "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key t v = bn_key s v"
  shows "bn_ds_tree_layout t P T \<and> bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"
  using L HN HE
proof (induction T)
  case (BN p cs)
  have HP: "bn_tree t p = bn_tree s p" using BN.prems by simp
  have CHILD: "\<forall>U \<in> set cs. bn_ds_tree_layout t P U \<and> bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U"
    using BN.IH BN.prems by (auto simp: list_all_iff; blast)
  have MV: "map (bn_values t) cs = map (bn_values s) cs" using CHILD by (auto intro!: map_cong)
  have MB: "map (bn_blocks t) cs = map (bn_blocks s) cs" using CHILD by (auto intro!: map_cong)
  have PAY: "\<forall>v \<in> set (bn_values s (BN p cs)). bn_payload P v"
    by (rule vero_aux_layout_payloads[OF BN.prems(1)])
  have ORDER: "\<forall>q \<in> set (concat (map (bn_values s) cs)).
    bn_key t (value_C (bn_tree s p)) \<le> bn_key t q"
  proof (intro ballI)
    fix q assume Q: "q \<in> set (concat (map (bn_values s) cs))"
    have PP: "bn_payload P (value_C (bn_tree s p))" and PQ: "bn_payload P q" using PAY Q by auto
    have KP: "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))" by (rule KEY[rule_format, OF PP])
    have KQ: "bn_key t q = bn_key s q" by (rule KEY[rule_format, OF PQ])
    have OLD: "bn_key s (value_C (bn_tree s p)) \<le> bn_key s q" using BN.prems(1) Q by (auto; blast)
    show "bn_key t (value_C (bn_tree s p)) \<le> bn_key t q" by (simp only: KP KQ; rule OLD)
  qed
  show ?case using BN.prems CHILD ORDER A
    by (auto simp: HP MV MB list_all_iff)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_array_view_clear:
  assumes V: "bn_review_root_array_view s a F" and I: "i<length F"
    and MEM: "hrs_mem (t_hrs_' t) = heap_update (a +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))"
  shows "bn_review_root_array_view t a (F[i:=None])"
proof -
  have G: "\<forall>j<length F. c_guard (a +\<^sub>p int j)" using V by (simp add: bn_review_root_array_view_def)
  have HV: "\<forall>j<length F. h_val (hrs_mem (t_hrs_' t)) (a +\<^sub>p int j) = case_option NULL bn_root ((F[i:=None])!j)"
  proof (intro allI impI)
    fix j assume J: "j<length F"
    show "h_val (hrs_mem (t_hrs_' t)) (a +\<^sub>p int j) = case_option NULL bn_root ((F[i:=None])!j)"
    proof (cases "j=i")
      case True then show ?thesis using I by (simp add: MEM)
    next
      case False
      have DIS: "ptr_span (a +\<^sub>p int j) \<inter> ptr_span (a +\<^sub>p int i) = {}"
        by (rule vero_aux_guarded_array_disjoint[OF G J I False])
      have VAL: "h_val (hrs_mem (t_hrs_' s)) (a +\<^sub>p int j) = case_option NULL bn_root (F!j)"
        using V J by (simp add: bn_review_root_array_view_def)
      show ?thesis using J False by (simp add: MEM h_val_heap_update_disjoint[OF DIS] VAL)
    qed
  qed
  show ?thesis using G HV by (simp add: bn_review_root_array_view_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_filter_remove:
  fixes xs :: "'a ptr list"
  assumes I: "i<length xs" and R: "xs!i=r" and NN: "r\<noteq>NULL"
  shows "mset (filter (\<lambda>p. p\<noteq>NULL) (xs[i:=NULL])) + {#r#} = mset (filter (\<lambda>p. p\<noteq>NULL) xs)"
  using I R
  by (induction xs arbitrary: i) (auto simp: NN add.assoc add.left_commute split: nat.splits)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_array_clear_handles:
  assumes V: "bn_review_root_array_view s a F" and VT: "bn_review_root_array_view t a (F[i:=None])"
    and I: "i<length F" and T: "F!i=Some T" and NN: "bn_root T\<noteq>NULL"
  shows "bn_ds_slot_handles t (bn_ds_slots a (length F)) + {#bn_root T#} = bn_ds_slot_handles s (bn_ds_slots a (length F))"
proof -
  have VS: "map (h_val (hrs_mem (t_hrs_' s))) (bn_ds_slots a (length F)) = map (case_option NULL bn_root) F"
    by (rule vero_aux_root_array_values[OF V])
  have TV: "map (h_val (hrs_mem (t_hrs_' t))) (bn_ds_slots a (length F)) = (map (case_option NULL bn_root) F)[i:=NULL]"
    using vero_aux_root_array_values[OF VT] by (simp add: map_update)
  have EQ: "mset (filter (\<lambda>p. p\<noteq>NULL) ((map (case_option NULL bn_root) F)[i:=NULL])) + {#bn_root T#} =
    mset (filter (\<lambda>p. p\<noteq>NULL) (map (case_option NULL bn_root) F))"
    apply (rule vero_aux_filter_remove) using I T NN by simp_all
  show ?thesis by (simp only: bn_ds_slot_handles_def VS TV EQ)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_concat_remove:
  assumes I: "i<length xs"
  shows "mset (concat xs) = mset (xs!i) + mset (concat (xs[i:=[]]))"
  using I
proof (induction xs arbitrary: i)
  case Nil then show ?case by simp
next
  case (Cons x xs)
  show ?case
  proof (cases i)
    case 0 then show ?thesis by simp
  next
    case (Suc j)
    have J: "j<length xs" using Cons.prems Suc by simp
    show ?thesis using Cons.IH[OF J] by (simp add: Suc add.assoc add.left_commute)
  qed
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_forest_remove_values:
  assumes I: "i<length F" and FT: "F!i=Some T"
  shows "mset (bn_forest_values s F) = mset (bn_values s T) + mset (bn_forest_values s (F[i:=None]))"
proof -
  have IL: "i<length (map (case_option [] (bn_values s)) F)" using I by simp
  show ?thesis using vero_aux_concat_remove[OF IL] I FT by (simp add: bn_forest_values_def map_update)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_concat_remove_distinct:
  assumes D: "distinct (concat xs)" and I: "i<length xs"
  shows "distinct (concat (xs[i:=[]])) \<and> set (concat (xs[i:=[]])) \<inter> set (xs!i) = {}"
  using D I
proof (induction xs arbitrary: i)
  case Nil then show ?case by simp
next
  case (Cons x xs)
  show ?case
  proof (cases i)
    case 0 then show ?thesis using Cons.prems by (auto simp: distinct_append)
  next
    case (Suc j)
    have DX: "distinct (concat xs)" and J: "j<length xs" using Cons.prems Suc by auto
    have IH: "distinct (concat (xs[j:=[]])) \<and> set (concat (xs[j:=[]])) \<inter> set (xs!j) = {}"
      by (rule Cons.IH[OF DX J])
    have EQ: "set (concat xs) = set (xs!j) \<union> set (concat (xs[j:=[]]))"
      using arg_cong[OF vero_aux_concat_remove[OF J], where f=set_mset]
      by (simp only: set_mset_mset set_mset_union)
    have SUB: "set (concat (xs[j:=[]])) \<subseteq> set (concat xs)" using EQ by blast
    have SUBJ: "set (xs!j) \<subseteq> set (concat xs)" using nth_mem[OF J] by auto
    show ?thesis using Cons.prems IH SUB SUBJ by (auto simp: Suc distinct_append; blast)
  qed
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_node_block_set:
  "set (concat (map (vero_aux_node_blocks s) xs)) = ptr_val ` set xs \<union>
    {ptr_val (subtrees_C (bn_tree s p)) |p. p\<in>set xs \<and> order_C (bn_tree s p)\<noteq>0}"
  by (auto simp: vero_aux_node_blocks_def split: if_splits; blast)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_graph_blocks:
  assumes R: "bn_rep s h P F M"
  shows "bn_ds_graph_blocks s (bn_ds_forest_nodes F) = set (concat (map (case_option [] (bn_blocks s)) F))"
proof -
  have V: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_valid s P T"
    using R by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_ds_tree_layout s P T"
    using V vero_aux_valid_layout by blast
  have BEQ: "concat (map (case_option [] (bn_blocks s)) F) =
    concat (map (vero_aux_node_blocks s) (concat (map (case_option [] bn_ds_node_list) F)))"
    by (rule vero_aux_forest_blocks[OF L])
  show ?thesis by (simp only: BEQ bn_ds_graph_blocks_def bn_ds_forest_nodes_def vero_aux_node_block_set)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_array_update_other:
  fixes a :: "StrictC'_BinomialTree_C ptr ptr" and q :: "'a::mem_type ptr"
  assumes W: "allocator_wf A" and LA: "live_blocks A (ptr_val a) = Some n"
    and LQ: "live_blocks A (ptr_val q) = Some m" and NE: "ptr_val q\<noteq>ptr_val a"
    and SZ: "8*k\<le>n" and I: "i<k" and SQ: "size_of TYPE('a) * l\<le>m" and J: "j<l"
  shows "h_val (heap_update (a +\<^sub>p int i) v hp) (q +\<^sub>p int j) = h_val hp (q +\<^sub>p int j)"
proof -
  have DIS: "ptr_span (q +\<^sub>p int j) \<inter> ptr_span (a +\<^sub>p int i) = {}"
    apply (rule vero_aux_live_spans_disjoint[OF W LQ LA NE SQ _ J I]) using SZ by simp
  show ?thesis by (rule h_val_heap_update_disjoint[OF DIS])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_array_update_key:
  fixes a :: "StrictC'_BinomialTree_C ptr ptr"
  assumes W: "allocator_wf A" and LA: "live_blocks A (ptr_val a) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * k\<le>n" and I: "i<k"
    and PAY: "bn_payload P v" and PS: "P\<subseteq>reserved_bytes A"
    and MEM: "hrs_mem (t_hrs_' t) = heap_update (a +\<^sub>p int i) x (hrs_mem (t_hrs_' s))"
  shows "bn_key t v = bn_key s v"
proof -
  let ?p = "ptr_coerce v :: 32 signed word ptr"
  have G: "c_guard ?p" and B: "block_bytes (ptr_val ?p) 4 \<subseteq> P" using PAY by (auto simp: bn_payload_def)
  have SP: "ptr_span ?p \<subseteq> P"
    using B intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]] by (simp add: block_bytes_def)
  have SA: "ptr_span (a +\<^sub>p int i) \<subseteq> block_bytes (ptr_val a) n" by (rule c0008_prove[OF W LA SZ I])
  have BR: "block_bytes (ptr_val a) n \<inter> reserved_bytes A = {}" using W LA unfolding allocator_wf_def by blast
  have DIS: "ptr_span ?p \<inter> ptr_span (a +\<^sub>p int i) = {}" using SP SA BR PS by blast
  show ?thesis unfolding bn_key_def MEM by (simp only: h_val_heap_update_disjoint[OF DIS])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_clear_other:
  fixes q :: "'a::mem_type ptr"
  assumes R: "bn_rep s h P F M" and I: "i<length F"
    and LQ: "live_blocks (phantom_machine_state_' s) (ptr_val q) = Some m"
    and NE: "ptr_val q\<noteq>ptr_val (roots_C (bn_heap s h))"
    and SQ: "size_of TYPE('a) * l\<le>m" and J: "j<l"
  shows "h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (q +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (q +\<^sub>p int j)"
proof -
  have W: "allocator_wf (phantom_machine_state_' s)" and NN: "roots_C (bn_heap s h)\<noteq>NULL"
    using R I by (auto simp: bn_rep_def)
  obtain n where LA: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
    and SZ: "8*length F\<le>n" using R NN by (auto simp: bn_rep_def)
  have H: "h_val (heap_update (roots_C (bn_heap s h) +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))) (q +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (q +\<^sub>p int j)"
    by (rule vero_aux_array_update_other[OF W LA LQ NE SZ I SQ J])
  show ?thesis using H by (simp add: bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_clear_header:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "bn_heap (bn_review_clear_root s h i) h = bn_heap s h"
proof -
  have L: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    and NN: "roots_C (bn_heap s h)\<noteq>NULL" using R I by (auto simp: bn_rep_def)
  have NE: "ptr_val h\<noteq>ptr_val (roots_C (bn_heap s h))" using R NN by (simp add: bn_rep_def bn_owned_def)
  have H: "h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (h +\<^sub>p int 0) =
    h_val (hrs_mem (t_hrs_' s)) (h +\<^sub>p int 0)"
    by (rule vero_aux_rep_clear_other[OF R I L NE, where l=1 and j=0]) simp_all
  show ?thesis using H by (simp add: bn_heap_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_roots_separate:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "ptr_val (roots_C (bn_heap s h)) \<notin> bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
proof -
  have NN: "roots_C (bn_heap s h)\<noteq>NULL" using R I by (auto simp: bn_rep_def)
  show ?thesis using R NN by (simp add: vero_aux_rep_graph_blocks[OF R] bn_rep_def bn_owned_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_clear_nodes:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "\<forall>p\<in>bn_ds_forest_nodes F. bn_tree (bn_review_clear_root s h i) p = bn_tree s p"
proof (intro ballI)
  fix p assume PN: "p\<in>bn_ds_forest_nodes F"
  have GR: "bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {}" using c0046_prove[OF R] by blast
  have LP: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using GR PN by (simp add: bn_ds_graph_def)
  have IN: "ptr_val p \<in> bn_ds_graph_blocks s (bn_ds_forest_nodes F)" using PN by (auto simp: bn_ds_graph_blocks_def)
  have OUT: "ptr_val (roots_C (bn_heap s h)) \<notin> bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
    by (rule vero_aux_rep_roots_separate[OF R I])
  have NE: "ptr_val p\<noteq>ptr_val (roots_C (bn_heap s h))"
  proof
    assume E: "ptr_val p = ptr_val (roots_C (bn_heap s h))"
    have IN': "ptr_val (roots_C (bn_heap s h)) \<in> bn_ds_graph_blocks s (bn_ds_forest_nodes F)" using IN by (simp only: E)
    show False using OUT IN' by contradiction
  qed
  have H: "h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (p +\<^sub>p int 0) =
    h_val (hrs_mem (t_hrs_' s)) (p +\<^sub>p int 0)"
    by (rule vero_aux_rep_clear_other[OF R I LP NE, where l=1 and j=0]) simp_all
  show "bn_tree (bn_review_clear_root s h i) p = bn_tree s p" using H by (simp add: bn_tree_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_clear_children:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "\<forall>p\<in>bn_ds_forest_nodes F. \<forall>j<length (bn_ds_physical_edges s p).
    h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (subtrees_C (bn_tree s p) +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int j)"
proof (intro ballI allI impI)
  fix p j assume PN: "p\<in>bn_ds_forest_nodes F" and J: "j<length (bn_ds_physical_edges s p)"
  have GR: "bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {}" using c0046_prove[OF R] by blast
  have ES: "bn_ds_physical_edges s p\<noteq>[]" using J by auto
  have LA: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
    Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length (bn_ds_physical_edges s p))"
    using GR PN ES by (simp add: bn_ds_graph_def)
  have NZ: "order_C (bn_tree s p)\<noteq>0" using GR PN J by (auto simp: bn_ds_graph_def)
  have IN: "ptr_val (subtrees_C (bn_tree s p)) \<in> bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
    using PN NZ by (auto simp: bn_ds_graph_blocks_def)
  have OUT: "ptr_val (roots_C (bn_heap s h)) \<notin> bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
    by (rule vero_aux_rep_roots_separate[OF R I])
  have NE: "ptr_val (subtrees_C (bn_tree s p))\<noteq>ptr_val (roots_C (bn_heap s h))"
  proof
    assume E: "ptr_val (subtrees_C (bn_tree s p)) = ptr_val (roots_C (bn_heap s h))"
    have IN': "ptr_val (roots_C (bn_heap s h)) \<in> bn_ds_graph_blocks s (bn_ds_forest_nodes F)" using IN by (simp only: E)
    show False using OUT IN' by contradiction
  qed
  show "h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (subtrees_C (bn_tree s p) +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int j)"
    by (rule vero_aux_rep_clear_other[OF R I LA NE order_refl J])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_clear_keys:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key (bn_review_clear_root s h i) v = bn_key s v"
proof (intro allI impI)
  fix v :: "unit ptr" assume PAY: "bn_payload P v"
  have W: "allocator_wf (phantom_machine_state_' s)" and NN: "roots_C (bn_heap s h)\<noteq>NULL"
    and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)" using R I by (auto simp: bn_rep_def)
  obtain n where LA: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F\<le>n" using R NN by (auto simp: bn_rep_def)
  have MEM: "hrs_mem (t_hrs_' (bn_review_clear_root s h i)) =
    heap_update (roots_C (bn_heap s h) +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))"
    by (simp add: bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  show "bn_key (bn_review_clear_root s h i) v = bn_key s v"
    by (rule vero_aux_array_update_key[OF W LA SZ I PAY PS MEM])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_clear_layouts:
  assumes R: "bn_rep s h P F M" and I: "i<length F" and TF: "Some T\<in>set F"
  shows "bn_ds_tree_layout (bn_review_clear_root s h i) P T \<and>
    bn_values (bn_review_clear_root s h i) T = bn_values s T \<and>
    bn_blocks (bn_review_clear_root s h i) T = bn_blocks s T"
proof -
  let ?t = "bn_review_clear_root s h i"
  have V: "bn_valid s P T" using R TF by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "bn_ds_tree_layout s P T" by (rule vero_aux_valid_layout[OF V])
  have A: "phantom_machine_state_' ?t = phantom_machine_state_' s" by (simp add: bn_review_clear_root_def)
  have SUB: "set (bn_ds_node_list T) \<subseteq> bn_ds_forest_nodes F" using TF by (auto simp: vero_aux_forest_node_member)
  have HN: "\<forall>p\<in>set (bn_ds_node_list T). bn_tree ?t p = bn_tree s p"
    using vero_aux_rep_clear_nodes[OF R I] SUB by blast
  have HE: "\<forall>p\<in>set (bn_ds_node_list T). \<forall>j<unat (order_C (bn_tree s p)).
    h_val (hrs_mem (t_hrs_' ?t)) (subtrees_C (bn_tree s p) +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int j)"
    using vero_aux_rep_clear_children[OF R I] SUB by (auto simp: bn_ds_physical_edges_def bn_ds_slots_def)
  show ?thesis by (rule vero_aux_layout_fields[OF L A HN HE vero_aux_rep_clear_keys[OF R I]])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_clear_graph:
  assumes R: "bn_rep s h P F M" and I: "i<length F" and FT: "F!i=Some T"
  shows "bn_ds_graph (bn_review_clear_root s h i) P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#bn_root T#} {} \<and>
    bn_ds_graph_storage (bn_review_clear_root s h i) (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"
proof -
  let ?t = "bn_review_clear_root s h i"
  let ?slots = "bn_ds_slots (roots_C (bn_heap s h)) (length F)"
  have GR: "bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s) ?slots {#} {}"
    and ST: "bn_ds_graph_storage s (bn_ds_forest_nodes F) ?slots" using c0046_prove[OF R] by blast+
  have A: "phantom_machine_state_' ?t = phantom_machine_state_' s" by (simp add: bn_review_clear_root_def)
  have HN: "\<forall>p\<in>bn_ds_forest_nodes F. bn_tree ?t p = bn_tree s p" by (rule vero_aux_rep_clear_nodes[OF R I])
  have KN: "\<forall>p\<in>bn_ds_forest_nodes F. bn_key ?t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
    using GR vero_aux_rep_clear_keys[OF R I] by (auto simp: bn_ds_graph_def)
  have HE: "\<forall>p\<in>bn_ds_forest_nodes F. \<forall>j<length (bn_ds_physical_edges s p).
    h_val (hrs_mem (t_hrs_' ?t)) (subtrees_C (bn_tree s p) +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int j)"
    by (rule vero_aux_rep_clear_children[OF R I])
  have V: "bn_review_root_array_view s (roots_C (bn_heap s h)) F" using R by (simp add: bn_rep_def bn_review_root_array_view_def)
  have MEM: "hrs_mem (t_hrs_' ?t) = heap_update (roots_C (bn_heap s h) +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))"
    by (simp add: bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have VT: "bn_review_root_array_view ?t (roots_C (bn_heap s h)) (F[i:=None])" by (rule vero_aux_array_view_clear[OF V I MEM])
  have VALID: "bn_valid s P T" using R I FT by (auto simp: bn_rep_def)
  have NN: "bn_root T\<noteq>NULL" using VALID by (cases T) (auto dest: c_guard_NULL)
  have SH: "bn_ds_slot_handles ?t ?slots + {#bn_root T#} = bn_ds_slot_handles s ?slots + {#}"
    using vero_aux_array_clear_handles[OF V VT I FT NN] by simp
  show ?thesis by (rule vero_aux_graph_rehandle[OF GR ST A HN KN HE SH])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_graph_reserved_frame:
  assumes GR: "bn_ds_graph s P N edges slots held pending" and ST: "bn_ds_graph_storage s N slots"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)" and PS: "P\<inter>S={}"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
    and SH: "bn_ds_slot_handles t slots = bn_ds_slot_handles s slots"
  shows "bn_ds_graph t P N edges slots held pending \<and> bn_ds_graph_storage t N slots \<and>
    (\<forall>p\<in>N. bn_tree t p = bn_tree s p)"
proof -
  have W: "allocator_wf (phantom_machine_state_' s)" using GR by (simp add: bn_ds_graph_def)
  have HN: "\<forall>p\<in>N. bn_tree t p = bn_tree s p"
  proof (intro ballI)
    fix p assume PN: "p\<in>N"
    have L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
      using GR PN by (simp add: bn_ds_graph_def)
    show "bn_tree t p = bn_tree s p" unfolding bn_tree_def
      by (rule vero_aux_stack_live_h_val[OF W L order_refl SS BF])
  qed
  have KN: "\<forall>p\<in>N. bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
  proof (intro ballI)
    fix p assume PN: "p\<in>N"
    have PAY: "bn_payload P (value_C (bn_tree s p))" using GR PN by (simp add: bn_ds_graph_def)
    show "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
      by (rule vero_aux_payload_key_frame[OF PAY PS BF])
  qed
  have HE: "\<forall>p\<in>N. \<forall>i<length (edges p).
    h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
  proof (intro ballI allI impI)
    fix p i assume PN: "p\<in>N" and I: "i<length (edges p)"
    have NE: "edges p\<noteq>[]" using I by auto
    have L: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
      Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length (edges p))"
      using GR PN NE by (simp add: bn_ds_graph_def)
    show "h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
      by (rule vero_aux_stack_live_array[OF W L order_refl I SS BF])
  qed
  have SHH: "bn_ds_slot_handles t slots + held = bn_ds_slot_handles s slots + held" by (simp only: SH)
  have GT: "bn_ds_graph t P N edges slots held pending \<and> bn_ds_graph_storage t N slots"
    by (rule vero_aux_graph_rehandle[OF GR ST A HN KN HE SHH])
  show ?thesis using GT HN by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_array_view_reserved:
  assumes W: "allocator_wf (phantom_machine_state_' s)" and V: "bn_review_root_array_view s a F"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val a) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F\<le>n"
    and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
  shows "bn_review_root_array_view t a F"
proof -
  have H: "\<forall>i<length F. h_val (hrs_mem (t_hrs_' t)) (a +\<^sub>p int i) = h_val (hrs_mem (t_hrs_' s)) (a +\<^sub>p int i)"
    by (intro allI impI; rule vero_aux_stack_live_array[OF W L SZ _ SS BF]; assumption)
  show ?thesis using V H by (simp add: bn_review_root_array_view_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_rep_clear_valid:
  assumes R: "bn_rep s h P F M" and I: "i<length F" and TF: "Some T\<in>set F"
  shows "bn_valid (bn_review_clear_root s h i) P T"
proof -
  let ?t = "bn_review_clear_root s h i"
  have V: "bn_valid s P T" using R TF by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "bn_ds_tree_layout ?t P T" using vero_aux_rep_clear_layouts[OF R I TF] by blast
  have SUB: "set (bn_ds_node_list T)\<subseteq>bn_ds_forest_nodes F" using TF by (auto simp: vero_aux_forest_node_member)
  have REFS: "\<forall>p\<in>set (bn_ds_node_list T). refcount_C (bn_tree ?t p) = 1"
    using vero_aux_valid_node_fields[OF V] vero_aux_rep_clear_nodes[OF R I] SUB
    by (auto simp: vero_aux_node_ok_def Let_def; blast)
  show ?thesis by (rule vero_aux_layout_valid_refs[OF L REFS])
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_update_span_frame:
  fixes p :: "'a::mem_type ptr"
  assumes G: "c_guard p" and SP: "ptr_span p\<subseteq>S"
  shows "bytes_frame S hp (heap_update p v hp)"
proof -
  have EQ: "block_bytes (ptr_val p) (size_of TYPE('a)) = ptr_span p"
    using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]] by (simp add: block_bytes_def)
  have BF: "bytes_frame (ptr_span p) hp (heap_update p v hp)" using vero_aux_update_frame[OF G] by (simp only: EQ)
  show ?thesis using BF SP by (auto simp: bytes_frame_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_live_reserved_span:
  fixes p :: "'a::mem_type ptr" and q :: "'b::mem_type ptr"
  assumes A: "allocator_wf B" and L: "live_blocks B (ptr_val p) = Some n"
    and SZ: "size_of TYPE('a) * k\<le>n" and I: "i<k"
    and SP: "ptr_span q\<subseteq>S" and SS: "S\<subseteq>reserved_bytes B"
  shows "ptr_span (p +\<^sub>p int i) \<inter> ptr_span q = {}"
proof -
  have BP: "ptr_span (p +\<^sub>p int i)\<subseteq>block_bytes (ptr_val p) n" by (rule c0008_prove[OF A L SZ I])
  have DIS: "block_bytes (ptr_val p) n \<inter> reserved_bytes B = {}" using A L unfolding allocator_wf_def by blast
  show ?thesis using BP DIS SP SS by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_forest_detach_distinct:
  assumes D: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
    and I: "i<length F" and FT: "F!i=Some (BN p cs)"
  shows "distinct (concat (map (case_option [] (bn_blocks s)) (F[i:=None] @ map Some cs)))"
proof -
  let ?xs = "map (case_option [] (bn_blocks s)) F"
  let ?rest = "concat (map (case_option [] (bn_blocks s)) (F[i:=None]))"
  let ?children = "concat (map (bn_blocks s) cs)"
  have IX: "i<length ?xs" using I by simp
  have E: "?xs!i=bn_blocks s (BN p cs)" using I FT by simp
  have U: "concat (?xs[i:=[]]) = ?rest" by (simp add: map_update)
  have DR: "distinct ?rest" and DIS: "set ?rest \<inter> set (bn_blocks s (BN p cs)) = {}"
    using vero_aux_concat_remove_distinct[OF D IX] by (simp_all only: U E)
  have TF: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FT by simp
  have DT: "distinct (bn_blocks s (BN p cs))"
    using vero_aux_distinct_components[OF D TF] by simp
  have DC: "distinct ?children" using DT by simp
  have SUB: "set ?children\<subseteq>set (bn_blocks s (BN p cs))" by auto
  have RC: "set ?rest \<inter> set ?children = {}" using DIS SUB by blast
  show ?thesis using DR DC RC by (simp add: o_def)
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_forest_detach_length:
  assumes I: "i<length F" and FT: "F!i=Some (BN p cs)"
  shows "length (bn_forest_values s F) =
    Suc (length (bn_forest_values s (F[i:=None])) + length (bn_forest_values s (map Some cs)))"
  using arg_cong[OF vero_aux_forest_remove_values[OF I FT], where f=size]
  by (simp add: bn_forest_values_def o_def add.commute)

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_detach_core:
  fixes i :: nat and s u t :: globals and v :: "StrictC'_BinomialHeap_C"
    and h fake :: "StrictC'_BinomialHeap_C ptr" and p :: "StrictC'_BinomialTree_C ptr"
  defines "u \<equiv> bn_review_clear_root s h i"
    and "v \<equiv> (bn_heap u fake)\<lparr>heap_type_C := heap_type_C (bn_heap u h),
      compare_func_C := compare_func_C (bn_heap u h), roots_C := subtrees_C (bn_tree u p),
      roots_length_C := UCAST(16 \<rightarrow> 32) (order_C (bn_tree u p))\<rparr>"
    and "t \<equiv> t_hrs_'_update (hrs_mem_update (heap_update fake v)) u"
  assumes R: "bn_rep s h P F M" and I: "i<length F" and FT: "F!i=Some (BN p cs)"
    and GF: "c_guard fake" and SP: "ptr_span fake\<subseteq>S"
    and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)" and PS: "P\<inter>S={}"
  shows "phantom_machine_state_' t = phantom_machine_state_' s \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    bn_heap t h = bn_heap s h \<and> bn_heap t fake = v \<and> bn_heap u h = bn_heap s h \<and>
    bn_tree u p = bn_tree s p \<and>
    bn_review_root_array_view t (roots_C (bn_heap s h)) (F[i:=None]) \<and>
    (\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid t P U \<and> bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U) \<and>
    (\<forall>q\<in>bn_ds_forest_nodes F. bn_tree t q = bn_tree s q) \<and>
    bn_ds_graph t P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
      (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#p#} {} \<and>
    bn_ds_graph_storage t (bn_ds_forest_nodes F) (bn_ds_slots (roots_C (bn_heap s h)) (length F)) \<and>
    distinct (concat (map (case_option [] (bn_blocks t)) (F[i:=None] @ map Some cs))) \<and>
    length (bn_forest_values t (F[i:=None])) + length (bn_forest_values t (map Some cs)) < 2^32"
proof -
  let ?N = "bn_ds_forest_nodes F"
  let ?a = "roots_C (bn_heap s h)"
  let ?slots = "bn_ds_slots ?a (length F)"
  have A0: "phantom_machine_state_' u = phantom_machine_state_' s" by (simp add: u_def bn_review_clear_root_def)
  have A1: "phantom_machine_state_' t = phantom_machine_state_' u" by (simp add: t_def)
  have AT: "phantom_machine_state_' t = phantom_machine_state_' s" by (simp only: A1 A0)
  have W: "allocator_wf (phantom_machine_state_' s)" and LEN: "length F\<le>32"
    and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    and NN: "?a\<noteq>NULL" using R I by (auto simp: bn_rep_def)
  have WU: "allocator_wf (phantom_machine_state_' u)" using W by (simp only: A0)
  have SSU: "S\<subseteq>reserved_bytes (phantom_machine_state_' u)" using SS by (simp only: A0)
  have BF: "bytes_frame S (hrs_mem (t_hrs_' u)) (hrs_mem (t_hrs_' t))"
    using vero_aux_update_span_frame[OF GF SP, where hp="hrs_mem (t_hrs_' u)" and v=v]
    by (simp add: t_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  obtain n where LA: "live_blocks (phantom_machine_state_' s) (ptr_val ?a) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F\<le>n" using R NN by (auto simp: bn_rep_def)
  have LAU: "live_blocks (phantom_machine_state_' u) (ptr_val ?a) = Some n" by (simp only: A0 LA)
  have SZU: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length (F[i:=None])\<le>n" using SZ by simp
  have V0: "bn_review_root_array_view s ?a F" using R by (simp add: bn_rep_def bn_review_root_array_view_def)
  have MU: "hrs_mem (t_hrs_' u) = heap_update (?a +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))"
    by (simp add: u_def bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have VU: "bn_review_root_array_view u ?a (F[i:=None])" by (rule vero_aux_array_view_clear[OF V0 I MU])
  have VT: "bn_review_root_array_view t ?a (F[i:=None])" by (rule vero_aux_array_view_reserved[OF WU VU LAU SZU SSU BF])
  have HVU: "map (h_val (hrs_mem (t_hrs_' u))) ?slots = map (case_option NULL bn_root) (F[i:=None])"
    using vero_aux_root_array_values[OF VU] by simp
  have HVT: "map (h_val (hrs_mem (t_hrs_' t))) ?slots = map (case_option NULL bn_root) (F[i:=None])"
    using vero_aux_root_array_values[OF VT] by simp
  have SH: "bn_ds_slot_handles t ?slots = bn_ds_slot_handles u ?slots"
    by (simp only: bn_ds_slot_handles_def HVU HVT)
  have GU: "bn_ds_graph u P ?N (bn_ds_physical_edges s) ?slots {#p#} {}"
    and SU: "bn_ds_graph_storage u ?N ?slots"
    using vero_aux_rep_clear_graph[OF R I FT] by (simp_all add: u_def)
  have HN0: "\<forall>q\<in>?N. bn_tree u q = bn_tree s q" using vero_aux_rep_clear_nodes[OF R I] by (simp only: u_def)
  have GT: "bn_ds_graph t P ?N (bn_ds_physical_edges s) ?slots {#p#} {}"
    and ST: "bn_ds_graph_storage t ?N ?slots"
    and HN1: "\<forall>q\<in>?N. bn_tree t q = bn_tree u q"
    using vero_aux_graph_reserved_frame[OF GU SU A1 SSU PS BF SH] by blast+
  have HN: "\<forall>q\<in>?N. bn_tree t q = bn_tree s q" using HN1 HN0 by auto
  have HU: "bn_heap u h = bn_heap s h" using vero_aux_rep_clear_header[OF R I] by (simp only: u_def)
  have LHU: "live_blocks (phantom_machine_state_' u) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    by (simp only: A0 LH)
  have HT: "bn_heap t h = bn_heap u h" unfolding bn_heap_def
    by (rule vero_aux_stack_live_h_val[OF WU LHU order_refl SSU BF])
  have HH: "bn_heap t h = bn_heap s h" by (simp only: HT HU)
  have HF: "bn_heap t fake = v" by (simp add: t_def bn_heap_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have TFM: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FT by simp
  have PN: "p\<in>?N" using TFM by (auto simp: vero_aux_forest_node_member)
  have HP: "bn_tree t p = bn_tree s p" using HN PN by blast
  have HPU: "bn_tree u p = bn_tree s p" using HN0 PN by blast
  have ALL: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid t P U \<and>
    bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U"
  proof (intro allI impI)
    fix U assume UF: "Some U\<in>set F"
    have VU': "bn_valid u P U" using vero_aux_rep_clear_valid[OF R I UF] by (simp only: u_def)
    have FRAME: "bn_valid t P U \<and> bn_values t U = bn_values u U \<and> bn_blocks t U = bn_blocks u U \<and>
      (\<forall>x\<in>set (bn_values u U). bn_key t x = bn_key u x)"
      by (rule vero_aux_valid_reserved_frame[OF WU A1 SSU PS BF VU'])
    have OLD: "bn_values u U = bn_values s U \<and> bn_blocks u U = bn_blocks s U"
      using vero_aux_rep_clear_layouts[OF R I UF] by (simp add: u_def)
    show "bn_valid t P U \<and> bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U"
      using FRAME OLD by simp
  qed
  have VP: "bn_valid t P (BN p cs)" and PV: "bn_values t (BN p cs) = bn_values s (BN p cs)"
    and PB: "bn_blocks t (BN p cs) = bn_blocks s (BN p cs)" using ALL TFM by blast+
  have RANK: "length cs=i" using R I FT by (auto simp: bn_rep_def)
  have CL: "length cs\<le>32" using RANK I LEN by arith
  have CV: "concat (map (bn_values t) cs) = concat (map (bn_values s) cs)" using PV HP by simp
  have CB: "concat (map (bn_blocks t) cs) = concat (map (bn_blocks s) cs)" using PB HP by (cases "cs=[]") simp_all
  have MFV: "map (case_option [] (bn_values t)) F = map (case_option [] (bn_values s)) F"
    using ALL by (auto intro!: map_cong split: option.splits)
  have MFB: "map (case_option [] (bn_blocks t)) F = map (case_option [] (bn_blocks s)) F"
    using ALL by (auto intro!: map_cong split: option.splits)
  have FV: "bn_forest_values t (F[i:=None]) = bn_forest_values s (F[i:=None])"
    by (simp add: bn_forest_values_def map_update MFV)
  have GV: "bn_forest_values t (map Some cs) = bn_forest_values s (map Some cs)"
    by (simp add: bn_forest_values_def o_def CV)
  have FB: "concat (map (case_option [] (bn_blocks t)) (F[i:=None])) = concat (map (case_option [] (bn_blocks s)) (F[i:=None]))"
    by (simp add: map_update MFB)
  have GB: "concat (map (case_option [] (bn_blocks t)) (map Some cs)) = concat (map (case_option [] (bn_blocks s)) (map Some cs))"
    by (simp add: o_def CB)
  have DB: "distinct (concat (map (case_option [] (bn_blocks s)) F))" using R by (auto simp: bn_rep_def bn_owned_def)
  have DIST: "distinct (concat (map (case_option [] (bn_blocks t)) (F[i:=None] @ map Some cs)))"
    using vero_aux_forest_detach_distinct[OF DB I FT] by (simp only: map_append concat_append FB GB)
  have MASS: "length (bn_forest_values t (F[i:=None])) + length (bn_forest_values t (map Some cs)) < 2^32"
  proof -
    have B: "length (bn_forest_values s F) < 2^32"
      using R unat_lt2p[of "num_values_C (bn_heap s h)"] by (simp add: bn_rep_def)
    show ?thesis using vero_aux_forest_detach_length[OF I FT, where s=s] B by (simp only: FV GV; arith)
  qed
  have HTD: "hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s)"
    by (simp add: t_def u_def bn_review_clear_root_def hrs_mem_update_def hrs_htd_def case_prod_unfold)
  show ?thesis using AT HTD HH HF HU HPU VT ALL HN GT ST DIST MASS by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_detach_views:
  fixes s :: globals
  assumes R: "bn_rep s h P F M" and I: "i<length F" and FT: "F!i=Some (BN p cs)"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s" and HH: "bn_heap t h = bn_heap s h"
    and GF: "c_guard fake" and SP: "ptr_span fake\<subseteq>S" and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and FK: "heap_type_C (bn_heap t fake) = BINOMIAL_HEAP_TYPE_MIN"
    and FC: "compare_func_C (bn_heap t fake) = binomial_heap_input.int_compare"
    and FR: "roots_C (bn_heap t fake) = subtrees_C (bn_tree t p)"
    and FL: "unat (roots_length_C (bn_heap t fake)) = length cs"
    and RV: "bn_review_root_array_view t (roots_C (bn_heap s h)) (F[i:=None])"
    and VP: "bn_valid t P (BN p cs)"
    and ALL: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid t P U"
  shows "bn_ds_forest_view t h P (F[i:=None]) \<and> bn_ds_forest_view t fake P (map Some cs)"
proof -
  have OLD: "bn_ds_forest_view s h P F" by (rule vero_aux_rep_forest_view[OF R])
  have LF: "length F\<le>32" and LC: "length cs=i" using R I FT by (auto simp: bn_rep_def)
  have CS: "length cs\<le>32" using LF LC I by arith
  have LAYOUT: "\<forall>j<length (F[i:=None]). case (F[i:=None])!j of None \<Rightarrow> True | Some U \<Rightarrow> bn_rank U=j \<and> bn_ds_tree_layout t P U"
  proof (intro allI impI)
    fix j assume J: "j<length (F[i:=None])"
    show "case (F[i:=None])!j of None \<Rightarrow> True | Some U \<Rightarrow> bn_rank U=j \<and> bn_ds_tree_layout t P U"
    proof (cases "(F[i:=None])!j")
      case None then show ?thesis by simp
    next
      case (Some U)
      have JF: "j<length F" using J by simp
      have OLDJ: "F!j=Some U" using Some I JF by (auto simp: nth_list_update split: if_splits)
      have RANK: "bn_rank U=j" using R JF OLDJ by (auto simp: bn_rep_def)
      have UF: "Some U\<in>set F" using nth_mem[OF JF] OLDJ by simp
      have VU: "bn_valid t P U" using ALL UF by blast
      have LU: "bn_ds_tree_layout t P U" by (rule vero_aux_valid_layout[OF VU])
      show ?thesis using Some RANK LU by simp
    qed
  qed
  have VH: "bn_ds_forest_view t h P (F[i:=None])"
    using OLD RV LAYOUT A HH
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
  have EQ: "block_bytes (ptr_val fake) (size_of TYPE(StrictC'_BinomialHeap_C)) = ptr_span fake"
    using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF GF]] by (simp add: block_bytes_def)
  have RF: "block_bytes (ptr_val fake) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq> readable_bytes (phantom_machine_state_' t)"
    using SP SS by (simp only: EQ A; auto simp: readable_bytes_def)
  have RA: "block_bytes (ptr_val (subtrees_C (bn_tree t p))) (8*length cs) \<subseteq> readable_bytes (phantom_machine_state_' t)"
  proof (cases "cs=[]")
    case True then show ?thesis by (auto simp: block_bytes_def)
  next
    case False
    have L: "live_blocks (phantom_machine_state_' t) (ptr_val (subtrees_C (bn_tree t p))) = Some (8*length cs)"
      using VP False by simp
    show ?thesis by (rule vero_aux_live_readable[OF L])
  qed
  have RVG: "bn_review_root_array_view t (subtrees_C (bn_tree t p)) (map Some cs)"
    using VP by (auto simp: bn_review_root_array_view_def)
  have RANKS: "map bn_rank cs = [0..<length cs]" using VP by simp
  have LG: "\<forall>j<length (map Some cs). case (map Some cs)!j of None \<Rightarrow> True | Some U \<Rightarrow> bn_rank U=j \<and> bn_ds_tree_layout t P U"
  proof (intro allI impI)
    fix j assume J: "j<length (map Some cs)"
    have JC: "j<length cs" using J by simp
    have VJ: "bn_valid t P (cs!j)" using VP nth_mem[OF JC] by (simp add: list_all_iff)
    have LJ: "bn_ds_tree_layout t P (cs!j)" by (rule vero_aux_valid_layout[OF VJ])
    have RJ: "bn_rank (cs!j)=j" using arg_cong[OF RANKS, where f="\<lambda>xs. xs!j"] JC by simp
    show "case (map Some cs)!j of None \<Rightarrow> True | Some U \<Rightarrow> bn_rank U=j \<and> bn_ds_tree_layout t P U"
      using JC LJ RJ by simp
  qed
  have VG: "bn_ds_forest_view t fake P (map Some cs)"
    using GF FK FC FR FL RF RA RVG CS LG
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
  show ?thesis using VH VG by blast
qed

end

context binomial_heap_input_global_addresses begin

lemma vero_aux_detach_merge_pre:
  assumes R: "bn_rep s h P F M" and I: "i<length F" and FT: "F!i=Some (BN p cs)"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s" and HH: "bn_heap t h = bn_heap s h"
    and SP: "ptr_span fake\<subseteq>S" and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and HN: "\<forall>q\<in>bn_ds_forest_nodes F. bn_tree t q = bn_tree s q"
    and VH: "bn_ds_forest_view t h P (F[i:=None])" and VG: "bn_ds_forest_view t fake P (map Some cs)"
    and GT: "bn_ds_graph t P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
      (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#p#} {}"
    and ST: "bn_ds_graph_storage t (bn_ds_forest_nodes F) (bn_ds_slots (roots_C (bn_heap s h)) (length F))"
    and DIST: "distinct (concat (map (case_option [] (bn_blocks t)) (F[i:=None] @ map Some cs)))"
    and MASS: "length (bn_forest_values t (F[i:=None])) + length (bn_forest_values t (map Some cs)) < 2^32"
  shows "bn_ds_merge_pre t h fake P (F[i:=None]) (map Some cs) [] {#p#}
    (bn_ds_forest_nodes F) (bn_ds_physical_edges s)"
proof -
  let ?N = "bn_ds_forest_nodes F"
  let ?a = "roots_C (bn_heap s h)"
  have W: "allocator_wf (phantom_machine_state_' s)"
    and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    and NN: "?a\<noteq>NULL" using R I by (auto simp: bn_rep_def)
  have LT: "live_blocks (phantom_machine_state_' t) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    by (simp only: A LH)
  have OA: "bn_ds_owned_array t ?a (length (F[i:=None]))" using R NN A by (auto simp: bn_rep_def bn_ds_owned_array_def)
  have GB: "bn_ds_graph_blocks t ?N = bn_ds_graph_blocks s ?N"
    using HN by (auto simp: bn_ds_graph_blocks_def HN[rule_format])
  have HB: "ptr_val h\<notin>bn_ds_graph_blocks s ?N"
    using R by (simp add: vero_aux_rep_graph_blocks[OF R] bn_rep_def bn_owned_def)
  have AB: "ptr_val ?a\<notin>bn_ds_graph_blocks s ?N" by (rule vero_aux_rep_roots_separate[OF R I])
  have D0: "ptr_span (h +\<^sub>p int 0) \<inter> ptr_span fake = {}"
    by (rule vero_aux_live_reserved_span[OF W LH _ _ SP SS, where k=1 and i=0]) simp_all
  have DIS: "ptr_span h \<inter> ptr_span fake = {}" using D0 by simp
  have NE: "h\<noteq>fake"
  proof
    assume E: "h=fake"
    have EMPTY: "ptr_span h = {}" using DIS by (simp only: E[symmetric] Int_absorb)
    have MEM: "ptr_val h\<in>ptr_span h" by (rule intvl_self) simp
    show False using MEM by (simp only: EMPTY; simp)
  qed
  have TFM: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FT by simp
  have ROOTS: "\<forall>U. Some U\<in>set (map Some cs) \<longrightarrow> bn_root U\<in>?N"
  proof (intro allI impI)
    fix U assume UF: "Some U\<in>set (map Some cs)"
    have UC: "U\<in>set cs" using UF by auto
    have NODE: "bn_root U\<in>set (bn_ds_node_list (BN p cs))" using UC vero_aux_nodes_root[of U] by auto
    show "bn_root U\<in>?N" using TFM NODE by (simp only: vero_aux_forest_node_member; blast)
  qed
  have V0: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid s P U" using R by (auto simp: bn_rep_def in_set_conv_nth)
  have REF0: "\<forall>q\<in>?N. refcount_C (bn_tree s q) = 1"
  proof (intro ballI)
    fix q assume QN: "q\<in>?N"
    obtain U where UF: "Some U\<in>set F" and QU: "q\<in>set (bn_ds_node_list U)"
      using QN by (auto simp: vero_aux_forest_node_member)
    have VU: "bn_valid s P U" using V0 UF by blast
    have OK: "vero_aux_node_ok s P q" using vero_aux_valid_node_fields[OF VU] QU by blast
    show "refcount_C (bn_tree s q) = 1" using OK by (simp add: vero_aux_node_ok_def Let_def)
  qed
  have REF: "\<forall>q\<in>?N. unat (refcount_C (bn_tree t q)) < 65533" using HN REF0 by auto
  show ?thesis using VH VG DIST LT OA HB AB NE GT ST ROOTS MASS REF
    by (auto simp: bn_ds_merge_pre_def HH GB)
qed

end

context binomial_heap_input_global_addresses begin

lemma c0061_prove:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  c_guard fake \<Longrightarrow> root_ptr_valid (hrs_htd (t_hrs_' entry)) fake \<Longrightarrow>
  ptr_span fake \<subseteq> \<S> \<Longrightarrow> \<S> \<subseteq> reserved_bytes (phantom_machine_state_' entry) \<Longrightarrow>
  P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t.
   r = bn_root T \<and> phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry) \<and>
   (\<exists>N edges. bn_ds_merge_pre t h fake P (F[i := None]) (map Some (bn_ds_children T)) [] {#r#} N edges))"
proof -
  assume R: "bn_rep entry h P F M" and I: "i<length F" and FT: "F!i=Some T"
    and GF: "c_guard fake" and RPV: "root_ptr_valid (hrs_htd (t_hrs_' entry)) fake"
    and SP: "ptr_span fake\<subseteq>\<S>" and SS: "\<S>\<subseteq>reserved_bytes (phantom_machine_state_' entry)"
    and PS: "P\<inter>\<S>={}"
  obtain p cs where SHAPE: "T=BN p cs" by (cases T) auto
  have FTP: "F!i=Some (BN p cs)" using FT SHAPE by simp
  let ?u = "bn_review_clear_root entry h i"
  let ?v = "(bn_heap ?u fake)\<lparr>heap_type_C := heap_type_C (bn_heap ?u h),
    compare_func_C := compare_func_C (bn_heap ?u h), roots_C := subtrees_C (bn_tree ?u p),
    roots_length_C := UCAST(16 \<rightarrow> 32) (order_C (bn_tree ?u p))\<rparr>"
  let ?t = "t_hrs_'_update (hrs_mem_update (heap_update fake ?v)) ?u"
  let ?N = "bn_ds_forest_nodes F"
  let ?slots = "bn_ds_slots (roots_C (bn_heap entry h)) (length F)"
  note CORE = vero_aux_detach_core[OF R I FTP GF SP SS PS]
  have A: "phantom_machine_state_' ?t = phantom_machine_state_' entry"
    and HTD: "hrs_htd (t_hrs_' ?t) = hrs_htd (t_hrs_' entry)"
    and HH: "bn_heap ?t h = bn_heap entry h" and HF: "bn_heap ?t fake = ?v"
    and HU: "bn_heap ?u h = bn_heap entry h" and HPU: "bn_tree ?u p = bn_tree entry p"
    and RV: "bn_review_root_array_view ?t (roots_C (bn_heap entry h)) (F[i:=None])"
    and ALL: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid ?t P U"
    and HN: "\<forall>q\<in>?N. bn_tree ?t q = bn_tree entry q"
    and GT: "bn_ds_graph ?t P ?N (bn_ds_physical_edges entry) ?slots {#p#} {}"
    and ST: "bn_ds_graph_storage ?t ?N ?slots"
    and DIST: "distinct (concat (map (case_option [] (bn_blocks ?t)) (F[i:=None] @ map Some cs)))"
    and MASS: "length (bn_forest_values ?t (F[i:=None])) + length (bn_forest_values ?t (map Some cs)) < 2^32"
    using CORE by blast+
  have TFM: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FTP by simp
  have PN: "p\<in>?N" using TFM by (auto simp: vero_aux_forest_node_member)
  have HP: "bn_tree ?t p = bn_tree entry p" using HN PN by blast
  have VP: "bn_valid ?t P (BN p cs)" using ALL TFM by blast
  have V0: "bn_valid entry P (BN p cs)" using R I FTP by (auto simp: bn_rep_def)
  have ORDER: "unat (order_C (bn_tree entry p)) = length cs" using V0 by simp
  have FK: "heap_type_C (bn_heap ?t fake) = BINOMIAL_HEAP_TYPE_MIN" using HF HU R by (simp add: bn_rep_def)
  have FC: "compare_func_C (bn_heap ?t fake) = binomial_heap_input.int_compare" using HF HU R by (simp add: bn_rep_def)
  have FR: "roots_C (bn_heap ?t fake) = subtrees_C (bn_tree ?t p)" by (simp only: HF HP; simp add: HPU)
  have FL: "unat (roots_length_C (bn_heap ?t fake)) = length cs" by (simp only: HF; simp add: HPU ORDER unat_ucast_up_simp)
  have VH: "bn_ds_forest_view ?t h P (F[i:=None])" and VG: "bn_ds_forest_view ?t fake P (map Some cs)"
    using vero_aux_detach_views[OF R I FTP A HH GF SP SS FK FC FR FL RV VP ALL] by blast+
  have MP: "bn_ds_merge_pre ?t h fake P (F[i:=None]) (map Some cs) [] {#p#} ?N (bn_ds_physical_edges entry)"
    by (rule vero_aux_detach_merge_pre[OF R I FTP A HH SP SS HN VH VG GT ST DIST MASS])
  have LEN: "length F\<le>32" and W: "allocator_wf (phantom_machine_state_' entry)"
    and LH: "live_blocks (phantom_machine_state_' entry) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using R by (auto simp: bn_rep_def)
  have IB: "i<2^32" using I LEN by (simp; arith)
  have IDX: "uint (of_nat i :: 32 word) = int i" using IB by (simp add: uint_nat unat_of_nat)
  have GS: "c_guard (roots_C (bn_heap entry h) +\<^sub>p uint (of_nat i :: 32 word))"
    using R I by (auto simp: bn_rep_def IDX)
  have VAL: "h_val (hrs_mem (t_hrs_' entry)) (roots_C (bn_heap entry h) +\<^sub>p uint (of_nat i :: 32 word)) = p"
    using R I FTP by (auto simp: bn_rep_def IDX)
  have GP: "c_guard p" and LP: "live_blocks (phantom_machine_state_' entry) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using V0 by auto
  have DH0: "ptr_span (h +\<^sub>p int 0) \<inter> ptr_span fake = {}"
    by (rule vero_aux_live_reserved_span[OF W LH _ _ SP SS, where k=1 and i=0]) simp_all
  have DP0: "ptr_span (p +\<^sub>p int 0) \<inter> ptr_span fake = {}"
    by (rule vero_aux_live_reserved_span[OF W LP _ _ SP SS, where k=1 and i=0]) simp_all
  have DH: "ptr_span h \<inter> ptr_span fake = {}" using DH0 by simp
  have DP: "ptr_span p \<inter> ptr_span fake = {}" using DP0 by simp
  have SEM: "bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t. r=p \<and> t=?t)"
    using vero_aux_detach_semantics[OF GS VAL GF GP DH DP]
    by (simp only: IDX bn_review_clear_root_def)
  show ?thesis
    apply (rule vero_aux_contract_weaken[OF SEM])
    using A HTD MP SHAPE by (auto; blast)
qed

end

definition vero_aux_closed_c0005 :: bool where
 "vero_aux_closed_c0005 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h P p q. allocator_wf (phantom_machine_state_' s) \<longrightarrow> c_guard h \<longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<longrightarrow>
    bn_valid s P (BN p []) \<longrightarrow> bn_valid s P (BN q []) \<longrightarrow> p \<noteq> q \<longrightarrow>
    live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C)) \<longrightarrow>
    ptr_val h \<noteq> ptr_val p \<longrightarrow> ptr_val h \<noteq> ptr_val q \<longrightarrow>
    bn_contract (binomial_tree_merge' h p q) s (\<lambda>r t. True)))"

lemma vero_aux_closed_c0005_iff:
  "vero_aux_closed_c0005 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0005"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    note PRE = binomial_heap_input_global_addresses.vero_aux_leaf_merge_pre[OF A]
    note FAIL = binomial_heap_input_global_addresses.vero_aux_leaf_merge_failure[OF A]
    have RUN: "bn_contract (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96))
      binomial_heap_input_global_addresses.vero_aux_leaf_merge_state (\<lambda>r t. True)"
      using H A PRE unfolding vero_aux_closed_c0005_def by blast
    show False using RUN FAIL by blast
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0005" by (simp add: vero_aux_closed_c0005_def)
qed

definition vero_aux_address_configuration ::
  "unit ptr list \<Rightarrow> addr set \<Rightarrow> addr set \<Rightarrow> bool" where
  "vero_aux_address_configuration fs g st = (length fs = 19 \<and> ((((c_fnptr_guard (fs ! 0) \<and>
   c_fnptr_guard (fs ! 1)) \<and>
  c_fnptr_guard (fs ! 2) \<and>
  c_fnptr_guard (fs ! 3) \<and>
  c_fnptr_guard (fs ! 4)) \<and>
 (c_fnptr_guard (fs ! 5) \<and>
  c_fnptr_guard (fs ! 6)) \<and>
 c_fnptr_guard (fs ! 7) \<and>
 c_fnptr_guard (fs ! 8) \<and>
 c_fnptr_guard (fs ! 9)) \<and>
((c_fnptr_guard (fs ! 10) \<and>
  c_fnptr_guard (fs ! 11)) \<and>
 c_fnptr_guard (fs ! 12) \<and>
 c_fnptr_guard (fs ! 13) \<and>
 c_fnptr_guard (fs ! 14)) \<and>
(c_fnptr_guard (fs ! 15) \<and>
 c_fnptr_guard (fs ! 16) \<and>
 c_fnptr_guard (fs ! 17)) \<and>
c_fnptr_guard (fs ! 18) \<and>
all_distinct
 (Node
   (Node
     (Node (Node Tip (fs ! 0) False Tip)
       (fs ! 1) False
       (Node Tip (fs ! 2) False
         (Node Tip (fs ! 3) False Tip)))
     (fs ! 4) False
     (Node (Node Tip (fs ! 5) False Tip)
       (fs ! 6) False
       (Node Tip (fs ! 7) False
         (Node Tip (fs ! 8) False Tip))))
   (fs ! 9) False
   (Node
     (Node (Node Tip (fs ! 10) False Tip)
       (fs ! 11) False
       (Node Tip (fs ! 12) False
         (Node Tip (fs ! 13) False Tip)))
     (fs ! 14) False
     (Node (Node Tip (fs ! 15) False Tip)
       (fs ! 16) False
       (Node Tip (fs ! 17) False
         (Node Tip (fs ! 18) False
           Tip))))) \<and>
g \<inter> st = {}))"

lemma vero_aux_address_configuration_possible:
  "\<exists>fs. vero_aux_address_configuration fs {} audit_stack_addresses"
  apply (rule exI[where x="[Ptr 1, Ptr 2, Ptr 3, Ptr 4, Ptr 5, Ptr 6, Ptr 7, Ptr 8, Ptr 9, Ptr 10, Ptr 11, Ptr 12, Ptr 13, Ptr 14, Ptr 15, Ptr 16, Ptr 17, Ptr 18, Ptr 19]"])
  by (simp add: vero_aux_address_configuration_def c_fnptr_guard_def)

end


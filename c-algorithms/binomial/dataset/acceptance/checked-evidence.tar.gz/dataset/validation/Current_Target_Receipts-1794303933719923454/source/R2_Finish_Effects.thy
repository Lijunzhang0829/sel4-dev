theory R2_Finish_Effects imports Repair_Phase_Model Revision_Witness_Provider R2_Finish_Inventory R2_Leaf_Unref begin
context binomial_heap_input_global_addresses begin


lemma r3_old_node_fields_equivalent:
 "bn_r3_old_node_fields s N t M = bn_ds_old_node_fields s N t M"
proof -
 have REC: "(x=y\<lparr>refcount_C:=refcount_C x\<rparr>) =
   (value_C x=value_C y \<and> order_C x=order_C y \<and> subtrees_C x=subtrees_C y)"
  for x y :: StrictC'_BinomialTree_C
  by (cases x; cases y) auto
 show ?thesis by (simp only: bn_r3_old_node_fields_def bn_ds_old_node_fields_def REC)
qed

lemma r2_layout_mod_refs:
  assumes L: "bn_ds_tree_layout s P T"
    and A: "\<forall>b\<in>set (bn_blocks s T). live_blocks (phantom_machine_state_' t) b = live_blocks (phantom_machine_state_' s) b"
    and HN: "\<forall>p \<in> set (bn_ds_node_list T). value_C (bn_tree t p)=value_C (bn_tree s p) \<and>
      order_C (bn_tree t p)=order_C (bn_tree s p) \<and> subtrees_C (bn_tree t p)=subtrees_C (bn_tree s p)"
    and HE: "\<forall>p \<in> set (bn_ds_node_list T). \<forall>i<unat (order_C (bn_tree s p)).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and KEY: "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key t v = bn_key s v"
  shows "bn_ds_tree_layout t P T \<and> bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"
  using L HN HE A
proof (induction T)
  case (BN p cs)
  have HP: "value_C (bn_tree t p)=value_C (bn_tree s p) \<and>
      order_C (bn_tree t p)=order_C (bn_tree s p) \<and> subtrees_C (bn_tree t p)=subtrees_C (bn_tree s p)" using BN.prems by simp
  have CHILD: "\<forall>U \<in> set cs. bn_ds_tree_layout t P U \<and> bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U"
  proof (intro ballI)
   fix U assume UC: "U\<in>set cs"
   have LU: "bn_ds_tree_layout s P U" using BN.prems(1) UC by (simp add: list_all_iff)
   have HNC: "\<forall>q\<in>set (bn_ds_node_list U). value_C (bn_tree t q)=value_C (bn_tree s q) \<and>
      order_C (bn_tree t q)=order_C (bn_tree s q) \<and> subtrees_C (bn_tree t q)=subtrees_C (bn_tree s q)"
    using BN.prems(2) UC by auto
   have HEC: "\<forall>q\<in>set (bn_ds_node_list U). \<forall>i<unat (order_C (bn_tree s q)).
    h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s q) +\<^sub>p int i) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s q) +\<^sub>p int i)"
    using BN.prems(3) UC by auto
   have AC: "\<forall>b\<in>set (bn_blocks s U). live_blocks (phantom_machine_state_' t) b =
     live_blocks (phantom_machine_state_' s) b"
    using BN.prems(4) UC by auto
   show "bn_ds_tree_layout t P U \<and> bn_values t U=bn_values s U \<and> bn_blocks t U=bn_blocks s U"
    by (rule BN.IH[OF UC LU HNC HEC AC])
  qed
  have MV: "map (bn_values t) cs = map (bn_values s) cs" using CHILD by (auto intro!: map_cong)
  have MB: "map (bn_blocks t) cs = map (bn_blocks s) cs" using CHILD by (auto intro!: map_cong)
  have PAY: "\<forall>v \<in> set (bn_values s (BN p cs)). bn_payload P v"
    by (rule vero_aux_layout_payloads[OF BN.prems(1)])
  have ORDER: "\<forall>q \<in> set (concat (map (bn_values s) cs)).
    bn_key t (value_C (bn_tree s p)) \<le> bn_key t q"
  proof (intro ballI)
    fix q assume Q: "q \<in> set (concat (map (bn_values s) cs))"
    have PP: "bn_payload P (value_C (bn_tree s p))" and PQ: "bn_payload P q" using PAY Q by auto
    have KP: "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))" by (rule KEY[rule_format, OF PP])
    have KQ: "bn_key t q = bn_key s q" by (rule KEY[rule_format, OF PQ])
    have OLD: "bn_key s (value_C (bn_tree s p)) \<le> bn_key s q" using BN.prems(1) Q by (auto; blast)
    show "bn_key t (value_C (bn_tree s p)) \<le> bn_key t q" by (simp only: KP KQ; rule OLD)
  qed
  show ?case using BN.prems CHILD ORDER
    by (auto simp: HP MV MB list_all_iff)
qed

end
end

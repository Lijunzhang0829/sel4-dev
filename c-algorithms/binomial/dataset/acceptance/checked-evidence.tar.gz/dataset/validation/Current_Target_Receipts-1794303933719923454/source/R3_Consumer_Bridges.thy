theory R3_Consumer_Bridges imports Repair_Phase_Model Revision_Callsite_Bridges begin
lemma r3_rep_graph_blocks:
 assumes R: "bn_rep s h P F M"
 shows "bn_ds_graph_blocks s (bn_ds_forest_nodes F)=set (concat (map (case_option [] (bn_blocks s)) F))"
proof -
 have V: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_valid s P T"
  using R by (auto simp: bn_rep_def in_set_conv_nth)
 have L: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_ds_tree_layout s P T"
  using V vero_aux_valid_layout by blast
 have NB: "set (concat (map (vero_aux_node_blocks s) xs))=ptr_val ` set xs \<union>
   {ptr_val (subtrees_C (bn_tree s p)) |p. p\<in>set xs \<and> order_C (bn_tree s p)\<noteq>0}" for xs
  by (auto simp: vero_aux_node_blocks_def split: if_splits; blast)
 have BEQ: "concat (map (case_option [] (bn_blocks s)) F)=
  concat (map (vero_aux_node_blocks s) (concat (map (case_option [] bn_ds_node_list) F)))"
  by (rule vero_aux_forest_blocks[OF L])
 show ?thesis by (simp only: BEQ bn_ds_graph_blocks_def bn_ds_forest_nodes_def NB)
qed

lemma r3_spec_0053:
  "bn_rep s h P F M \<Longrightarrow>
  bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {} \<and>
  bn_r2_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"
proof -
 assume R: "bn_rep s h P F M"
 let ?a="roots_C (bn_heap s h)"
 let ?N="bn_ds_forest_nodes F"
 let ?slots="bn_ds_slots ?a (length F)"
 have W: "allocator_wf (phantom_machine_state_' s)" using R by (simp add: bn_rep_def)
 have OLD: "bn_ds_graph s P ?N (bn_ds_physical_edges s) ?slots {#} {} \<and>
   bn_ds_graph_storage s ?N ?slots" by (rule c0046_prove[OF R])
 have S: "bn_r2_slots_supported s ?slots (bn_ds_graph_blocks s ?N)"
 proof (cases "?a=NULL")
  case True
  have "F=[]" using R True by (simp add: bn_rep_def)
  then show ?thesis by (simp add: bn_r2_slots_supported_def bn_ds_slots_def)
 next
  case False
  have OA: "bn_ds_owned_array s ?a (length F)" using R False by (auto simp: bn_rep_def bn_ds_owned_array_def)
  have OUT: "ptr_val ?a\<notin>bn_ds_graph_blocks s ?N"
   using R False by (simp add: r3_rep_graph_blocks[OF R] bn_rep_def bn_owned_def)
  show ?thesis by (rule r2_owned_array_slots[OF W OA OUT])
 qed
 show ?thesis using OLD S by (simp add: bn_r2_graph_storage_def)
qed
context binomial_heap_input_global_addresses begin
lemma vero_aux_sum_twopowers:
  "sum_list (map (\<lambda>i. (2::nat)^i) [0..<n]) + 1 = 2^n"
proof (induction n)
  case 0
  then show ?case by simp
next
  case (Suc n)
  have E: "sum_list (map (\<lambda>i. (2::nat)^i) [0..<Suc n]) =
    sum_list (map (\<lambda>i. (2::nat)^i) [0..<n]) + 2^n"
    by (simp add: upt_Suc_snoc)
  have P: "(2::nat)^Suc n = 2 * 2^n" by (rule Power.power_class.power.power_Suc)
  show ?case using Suc.IH by (simp only: E P; arith)
qed

lemma vero_aux_layout_size:
  "bn_ds_tree_layout s P T \<Longrightarrow> length (bn_values s T) = 2 ^ bn_rank T"
proof (induction T)
  case (BN p cs)
  have IH: "map (\<lambda>U. length (bn_values s U)) cs = map (\<lambda>U. (2::nat) ^ bn_rank U) cs"
    using BN.IH BN.prems by (auto simp: list_all_iff intro!: map_cong)
  have RK: "map bn_rank cs = [0..<length cs]" using BN.prems by simp
  have MP: "map (\<lambda>U. (2::nat) ^ bn_rank U) cs = map (\<lambda>i. (2::nat)^i) [0..<length cs]"
    by (simp only: RK[symmetric] map_map o_def)
  have POW: "sum_list (map (\<lambda>U. (2::nat) ^ bn_rank U) cs) + 1 = 2 ^ length cs"
    by (simp only: MP vero_aux_sum_twopowers)
  show ?case using POW by (simp add: length_concat o_def IH)
qed

lemma vero_aux_forest_size_bound:
  assumes R: "\<forall>i < length F. case F ! i of None \<Rightarrow> True | Some T \<Rightarrow>
    length (bn_values s T) = 2 ^ (r + i)"
  shows "length (bn_forest_values s F) + 2^r \<le> 2^(r + length F)"
  using R
proof (induction F arbitrary: r)
  case Nil
  then show ?case by (simp add: bn_forest_values_def)
next
  case (Cons a F)
  have HD: "length (case_option [] (bn_values s) a) \<le> 2^r"
    using Cons.prems[rule_format, of 0] by (cases a) auto
  have TAIL: "\<forall>i < length F. case F ! i of None \<Rightarrow> True | Some T \<Rightarrow>
    length (bn_values s T) = 2 ^ (Suc r + i)"
  proof (intro allI impI)
    fix i assume I: "i < length F"
    show "case F ! i of None \<Rightarrow> True | Some T \<Rightarrow> length (bn_values s T) = 2 ^ (Suc r + i)"
      using Cons.prems[rule_format, of "Suc i"] I
      by (cases "F ! i") (auto simp: add_Suc_shift)
  qed
  show ?case using HD Cons.IH[OF TAIL]
    by (simp add: bn_forest_values_def power_Suc; arith)
qed

lemma vero_aux_layout_root_nonnull:
  "bn_ds_tree_layout s P T \<Longrightarrow> bn_root T \<noteq> NULL"
  by (cases T) (auto dest: c_guard_NULL)

lemma vero_aux_forest_view_size_bound:
  assumes V: "bn_ds_forest_view s h P F"
  shows "length (bn_forest_values s F) + 1 \<le> 2 ^ length F"
proof -
  have R: "\<forall>i < length F. case F ! i of None \<Rightarrow> True | Some T \<Rightarrow>
    length (bn_values s T) = 2 ^ (0 + i)"
  proof (intro allI impI)
    fix i assume I: "i < length F"
    show "case F ! i of None \<Rightarrow> True | Some T \<Rightarrow> length (bn_values s T) = 2 ^ (0 + i)"
    proof (cases "F ! i")
      case None
      then show ?thesis by simp
    next
      case (Some T)
      have L: "bn_ds_tree_layout s P T" and RK: "bn_rank T = i"
        using V I Some by (auto simp: bn_ds_forest_view_def)
      show ?thesis using vero_aux_layout_size[OF L] RK by (simp add: Some)
    qed
  qed
  show ?thesis using vero_aux_forest_size_bound[OF R] by simp
qed

lemma r3_spec_0083:
  "bn_r2_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<Longrightarrow>
  unat i = n \<Longrightarrow>
  bn_r2_carry_done s0 h P F G ext held N a n (bn_carry,i,len,vals) s"

proof -
  assume PRE: "bn_r2_merge_pre s0 h other P F G ext held N edges"
    and N: "n = max (length F) (length G) + 1"
    and INV: "bn_r2_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s"
    and END: "unat i = n"
  have BF: "length (bn_forest_values s0 F) + 1 \<le> 2 ^ length F"
    apply (rule vero_aux_forest_view_size_bound[where h=h and P=P])
    using PRE by (simp add: bn_r2_merge_pre_def)
  have BG: "length (bn_forest_values s0 G) + 1 \<le> 2 ^ length G"
    apply (rule vero_aux_forest_view_size_bound[where h=other and P=P])
    using PRE by (simp add: bn_r2_merge_pre_def)
  have PF: "(2::nat)^length F \<le> 2^max (length F) (length G)" by (simp add: power_increasing_iff)
  have PG: "(2::nat)^length G \<le> 2^max (length F) (length G)" by (simp add: power_increasing_iff)
  have TOT: "length (bn_forest_values s0 F) + length (bn_forest_values s0 G) < 2^n"
    using BF BG PF PG by (simp add: N power_Suc; arith)
  have LF: "length F < n" and LG: "length G < n" by (simp_all add: N)
  have DF: "drop n F = []" using LF by simp
  have DG: "drop n G = []" using LG by simp
  obtain prefix C where CAR: "bn_carry = case_option NULL bn_root C"
    and CL: "case C of None \<Rightarrow> True | Some T \<Rightarrow> bn_rank T = n \<and> bn_ds_tree_layout s P T"
    and MASS: "mset (bn_forest_values s0 F) + mset (bn_forest_values s0 G) =
      mset (bn_forest_values s prefix) + mset (case_option [] (bn_values s) C)"
    using INV END DF DG by (auto simp: bn_r2_carry_inv_def bn_forest_values_def)
  have CN: "C = None"
  proof (cases C)
    case None
    thus ?thesis .
  next
    case (Some T)
    have SZ: "length (bn_values s T) = 2^n"
      using CL vero_aux_layout_size[of s P T] by (simp add: Some)
    have SIZE: "length (bn_forest_values s0 F) + length (bn_forest_values s0 G) =
      length (bn_forest_values s prefix) + length (bn_values s T)"
      using arg_cong[where f=size, OF MASS] by (simp add: Some)
    show ?thesis using TOT SZ SIZE by arith
  qed
  have NULL: "bn_carry = NULL" using CAR CN by simp
  show ?thesis using INV END NULL DF DG
    by (auto simp: bn_r2_carry_inv_def bn_r2_carry_done_def bn_forest_values_def
      split: option.splits dest: vero_aux_layout_root_nonnull; blast)
qed



end
ML \<open>
 val facts = @{thms r3_spec_0053 binomial_heap_input_global_addresses.r3_spec_0083};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "R3_CONSUMER_BRIDGES_PASS";
\<close>
end

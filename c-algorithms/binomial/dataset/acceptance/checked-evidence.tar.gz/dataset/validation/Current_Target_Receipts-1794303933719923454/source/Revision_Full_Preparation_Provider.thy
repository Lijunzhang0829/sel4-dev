theory Revision_Full_Preparation_Provider imports Revised_Ownership_Model begin


lemma vero_aux_live_readable:
  "live_blocks A p = Some n \<Longrightarrow> block_bytes p n \<subseteq> readable_bytes A"
  by (auto simp: readable_bytes_def)










context binomial_heap_input_global_addresses begin



lemma c0001_prove:
  "c_guard h \<Longrightarrow>
   heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
   compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
   c_guard (ptr_coerce v :: 32 signed word ptr) \<Longrightarrow>
   runs_to (binomial_heap_cmp' h v v) s Q = Q (Result 0) s"

by (simp add: binomial_heap_cmp'_def bn_heap_def runs_to_bind_iff runs_to_condition_iff runs_to_gets_iff \<P>_fun_ptr_simps int_compare'_def)



end



lemma c0002_prove:
  "fresh_block A p n \<Longrightarrow> live_blocks A q = Some m \<Longrightarrow>
    block_bytes p n \<inter> block_bytes q m = {}"

by (auto simp: fresh_block_def)



context binomial_heap_input_global_addresses begin

lemma vero_aux_contract_weaken:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract f s Q"
by (auto simp: bn_contract_def runs_to_def_old; blast)

lemma vero_aux_scan_none:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = None \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r = (i + 1,j) \<and> t = s)"
proof -
  assume R: "bn_rep s h P F M" and I: "unat i < length F" and N: "F ! unat i = None"
  have G: "c_guard (roots_C (bn_heap s h) +\<^sub>p uint i)"
    and V: "h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint i) = NULL"
    using R I N by (auto simp: bn_rep_def int_unat)
  show ?thesis using G V
    by (auto simp: bn_ds_scan_step_def bn_contract_def bn_heap_def
      runs_to_bind_iff runs_to_guard_iff runs_to_condition_iff reaches_bind reaches_condition_iff
      succeeds_runs_to_iff reaches_guard reaches_return)
qed

lemma vero_aux_scan_first:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = Some T \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,0xFFFFFFFF)) s
     (\<lambda>r t. r = (i + 1,i) \<and> t = s)"
proof -
  assume R: "bn_rep s h P F M" and I: "unat i < length F" and N: "F ! unat i = Some T"
  have G: "c_guard (roots_C (bn_heap s h) +\<^sub>p uint i)"
    and V: "h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint i) = bn_root T"
    and T: "bn_valid s P T"
    using R I N by (auto simp: bn_rep_def int_unat)
  have "c_guard (bn_root T)" using T by (cases T) auto
  hence NN: "bn_root T \<noteq> NULL" by (rule c_guard_NULL)
  show ?thesis using G V NN
    by (auto simp: bn_ds_scan_step_def bn_contract_def bn_heap_def
      runs_to_bind_iff runs_to_guard_iff runs_to_condition_iff reaches_bind reaches_condition_iff
      succeeds_runs_to_iff reaches_guard reaches_return)
qed

lemma vero_aux_scan_compare:
  assumes R: "bn_rep s h P F M" and I: "unat i < length F" and J: "unat j < length F"
    and IT: "F ! unat i = Some T" and JU: "F ! unat j = Some U" and NJ: "j \<noteq> 0xFFFFFFFF"
  shows "bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t.
    r = (i+1, if bn_key s (value_C (bn_tree s (bn_root T))) < bn_key s (value_C (bn_tree s (bn_root U))) then i else j) \<and> t=s)"
proof -
  have AI: "c_guard (roots_C (bn_heap s h) +\<^sub>p uint i) \<and>
    h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint i) = bn_root T \<and> bn_valid s P T"
    using R I IT by (auto simp: bn_rep_def int_unat)
  have AJ: "c_guard (roots_C (bn_heap s h) +\<^sub>p uint j) \<and>
    h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint j) = bn_root U \<and> bn_valid s P U"
    using R J JU by (auto simp: bn_rep_def int_unat)
  have TP: "c_guard (bn_root T) \<and> bn_payload P (value_C (bn_tree s (bn_root T)))"
    using AI by (cases T) auto
  have UP: "c_guard (bn_root U) \<and> bn_payload P (value_C (bn_tree s (bn_root U)))"
    using AJ by (cases U) auto
  have NN: "bn_root T \<noteq> NULL" using TP by (auto dest: c_guard_NULL)
  have H: "c_guard h \<and> heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<and>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare"
    using R by (auto simp: bn_rep_def)
  show ?thesis using AI AJ TP UP NN H NJ
    by (auto simp: bn_ds_scan_step_def bn_contract_def bn_heap_def bn_tree_def bn_key_def bn_payload_def
      binomial_heap_cmp'_def int_compare'_def \<P>_fun_ptr_simps
      runs_to_bind_iff runs_to_guard_iff runs_to_condition_iff runs_to_gets_iff
      reaches_bind reaches_condition_iff reaches_gets[abs_def] reaches_guard[abs_def] reaches_return[abs_def]
      succeeds_runs_to_iff word_sless_alt)
qed

lemma vero_aux_prefix_none:
  "bn_review_scan_prefix s F i j \<Longrightarrow> i < length F \<Longrightarrow> F ! i = None \<Longrightarrow>
    bn_review_scan_prefix s F (Suc i) j"
  by (auto simp: bn_review_scan_prefix_def less_Suc_eq split: option.splits; blast)

lemma vero_aux_prefix_first:
  "bn_review_scan_prefix s F i None \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
    bn_review_scan_prefix s F (Suc i) (Some i)"
  by (auto simp: bn_review_scan_prefix_def less_Suc_eq; blast)

lemma vero_aux_prefix_compare:
  "bn_review_scan_prefix s F i (Some j) \<Longrightarrow> i < length F \<Longrightarrow>
   F ! i = Some T \<Longrightarrow> F ! j = Some U \<Longrightarrow>
   bn_review_scan_prefix s F (Suc i)
    (Some (if bn_key s (value_C (bn_tree s (bn_root T))) < bn_key s (value_C (bn_tree s (bn_root U))) then i else j))"
  by (auto simp: bn_review_scan_prefix_def less_Suc_eq split: if_splits;
    meson order_trans order_less_imp_le)

lemma c0003_prove:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
  bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j)) \<Longrightarrow>
  bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>(i',j') t.
    t = s \<and> i' = i + 1 \<and>
    bn_review_scan_prefix s F (unat i') (if j' = 0xFFFFFFFF then None else Some (unat j')))"

proof -
  assume R: "bn_rep s h P F M" and I: "unat i < length F"
    and SC: "bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j))"
  have B: "length F \<le> 32" using R by (simp add: bn_rep_def)
  have IB: "unat i < 32" using I B by arith
  have NB: "unat i + 1 < 2^32" using IB by (simp; arith)
  have IS: "unat (i+1) = Suc (unat i)" using NB by (simp add: unat_word_ariths)
  have NI: "i \<noteq> 0xFFFFFFFF" using IB by auto
  show ?thesis
  proof (cases "F ! unat i")
    case None
    have C: "bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r=(i+1,j) \<and> t=s)"
      by (rule vero_aux_scan_none[OF R I None])
    have PF: "bn_review_scan_prefix s F (Suc (unat i)) (if j = 0xFFFFFFFF then None else Some (unat j))"
      by (rule vero_aux_prefix_none[OF SC I None])
    show ?thesis
      apply (rule vero_aux_contract_weaken[OF C])
      using PF IS by auto
  next
    case (Some T)
    show ?thesis
    proof (cases "j = 0xFFFFFFFF")
      case True
      have C: "bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r=(i+1,i) \<and> t=s)"
        using vero_aux_scan_first[OF R I Some] True by simp
      have SC0: "bn_review_scan_prefix s F (unat i) None" using SC True by simp
      have PF: "bn_review_scan_prefix s F (Suc (unat i)) (Some (unat i))"
        by (rule vero_aux_prefix_first[OF SC0 I Some])
      show ?thesis
        apply (rule vero_aux_contract_weaken[OF C])
        using PF IS NI by auto
    next
      case False
      have SC1: "bn_review_scan_prefix s F (unat i) (Some (unat j))" using SC False by simp
      have JI: "unat j < unat i" using SC1 by (auto simp: bn_review_scan_prefix_def)
      have J: "unat j < length F" using JI I by arith
      obtain U where JU: "F ! unat j = Some U" using SC1 by (auto simp: bn_review_scan_prefix_def)
      let ?K = "bn_key s (value_C (bn_tree s (bn_root T))) < bn_key s (value_C (bn_tree s (bn_root U)))"
      have C: "bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r=(i+1,if ?K then i else j) \<and> t=s)"
        by (rule vero_aux_scan_compare[OF R I J Some JU False])
      have PF: "bn_review_scan_prefix s F (Suc (unat i)) (Some (if ?K then unat i else unat j))"
        by (rule vero_aux_prefix_compare[OF SC1 I Some JU])
      show ?thesis
        apply (rule vero_aux_contract_weaken[OF C])
        using PF IS NI False by (auto split: if_splits)
    qed
  qed
qed



end

context binomial_heap_input_global_addresses begin





end

context binomial_heap_input_global_addresses begin

lemma vero_aux_guard_bounds:
  fixes p :: "'a::mem_type ptr"
  assumes N: "ptr_val p\<noteq>0" and B: "unat (ptr_val p)+size_of TYPE('a)\<le>2^64"
    and A: "align_of TYPE('a) dvd unat (ptr_val p)"
  shows "c_guard p"
proof -
  have NG: "0\<notin>{ptr_val p..+size_of TYPE('a)}"
    using intvl_no_overflow_nat'[where a="ptr_val p" and b="size_of TYPE('a)" and x=0] B N
    by (simp add: unat_eq_zero)
  show ?thesis using A NG by (simp add: c_guard_def ptr_aligned_def c_null_guard_def)
qed

lemma vero_aux_span_block:
  fixes p :: "'a::mem_type ptr"
  assumes G: "c_guard p"
  shows "ptr_span p = block_bytes (ptr_val p) (size_of TYPE('a))"
  using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]]
  by (simp add: block_bytes_def)

lemma vero_aux_separated_spans:
  fixes p :: "'a::mem_type ptr" and q :: "'b::mem_type ptr"
  assumes GP: "c_guard p" and GQ: "c_guard q"
    and D: "unat (ptr_val p)+size_of TYPE('a) \<le> unat (ptr_val q) \<or>
      unat (ptr_val q)+size_of TYPE('b) \<le> unat (ptr_val p)"
  shows "ptr_span p \<inter> ptr_span q = {}"
  using D by (simp only: vero_aux_span_block[OF GP] vero_aux_span_block[OF GQ];
    auto simp: block_bytes_def; arith)

definition vero_aux_leaf_merge_header :: StrictC'_BinomialHeap_C where
  "vero_aux_leaf_merge_header = ZERO(StrictC'_BinomialHeap_C)\<lparr>heap_type_C:=BINOMIAL_HEAP_TYPE_MIN,
    compare_func_C:=binomial_heap_input.int_compare, num_values_C:=0,
    roots_C:=NULL, roots_length_C:=0\<rparr>"

definition vero_aux_leaf_merge_tree :: StrictC'_BinomialTree_C where
  "vero_aux_leaf_merge_tree = ZERO(StrictC'_BinomialTree_C)\<lparr>value_C:=Ptr 192, order_C:=0, refcount_C:=1, subtrees_C:=NULL\<rparr>"

definition vero_aux_leaf_merge_mem :: heap_mem where
  "vero_aux_leaf_merge_mem = heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr) vero_aux_leaf_merge_header
    (heap_update (Ptr 64 :: StrictC'_BinomialTree_C ptr) vero_aux_leaf_merge_tree
      (heap_update (Ptr 96 :: StrictC'_BinomialTree_C ptr) vero_aux_leaf_merge_tree (\<lambda>_. 0)))"

definition vero_aux_leaf_merge_allocator :: calg_allocator where
  "vero_aux_leaf_merge_allocator = \<lparr>
    live_blocks=(\<lambda>q. if q=16 then Some 40 else if q=64 \<or> q=96 then Some 24 else None),
    reserved_bytes=block_bytes 192 4\<rparr>"

definition vero_aux_leaf_merge_state :: globals where
  "vero_aux_leaf_merge_state = (undefined::globals)\<lparr>
    t_hrs_' := (vero_aux_leaf_merge_mem, undefined),
    phantom_machine_state_' := vero_aux_leaf_merge_allocator\<rparr>"

lemma vero_aux_leaf_merge_guards:
  "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 160 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 192 :: 32 signed word ptr)"
  by (intro conjI; rule vero_aux_guard_bounds) simp_all

lemma vero_aux_leaf_merge_fields:
  "bn_heap vero_aux_leaf_merge_state (Ptr 16) = vero_aux_leaf_merge_header \<and>
   bn_tree vero_aux_leaf_merge_state (Ptr 64) = vero_aux_leaf_merge_tree \<and>
   bn_tree vero_aux_leaf_merge_state (Ptr 96) = vero_aux_leaf_merge_tree"
proof -
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GP: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and GQ: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    using vero_aux_leaf_merge_guards by blast+
  have PH: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (simp only: vero_aux_span_block[OF GP] vero_aux_span_block[OF GH]; auto simp: block_bytes_def)
  have QH: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (simp only: vero_aux_span_block[OF GQ] vero_aux_span_block[OF GH]; auto simp: block_bytes_def)
  have QP: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (simp only: vero_aux_span_block[OF GQ] vero_aux_span_block[OF GP]; auto simp: block_bytes_def)
  have HH: "bn_heap vero_aux_leaf_merge_state (Ptr 16) = vero_aux_leaf_merge_header"
    using GH by (simp add: vero_aux_leaf_merge_state_def vero_aux_leaf_merge_mem_def bn_heap_def hrs_mem_def h_val_heap_update)
  have HP: "bn_tree vero_aux_leaf_merge_state (Ptr 64) = vero_aux_leaf_merge_tree"
    using GP by (simp add: vero_aux_leaf_merge_state_def vero_aux_leaf_merge_mem_def bn_tree_def hrs_mem_def h_val_heap_update_disjoint[OF PH] h_val_heap_update)
  have HQ: "bn_tree vero_aux_leaf_merge_state (Ptr 96) = vero_aux_leaf_merge_tree"
    using GQ by (simp add: vero_aux_leaf_merge_state_def vero_aux_leaf_merge_mem_def bn_tree_def hrs_mem_def h_val_heap_update_disjoint[OF QH] h_val_heap_update_disjoint[OF QP] h_val_heap_update)
  show ?thesis using HH HP HQ by blast
qed

lemma vero_aux_leaf_merge_allocator_wf:
  "allocator_wf vero_aux_leaf_merge_allocator"
  by (auto simp: vero_aux_leaf_merge_allocator_def allocator_wf_def block_ok_def block_bytes_def split: if_splits; arith)

lemma vero_aux_leaf_merge_pre:
  "allocator_wf (phantom_machine_state_' vero_aux_leaf_merge_state) \<and>
    c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
    heap_type_C (bn_heap vero_aux_leaf_merge_state (Ptr 16)) = BINOMIAL_HEAP_TYPE_MIN \<and>
    compare_func_C (bn_heap vero_aux_leaf_merge_state (Ptr 16)) = binomial_heap_input.int_compare \<and>
    block_bytes 192 4 \<subseteq> reserved_bytes (phantom_machine_state_' vero_aux_leaf_merge_state) \<and>
    bn_valid vero_aux_leaf_merge_state (block_bytes 192 4) (BN (Ptr 64) []) \<and>
    bn_valid vero_aux_leaf_merge_state (block_bytes 192 4) (BN (Ptr 96) []) \<and>
    (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<noteq> Ptr 96 \<and>
    live_blocks (phantom_machine_state_' vero_aux_leaf_merge_state) (ptr_val (Ptr 16 :: StrictC'_BinomialHeap_C ptr)) = Some (size_of TYPE(StrictC'_BinomialHeap_C)) \<and>
    ptr_val (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<noteq> ptr_val (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<and>
    ptr_val (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<noteq> ptr_val (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
  using vero_aux_leaf_merge_guards vero_aux_leaf_merge_fields vero_aux_leaf_merge_allocator_wf
  by (simp add: vero_aux_leaf_merge_state_def vero_aux_leaf_merge_allocator_def vero_aux_leaf_merge_header_def vero_aux_leaf_merge_tree_def bn_payload_def)

lemma vero_aux_leaf_merge_fresh:
  "fresh_block vero_aux_leaf_merge_allocator 128 24 \<and>
   fresh_block (vero_aux_leaf_merge_allocator\<lparr>live_blocks := (live_blocks vero_aux_leaf_merge_allocator)(128:=Some 24)\<rparr>) 160 8"
  by (auto simp: vero_aux_leaf_merge_allocator_def fresh_block_def block_ok_def block_bytes_def split: if_splits; arith)


definition vero_aux_merge_after_second where
  "vero_aux_merge_after_second p q r allocated =
do {
       modify
        (t_hrs_'_update
          (\<lambda>a.
              hrs_mem_update
               (heap_update r
                 (subtrees_C_update
                   (\<lambda>a.
                       PTR_COERCE
                        (unit \<rightarrow> StrictC'_BinomialTree_C ptr)
                        allocated)
                   (h_val (hrs_mem a) r)))
               a));
       condition (\<lambda>s.
                     subtrees_C (h_val (hrs_mem (t_hrs_' s)) r) =
                     NULL)
         (do {
            ret \<leftarrow>
              free'
               (PTR_COERCE(StrictC'_BinomialTree_C \<rightarrow> unit)
                 r);
            return NULL
          })
         (do {
            dest \<leftarrow>
              gets
               (\<lambda>xq.
                   PTR_COERCE
                    (StrictC'_BinomialTree_C ptr \<rightarrow> unit)
                    (subtrees_C (h_val (hrs_mem (t_hrs_' xq)) r)));
            src \<leftarrow>
              gets
               (\<lambda>xr.
                   PTR_COERCE
                    (StrictC'_BinomialTree_C ptr \<rightarrow> unit)
                    (subtrees_C (h_val (hrs_mem (t_hrs_' xr)) p)));
            count \<leftarrow>
              gets
               (\<lambda>xs.
                   word_of_nat (size_of TYPE(StrictC'_BinomialTree_C ptr)) *
                   UCAST(16 \<rightarrow> 64)
                    (order_C (h_val (hrs_mem (t_hrs_' xs)) p)));
            ret \<leftarrow> memcpy' dest src count;
            guard
             (\<lambda>s.
                 c_guard
                  (subtrees_C
                    (h_val (hrs_mem (t_hrs_' s)) r) +\<^sub>p
                   sint
                    (UCAST(16 \<rightarrow> 32 signed)
                      (order_C (h_val (hrs_mem (t_hrs_' s)) r)) -
                     1)));
            guard
             (\<lambda>s.
                 - INT_MAX - 1
                 < uint (order_C (h_val (hrs_mem (t_hrs_' s)) r)));
            guard
             (\<lambda>s.
                 uint (order_C (h_val (hrs_mem (t_hrs_' s)) r))
                 \<le> INT_MAX + 1);
            modify
             (t_hrs_'_update
               (\<lambda>a.
                   hrs_mem_update
                    (heap_update
                      (subtrees_C (h_val (hrs_mem a) r) +\<^sub>p
                       sint
                        (UCAST(16 \<rightarrow> 32 signed)
                          (order_C (h_val (hrs_mem a) r)) -
                         1))
                      q)
                    a));
            i \<leftarrow>
              whileLoop (\<lambda>i s.
                            i <s UCAST(16 \<rightarrow> 32 signed)
                                  (order_C
                                    (h_val (hrs_mem (t_hrs_' s)) r)))
                (\<lambda>i.
                    do {
                      guard
                       (\<lambda>s.
                           c_guard
                            (subtrees_C
                              (h_val (hrs_mem (t_hrs_' s))
                                r) +\<^sub>p
                             sint i));
                      tree \<leftarrow>
                        gets
                         (\<lambda>xx.
                             h_val (hrs_mem (t_hrs_' xx))
                              (subtrees_C
                                (h_val (hrs_mem (t_hrs_' xx))
                                  r) +\<^sub>p
                               sint i));
                      ret \<leftarrow> binomial_tree_ref' tree;
                      guard (\<lambda>s. 0 \<le> 2147483649 + sint i);
                      guard (\<lambda>s. sint i < INT_MAX);
                      return (i + 1)
                    })
               0;
            return r
          })
}"

definition vero_aux_merge_after_first where
  "vero_aux_merge_after_first p q r =
condition (\<lambda>s. r = NULL)
    (return NULL)
    (do {
       guard (\<lambda>s. c_guard r);
       modify
        (t_hrs_'_update
          (\<lambda>a.
              hrs_mem_update
               (heap_update r
                 (refcount_C_update (\<lambda>a. 0)
                   (h_val (hrs_mem a) r)))
               a));
       guard
        (\<lambda>s.
            uint (order_C (h_val (hrs_mem (t_hrs_' s)) p)) < INT_MAX);
       guard (\<lambda>s. c_guard p);
       modify
        (t_hrs_'_update
          (\<lambda>a.
              hrs_mem_update
               (heap_update r
                 (order_C_update
                   (\<lambda>b. order_C (h_val (hrs_mem a) p) + 1)
                   (h_val (hrs_mem a) r)))
               a));
       modify
        (t_hrs_'_update
          (\<lambda>a.
              hrs_mem_update
               (heap_update r
                 (value_C_update
                   (\<lambda>b. value_C (h_val (hrs_mem a) p))
                   (h_val (hrs_mem a) r)))
               a));
       size \<leftarrow>
         gets
          (\<lambda>xm.
              word_of_nat (size_of TYPE(StrictC'_BinomialTree_C ptr)) *
              UCAST(16 \<rightarrow> 64)
               (order_C (h_val (hrs_mem (t_hrs_' xm)) r)));
       allocated \<leftarrow> malloc' size;
       vero_aux_merge_after_second p q r allocated
     })"

lemma vero_aux_merge_factor:
  "binomial_tree_merge' h p q =
do {
  guard (\<lambda>s. c_guard p);
  guard (\<lambda>s. c_guard q);
  data1 \<leftarrow>
    gets (\<lambda>xb. value_C (h_val (hrs_mem (t_hrs_' xb)) p));
  data2 \<leftarrow>
    gets (\<lambda>xc. value_C (h_val (hrs_mem (t_hrs_' xc)) q));
  ret'int'1 \<leftarrow> binomial_heap_cmp' h data1 data2;
  (tree1, tree2) \<leftarrow>
    return
     (if 0 <s ret'int'1 then (q, p)
      else (p, q));
  ret'ptr_to_void'1 \<leftarrow>
    malloc' (word_of_nat (size_of TYPE(StrictC'_BinomialTree_C)));
  new_tree \<leftarrow>
    return
     (PTR_COERCE(unit \<rightarrow> StrictC'_BinomialTree_C)
       ret'ptr_to_void'1);
  vero_aux_merge_after_first tree1 tree2 new_tree
}"
  by (simp only: binomial_tree_merge'_def vero_aux_merge_after_first_def vero_aux_merge_after_second_def)



lemma vero_aux_merge_selected_runs_to:
  assumes GP: "c_guard p" and GQ: "c_guard q" and GH: "c_guard h"
    and MIN: "heap_type_C (bn_heap s h)=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap s h)=binomial_heap_input.int_compare"
    and PV: "value_C (bn_tree s p)=v" and QV: "value_C (bn_tree s q)=v"
    and GV: "c_guard (ptr_coerce v :: 32 signed word ptr)"
  shows "runs_to (binomial_tree_merge' h p q) s Q =
    runs_to (do {a \<leftarrow> malloc' 24; vero_aux_merge_after_first p q (ptr_coerce a)}) s Q"
  by (simp add: vero_aux_merge_factor runs_to_bind_iff runs_to_guard_iff runs_to_gets_iff
    GP GQ PV[unfolded bn_tree_def] QV[unfolded bn_tree_def] c0001_prove[OF GH MIN CMP GV] split: prod.splits)

lemma vero_aux_malloc_bindD:
  fixes K :: "unit ptr \<Rightarrow> (unit, 'a, globals) spec_monad"
  assumes RT: "runs_to (do {p \<leftarrow> malloc' n; K p}) s Q"
    and REL: "malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) (ptr_val p) hp A"
  shows "runs_to (K p) ((t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>) Q"
  using RT REL
  by (auto simp: malloc'_def runs_to_bind_iff runs_to_guard_iff runs_to_assume_result_and_state_iff)

lemma vero_aux_merge_after_second_fails:
  assumes GR: "c_guard r" and D: "ptr_span p \<inter> ptr_span r = {}"
    and Z: "subtrees_C (bn_tree s p)=NULL" and NN: "allocated\<noteq>NULL"
  shows "\<not>runs_to (vero_aux_merge_after_second p q r allocated) s Q"
  using GR Z NN
  by (simp add: vero_aux_merge_after_second_def bn_tree_def memcpy'_def memcpy_ok_def
    runs_to_bind_iff runs_to_modify_iff runs_to_condition_iff runs_to_gets_iff runs_to_guard_iff
    hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update h_val_heap_update_disjoint[OF D])


definition vero_aux_merge_mid where
  "vero_aux_merge_mid s p r = t_hrs_'_update (hrs_mem_update (heap_update r
    ((bn_tree s r)\<lparr>refcount_C:=0, order_C:=1, value_C:=value_C (bn_tree s p)\<rparr>))) s"

lemma vero_aux_merge_mid_fields:
  assumes D: "ptr_span p \<inter> ptr_span r = {}"
  shows "bn_tree (vero_aux_merge_mid s p r) p = bn_tree s p \<and>
    phantom_machine_state_' (vero_aux_merge_mid s p r) = phantom_machine_state_' s"
  by (simp add: vero_aux_merge_mid_def bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update_disjoint[OF D])

lemma vero_aux_merge_after_firstD:
  assumes RT: "runs_to (vero_aux_merge_after_first p q r) s Q"
    and GR: "c_guard r" and GP: "c_guard p" and D: "ptr_span p \<inter> ptr_span r = {}"
    and OP: "order_C (bn_tree s p)=0"
  shows "runs_to (do {a \<leftarrow> malloc' 8; vero_aux_merge_after_second p q r a}) (vero_aux_merge_mid s p r) Q"
proof -
  let ?f = "\<lambda>a. hrs_mem_update (heap_update r (value_C_update (\<lambda>_. value_C (h_val (hrs_mem a) p)) (h_val (hrs_mem a) r))) a"
  let ?g = "\<lambda>a. hrs_mem_update (heap_update r (order_C_update (\<lambda>_. order_C (h_val (hrs_mem a) p)+1) (h_val (hrs_mem a) r))) a"
  let ?h = "\<lambda>a. hrs_mem_update (heap_update r (refcount_C_update (\<lambda>_. 0) (h_val (hrs_mem a) r))) a"
  have E: "t_hrs_'_update (?f \<circ> ?g \<circ> ?h) s = vero_aux_merge_mid s p r"
    by (rule globals.equality; simp add: vero_aux_merge_mid_def bn_tree_def GR OP[unfolded bn_tree_def hrs_mem_def]
      hrs_mem_update_def hrs_mem_def case_prod_unfold comp_def h_val_heap_update h_val_heap_update_disjoint[OF D] heap_update_collapse)
  have NN: "r\<noteq>NULL" using GR by (auto dest: c_guard_NULL)
  have RAW: "runs_to (do {a \<leftarrow> malloc' 8; vero_aux_merge_after_second p q r a}) (t_hrs_'_update (?f \<circ> ?g \<circ> ?h) s) Q"
    using RT GR GP OP NN
    by (simp add: vero_aux_merge_after_first_def bn_tree_def
      runs_to_bind_iff runs_to_guard_iff runs_to_modify_iff runs_to_gets_iff runs_to_condition_iff
      hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update h_val_heap_update_disjoint[OF D]
      heap_update_collapse INT_MAX_def)
  show ?thesis using RAW by (simp only: E)
qed

lemma vero_aux_merge_after_first_fails:
  fixes b :: "unit ptr"
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and GR: "c_guard r" and GP: "c_guard p" and D: "ptr_span p \<inter> ptr_span r = {}"
    and OP: "order_C (bn_tree s p)=0" and Z: "subtrees_C (bn_tree s p)=NULL"
    and F: "fresh_block (phantom_machine_state_' s) (ptr_val b) 8"
  shows "\<not>runs_to (vero_aux_merge_after_first p q r) s Q"
proof
  assume RT: "runs_to (vero_aux_merge_after_first p q r) s Q"
  let ?m = "vero_aux_merge_mid s p r"
  have RM: "runs_to (do {a \<leftarrow> malloc' 8; vero_aux_merge_after_second p q r a}) ?m Q"
    by (rule vero_aux_merge_after_firstD[OF RT GR GP D OP])
  have AM: "phantom_machine_state_' ?m = phantom_machine_state_' s"
    and PM: "bn_tree ?m p = bn_tree s p" using vero_aux_merge_mid_fields[OF D] by blast+
  let ?A = "(phantom_machine_state_' ?m)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' ?m))(ptr_val b:=Some 8)\<rparr>"
  have REL: "malloc_rel (unat (8::64 word)) (hrs_mem (t_hrs_' ?m)) (phantom_machine_state_' ?m) (ptr_val b) (hrs_mem (t_hrs_' ?m)) ?A"
    using W F by (simp add: AM malloc_rel_def bytes_frame_def)
  let ?u = "(t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' ?m))) ?m)\<lparr>phantom_machine_state_' := ?A\<rparr>"
  have R2: "runs_to (vero_aux_merge_after_second p q r b) ?u Q"
    by (rule vero_aux_malloc_bindD[OF RM REL])
  have TU: "bn_tree ?u p = bn_tree ?m p"
    by (simp add: bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have ZU: "subtrees_C (bn_tree ?u p)=NULL" by (simp only: TU PM Z)
  have NZ: "ptr_val b\<noteq>0" using F by (simp add: fresh_block_def block_ok_def)
  have NN: "b\<noteq>NULL" using NZ by auto
  have FAIL: "\<not>runs_to (vero_aux_merge_after_second p q r b) ?u Q"
    by (rule vero_aux_merge_after_second_fails[OF GR D ZU NN])
  show False using FAIL R2 by blast
qed


lemma vero_aux_leaf_merge_runs_to_fails:
  fixes r :: "StrictC'_BinomialTree_C ptr" and b :: "unit ptr"
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and GP: "c_guard p" and GQ: "c_guard q" and GH: "c_guard h"
    and MIN: "heap_type_C (bn_heap s h)=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap s h)=binomial_heap_input.int_compare"
    and PV: "value_C (bn_tree s p)=v" and QV: "value_C (bn_tree s q)=v"
    and GV: "c_guard (ptr_coerce v :: 32 signed word ptr)"
    and GR: "c_guard r" and D: "ptr_span p \<inter> ptr_span r = {}"
    and OP: "order_C (bn_tree s p)=0" and Z: "subtrees_C (bn_tree s p)=NULL"
    and F1: "fresh_block (phantom_machine_state_' s) (ptr_val r) 24"
    and F2: "fresh_block ((phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val r:=Some 24)\<rparr>) (ptr_val b) 8"
  shows "\<not>runs_to (binomial_tree_merge' h p q) s Q"
proof
  assume RT: "runs_to (binomial_tree_merge' h p q) s Q"
  have RM: "runs_to (do {a \<leftarrow> malloc' 24; vero_aux_merge_after_first p q (ptr_coerce a)}) s Q"
    using RT by (simp only: vero_aux_merge_selected_runs_to[OF GP GQ GH MIN CMP PV QV GV])
  let ?A = "(phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val r:=Some 24)\<rparr>"
  have REL: "malloc_rel (unat (24::64 word)) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s)
      (ptr_val (ptr_coerce r :: unit ptr)) (hrs_mem (t_hrs_' s)) ?A"
    using W F1 by (simp add: malloc_rel_def bytes_frame_def)
  let ?u = "(t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' s))) s)\<lparr>phantom_machine_state_' := ?A\<rparr>"
  have R1: "runs_to (vero_aux_merge_after_first p q r) ?u Q"
    using vero_aux_malloc_bindD[OF RM REL] by (simp only: ptr_coerce_idem ptr_coerce_id)
  have AU: "phantom_machine_state_' ?u = ?A" by simp
  have TU: "bn_tree ?u p = bn_tree s p"
    by (simp add: bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have WA: "allocator_wf ?A" using W F1 by (auto simp: allocator_wf_def fresh_block_def Int_commute)
  have WU: "allocator_wf (phantom_machine_state_' ?u)" by (simp only: AU WA)
  have FU: "fresh_block (phantom_machine_state_' ?u) (ptr_val b) 8" using F2 by (simp only: AU)
  have OU: "order_C (bn_tree ?u p)=0" by (simp only: TU OP)
  have ZU: "subtrees_C (bn_tree ?u p)=NULL" by (simp only: TU Z)
  have FAIL: "\<not>runs_to (vero_aux_merge_after_first p q r) ?u Q"
    by (rule vero_aux_merge_after_first_fails[OF WU GR GP D OU ZU FU])
  show False using FAIL R1 by blast
qed

lemma vero_aux_leaf_merge_fails:
  fixes r :: "StrictC'_BinomialTree_C ptr" and b :: "unit ptr"
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and GP: "c_guard p" and GQ: "c_guard q" and GH: "c_guard h"
    and MIN: "heap_type_C (bn_heap s h)=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap s h)=binomial_heap_input.int_compare"
    and PV: "value_C (bn_tree s p)=v" and QV: "value_C (bn_tree s q)=v"
    and GV: "c_guard (ptr_coerce v :: 32 signed word ptr)"
    and GR: "c_guard r" and D: "ptr_span p \<inter> ptr_span r = {}"
    and OP: "order_C (bn_tree s p)=0" and Z: "subtrees_C (bn_tree s p)=NULL"
    and F1: "fresh_block (phantom_machine_state_' s) (ptr_val r) 24"
    and F2: "fresh_block ((phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val r:=Some 24)\<rparr>) (ptr_val b) 8"
  shows "\<not>bn_contract (binomial_tree_merge' h p q) s Q"
  using vero_aux_leaf_merge_runs_to_fails[OF W GP GQ GH MIN CMP PV QV GV GR D OP Z F1 F2]
  by (simp add: bn_contract_def)

lemma vero_aux_leaf_merge_failure:
  "\<not>bn_contract (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96)) vero_aux_leaf_merge_state Q"
proof -
  let ?s = "vero_aux_leaf_merge_state"
  have W: "allocator_wf (phantom_machine_state_' ?s)"
    and GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and MIN: "heap_type_C (bn_heap ?s (Ptr 16))=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap ?s (Ptr 16))=binomial_heap_input.int_compare"
    using vero_aux_leaf_merge_pre by blast+
  have GP: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and GQ: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    and GR: "c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr)"
    and GV0: "c_guard (Ptr 192 :: 32 signed word ptr)"
    using vero_aux_leaf_merge_guards by blast+
  have GV: "c_guard (ptr_coerce (Ptr 192 :: unit ptr) :: 32 signed word ptr)" using GV0 by simp
  have HP: "bn_tree ?s (Ptr 64)=vero_aux_leaf_merge_tree"
    and HQ: "bn_tree ?s (Ptr 96)=vero_aux_leaf_merge_tree"
    using vero_aux_leaf_merge_fields by blast+
  have PV: "value_C (bn_tree ?s (Ptr 64))=(Ptr 192 :: unit ptr)"
    and QV: "value_C (bn_tree ?s (Ptr 96))=(Ptr 192 :: unit ptr)"
    and OP: "order_C (bn_tree ?s (Ptr 64))=0"
    and Z: "subtrees_C (bn_tree ?s (Ptr 64))=NULL"
    by (simp add: HP HQ vero_aux_leaf_merge_tree_def)+
  have D: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) = {}"
    by (simp only: vero_aux_span_block[OF GP] vero_aux_span_block[OF GR]; auto simp: block_bytes_def)
  have F1: "fresh_block (phantom_machine_state_' ?s) (ptr_val (Ptr 128 :: StrictC'_BinomialTree_C ptr)) 24"
    and F2: "fresh_block ((phantom_machine_state_' ?s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' ?s))(ptr_val (Ptr 128 :: StrictC'_BinomialTree_C ptr):=Some 24)\<rparr>) (ptr_val (Ptr 160 :: unit ptr)) 8"
    using vero_aux_leaf_merge_fresh by (auto simp: vero_aux_leaf_merge_state_def)
  show ?thesis by (rule vero_aux_leaf_merge_fails[OF W GP GQ GH MIN CMP PV QV GV GR D OP Z F1 F2])
qed


lemma vero_aux_leaf_tree_merge_pre:
  "bn_ds_tree_merge_pre vero_aux_leaf_merge_state (Ptr 16) (block_bytes 192 4)
    (BN (Ptr 64) []) (BN (Ptr 96) []) {Ptr 64, Ptr 96} (\<lambda>_. []) [] {#Ptr 64, Ptr 96#}"
proof -
  let ?s = "vero_aux_leaf_merge_state"
  let ?P = "block_bytes 192 4"
  let ?N = "{Ptr 64, Ptr 96 :: StrictC'_BinomialTree_C ptr}"
  have AS: "phantom_machine_state_' ?s=vero_aux_leaf_merge_allocator"
    by (simp add: vero_aux_leaf_merge_state_def)
  have HP: "bn_tree ?s (Ptr 64)=vero_aux_leaf_merge_tree"
    and HQ: "bn_tree ?s (Ptr 96)=vero_aux_leaf_merge_tree"
    using vero_aux_leaf_merge_fields by blast+
  have GP: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and GQ: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    and GV: "c_guard (Ptr 192 :: 32 signed word ptr)"
    using vero_aux_leaf_merge_guards by blast+
  have W: "allocator_wf vero_aux_leaf_merge_allocator" by (rule vero_aux_leaf_merge_allocator_wf)
  have GR: "bn_ds_graph ?s ?P ?N (\<lambda>_. []) [] {#Ptr 64, Ptr 96#} {}"
    using W GP GQ GV
    by (auto simp: bn_ds_graph_def bn_ds_slot_handles_def HP HQ AS
      vero_aux_leaf_merge_tree_def vero_aux_leaf_merge_allocator_def bn_payload_def)
  have ST: "bn_ds_graph_storage ?s ?N []"
    by (auto simp: bn_ds_graph_storage_def HP HQ vero_aux_leaf_merge_tree_def)
  have GB: "bn_ds_graph_blocks ?s ?N = {64,96}"
    by (auto simp: bn_ds_graph_blocks_def HP HQ vero_aux_leaf_merge_tree_def)
  have VP: "bn_valid ?s ?P (BN (Ptr 64) [])"
    and VQ: "bn_valid ?s ?P (BN (Ptr 96) [])"
    and GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and MIN: "heap_type_C (bn_heap ?s (Ptr 16))=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap ?s (Ptr 16))=binomial_heap_input.int_compare"
    and LH: "live_blocks (phantom_machine_state_' ?s) (ptr_val (Ptr 16 :: StrictC'_BinomialHeap_C ptr)) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using vero_aux_leaf_merge_pre by blast+
  have LP: "bn_ds_tree_layout ?s ?P (BN (Ptr 64) [])" using VP by simp
  have LQ: "bn_ds_tree_layout ?s ?P (BN (Ptr 96) [])" using VQ by simp
  show ?thesis using GH MIN CMP LH LP LQ GR ST GB
    by (auto simp: bn_ds_tree_merge_pre_def HP HQ vero_aux_leaf_merge_tree_def)
qed

lemma vero_aux_carry_loop_factor:
  "bn_ds_carry_loop h other n a vals =
    bn_ds_carry_loop_from h other n a (NULL,0,0,vals)"
  by (simp only: bn_ds_carry_loop_def bn_ds_carry_loop_from_def bn_ds_carry_loop_step_def)

definition vero_aux_heap_merge_after_roots where
  "vero_aux_heap_merge_after_roots heap other bn_max new_roots vals =
condition (\<lambda>s. new_roots = NULL)
    (return 0)
    (finally
      (do {
         (carry, i, new_roots_length, vals) \<leftarrow>
           bn_ds_carry_loop heap other bn_max new_roots vals;
         i \<leftarrow>
           liftE
            (whileLoop (\<lambda>i s.
                           i < roots_length_C
                                (h_val (hrs_mem (t_hrs_' s)) heap))
               (\<lambda>i.
                   do {
                     guard
                      (\<lambda>s.
                          c_guard
                           (roots_C
                             (h_val (hrs_mem (t_hrs_' s)) heap) +\<^sub>p
                            uint i));
                     ret \<leftarrow>
                       condition (\<lambda>s.
                                     h_val (hrs_mem (t_hrs_' s))
(roots_C (h_val (hrs_mem (t_hrs_' s)) heap) +\<^sub>p uint i) \<noteq>
                                     NULL)
                         (gets
                           (\<lambda>xi.
                               h_val (hrs_mem (t_hrs_' xi))
                                (roots_C
                                  (h_val (hrs_mem (t_hrs_' xi))
                                    heap) +\<^sub>p
                                 uint i)) >>=
                          binomial_tree_unref')
                         skip;
                     return (i + 1)
                   })
              0);
         ptr \<leftarrow>
           gets
            (\<lambda>xh.
                PTR_COERCE(StrictC'_BinomialTree_C ptr \<rightarrow> unit)
                 (roots_C (h_val (hrs_mem (t_hrs_' xh)) heap)));
         ret \<leftarrow> liftE (free' ptr);
         modify
          (t_hrs_'_update
            (\<lambda>a.
                hrs_mem_update
                 (heap_update heap
                   (roots_C_update (\<lambda>a. new_roots)
                     (h_val (hrs_mem a) heap)))
                 a));
         modify
          (t_hrs_'_update
            (\<lambda>a.
                hrs_mem_update
                 (heap_update heap
                   (roots_length_C_update (\<lambda>a. new_roots_length)
                     (h_val (hrs_mem a) heap)))
                 a));
         throw 1
       }))"


lemma vero_aux_heap_merge_expanded:
  "binomial_heap_merge' heap other = bn_ds_binomial_heap_merge_expanded heap other"
  by (simp only: binomial_heap_merge'_def bn_ds_binomial_heap_merge_expanded_def bn_ds_carry_loop_def)

lemma vero_aux_heap_merge_factor:
  "binomial_heap_merge' heap other =
do {
  vals \<leftarrow> unknown;
  guard (\<lambda>s. c_guard heap);
  guard (\<lambda>s. c_guard other);
  bn_max \<leftarrow>
    condition (\<lambda>s.
                  roots_length_C (h_val (hrs_mem (t_hrs_' s)) other)
                  < roots_length_C (h_val (hrs_mem (t_hrs_' s)) heap))
      (gets
        (\<lambda>xc.
            roots_length_C (h_val (hrs_mem (t_hrs_' xc)) heap) + 1))
      (gets
        (\<lambda>xc.
            roots_length_C (h_val (hrs_mem (t_hrs_' xc)) other) + 1));
  ret'ptr_to_void'1 \<leftarrow>
    malloc'
     (word_of_nat (size_of TYPE(StrictC'_BinomialTree_C ptr)) *
      UCAST(32 \<rightarrow> 64) bn_max);
  new_roots \<leftarrow>
    return
     (PTR_COERCE(unit \<rightarrow> StrictC'_BinomialTree_C ptr)
       ret'ptr_to_void'1);
  vero_aux_heap_merge_after_roots heap other bn_max new_roots vals
}"
  by (simp only: vero_aux_heap_merge_expanded bn_ds_binomial_heap_merge_expanded_def vero_aux_heap_merge_after_roots_def)



lemma vero_aux_carry_first_step_fails:
  assumes LH: "0 < roots_length_C (bn_heap s h)"
    and LO: "0 < roots_length_C (bn_heap s other)"
    and RH: "roots_C (bn_heap s h)=a1" and RO: "roots_C (bn_heap s other)=a2"
    and H1: "h_val (hrs_mem (t_hrs_' s)) a1=p"
    and H2: "h_val (hrs_mem (t_hrs_' s)) a2=q"
    and G1: "c_guard a1" and G2: "c_guard a2" and GA: "c_guard a"
    and PN: "p\<noteq>NULL" and QN: "q\<noteq>NULL"
    and FAIL: "\<And>R. \<not>runs_to (binomial_tree_merge' h p q)
      (t_hrs_'_update (hrs_mem_update (heap_update a NULL)) s) R"
  shows "\<not>runs_to (bn_ds_carry_loop_step h other n a (NULL,0,0,vals)) s Q"
  by (simp add: bn_ds_carry_loop_step_def runs_to_bind_iff runs_to_liftE_iff
    runs_to_gets_iff runs_to_guard_iff runs_to_condition_iff runs_to_modify_iff
    LH[unfolded bn_heap_def] LO[unfolded bn_heap_def]
    RH[unfolded bn_heap_def] RO[unfolded bn_heap_def] H1 H2 G1 G2 GA PN QN
    Arrays.index_update Arrays.index_update2 INT_MAX_def FAIL)

lemma vero_aux_carry_first_loop_fails:
  assumes N: "0<n"
    and FAIL: "\<And>R. \<not>runs_to (bn_ds_carry_loop_step h other n a (NULL,0,0,vals)) s R"
  shows "\<not>runs_to (bn_ds_carry_loop h other n a vals) s Q"
  apply (simp only: vero_aux_carry_loop_factor bn_ds_carry_loop_from_def)
  apply (subst whileLoop_unroll)
  by (simp add: runs_to_condition_iff runs_to_bind_iff N FAIL)

lemma vero_aux_after_roots_fails:
  assumes A: "a\<noteq>NULL"
    and FAIL: "\<And>R. \<not>runs_to (bn_ds_carry_loop h other n a vals) s R"
  shows "\<not>runs_to (vero_aux_heap_merge_after_roots h other n a vals) s Q"
  by (simp add: vero_aux_heap_merge_after_roots_def runs_to_condition_iff
    runs_to_finally_iff runs_to_bind_iff A FAIL)

lemma vero_aux_heap_merge_malloc_prefix:
  assumes RT: "runs_to (binomial_heap_merge' h other) s Q"
    and GH: "c_guard h" and GO: "c_guard other"
    and LH: "roots_length_C (bn_heap s h)=l"
    and LO: "roots_length_C (bn_heap s other)=m"
  shows "\<forall>vals. runs_to (do {p \<leftarrow> malloc' (8 * ucast (if m<l then l+1 else m+1));
    vero_aux_heap_merge_after_roots h other (if m<l then l+1 else m+1) (ptr_coerce p) vals}) s Q"
  using RT by (cases "m<l"; simp add: vero_aux_heap_merge_factor runs_to_bind_iff runs_to_unknown_iff
    runs_to_guard_iff runs_to_condition_iff runs_to_gets_iff GH GO
    LH[unfolded bn_heap_def] LO[unfolded bn_heap_def])

lemma vero_aux_mem_identity:
  "t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' s))) s=s"
  by (rule globals.equality; simp add: hrs_mem_update_def hrs_mem_def case_prod_unfold)


lemma vero_aux_heap_first_collision_fails:
  fixes a :: "StrictC'_BinomialTree_C ptr ptr"
    and r :: "StrictC'_BinomialTree_C ptr" and b :: "unit ptr"
  assumes GH: "c_guard h" and GO: "c_guard other"
    and LH: "roots_length_C (bn_heap s h)=l" and LO: "roots_length_C (bn_heap s other)=m"
    and LP: "0<l" and MP: "0<m"
    and N: "n=(if m<l then l+1 else m+1)" and NP: "0<n"
    and RH: "roots_C (bn_heap s h)=roots_left" and RO: "roots_C (bn_heap s other)=roots_right"
    and H1: "h_val (hrs_mem (t_hrs_' s)) roots_left=p"
    and H2: "h_val (hrs_mem (t_hrs_' s)) roots_right=q"
    and G1: "c_guard roots_left" and G2: "c_guard roots_right" and GA: "c_guard a" and AN: "a\<noteq>NULL"
    and GP: "c_guard p" and GQ: "c_guard q" and GR: "c_guard r"
    and MIN: "heap_type_C (bn_heap s h)=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap s h)=binomial_heap_input.int_compare"
    and PV: "value_C (bn_tree s p)=v" and QV: "value_C (bn_tree s q)=v"
    and GV: "c_guard (ptr_coerce v :: 32 signed word ptr)"
    and OP: "order_C (bn_tree s p)=0" and Z: "subtrees_C (bn_tree s p)=NULL"
    and DHA: "ptr_span h \<inter> ptr_span a={}"
    and DPA: "ptr_span p \<inter> ptr_span a={}" and DQA: "ptr_span q \<inter> ptr_span a={}"
    and DPR: "ptr_span p \<inter> ptr_span r={}"
    and REL: "malloc_rel (unat (8 * (ucast n :: 64 word))) (hrs_mem (t_hrs_' s))
      (phantom_machine_state_' s) (ptr_val a) (hrs_mem (t_hrs_' s)) A"
    and WA: "allocator_wf A"
    and F1: "fresh_block A (ptr_val r) 24"
    and F2: "fresh_block (A\<lparr>live_blocks := (live_blocks A)(ptr_val r:=Some 24)\<rparr>) (ptr_val b) 8"
  shows "\<not>runs_to (binomial_heap_merge' h other) s Q"
proof
  assume RT: "runs_to (binomial_heap_merge' h other) s Q"
  let ?u = "s\<lparr>phantom_machine_state_' := A\<rparr>"
  let ?t = "t_hrs_'_update (hrs_mem_update (heap_update a NULL)) ?u"
  have HT: "bn_heap ?t h=bn_heap s h"
    by (simp add: bn_heap_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update_disjoint[OF DHA])
  have PT: "bn_tree ?t p=bn_tree s p"
    by (simp add: bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update_disjoint[OF DPA])
  have QT: "bn_tree ?t q=bn_tree s q"
    by (simp add: bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update_disjoint[OF DQA])
  have WT: "allocator_wf (phantom_machine_state_' ?t)" by (simp add: WA)
  have MINT: "heap_type_C (bn_heap ?t h)=BINOMIAL_HEAP_TYPE_MIN" by (simp only: HT MIN)
  have CMPT: "compare_func_C (bn_heap ?t h)=binomial_heap_input.int_compare" by (simp only: HT CMP)
  have PVT: "value_C (bn_tree ?t p)=v" by (simp only: PT PV)
  have QVT: "value_C (bn_tree ?t q)=v" by (simp only: QT QV)
  have OPT: "order_C (bn_tree ?t p)=0" by (simp only: PT OP)
  have ZT: "subtrees_C (bn_tree ?t p)=NULL" by (simp only: PT Z)
  have FT1: "fresh_block (phantom_machine_state_' ?t) (ptr_val r) 24" using F1 by simp
  have FT2: "fresh_block ((phantom_machine_state_' ?t)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' ?t))(ptr_val r:=Some 24)\<rparr>) (ptr_val b) 8"
    using F2 by simp
  have LEAF: "\<And>R. \<not>runs_to (binomial_tree_merge' h p q) ?t R"
    by (rule vero_aux_leaf_merge_runs_to_fails[OF WT GP GQ GH MINT CMPT PVT QVT GV GR DPR OPT ZT FT1 FT2])
  have LU: "0<roots_length_C (bn_heap ?u h)" using LH LP by (simp add: bn_heap_def)
  have MU: "0<roots_length_C (bn_heap ?u other)" using LO MP by (simp add: bn_heap_def)
  have RHU: "roots_C (bn_heap ?u h)=roots_left" using RH by (simp add: bn_heap_def)
  have ROU: "roots_C (bn_heap ?u other)=roots_right" using RO by (simp add: bn_heap_def)
  have H1U: "h_val (hrs_mem (t_hrs_' ?u)) roots_left=p" using H1 by simp
  have H2U: "h_val (hrs_mem (t_hrs_' ?u)) roots_right=q" using H2 by simp
  have PN: "p\<noteq>NULL" using GP by (rule c_guard_NULL)
  have QN: "q\<noteq>NULL" using GQ by (rule c_guard_NULL)
  have STEP: "\<And>vals R. \<not>runs_to (bn_ds_carry_loop_step h other n a (NULL,0,0,vals)) ?u R"
    by (rule vero_aux_carry_first_step_fails[OF LU MU RHU ROU H1U H2U G1 G2 GA PN QN LEAF])
  have LOOP: "\<And>vals R. \<not>runs_to (bn_ds_carry_loop h other n a vals) ?u R"
    by (rule vero_aux_carry_first_loop_fails[OF NP STEP])
  have AFTER: "\<And>vals R. \<not>runs_to (vero_aux_heap_merge_after_roots h other n a vals) ?u R"
    by (rule vero_aux_after_roots_fails[OF AN LOOP])
  have PRE: "\<forall>vals. runs_to (do {x \<leftarrow> malloc' (8 * (ucast n :: 64 word));
    vero_aux_heap_merge_after_roots h other n (ptr_coerce x) vals}) s Q"
    using vero_aux_heap_merge_malloc_prefix[OF RT GH GO LH LO] by (simp only: N; blast)
  have REL': "malloc_rel (unat (8 * (ucast n :: 64 word))) (hrs_mem (t_hrs_' s))
    (phantom_machine_state_' s) (ptr_val (ptr_coerce a :: unit ptr)) (hrs_mem (t_hrs_' s)) A"
    using REL by simp
  have BAD: "runs_to (vero_aux_heap_merge_after_roots h other n a undefined) ?u Q"
    using vero_aux_malloc_bindD[OF PRE[rule_format, of undefined] REL']
    by (simp add: vero_aux_mem_identity)
  show False using BAD AFTER by blast
qed



end



lemma c0006_prove:
  "bn_stack_ready S s \<Longrightarrow>
   \<exists>p d q e.
     (p,d) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<and>
     (q,e) \<in> stack_allocs 1 S TYPE(StrictC'_BinomialTree_C ptr) d"

proof -
  assume H: "bn_stack_ready S s"
  have A: "stack_allocs 1 S TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<noteq> {}"
    using H unfolding bn_stack_ready_def by blast
  obtain x where X: "x \<in> stack_allocs 1 S TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s))"
    using A by blast
  obtain p d where XD: "x = (p,d)" by (cases x) auto
  have B: "stack_allocs 1 S TYPE(StrictC'_BinomialTree_C ptr) d \<noteq> {}"
    using H X XD unfolding bn_stack_ready_def by blast
  obtain y where Y: "y \<in> stack_allocs 1 S TYPE(StrictC'_BinomialTree_C ptr) d"
    using B by blast
  obtain q e where YE: "y = (q,e)" by (cases y) auto
  show ?thesis using X Y XD YE by blast
qed



context binomial_heap_input_global_addresses begin

lemma vero_aux_update_frame:
  fixes p :: "'a::mem_type ptr"
  assumes G: "c_guard p"
  shows "bytes_frame (block_bytes (ptr_val p) (size_of TYPE('a))) hp (heap_update p v hp)"
proof -
  have SP: "ptr_span p = block_bytes (ptr_val p) (size_of TYPE('a))"
    using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]]
    by (simp add: block_bytes_def)
  show ?thesis unfolding bytes_frame_def heap_update_def
    by (auto intro!: heap_update_nmem_same simp: SP)
qed

lemma vero_aux_refcount_dec:
  "refcount_C_update (\<lambda>a. a - 1) x = x\<lparr>refcount_C := refcount_C x - 1\<rparr>"
  by (cases x) simp

lemma vero_aux_refcount_inc:
  "refcount_C_update (\<lambda>a. a + 1) x = x\<lparr>refcount_C := refcount_C x + 1\<rparr>"
  by (cases x) simp

lemma c0007_prove:
  "c_guard p \<Longrightarrow> 1 < unat (refcount_C (bn_tree s p)) \<Longrightarrow>
    bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) - 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

proof -
  assume G: "c_guard p" and B: "1 < unat (refcount_C (bn_tree s p))"
  have NN: "p \<noteq> NULL" using G by (auto dest: c_guard_NULL)
  have LB: "- INT_MAX - 1 < uint (refcount_C (bn_tree s p))"
    using uint_nonnegative[of "refcount_C (bn_tree s p)"] by (simp add: INT_MAX_def; arith)
  have UB: "uint (refcount_C (bn_tree s p)) \<le> INT_MAX + 1"
    using uint_lt2p[of "refcount_C (bn_tree s p)"] by (simp add: INT_MAX_def; arith)
  have NZ: "refcount_C (bn_tree s p) - 1 \<noteq> 0" using B by auto
  show ?thesis
    apply (subst binomial_tree_unref'.simps)
    using G NN LB UB NZ vero_aux_update_frame[OF G]
    by (auto simp: bn_contract_def bn_tree_def
      hrs_mem_def hrs_mem_update_def case_prod_unfold h_val_heap_update vero_aux_refcount_dec vero_aux_refcount_inc
      runs_to_bind_iff runs_to_guard_iff runs_to_modify_iff runs_to_condition_iff
      reaches_bind succeeds_runs_to_iff reaches_guard reaches_modify reaches_condition_iff
      reaches_return[abs_def] ucast_eq_0)
qed



end



lemma c0008_prove:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"

proof -
  assume A: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and K: "size_of TYPE('a) * k \<le> n" and I: "i < k"
  have B: "unat (ptr_val p) + n \<le> 2^64"
    using A L unfolding allocator_wf_def block_ok_def by blast
  show ?thesis
  proof
    fix x assume X: "x \<in> ptr_span (p +\<^sub>p int i)"
    obtain j where J: "j < size_of TYPE('a)"
      and E: "x = ptr_val p + of_nat (i * size_of TYPE('a) + j)"
      using X by (auto simp: intvl_def ptr_add_def algebra_simps)
    have M: "(i+1) * size_of TYPE('a) \<le> k * size_of TYPE('a)"
      using I by (intro mult_le_mono1) simp
    have N: "i * size_of TYPE('a) + j < n" using J M K by (simp only: algebra_simps; arith)
    have C: "unat (ptr_val p) + (i * size_of TYPE('a) + j) < 2^64"
      using B N by arith
    have D: "i * size_of TYPE('a) + j < 2^64" using C by arith
    have U: "unat x = unat (ptr_val p) + (i * size_of TYPE('a) + j)"
      using C D by (simp only: E unat_word_ariths unat_of_nat; simp_all)
    show "x \<in> block_bytes (ptr_val p) n"
      using N by (simp add: block_bytes_def U)
  qed
qed



context binomial_heap_input_global_addresses begin

lemma vero_aux_contract_bind:
  "bn_contract f s P \<Longrightarrow> (\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q) \<Longrightarrow> bn_contract (f >>= g) s Q"
proof -
  assume F: "bn_contract f s P"
    and G: "\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q"
  have FR: "runs_to f s (\<lambda>r t. \<exists>v. r = Result v \<and> P v t)"
    using F by (simp add: bn_contract_def)
  have RUN: "runs_to (f >>= g) s (\<lambda>r t. \<exists>v. r = Result v \<and> Q v t)"
    apply (rule runs_to_bind)
    apply (rule runs_to_weaken[OF FR])
    using G by (auto simp: bn_contract_def)
  obtain v t where FV: "reaches f s (Result v) t"
    using F by (auto simp: bn_contract_def)
  have PV: "P v t" using runs_toD2[OF FR FV] by (simp add: Result_eq_Result)
  obtain w u where GW: "reaches (g v) t (Result w) u"
    using G[OF PV] by (auto simp: bn_contract_def)
  have SU: "succeeds (f >>= g) s" using RUN by (auto simp: runs_to_def_old)
  have REACH: "reaches (f >>= g) s (Result w) u"
    apply (simp only: reaches_bind)
    apply (rule conjI[OF SU])
    apply (rule exI[where x="Result v"])
    apply (rule exI[where x=t])
    using FV GW by simp
  show ?thesis using RUN REACH by (auto simp: bn_contract_def)
qed


lemma vero_aux_heap_block_guard:
  assumes B: "block_ok (ptr_val (p :: StrictC'_BinomialHeap_C ptr)) 40"
  shows "c_guard p"
proof -
  have N: "ptr_val p \<noteq> 0" and UB: "unat (ptr_val p) + 40 \<le> 2^64"
    and AL: "unat (ptr_val p) mod 16 = 0" using B by (auto simp: block_ok_def)
  have D: "16 dvd unat (ptr_val p)" using AL by (simp only: mod_eq_0_iff_dvd)
  have A: "8 dvd unat (ptr_val p)" by (rule dvd_trans[OF _ D]) simp
  have NG: "0 \<notin> {ptr_val p..+40}"
    using intvl_no_overflow_nat'[where a="ptr_val p" and b=40 and x=0] UB N by (simp add: unat_eq_zero)
  show ?thesis using A NG by (simp add: c_guard_def ptr_aligned_def c_null_guard_def)
qed

lemma vero_aux_heap_zero:
  assumes Z: "\<forall>i<40. hp (ptr_val (p :: StrictC'_BinomialHeap_C ptr) + of_nat i) = 0"
  shows "h_val hp p = ZERO(StrictC'_BinomialHeap_C)"
proof -
  have H0: "\<And>n a. (\<forall>i<n. hp (a + of_nat i) = 0) \<Longrightarrow> heap_list hp n a = replicate n 0"
    by (intro nth_equalityI) (auto simp: heap_list_nth)
  have H: "heap_list hp 40 (ptr_val p) = replicate 40 0" by (rule H0[OF Z])
  show ?thesis by (simp add: h_val_def zero_def H)
qed






lemma vero_aux_new_allocator_wf:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow>
   allocator_wf (A\<lparr>live_blocks := (live_blocks A)(p := Some n)\<rparr>)"
  by (auto simp: allocator_wf_def fresh_block_def Int_commute)

lemma vero_aux_new_calloc:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
  shows "bn_contract (calloc' 1 40) s (\<lambda>p t. \<exists>hp A.
    calloc_rel 1 40 (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) (ptr_val p) hp A \<and>
    t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>)"
proof -
  have R: "calloc_rel 1 40 (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s)
      (ptr_val (NULL :: unit ptr)) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s)"
    using W by (simp add: calloc_rel_def malloc_rel_def ptr_val_def)
  have EX: "\<exists>p hp A. calloc_rel 1 40 (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) (ptr_val (p :: unit ptr)) hp A"
    using R by blast
  show ?thesis using W EX
    by (auto simp: bn_contract_def calloc'_def binomial_heap_input.calloc.count_'_def
      binomial_heap_input.calloc.ret'_'_def runs_to_bind_iff runs_to_guard_iff
      runs_to_assume_result_and_state_iff reaches_bind reaches_guard reaches_assume_result_and_state
      succeeds_runs_to_iff)
qed


lemma vero_aux_new_init:
  fixes p :: "StrictC'_BinomialHeap_C ptr"
  assumes G: "c_guard p" and Z: "h_val (hrs_mem (t_hrs_' s)) p = ZERO(StrictC'_BinomialHeap_C)"
  shows "bn_contract (do {
      guard (\<lambda>_. c_guard p);
      modify (t_hrs_'_update (\<lambda>a. hrs_mem_update
        (heap_update p (heap_type_C_update (\<lambda>_. BINOMIAL_HEAP_TYPE_MIN) (h_val (hrs_mem a) p))) a));
      modify (t_hrs_'_update (\<lambda>a. hrs_mem_update
        (heap_update p (compare_func_C_update (\<lambda>_. binomial_heap_input.int_compare) (h_val (hrs_mem a) p))) a));
      return p
    }) s (\<lambda>r t. r=p \<and> t = t_hrs_'_update (hrs_mem_update (heap_update p
      (ZERO(StrictC'_BinomialHeap_C)\<lparr>heap_type_C := BINOMIAL_HEAP_TYPE_MIN,
        compare_func_C := binomial_heap_input.int_compare\<rparr>))) s)"
  using G Z
  by (auto simp: bn_contract_def runs_to_bind_iff runs_to_guard_iff runs_to_modify_iff
    reaches_bind reaches_guard reaches_modify reaches_return[abs_def] succeeds_runs_to_iff
    hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update heap_update_collapse)

lemma vero_aux_new_not_live:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow> live_blocks A p = None"



proof -
  assume A: "allocator_wf A" and F: "fresh_block A p n"
  show ?thesis
  proof (cases "live_blocks A p")
    case None thus ?thesis .
  next
    case (Some m)
    have N: "0 < n" using F by (simp add: fresh_block_def block_ok_def)
    have M: "0 < m" using A Some by (auto simp: allocator_wf_def block_ok_def)
    have D: "block_bytes p n \<inter> block_bytes p m = {}"
      using F Some unfolding fresh_block_def by blast
    have "p \<in> block_bytes p n" "p \<in> block_bytes p m"
      using N M by (simp_all add: block_bytes_def)
    thus ?thesis using D by blast
  qed
qed



lemma vero_aux_zero_word32: "ZERO(32 word) = 0"
  by (simp add: zero_def from_bytes_def typ_info_word word_tag_def update_ti_t_def word_rcat_def)

lemma vero_aux_zero_pointer: "ZERO('a::mem_type ptr) = NULL"
  by (simp add: zero_def from_bytes_def typ_info_ptr size_of_ptr update_ti_t_def word_rcat_def)

lemma vero_aux_new_success:
  fixes p :: "StrictC'_BinomialHeap_C ptr"
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and P: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and R: "calloc_rel 1 40 (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) (ptr_val p) hp A"
    and NN: "p \<noteq> NULL"
    and U: "u = t_hrs_'_update (hrs_mem_update (heap_update p
      (ZERO(StrictC'_BinomialHeap_C)\<lparr>heap_type_C := BINOMIAL_HEAP_TYPE_MIN,
       compare_func_C := binomial_heap_input.int_compare\<rparr>)))
      ((t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>)"
  shows "(\<forall>a \<in> P. hrs_mem (t_hrs_' u) a = hrs_mem (t_hrs_' s) a) \<and>
    (\<forall>q n. live_blocks (phantom_machine_state_' s) q = Some n \<longrightarrow>
      live_blocks (phantom_machine_state_' u) q = Some n \<and>
      (\<forall>a \<in> block_bytes q n. hrs_mem (t_hrs_' u) a = hrs_mem (t_hrs_' s) a)) \<and>
    bn_rep u p P [] {#} \<and> roots_C (bn_heap u p) = NULL \<and>
    phantom_machine_state_' u = (phantom_machine_state_' s)\<lparr>live_blocks :=
      (live_blocks (phantom_machine_state_' s))(ptr_val p := Some 40)\<rparr>"
proof -
  have PN: "ptr_val p \<noteq> 0" using NN by (cases p) (simp add: ptr_val_def)
  have F: "fresh_block (phantom_machine_state_' s) (ptr_val p) 40"
    and BF: "bytes_frame (block_bytes (ptr_val p) 40) (hrs_mem (t_hrs_' s)) hp"
    and A: "A = (phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val p := Some 40)\<rparr>"
    using R PN by (auto simp: calloc_rel_def malloc_rel_def)
  have G: "c_guard p" using F by (intro vero_aux_heap_block_guard) (simp add: fresh_block_def)
  have AW: "allocator_wf A" using vero_aux_new_allocator_wf[OF W F] by (simp add: A)
  have NL: "live_blocks (phantom_machine_state_' s) (ptr_val p) = None"
    by (rule vero_aux_new_not_live[OF W F])
  let ?v = "ZERO(StrictC'_BinomialHeap_C)\<lparr>heap_type_C := BINOMIAL_HEAP_TYPE_MIN,
       compare_func_C := binomial_heap_input.int_compare\<rparr>"
  have BF2: "bytes_frame (block_bytes (ptr_val p) 40) hp (heap_update p ?v hp)"
    using vero_aux_update_frame[OF G, where v="?v" and hp=hp] by simp
  have UF: "bytes_frame (block_bytes (ptr_val p) 40) (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' u))"
    using BF BF2 by (auto simp: U hrs_mem_update_def hrs_mem_def case_prod_unfold bytes_frame_def)
  have UA: "phantom_machine_state_' u = A" by (simp add: U)
  have HV: "bn_heap u p = ?v"
    by (simp add: U bn_heap_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update)
  have REP: "bn_rep u p P [] {#}"
    using AW P G PN by (simp add: bn_rep_def UA A HV bn_owned_def bn_forest_values_def StrictC'_BinomialHeap_C_zero_simps vero_aux_zero_word32 vero_aux_zero_pointer)
  show ?thesis using F UF UA A NL REP HV P
    by (auto simp: fresh_block_def bytes_frame_def StrictC'_BinomialHeap_C_zero_simps vero_aux_zero_word32 vero_aux_zero_pointer; blast)
qed


lemma vero_aux_condition_false:
  "\<not> C s \<Longrightarrow> bn_contract f s Q \<Longrightarrow> bn_contract (condition C g f) s Q"
  by (auto simp: bn_contract_def runs_to_condition_iff reaches_condition_iff)

lemma c0009_prove:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_contract calg_binomial_new' s (\<lambda>h t.
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        live_blocks (phantom_machine_state_' t) p = Some n \<and>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)) \<and>
      (if h = NULL then phantom_machine_state_' t = phantom_machine_state_' s else
        bn_rep t h P [] {#} \<and> roots_C (bn_heap t h) = NULL \<and>
        phantom_machine_state_' t = (phantom_machine_state_' s)\<lparr>live_blocks :=
          (live_blocks (phantom_machine_state_' s))(ptr_val h := Some (size_of TYPE(StrictC'_BinomialHeap_C)))\<rparr>))"

proof -
  assume W: "allocator_wf (phantom_machine_state_' s)"
    and P: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
  have MAL: "bn_contract (calloc' 1 (word_of_nat (size_of TYPE(StrictC'_BinomialHeap_C)))) s
    (\<lambda>p t. \<exists>hp A. calloc_rel 1 40 (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) (ptr_val p) hp A \<and>
      t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>)"
    using vero_aux_new_calloc[OF W] by simp
  show ?thesis
    unfolding calg_binomial_new'_def binomial_heap_new'_def
    apply (rule vero_aux_contract_bind[OF MAL])
    subgoal premises PRE for q t
    proof -
      obtain hp A where R: "calloc_rel 1 40 (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) (ptr_val q) hp A"
        and T: "t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>"
        using PRE by blast
      let ?p = "ptr_coerce q :: StrictC'_BinomialHeap_C ptr"
      show ?thesis
      proof (cases "?p = NULL")
        case True
        have PN: "ptr_val q = 0" using True by (cases q) (simp add: ptr_coerce_def ptr_val_def)
        have HP: "hp = hrs_mem (t_hrs_' s)" and AA: "A = phantom_machine_state_' s"
          using R PN by (auto simp: calloc_rel_def malloc_rel_def fresh_block_def block_ok_def)
        have TS: "t=s" by (simp add: T HP AA hrs_mem_update_def hrs_mem_def case_prod_unfold)
        show ?thesis using True TS
          by (auto simp: bn_contract_def runs_to_bind_iff runs_to_condition_iff
            reaches_bind reaches_condition_iff reaches_return[abs_def] succeeds_runs_to_iff)
      next
        case False
        have RP: "calloc_rel 1 40 (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) (ptr_val ?p) hp A"
          using R by simp
        have PN: "ptr_val ?p \<noteq> 0" using False by (cases q) (simp add: ptr_coerce_def ptr_val_def)
        have G: "c_guard ?p" using RP PN
          by (intro vero_aux_heap_block_guard) (auto simp: calloc_rel_def malloc_rel_def fresh_block_def)
        have Z: "h_val (hrs_mem (t_hrs_' t)) ?p = ZERO(StrictC'_BinomialHeap_C)"
          apply (rule vero_aux_heap_zero)
          using RP PN by (simp add: T calloc_rel_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
        let ?v = "ZERO(StrictC'_BinomialHeap_C)\<lparr>heap_type_C := BINOMIAL_HEAP_TYPE_MIN,
          compare_func_C := binomial_heap_input.int_compare\<rparr>"
        have POST: "(\<forall>a \<in> P. hrs_mem (t_hrs_' (t_hrs_'_update (hrs_mem_update (heap_update ?p ?v)) t)) a = hrs_mem (t_hrs_' s) a) \<and>
          (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
            live_blocks (phantom_machine_state_' (t_hrs_'_update (hrs_mem_update (heap_update ?p ?v)) t)) p = Some n \<and>
            (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' (t_hrs_'_update (hrs_mem_update (heap_update ?p ?v)) t)) a = hrs_mem (t_hrs_' s) a)) \<and>
          bn_rep (t_hrs_'_update (hrs_mem_update (heap_update ?p ?v)) t) ?p P [] {#} \<and>
          roots_C (bn_heap (t_hrs_'_update (hrs_mem_update (heap_update ?p ?v)) t) ?p) = NULL \<and>
          phantom_machine_state_' (t_hrs_'_update (hrs_mem_update (heap_update ?p ?v)) t) =
            (phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val ?p := Some 40)\<rparr>"
          by (rule vero_aux_new_success[OF W P RP False]) (simp only: T)
        show ?thesis
          apply (simp only: return_bind)
          apply (rule vero_aux_condition_false)
           apply (rule False)
          apply (rule vero_aux_contract_weaken[OF vero_aux_new_init[OF G Z]])
          apply clarify
          apply (simp only: False if_False StrictC'_BinomialHeap_C_size)
          using POST by assumption
      qed
    qed
    done
qed



end



lemma c0010_prove:
  "bn_valid s P T \<Longrightarrow> refcount_C (bn_tree s (bn_root T)) = 1"

by (cases T) auto





lemma c0011_prove:
  "bn_rep s h P F M \<Longrightarrow>
    length F \<le> 32 \<and> unat (roots_length_C (bn_heap s h)) = length F"

by (auto simp: bn_rep_def)



lemma vero_aux_concat_subseq:
  "(\<And>x. x \<in> set xs \<Longrightarrow> subseq (f x) (g x)) \<Longrightarrow>
    subseq (concat (map f xs)) (concat (map g xs))"
  by (induction xs) (auto intro: list_emb_append_mono)

lemma vero_aux_nodes_blocks_subseq:
  "subseq (map ptr_val (bn_ds_node_list T)) (bn_blocks s T)"
proof (induction T)
  case (BN p cs)
  have H: "subseq (concat (map (\<lambda>T. map ptr_val (bn_ds_node_list T)) cs))
      (concat (map (bn_blocks s) cs))"
    by (rule vero_aux_concat_subseq) (rule BN.IH)
  show ?case using H by (cases cs) (auto simp: map_concat o_def intro: list_emb_Cons)
qed

lemma vero_aux_nodes_distinct:
  assumes D: "distinct (bn_blocks s T)"
  shows "distinct (bn_ds_node_list T)"
proof -
  have "distinct (map ptr_val (bn_ds_node_list T))"
    using vero_aux_nodes_blocks_subseq[where T=T and s=s] D
    by (metis in_set_subseqs subseqs_distinctD)
  thus ?thesis by (simp add: distinct_map)
qed

lemma vero_aux_nodes_root: "bn_root T \<in> set (bn_ds_node_list T)"
  by (cases T) simp

lemma vero_aux_layout_physical:
  assumes L: "bn_ds_tree_layout s P (BN p cs)"
  shows "bn_ds_physical_edges s p = map bn_root cs"
proof -
  have LEN: "unat (order_C (bn_tree s p)) = length cs"
    and AR: "\<forall>i<length cs. h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i) = bn_root (cs ! i)"
    using L by auto
  show ?thesis
    unfolding bn_ds_physical_edges_def bn_ds_slots_def LEN
    apply (rule nth_equalityI)
     apply simp
    using AR by (simp add: o_def)
qed

lemma vero_aux_layout_valid_refs:
  assumes L: "bn_ds_tree_layout s P T"
    and REF: "\<forall>p \<in> set (bn_ds_node_list T). refcount_C (bn_tree s p) = 1"
  shows "bn_valid s P T"
  using L REF
  by (induction T) (auto simp: list_all_iff)






lemma vero_aux_graph_physical:
  assumes GR: "bn_ds_graph s P N edges slots held pending" and PN: "p \<in> N"
  shows "edges p = bn_ds_physical_edges s p"
proof -
  have LEN: "unat (order_C (bn_tree s p)) = length (edges p)"
    and AR: "\<forall>i<length (edges p). h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i) = edges p ! i"
    using GR PN by (auto simp: bn_ds_graph_def)
  show ?thesis
    unfolding bn_ds_physical_edges_def bn_ds_slots_def LEN
    apply (rule nth_equalityI)
     apply simp
    using AR by (simp add: o_def)
qed

lemma vero_aux_layout_graph_nodes:
  assumes L: "bn_ds_tree_layout s P T"
    and ROOT: "bn_root T \<in> N"
    and GR: "bn_ds_graph s P N edges slots held pending"
  shows "set (bn_ds_node_list T) \<subseteq> N"
  using L ROOT
proof (induction T)
  case (BN p cs)
  have PN: "p \<in> N" using BN.prems by simp
  have ED: "edges p = map bn_root cs"
    using vero_aux_graph_physical[OF GR PN] vero_aux_layout_physical[OF BN.prems(1)] by simp
  have EN: "set (edges p) \<subseteq> N" using GR PN unfolding bn_ds_graph_def by blast
  have CN: "\<forall>T \<in> set cs. bn_root T \<in> N"
    using EN by (auto simp: ED)
  have CHILD: "\<forall>T \<in> set cs. set (bn_ds_node_list T) \<subseteq> N"
    using BN.IH BN.prems CN by (auto simp: list_all_iff)
  show ?case using CHILD PN by auto
qed

lemma vero_aux_layout_edges_closed:
  assumes L: "bn_ds_tree_layout s P T"
  shows "\<forall>p \<in> set (bn_ds_node_list T). set (bn_ds_physical_edges s p) \<subseteq> set (bn_ds_node_list T)"
  using L
proof (induction T)
  case (BN p cs)
  have ED: "bn_ds_physical_edges s p = map bn_root cs" by (rule vero_aux_layout_physical[OF BN.prems])
  have CHILD: "\<forall>T \<in> set cs. \<forall>q \<in> set (bn_ds_node_list T).
    set (bn_ds_physical_edges s q) \<subseteq> set (bn_ds_node_list T)"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  show ?case using CHILD vero_aux_nodes_root
    by (auto simp: ED; blast)
qed


lemma vero_aux_count_concat:
  "count (mset (concat (map f xs))) p = sum_list (map (\<lambda>x. count (mset (f x)) p) xs)"
  by (induction xs) simp_all

lemma vero_aux_sum_concat:
  "sum_list (map f (concat (map g xs))) = sum_list (map (\<lambda>x. sum_list (map f (g x))) xs)"
  by (induction xs) simp_all

lemma vero_aux_count_map:
  "count (mset (map f xs)) p = sum_list (map (\<lambda>x. if f x = p then 1 else 0) xs)"
  by (induction xs) auto

lemma vero_aux_layout_edge_count:
  assumes L: "bn_ds_tree_layout s P T"
  shows "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) x) (bn_ds_node_list T)) +
    (if bn_root T = x then 1 else 0) = count (mset (bn_ds_node_list T)) x"
  using L
proof (induction T)
  case (BN p cs)
  let ?f = "\<lambda>q. count (mset (bn_ds_physical_edges s q)) x"
  have ED: "bn_ds_physical_edges s p = map bn_root cs" by (rule vero_aux_layout_physical[OF BN.prems])
  have IH: "\<forall>T \<in> set cs. sum_list (map ?f (bn_ds_node_list T)) +
      (if bn_root T = x then 1 else 0) = count (mset (bn_ds_node_list T)) x"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  have MAP: "map (\<lambda>T. sum_list (map ?f (bn_ds_node_list T)) + (if bn_root T = x then 1 else 0)) cs =
      map (\<lambda>T. count (mset (bn_ds_node_list T)) x) cs"
    using IH by (auto intro!: map_cong)
  have SUM: "sum_list (map (\<lambda>T. sum_list (map ?f (bn_ds_node_list T))) cs) +
      sum_list (map (\<lambda>T. if bn_root T = x then 1 else 0) cs) =
      sum_list (map (\<lambda>T. count (mset (bn_ds_node_list T)) x) cs)"
    using arg_cong[OF MAP, where f=sum_list] by (simp only: sum_list_addf)
  show ?case using SUM
    by (simp del: mset_map add: ED vero_aux_count_concat vero_aux_sum_concat vero_aux_count_map algebra_simps)
qed


lemma vero_aux_forest_distinct_nodes:
  assumes D: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
  shows "distinct (concat (map (case_option [] bn_ds_node_list) F))"
proof -
  have EACH: "\<And>U. U \<in> set F \<Longrightarrow>
    subseq (map ptr_val (case_option [] bn_ds_node_list U)) (case_option [] (bn_blocks s) U)"
    by (case_tac U) (simp_all add: vero_aux_nodes_blocks_subseq)
  have SS: "subseq (map ptr_val (concat (map (case_option [] bn_ds_node_list) F)))
      (concat (map (case_option [] (bn_blocks s)) F))"
    using vero_aux_concat_subseq[OF EACH] by (simp add: map_concat o_def)
  have "distinct (map ptr_val (concat (map (case_option [] bn_ds_node_list) F)))"
    using SS D by (metis in_set_subseqs subseqs_distinctD)
  thus ?thesis by (simp add: distinct_map)
qed

lemma vero_aux_root_array_values:
  assumes V: "bn_review_root_array_view s a F"
  shows "map (h_val (hrs_mem (t_hrs_' s))) (bn_ds_slots a (length F)) = map (case_option NULL bn_root) F"
  using V unfolding bn_review_root_array_view_def bn_ds_slots_def
  by (intro nth_equalityI) (auto simp: o_def)

lemma vero_aux_root_array_handles:
  assumes V: "bn_review_root_array_view s a F"
    and NN: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<noteq> NULL"
  shows "bn_ds_slot_handles s (bn_ds_slots a (length F)) =
    mset (concat (map (case_option [] (\<lambda>T. [bn_root T])) F))"
proof -
  have E: "filter (\<lambda>p. p \<noteq> NULL) (map (case_option NULL bn_root) F) =
      concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
    using NN by (induction F) (auto split: option.splits)
  show ?thesis by (simp only: bn_ds_slot_handles_def vero_aux_root_array_values[OF V] E)
qed


lemma vero_aux_forest_edge_count:
  assumes L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
  shows "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) x)
      (concat (map (case_option [] bn_ds_node_list) F))) +
    count (mset (concat (map (case_option [] (\<lambda>T. [bn_root T])) F))) x =
    count (mset (concat (map (case_option [] bn_ds_node_list) F))) x"
  using L
proof (induction F)
  case Nil
  then show ?case by simp
next
  case (Cons U F)
  have IH: "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) x)
      (concat (map (case_option [] bn_ds_node_list) F))) +
    count (mset (concat (map (case_option [] (\<lambda>T. [bn_root T])) F))) x =
    count (mset (concat (map (case_option [] bn_ds_node_list) F))) x"
    using Cons.IH Cons.prems by auto
  show ?case
  proof (cases U)
    case None
    then show ?thesis using IH by simp
  next
    case (Some T)
    have LT: "bn_ds_tree_layout s P T" using Cons.prems Some by simp
    have E: "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) x) (bn_ds_node_list T)) +
      (if bn_root T = x then 1 else 0) = count (mset (bn_ds_node_list T)) x"
      by (rule vero_aux_layout_edge_count[OF LT])
    show ?thesis
    proof (cases "bn_root T = x")
      case True
      show ?thesis using IH E True Some by (simp; arith)
    next
      case False
      show ?thesis using IH E False Some by (simp; arith)
    qed
  qed
qed


lemma vero_aux_forest_node_member:
  "p \<in> bn_ds_forest_nodes F \<longleftrightarrow> (\<exists>T. Some T \<in> set F \<and> p \<in> set (bn_ds_node_list T))"
  by (auto simp: bn_ds_forest_nodes_def split: option.splits)

lemma vero_aux_rtrancl_closed:
  assumes RP: "(r,p) \<in> E\<^sup>*" and R: "r \<in> X"
    and STEP: "\<And>a b. a \<in> X \<Longrightarrow> (a,b) \<in> E \<Longrightarrow> b \<in> X"
  shows "p \<in> X"
  using RP R by (induction rule: rtrancl_induct) (auto intro: STEP)

lemma vero_aux_forest_graph_nodes:
  assumes FV: "bn_ds_forest_view s h P F"
    and GR: "bn_ds_graph s P N edges (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {}"
  shows "N = bn_ds_forest_nodes F"
proof -
  let ?slots = "bn_ds_slots (roots_C (bn_heap s h)) (length F)"
  let ?roots = "concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
  let ?nodes = "bn_ds_forest_nodes F"
  have L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    using FV by (auto simp: bn_ds_forest_view_def in_set_conv_nth)
  have NN: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<noteq> NULL"
  proof (intro allI impI)
    fix T assume "Some T \<in> set F"
    then have "bn_ds_tree_layout s P T" using L by blast
    then show "bn_root T \<noteq> NULL" by (cases T) (auto dest: c_guard_NULL)
  qed
  have RV: "bn_review_root_array_view s (roots_C (bn_heap s h)) F"
    using FV by (simp add: bn_ds_forest_view_def bn_review_header_view_def)
  have RH: "bn_ds_slot_handles s ?slots = mset ?roots" by (rule vero_aux_root_array_handles[OF RV NN])
  have RN: "set ?roots \<subseteq> N"
    using GR by (simp add: bn_ds_graph_def RH)
  have RT: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<in> N"
    using RN by (auto split: option.splits)
  have SUB: "?nodes \<subseteq> N"
    using L RT vero_aux_layout_graph_nodes[OF _ _ GR]
    by (auto simp: vero_aux_forest_node_member; blast)
  have ROOTS: "set ?roots \<subseteq> ?nodes"
    using vero_aux_nodes_root by (auto simp: vero_aux_forest_node_member split: option.splits; blast)
  have CLOSED: "\<forall>p \<in> ?nodes. set (bn_ds_physical_edges s p) \<subseteq> ?nodes"
  proof (intro ballI)
    fix p assume PN: "p \<in> ?nodes"
    obtain T where TF: "Some T \<in> set F" and PT: "p \<in> set (bn_ds_node_list T)"
      using PN by (auto simp: vero_aux_forest_node_member)
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    show "set (bn_ds_physical_edges s p) \<subseteq> ?nodes"
      using vero_aux_layout_edges_closed[OF LT] PT TF by (auto simp: vero_aux_forest_node_member; blast)
  qed
  have BACK: "N \<subseteq> ?nodes"
  proof
    fix p assume PN: "p \<in> N"
    have NR: "N = {p. \<exists>r \<in> set ?roots.
      (r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*}"
      using GR by (simp add: bn_ds_graph_def RH)
    have IN: "p \<in> {p. \<exists>r \<in> set ?roots.
      (r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*}"
      using PN NR by blast
    obtain r where RR: "r \<in> set ?roots"
      and RP: "(r,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (edges q)}\<^sup>*"
      using IN by blast
    show "p \<in> ?nodes"
      apply (rule vero_aux_rtrancl_closed[OF RP])
       using ROOTS RR apply blast
      using CLOSED vero_aux_graph_physical[OF GR] by (auto; blast)
  qed
  show ?thesis using SUB BACK by blast
qed

lemma c0012_prove:
  "bn_ds_finish_base s h P F N edges [] {#} \<Longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<Longrightarrow>
  M = mset (bn_forest_values s F) \<Longrightarrow> bn_rep s h P F M"

proof -
  assume FB: "bn_ds_finish_base s h P F N edges [] {#}"
    and NUM: "unat (num_values_C (bn_heap s h)) = size M"
    and MASS: "M = mset (bn_forest_values s F)"
  let ?slots = "bn_ds_slots (roots_C (bn_heap s h)) (length F)"
  let ?nodes = "concat (map (case_option [] bn_ds_node_list) F)"
  let ?roots = "concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
  have FV: "bn_ds_forest_view s h P F" and GR: "bn_ds_graph s P N edges ?slots {#} {}"
    and DB: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
    using FB by (auto simp: bn_ds_finish_base_def bn_owned_def)
  have NEQ: "N = set ?nodes" using vero_aux_forest_graph_nodes[OF FV GR] by (simp add: bn_ds_forest_nodes_def)
  have DN: "distinct ?nodes" by (rule vero_aux_forest_distinct_nodes[OF DB])
  have L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    using FV by (auto simp: bn_ds_forest_view_def in_set_conv_nth)
  have NN: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<noteq> NULL"
  proof (intro allI impI)
    fix T assume "Some T \<in> set F"
    then have "bn_ds_tree_layout s P T" using L by blast
    then show "bn_root T \<noteq> NULL" by (cases T) (auto dest: c_guard_NULL)
  qed
  have RV: "bn_review_root_array_view s (roots_C (bn_heap s h)) F"
    using FV by (simp add: bn_ds_forest_view_def bn_review_header_view_def)
  have RH: "bn_ds_slot_handles s ?slots = mset ?roots" by (rule vero_aux_root_array_handles[OF RV NN])
  have REFS: "\<forall>p \<in> N. refcount_C (bn_tree s p) = 1"
  proof (intro ballI)
    fix p assume PN: "p \<in> N"
    have MAP: "map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) p) ?nodes =
      map (\<lambda>q. count (mset (edges q)) p) ?nodes"
      using vero_aux_graph_physical[OF GR] NEQ by (auto intro!: map_cong)
    have SUM: "sum_list (map (\<lambda>q. count (mset (edges q)) p) ?nodes) =
      (\<Sum>q \<in> N. count (mset (edges q)) p)"
      using sum_list_distinct_conv_sum_set[OF DN, where f="\<lambda>q. count (mset (edges q)) p"] by (simp only: NEQ)
    have ONE: "count (mset ?nodes) p = 1" using DN PN NEQ by (simp add: distinct_count_atmost_1)
    have COUNT: "count (bn_ds_slot_handles s ?slots) p + (\<Sum>q \<in> N. count (mset (edges q)) p) = 1"
      using vero_aux_forest_edge_count[OF L, where x=p]
      by (simp only: MAP SUM ONE RH add.commute)
    have RC: "unat (refcount_C (bn_tree s p)) = count (bn_ds_slot_handles s ?slots) p +
      (\<Sum>q \<in> N. count (mset (edges q)) p)"
      using GR PN by (simp add: bn_ds_graph_def)
    show "refcount_C (bn_tree s p) = 1" using RC COUNT by (simp add: unat_eq_1)
  qed
  have VALID: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid s P T"
  proof (intro allI impI)
    fix T assume TF: "Some T \<in> set F"
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    show "bn_valid s P T"
      apply (rule vero_aux_layout_valid_refs[OF LT])
      using TF REFS NEQ by (auto simp: bn_ds_forest_nodes_def[symmetric] vero_aux_forest_node_member)
  qed
  have EMPTY: "roots_C (bn_heap s h) = NULL \<Longrightarrow> F=[]"
    using RV by (cases F) (auto simp: bn_review_root_array_view_def dest: c_guard_NULL)
  have W: "allocator_wf (phantom_machine_state_' s)"
    and PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    using GR by (auto simp: bn_ds_graph_def)
  show ?thesis using FB FV RV W PS EMPTY VALID NUM MASS
    by (auto simp: bn_rep_def bn_ds_finish_base_def bn_ds_forest_view_def bn_review_header_view_def
      bn_review_root_array_view_def bn_ds_owned_array_def split: option.splits dest: nth_mem)
qed



context binomial_heap_input_global_addresses begin



lemma c0013_prove:
  "c_guard h \<Longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<Longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<Longrightarrow>
    bn_payload P x \<Longrightarrow> bn_payload P y \<Longrightarrow>
    bn_contract (binomial_heap_cmp' h x y) s (\<lambda>r t.
      t = s \<and> ((r <s 0) \<longleftrightarrow> bn_key s x < bn_key s y) \<and>
      ((r = 0) \<longleftrightarrow> bn_key s x = bn_key s y))"

by (auto simp: bn_contract_def binomial_heap_cmp'_def bn_heap_def bn_key_def bn_payload_def runs_to_bind_iff runs_to_condition_iff runs_to_gets_iff \<P>_fun_ptr_simps int_compare'_def reaches_bind reaches_condition_iff reaches_gets reaches_guard reaches_return succeeds_runs_to_iff word_sless_alt; (rule exI, rule exI, simp add: reaches_condition_iff reaches_return))



end



lemma c0014_prove:
  "memcpy_ok A dst src 0 \<Longrightarrow> dst \<noteq> 0 \<and> src \<noteq> 0"

by (auto simp: memcpy_ok_def)





lemma c0015_prove:
  "free_rel p hp A hp' B \<Longrightarrow> q \<noteq> p \<Longrightarrow>
    live_blocks B q = live_blocks A q"

by (auto simp: free_rel_def)





lemma c0016_prove:
  "bytes_frame W hp hp' \<Longrightarrow> W \<subseteq> V \<Longrightarrow> bytes_frame V hp hp'"

by (auto simp: bytes_frame_def)



context binomial_heap_input_global_addresses begin

lemma vero_aux_root_value:
  "value_C (bn_tree s (bn_root T)) \<in> set (bn_values s T)"
  by (cases T) simp

lemma vero_aux_root_min:
  "bn_valid s P T \<Longrightarrow> q \<in> set (bn_values s T) \<Longrightarrow>
   bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q"
  by (cases T) auto

lemma vero_aux_forest_member:
  "q \<in> set (bn_forest_values s F) \<longleftrightarrow>
   (\<exists>i T. i < length F \<and> F ! i = Some T \<and> q \<in> set (bn_values s T))"
  proof
  assume Q: "q \<in> set (bn_forest_values s F)"
  obtain x where X: "x \<in> set F" and V: "q \<in> set (case_option [] (bn_values s) x)"
    using Q by (auto simp: bn_forest_values_def)
  obtain T where T: "x = Some T" and QV: "q \<in> set (bn_values s T)"
    using V by (cases x) auto
  obtain i where I: "i < length F" and E: "F ! i = x"
    using X by (auto simp: in_set_conv_nth)
  show "\<exists>i T. i < length F \<and> F ! i = Some T \<and> q \<in> set (bn_values s T)"
    using I E T QV by blast
next
  assume "\<exists>i T. i < length F \<and> F ! i = Some T \<and> q \<in> set (bn_values s T)"
  then obtain i T where I: "i < length F" and E: "F ! i = Some T" and V: "q \<in> set (bn_values s T)" by blast
  have "Some T \<in> set F" using nth_mem[OF I] E by simp
  thus "q \<in> set (bn_forest_values s F)" using V
    by (auto simp: bn_forest_values_def)
qed

lemma vero_aux_scan_minimum:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_review_scan_prefix s F (length F) (Some j) \<Longrightarrow>
  \<exists>T. F ! j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
   (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"
proof -
  assume R: "bn_rep s h P F M" and NE: "M \<noteq> {#}"
    and SC: "bn_review_scan_prefix s F (length F) (Some j)"
  obtain T where J: "j < length F" and T: "F ! j = Some T"
    and MIN: "\<forall>l < length F. \<forall>U. F ! l = Some U \<longrightarrow>
      bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s (value_C (bn_tree s (bn_root U)))"
    using SC by (auto simp: bn_review_scan_prefix_def)
  have M: "M = mset (bn_forest_values s F)" using R by (simp add: bn_rep_def)
  have ROOT: "value_C (bn_tree s (bn_root T)) \<in># M"
    using J T vero_aux_root_value[of s T] by (auto simp: M vero_aux_forest_member)
  have ALL: "\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q"
  proof (intro ballI)
    fix q assume Q: "q \<in># M"
    obtain l U where L: "l < length F" and U: "F ! l = Some U" and V: "q \<in> set (bn_values s U)"
      using Q by (auto simp: M vero_aux_forest_member)
    have VALID: "bn_valid s P U" using R L U by (auto simp: bn_rep_def)
    have LE: "bn_key s (value_C (bn_tree s (bn_root U))) \<le> bn_key s q"
      by (rule vero_aux_root_min[OF VALID V])
    show "bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q"
      using MIN L U LE by (meson order_trans)
  qed
  show ?thesis using T ROOT ALL by blast
qed

lemma vero_aux_scan_values_nonempty:
  "bn_values s T \<noteq> []"
  by (cases T) simp

lemma vero_aux_scan_forest_empty:
  "bn_forest_values s F = [] \<longleftrightarrow> (\<forall>x \<in> set F. x = None)"
  by (induction F) (auto simp: bn_forest_values_def vero_aux_scan_values_nonempty split: option.splits)

lemma vero_aux_contract_while:
  fixes m :: "'a \<Rightarrow> nat"
  assumes STEP: "\<And>a. I a \<Longrightarrow> C a s \<Longrightarrow>
      bn_contract (B a) s (\<lambda>b t. t=s \<and> I b \<and> m b < m a)"
    and EXIT: "\<And>a. I a \<Longrightarrow> \<not> C a s \<Longrightarrow> Q a s"
    and INIT: "I a"
  shows "bn_contract (whileLoop C B a) s Q"
  using INIT
proof (induction a rule: measure_induct_rule[of m])
  case (less a)
  show ?case
  proof (cases "C a s")
    case False
    show ?thesis
      apply (subst whileLoop_unroll)
      using EXIT[OF less.prems False] False
      by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff reaches_return[abs_def])
  next
    case True
    have ST: "bn_contract (B a) s (\<lambda>b t. t=s \<and> I b \<and> m b < m a)"
      by (rule STEP[OF less.prems True])
    have BC: "bn_contract (B a >>= whileLoop C B) s Q"
    proof (rule vero_aux_contract_bind[OF ST])
      fix b t assume BT: "t=s \<and> I b \<and> m b < m a"
      have D: "m b < m a" and IB: "I b" using BT by auto
      have LOOP: "bn_contract (whileLoop C B b) s Q" by (rule less.IH[OF D IB])
      show "bn_contract (whileLoop C B b) t Q" using LOOP BT by simp
    qed
    show ?thesis
      apply (subst whileLoop_unroll)
      using BC True by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff)
  qed
qed

lemma c0017_prove:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_contract (bn_ds_scan h) s (\<lambda>(i,j) t.
   t = s \<and> unat i = length F \<and> unat j < length F \<and>
   (\<exists>T. F ! unat j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
    (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)))"

proof -
  assume R: "bn_rep s h P F M" and NE: "M \<noteq> {#}"
  let ?I = "\<lambda>(i::32 word,j::32 word). unat i \<le> length F \<and>
    bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j))"
  let ?m = "\<lambda>(i::32 word,j::32 word). length F - unat i"
  let ?C = "\<lambda>(i::32 word,j::32 word) (t::globals). i < roots_length_C (h_val (hrs_mem (t_hrs_' t)) h)"
  let ?Q = "\<lambda>(i::32 word,j::32 word) t. t=s \<and> unat i = length F \<and>
    bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j))"
  have HL: "unat (roots_length_C (h_val (hrs_mem (t_hrs_' s)) h)) = length F"
    and B: "length F \<le> 32" using R by (auto simp: bn_rep_def bn_heap_def)
  have PB: "\<And>i j. bn_review_scan_prefix s F i j \<Longrightarrow> i \<le> length F"
    by (simp add: bn_review_scan_prefix_def)
  have STEP0: "\<And>i j. ?I (i,j) \<Longrightarrow> ?C (i,j) s \<Longrightarrow>
    bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>b t. t=s \<and> ?I b \<and> ?m b < ?m (i,j))"
  proof -
    fix i j :: "32 word"
    assume IP: "?I (i,j)" and CP: "?C (i,j) s"
    have IB: "unat i < length F" using CP by (simp add: word_less_nat_alt HL)
    have SC: "bn_review_scan_prefix s F (unat i) (if j = 0xFFFFFFFF then None else Some (unat j))"
      using IP by simp
    have SMALL: "unat i < 32" using IB B by arith
    have NB: "unat i + 1 < 2^32" using SMALL by (simp; arith)
    have IS: "unat (i+1) = Suc (unat i)" using NB by (simp add: unat_word_ariths)
    show "bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>b t. t=s \<and> ?I b \<and> ?m b < ?m (i,j))"
      apply (rule vero_aux_contract_weaken[OF c0003_prove[OF R IB SC]])
      subgoal for r t
        apply (cases r)
        using IB PB by (auto simp: IS; arith)
      done
  qed
  have STEP: "\<And>a. ?I a \<Longrightarrow> ?C a s \<Longrightarrow>
    bn_contract (bn_ds_scan_step h a) s (\<lambda>b t. t=s \<and> ?I b \<and> ?m b < ?m a)"
  proof -
    fix a assume IA: "?I a" and CA: "?C a s"
    obtain i j where A: "a = (i,j)" by (cases a) auto
    have IP: "?I (i,j)" using IA by (simp only: A)
    have CP: "?C (i,j) s" using CA by (simp only: A)
    have ST: "bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>b t. t=s \<and> ?I b \<and> ?m b < ?m (i,j))"
      by (rule STEP0[OF IP CP])
    show "bn_contract (bn_ds_scan_step h a) s (\<lambda>b t. t=s \<and> ?I b \<and> ?m b < ?m a)"
      using ST by (simp only: A)
  qed
  have EXIT: "\<And>a. ?I a \<Longrightarrow> \<not> ?C a s \<Longrightarrow> ?Q a s"
  proof -
    fix a assume IA: "?I a" and CA: "\<not> ?C a s"
    show "?Q a s" using IA CA by (cases a) (auto simp: word_less_nat_alt HL; arith)
  qed
  have INIT: "?I (0,0xFFFFFFFF)" by (simp add: bn_review_scan_prefix_def)
  have LOOP: "bn_contract (whileLoop ?C (bn_ds_scan_step h) (0,0xFFFFFFFF)) s ?Q"
    apply (rule vero_aux_contract_while[where m="?m" and I="?I"])
    apply (rule STEP; assumption)
    apply (rule EXIT; assumption)
    by (rule INIT)
  have EQ: "bn_ds_scan h = whileLoop ?C (bn_ds_scan_step h) (0,0xFFFFFFFF)"
    by (simp only: bn_ds_scan_def bn_ds_scan_step_def)
  have RAW: "bn_contract (bn_ds_scan h) s ?Q" using LOOP by (simp only: EQ)
  have FINAL: "\<And>j::32 word. bn_review_scan_prefix s F (length F) (if j = 0xFFFFFFFF then None else Some (unat j)) \<Longrightarrow>
    unat j < length F \<and> (\<exists>T. F ! unat j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
      (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q))"
  proof -
    fix j :: "32 word"
    assume SC: "bn_review_scan_prefix s F (length F) (if j = 0xFFFFFFFF then None else Some (unat j))"
    have NJ: "j \<noteq> 0xFFFFFFFF"
    proof
      assume J: "j = 0xFFFFFFFF"
      have NONE: "\<forall>k < length F. F ! k = None" using SC J by (simp add: bn_review_scan_prefix_def)
      have EMPTY: "bn_forest_values s F = []"
        using NONE by (auto simp: vero_aux_scan_forest_empty in_set_conv_nth)
      have "M = {#}" using R EMPTY by (simp add: bn_rep_def)
      with NE show False by simp
    qed
    have SC1: "bn_review_scan_prefix s F (length F) (Some (unat j))" using SC NJ by simp
    have J: "unat j < length F" using SC1 by (auto simp: bn_review_scan_prefix_def)
    have MIN: "\<exists>T. F ! unat j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
      (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"
      by (rule vero_aux_scan_minimum[OF R NE SC1])
    show "unat j < length F \<and> (\<exists>T. F ! unat j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
      (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q))"
      using J MIN by blast
  qed
  show ?thesis
    apply (rule vero_aux_contract_weaken[OF RAW])
    subgoal for r t using FINAL by (cases r) auto
    done
qed



end

context binomial_heap_input_global_addresses begin



lemma c0018_prove:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
    \<exists>i T. i < length F \<and> F ! i = Some T \<and>
      value_C (bn_tree s (bn_root T)) \<in># M \<and>
      (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

proof -
  assume R: "bn_rep s h P F M" and NE: "M \<noteq> {#}"
  have M: "M = mset (bn_forest_values s F)" using R by (simp add: bn_rep_def)
  let ?V = "set (bn_forest_values s F)"
  let ?q = "arg_min_on (bn_key s) ?V"
  have FIN: "finite ?V" by simp
  have NON: "?V \<noteq> {}" using NE M by auto
  have Q: "?q \<in> ?V" by (rule arg_min_if_finite[OF FIN NON])
  obtain i T where I: "i < length F" and T: "F ! i = Some T"
    and V: "?q \<in> set (bn_values s T)"
    using Q unfolding vero_aux_forest_member by blast
  have VALID: "bn_valid s P T" using R I T by (auto simp: bn_rep_def)
  have ROOTSET: "value_C (bn_tree s (bn_root T)) \<in> ?V"
    apply (subst vero_aux_forest_member)
    apply (rule exI[where x=i])
    apply (rule exI[where x=T])
    using I T vero_aux_root_value[of s T] by blast
  have ROOT: "value_C (bn_tree s (bn_root T)) \<in># M" using ROOTSET by (simp add: M)
  have LE: "bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s ?q"
    by (rule vero_aux_root_min[OF VALID V])
  have ALL: "\<forall>v \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s v"
  proof (intro ballI)
    fix v assume "v \<in># M"
    hence VM: "v \<in> ?V" by (simp add: M)
    have "bn_key s ?q \<le> bn_key s v" by (rule arg_min_least[OF FIN NON VM])
    thus "bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s v" by (rule order_trans[OF LE])
  qed
  show ?thesis
    apply (rule exI[where x=i])
    apply (rule exI[where x=T])
    using I T ROOT ALL by blast
qed



end



lemma c0019_prove:
  "bytes_frame W hp hp"

by (simp add: bytes_frame_def)





lemma c0020_prove:
  "c_guard (p :: 'a::mem_type ptr) \<Longrightarrow>
   c_guard (q :: 'b::mem_type ptr) \<Longrightarrow>
   ptr_span p \<inter> ptr_span q = {} \<Longrightarrow>
   h_val (heap_update p v m) q = h_val m q"

by (simp add: h_val_heap_update_disjoint Int_commute)





lemma c0021_prove:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow>
   allocator_wf (A\<lparr>live_blocks := (live_blocks A)(p := Some n)\<rparr>)"

by (auto simp: allocator_wf_def fresh_block_def Int_commute)





lemma c0022_prove:
  "malloc_rel n hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    live_blocks B p = Some n \<and> reserved_bytes B = reserved_bytes A \<and>
    (\<forall>q. q \<noteq> p \<longrightarrow> live_blocks B q = live_blocks A q)"

by (auto simp: malloc_rel_def)





lemma c0023_prove:
  "bytes_frame W hp hp' \<Longrightarrow> a \<notin> W \<Longrightarrow> hp' a = hp a"

by (auto simp: bytes_frame_def)



context binomial_heap_input_global_addresses begin

lemma vero_aux_contract_while_state:
  fixes m :: "'a \<Rightarrow> nat"
  assumes STEP: "\<And>a s. I a s \<Longrightarrow> C a s \<Longrightarrow>
      bn_contract (B a) s (\<lambda>b t. I b t \<and> m b < m a)"
    and EXIT: "\<And>a s. I a s \<Longrightarrow> \<not> C a s \<Longrightarrow> Q a s"
    and INIT: "I a s"
  shows "bn_contract (whileLoop C B a) s Q"
  using INIT
proof (induction a arbitrary: s rule: measure_induct_rule[of m])
  case (less a)
  show ?case
  proof (cases "C a s")
    case False
    show ?thesis
      apply (subst whileLoop_unroll)
      using EXIT[OF less.prems False] False
      by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff reaches_return[abs_def])
  next
    case True
    have ST: "bn_contract (B a) s (\<lambda>b t. I b t \<and> m b < m a)"
      by (rule STEP[OF less.prems True])
    have BC: "bn_contract (B a >>= whileLoop C B) s Q"
    proof (rule vero_aux_contract_bind[OF ST])
      fix b t assume BT: "I b t \<and> m b < m a"
      have D: "m b < m a" and IB: "I b t" using BT by auto
      show "bn_contract (whileLoop C B b) t Q" by (rule less.IH[OF D IB])
    qed
    show ?thesis
      apply (subst whileLoop_unroll)
      using BC True by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff)
  qed
qed


lemma vero_aux_free_allocator:
  "allocator_wf A \<Longrightarrow> allocator_wf (A\<lparr>live_blocks := (live_blocks A)(p:=None)\<rparr>)"
  by (auto simp: allocator_wf_def)

lemma vero_aux_free_contract:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and G: "p=NULL \<or> (\<exists>n. live_blocks (phantom_machine_state_' s) (ptr_val p) = Some n)"
  shows "bn_contract (free' p) s (\<lambda>r t. \<exists>hp A.
    free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A \<and>
    t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>)"
proof -
  have Z: "ptr_val p=0 \<longleftrightarrow> p=NULL" by (cases p) (simp add: ptr_val_def)
  have EX: "\<exists>hp A. free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A"
    using W G Z by (auto simp: free_rel_def bytes_frame_def)
  show ?thesis using W G EX
    by (auto simp: bn_contract_def free'_def runs_to_bind_iff runs_to_guard_iff
      runs_to_assume_result_and_state_iff reaches_bind reaches_guard reaches_assume_result_and_state
      succeeds_runs_to_iff)
qed


definition vero_aux_release where
  "vero_aux_release s D W t \<longleftrightarrow>
    allocator_wf (phantom_machine_state_' t) \<and>
    reserved_bytes (phantom_machine_state_' t) = reserved_bytes (phantom_machine_state_' s) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>q. live_blocks (phantom_machine_state_' t) q =
      (if q\<in>D then None else live_blocks (phantom_machine_state_' s) q)) \<and>
    (\<forall>x\<in>reserved_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) x = hrs_mem (t_hrs_' s) x) \<and>
    (\<forall>q n. live_blocks (phantom_machine_state_' s) q = Some n \<longrightarrow> q\<notin>W \<longrightarrow>
      (\<forall>x\<in>block_bytes q n. hrs_mem (t_hrs_' t) x = hrs_mem (t_hrs_' s) x))"

lemma vero_aux_release_refl:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow> vero_aux_release s {} {} s"
  by (simp add: vero_aux_release_def)

lemma vero_aux_release_comp:
  assumes A: "vero_aux_release s D W t" and B: "vero_aux_release t E V u" and DW: "D\<subseteq>W"
  shows "vero_aux_release s (D\<union>E) (W\<union>V) u"
proof -
  have WU: "allocator_wf (phantom_machine_state_' u)" using B by (simp add: vero_aux_release_def)
  have RS: "reserved_bytes (phantom_machine_state_' u) = reserved_bytes (phantom_machine_state_' s)"
    and HT: "hrs_htd (t_hrs_' u) = hrs_htd (t_hrs_' s)"
    using A B by (auto simp: vero_aux_release_def)
  have LIVE: "\<forall>q. live_blocks (phantom_machine_state_' u) q =
    (if q\<in>D\<union>E then None else live_blocks (phantom_machine_state_' s) q)"
    using A B by (auto simp: vero_aux_release_def)
  have RES: "\<forall>x\<in>reserved_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' u) x = hrs_mem (t_hrs_' s) x"
    using A B unfolding vero_aux_release_def by metis
  have MEM: "\<forall>q n. live_blocks (phantom_machine_state_' s) q = Some n \<longrightarrow> q\<notin>W\<union>V \<longrightarrow>
    (\<forall>x\<in>block_bytes q n. hrs_mem (t_hrs_' u) x = hrs_mem (t_hrs_' s) x)"
  proof (intro allI impI ballI)
    fix q n x assume L: "live_blocks (phantom_machine_state_' s) q = Some n" and NW: "q\<notin>W\<union>V"
      and X: "x\<in>block_bytes q n"
    have ND: "q\<notin>D" using DW NW by blast
    have LT: "live_blocks (phantom_machine_state_' t) q = Some n" using A L ND by (simp add: vero_aux_release_def)
    have ST: "hrs_mem (t_hrs_' t) x = hrs_mem (t_hrs_' s) x" using A L NW X unfolding vero_aux_release_def by blast
    have TU: "hrs_mem (t_hrs_' u) x = hrs_mem (t_hrs_' t) x" using B LT NW X unfolding vero_aux_release_def by blast
    show "hrs_mem (t_hrs_' u) x = hrs_mem (t_hrs_' s) x" by (simp only: TU ST)
  qed
  show ?thesis using WU RS HT LIVE RES MEM by (simp add: vero_aux_release_def)
qed

lemma vero_aux_free_release:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some n"
  shows "bn_contract (free' p) s (\<lambda>r t. vero_aux_release s {ptr_val p} {ptr_val p} t)"
proof -
  have PN: "ptr_val p\<noteq>0" using W L by (auto simp: allocator_wf_def block_ok_def)
  have FC: "bn_contract (free' p) s (\<lambda>r t. \<exists>hp A.
    free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A \<and>
    t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>)"
    apply (rule vero_aux_free_contract[OF W]) using L by blast
  show ?thesis
  proof (rule vero_aux_contract_weaken[OF FC])
    fix r t assume POST: "\<exists>hp A. free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A \<and>
      t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>"
    obtain hp A where FR: "free_rel (ptr_val p) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) hp A"
      and T: "t = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := A\<rparr>"
      using POST by blast
    have AE: "A = (phantom_machine_state_' s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' s))(ptr_val p:=None)\<rparr>"
      and BF: "bytes_frame (block_bytes (ptr_val p) n) (hrs_mem (t_hrs_' s)) hp"
      using FR PN L by (auto simp: free_rel_def)
    have WA: "allocator_wf A" using vero_aux_free_allocator[OF W] by (simp only: AE)
    have RES: "\<forall>x\<in>reserved_bytes (phantom_machine_state_' s). hp x = hrs_mem (t_hrs_' s) x"
      using W L BF by (auto simp: allocator_wf_def bytes_frame_def; blast)
    have OTHER: "\<forall>q m. live_blocks (phantom_machine_state_' s) q = Some m \<longrightarrow> q\<noteq>ptr_val p \<longrightarrow>
      (\<forall>x\<in>block_bytes q m. hp x = hrs_mem (t_hrs_' s) x)"
      using W L BF by (auto simp: allocator_wf_def bytes_frame_def; blast)
    show "vero_aux_release s {ptr_val p} {ptr_val p} t"
      using WA RES OTHER by (simp add: vero_aux_release_def T AE hrs_mem_update_def hrs_mem_def hrs_htd_def case_prod_unfold)
  qed
qed

lemma vero_aux_stack_h_val_agree:
  "(\<And>a. a \<in> ptr_span p \<Longrightarrow> hp' a = hp a) \<Longrightarrow> h_val hp' p = h_val hp p"
  by (unfold h_val_def; rule arg_cong; rule heap_list_h_eq2; assumption)


lemma vero_aux_release_array:
  fixes p :: "'a::mem_type ptr"
  assumes A: "allocator_wf (phantom_machine_state_' s)"
    and R: "vero_aux_release s D W t"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some n"
    and NW: "ptr_val p\<notin>W" and K: "size_of TYPE('a) * k \<le> n" and I: "i<k"
  shows "h_val (hrs_mem (t_hrs_' t)) (p +\<^sub>p int i) = h_val (hrs_mem (t_hrs_' s)) (p +\<^sub>p int i)"
proof -
  have SP: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n" by (rule c0008_prove[OF A L K I])
  have BF: "\<forall>x\<in>block_bytes (ptr_val p) n. hrs_mem (t_hrs_' t) x = hrs_mem (t_hrs_' s) x"
    using R L NW unfolding vero_aux_release_def by blast
  show ?thesis apply (rule vero_aux_stack_h_val_agree) using SP BF by blast
qed

lemma vero_aux_release_key:
  assumes R: "vero_aux_release s D W t" and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and PAY: "bn_payload P v"
  shows "bn_key t v = bn_key s v"
proof -
  let ?p = "ptr_coerce v :: 32 signed word ptr"
  have G: "c_guard ?p" and B: "block_bytes (ptr_val ?p) 4 \<subseteq> P" using PAY by (auto simp: bn_payload_def)
  have SP: "ptr_span ?p \<subseteq> P"
    using B intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]] by (simp add: block_bytes_def)
  have H: "h_val (hrs_mem (t_hrs_' t)) ?p = h_val (hrs_mem (t_hrs_' s)) ?p"
    apply (rule vero_aux_stack_h_val_agree) using R PS SP unfolding vero_aux_release_def by blast
  show ?thesis by (simp only: bn_key_def H)
qed

lemma vero_aux_release_valid:
  assumes A: "allocator_wf (phantom_machine_state_' s)" and R: "vero_aux_release s D W t"
    and DW: "D\<subseteq>W" and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and V: "bn_valid s P T" and DIS: "set (bn_blocks s T) \<inter> W = {}"
  shows "bn_valid t P T \<and> bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T \<and>
    (\<forall>v\<in>set (bn_values s T). bn_key t v = bn_key s v)"
  using V DIS
proof (induction T)
  case (BN p cs)
  have LP: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using BN.prems by simp
  have NP: "ptr_val p\<notin>W" using BN.prems by auto
  have H0: "h_val (hrs_mem (t_hrs_' t)) (p +\<^sub>p int 0) = h_val (hrs_mem (t_hrs_' s)) (p +\<^sub>p int 0)"
    by (rule vero_aux_release_array[OF A R LP NP, where k=1 and i=0]) simp_all
  have HP: "bn_tree t p = bn_tree s p" using H0 by (simp add: bn_tree_def)
  have LPT: "live_blocks (phantom_machine_state_' t) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using R DW NP LP by (auto simp: vero_aux_release_def)
  have CHILD: "\<forall>U\<in>set cs. bn_valid t P U \<and> bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U \<and>
    (\<forall>v\<in>set (bn_values s U). bn_key t v = bn_key s v)"
    using BN.IH BN.prems by (auto simp: list_all_iff; blast)
  have MV: "map (bn_values t) cs = map (bn_values s) cs" using CHILD by (auto intro!: map_cong)
  have MB: "map (bn_blocks t) cs = map (bn_blocks s) cs" using CHILD by (auto intro!: map_cong)
  have PAY: "bn_payload P (value_C (bn_tree s p))" using BN.prems by simp
  have KEY: "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))" by (rule vero_aux_release_key[OF R PS PAY])
  have ARR: "cs\<noteq>[] \<Longrightarrow>
    live_blocks (phantom_machine_state_' t) (ptr_val (subtrees_C (bn_tree s p))) = Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length cs) \<and>
    (\<forall>i<length cs. h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i))"
  proof -
    assume NE: "cs\<noteq>[]"
    have LA: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) = Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length cs)"
      using BN.prems NE by simp
    have NA: "ptr_val (subtrees_C (bn_tree s p))\<notin>W" using BN.prems NE by auto
    have LAT: "live_blocks (phantom_machine_state_' t) (ptr_val (subtrees_C (bn_tree s p))) = Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length cs)"
      using R DW NA LA by (auto simp: vero_aux_release_def)
    have HV: "\<forall>i<length cs. h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
      by (intro allI impI; rule vero_aux_release_array[OF A R LA NA order_refl]; assumption)
    show ?thesis using LAT HV by blast
  qed
  show ?case using BN.prems CHILD LPT ARR KEY
    by (auto simp: HP MV MB list_all_iff)
qed


lemma vero_aux_update_release:
  fixes p :: "'a::mem_type ptr"
  assumes A: "allocator_wf (phantom_machine_state_' s)" and G: "c_guard p"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE('a))"
  shows "vero_aux_release s {} {ptr_val p} (t_hrs_'_update (hrs_mem_update (heap_update p v)) s)"
proof -
  let ?hp = "heap_update p v (hrs_mem (t_hrs_' s))"
  have BF: "bytes_frame (block_bytes (ptr_val p) (size_of TYPE('a))) (hrs_mem (t_hrs_' s)) ?hp"
    by (rule vero_aux_update_frame[OF G])
  have RES: "\<forall>x\<in>reserved_bytes (phantom_machine_state_' s). ?hp x = hrs_mem (t_hrs_' s) x"
    using A L BF by (auto simp: allocator_wf_def bytes_frame_def; blast)
  have OTHER: "\<forall>q m. live_blocks (phantom_machine_state_' s) q = Some m \<longrightarrow> q\<noteq>ptr_val p \<longrightarrow>
    (\<forall>x\<in>block_bytes q m. ?hp x = hrs_mem (t_hrs_' s) x)"
    using A L BF by (auto simp: allocator_wf_def bytes_frame_def; blast)
  show ?thesis using A RES OTHER by (simp add: vero_aux_release_def hrs_mem_update_def hrs_mem_def hrs_htd_def case_prod_unfold)
qed


lemma vero_aux_guard_prefix:
  "G s \<Longrightarrow> bn_contract B s Q \<Longrightarrow> bn_contract (do {guard G; B}) s Q"
  by (auto simp: bn_contract_def runs_to_bind_iff runs_to_guard_iff reaches_bind reaches_guard succeeds_runs_to_iff; erule runs_to_weaken; simp)

lemma vero_aux_gets_prefix:
  "bn_contract (B (f s)) s Q \<Longrightarrow> bn_contract (gets f >>= B) s Q"
  by (auto simp: bn_contract_def runs_to_bind_iff runs_to_gets_iff reaches_bind reaches_gets succeeds_runs_to_iff; erule runs_to_weaken; simp)

lemma vero_aux_modify_prefix:
  "bn_contract B (f s) Q \<Longrightarrow> bn_contract (do {modify f; B}) s Q"
  by (auto simp: bn_contract_def runs_to_bind_iff runs_to_modify_iff reaches_bind reaches_modify succeeds_runs_to_iff; erule runs_to_weaken; simp)

lemma vero_aux_return_contract:
  "Q v s \<Longrightarrow> bn_contract (return v) s Q"
  by (simp add: bn_contract_def reaches_return[abs_def])


definition vero_aux_unref_body where
  "vero_aux_unref_body p (i :: 32 signed word) = do {
    guard (\<lambda>s. c_guard (subtrees_C (bn_tree s p) +\<^sub>p sint i));
    child \<leftarrow> gets (\<lambda>s. h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p sint i));
    ret \<leftarrow> binomial_tree_unref' child;
    guard (\<lambda>s. 0 \<le> 2147483649 + sint i);
    guard (\<lambda>s. sint i < INT_MAX);
    return (i+1)
  }"

lemma vero_aux_unref_body_contract:
  assumes G: "c_guard (subtrees_C (bn_tree s p) +\<^sub>p sint i)"
    and V: "h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p sint i) = child"
    and C: "bn_contract (binomial_tree_unref' child) s Q"
    and LO: "0 \<le> 2147483649 + sint i" and HI: "sint i < INT_MAX"
  shows "bn_contract (vero_aux_unref_body p i) s (\<lambda>r t. r=i+1 \<and> Q () t)"
  unfolding vero_aux_unref_body_def
  apply (rule vero_aux_guard_prefix)
   apply (rule G)
  apply (rule vero_aux_gets_prefix)
  apply (simp only: V)
  apply (rule vero_aux_contract_bind[OF C])
  subgoal for r t
    apply (rule vero_aux_guard_prefix)
     apply (rule LO)
    apply (rule vero_aux_guard_prefix)
     apply (rule HI)
    apply (rule vero_aux_return_contract)
    by (cases r) simp
  done


lemma vero_aux_small_signed_index:
  assumes K: "k\<le>65535"
  shows "sint (of_nat k :: 32 signed word) = int k"
proof -
  have E: "(of_nat k :: 32 signed word) = of_int (int k)" by simp
  have LO: "- (2 ^ (LENGTH(32 signed) - 1)) \<le> int k" by simp
  have HI: "int k < 2 ^ (LENGTH(32 signed) - 1)" using K by (simp; arith)
  show ?thesis unfolding E by (rule sint_of_int_eq[OF LO HI])
qed

lemma vero_aux_small_signed_unat:
  "k\<le>65535 \<Longrightarrow> unat (of_nat k :: 32 signed word) = k"
  apply (rule unat_of_nat_eq) by (simp; arith)


lemma vero_aux_prefix_component_disjoint:
  assumes D: "distinct (concat (map f xs))" and I: "i<length xs"
  shows "set (concat (map f (take i xs))) \<inter> set (f (xs!i)) = {}"
proof -
  have E0: "concat (map f xs) = concat (map f (take i xs @ xs!i # drop (Suc i) xs))"
    by (rule arg_cong[OF id_take_nth_drop[OF I]])
  have E: "concat (map f xs) = concat (map f (take i xs)) @ f (xs!i) @ concat (map f (drop (Suc i) xs))"
    using E0 by (simp only: map_append list.map concat_append concat.simps)
  have DD: "distinct (concat (map f (take i xs)) @ f (xs!i) @ concat (map f (drop (Suc i) xs)))"
    using D by (simp only: E[symmetric])
  show ?thesis using DD by auto
qed

lemma vero_aux_prefix_blocks_subset:
  "set (concat (map f (take i xs))) \<subseteq> set (concat (map f xs))"
  by (auto dest: set_take_subset[THEN subsetD])


lemma vero_aux_free_null:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
  shows "bn_contract (free' NULL) s (\<lambda>r t. t=s)"
  using W
  by (auto simp: bn_contract_def free'_def free_rel_def ptr_val_def
    hrs_mem_update_def hrs_mem_def case_prod_unfold
    runs_to_bind_iff runs_to_guard_iff runs_to_assume_result_and_state_iff
    reaches_bind reaches_guard reaches_assume_result_and_state succeeds_runs_to_iff)

lemma vero_aux_unref_null:
  "bn_contract (binomial_tree_unref' NULL) s (\<lambda>r t. t=s)"
  apply (subst binomial_tree_unref'.simps)
  by (simp add: bn_contract_def reaches_return[abs_def])


definition vero_aux_prefix_blocks where
  "vero_aux_prefix_blocks s cs k = set (concat (map (bn_blocks s) (take k cs)))"

lemma vero_aux_unref_child_step:
  assumes A: "allocator_wf (phantom_machine_state_' s)"
    and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and V: "bn_valid s P (BN p cs)" and D: "distinct (bn_blocks s (BN p cs))"
    and K: "k<length cs"
    and R: "vero_aux_release s (vero_aux_prefix_blocks s cs k) (insert (ptr_val p) (vero_aux_prefix_blocks s cs k)) t"
    and HP: "bn_tree t p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
    and CHILD: "\<And>u. allocator_wf (phantom_machine_state_' u) \<Longrightarrow>
      P\<subseteq>reserved_bytes (phantom_machine_state_' u) \<Longrightarrow>
      bn_valid u P (cs!k) \<Longrightarrow> distinct (bn_blocks u (cs!k)) \<Longrightarrow>
      bn_contract (binomial_tree_unref' (bn_root (cs!k))) u
        (\<lambda>r v. vero_aux_release u (set (bn_blocks u (cs!k))) (set (bn_blocks u (cs!k))) v)"
  shows "bn_contract (vero_aux_unref_body p (of_nat k)) t (\<lambda>j u.
    j=of_nat (Suc k) \<and>
    vero_aux_release s (vero_aux_prefix_blocks s cs (Suc k)) (insert (ptr_val p) (vero_aux_prefix_blocks s cs (Suc k))) u \<and>
    bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>)"
proof -
  let ?B = "vero_aux_prefix_blocks s cs k"
  let ?U = "cs!k"
  let ?a = "subtrees_C (bn_tree s p)"
  have NE: "cs\<noteq>[]" using K by auto
  have DC: "distinct (concat (map (bn_blocks s) cs))" using D by simp
  have UK: "?U\<in>set cs" by (rule nth_mem[OF K])
  have VU: "bn_valid s P ?U" using V UK by (simp add: list_all_iff)
  have ALLD: "\<forall>ys\<in>set (map (bn_blocks s) cs). distinct ys" using DC by (simp only: distinct_concat_iff; blast)
  have DU: "distinct (bn_blocks s ?U)" using ALLD UK by auto
  have NP: "ptr_val p\<notin>set (concat (map (bn_blocks s) cs))" using D by simp
  have NA: "ptr_val ?a\<notin>set (concat (map (bn_blocks s) cs))" using D NE by simp
  have SUB: "?B\<subseteq>set (concat (map (bn_blocks s) cs))"
    unfolding vero_aux_prefix_blocks_def by (rule vero_aux_prefix_blocks_subset)
  have DIS0: "?B \<inter> set (bn_blocks s ?U) = {}"
    unfolding vero_aux_prefix_blocks_def by (rule vero_aux_prefix_component_disjoint[OF DC K])
  have DIS: "set (bn_blocks s ?U) \<inter> insert (ptr_val p) ?B = {}" using DIS0 NP UK by auto
  have PRES: "bn_valid t P ?U \<and> bn_blocks t ?U = bn_blocks s ?U"
    using vero_aux_release_valid[OF A R _ PS VU DIS] by blast
  have AT: "allocator_wf (phantom_machine_state_' t)" and PST: "P\<subseteq>reserved_bytes (phantom_machine_state_' t)"
    using R PS by (auto simp: vero_aux_release_def)
  have VT: "bn_valid t P ?U" and BT: "bn_blocks t ?U = bn_blocks s ?U" using PRES by blast+
  have DT: "distinct (bn_blocks t ?U)" using DU by (simp only: BT)
  have CT: "bn_contract (binomial_tree_unref' (bn_root ?U)) t
      (\<lambda>r u. vero_aux_release t (set (bn_blocks t ?U)) (set (bn_blocks t ?U)) u)"
    by (rule CHILD[OF AT PST VT DT])
  have LA: "live_blocks (phantom_machine_state_' s) (ptr_val ?a) = Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length cs)"
    using V NE by simp
  have NAP: "ptr_val ?a\<notin>insert (ptr_val p) ?B" using D NE NA SUB by auto
  have HV: "h_val (hrs_mem (t_hrs_' t)) (?a +\<^sub>p int k) = h_val (hrs_mem (t_hrs_' s)) (?a +\<^sub>p int k)"
    by (rule vero_aux_release_array[OF A R LA NAP order_refl K])
  have L: "length cs\<le>65535" using V unat_lt2p[of "order_C (bn_tree s p)"] by (simp; arith)
  have KB: "k\<le>65535" using K L by arith
  have SI: "sint (of_nat k :: 32 signed word) = int k" by (rule vero_aux_small_signed_index[OF KB])
  have G: "c_guard (subtrees_C (bn_tree t p) +\<^sub>p sint (of_nat k :: 32 signed word))" using V K by (simp add: HP SI)
  have VAL: "h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree t p) +\<^sub>p sint (of_nat k :: 32 signed word)) = bn_root ?U"
    using V K by (simp add: HP SI HV)
  have LO: "0\<le>2147483649+sint (of_nat k :: 32 signed word)" by (simp add: SI)
  have HI: "sint (of_nat k :: 32 signed word)<INT_MAX" using KB by (simp add: SI INT_MAX_def)
  have BODY: "bn_contract (vero_aux_unref_body p (of_nat k)) t
    (\<lambda>j u. j=(of_nat k :: 32 signed word)+1 \<and> vero_aux_release t (set (bn_blocks t ?U)) (set (bn_blocks t ?U)) u)"
    by (rule vero_aux_unref_body_contract[OF G VAL CT LO HI])
  show ?thesis
  proof (rule vero_aux_contract_weaken[OF BODY])
    fix j u assume JU: "j=(of_nat k :: 32 signed word)+1 \<and> vero_aux_release t (set (bn_blocks t ?U)) (set (bn_blocks t ?U)) u"
    have RU: "vero_aux_release t (set (bn_blocks s ?U)) (set (bn_blocks s ?U)) u" using JU by (simp only: BT)
    have COMP: "vero_aux_release s (?B\<union>set (bn_blocks s ?U)) (insert (ptr_val p) ?B\<union>set (bn_blocks s ?U)) u"
      by (rule vero_aux_release_comp[OF R RU]) blast
    have BS: "vero_aux_prefix_blocks s cs (Suc k) = ?B\<union>set (bn_blocks s ?U)"
      by (simp add: vero_aux_prefix_blocks_def take_Suc_conv_app_nth[OF K])
    have LP: "live_blocks (phantom_machine_state_' t) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
      using R V NP SUB by (auto simp: vero_aux_release_def)
    have NPU: "ptr_val p\<notin>set (bn_blocks s ?U)" using NP UK by auto
    have H0: "h_val (hrs_mem (t_hrs_' u)) (p +\<^sub>p int 0) = h_val (hrs_mem (t_hrs_' t)) (p +\<^sub>p int 0)"
      by (rule vero_aux_release_array[OF AT RU LP NPU, where k=1 and i=0]) simp_all
    have HU: "bn_tree u p = bn_tree t p" using H0 by (simp add: bn_tree_def)
    show "j=of_nat (Suc k) \<and> vero_aux_release s (vero_aux_prefix_blocks s cs (Suc k)) (insert (ptr_val p) (vero_aux_prefix_blocks s cs (Suc k))) u \<and> bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
      using JU COMP by (simp add: BS HU HP)
  qed
qed


lemma vero_aux_unref_children:
  assumes A: "allocator_wf (phantom_machine_state_' s)"
    and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and V: "bn_valid s P (BN p cs)" and D: "distinct (bn_blocks s (BN p cs))"
    and R: "vero_aux_release s {} {ptr_val p} t"
    and HP: "bn_tree t p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
    and CHILD: "\<And>U u. U\<in>set cs \<Longrightarrow> allocator_wf (phantom_machine_state_' u) \<Longrightarrow>
      P\<subseteq>reserved_bytes (phantom_machine_state_' u) \<Longrightarrow>
      bn_valid u P U \<Longrightarrow> distinct (bn_blocks u U) \<Longrightarrow>
      bn_contract (binomial_tree_unref' (bn_root U)) u
        (\<lambda>r v. vero_aux_release u (set (bn_blocks u U)) (set (bn_blocks u U)) v)"
  shows "bn_contract (whileLoop (\<lambda>i u. i <s (ucast (order_C (bn_tree u p)) :: 32 signed word)) (vero_aux_unref_body p) 0) t
    (\<lambda>j u. vero_aux_release s (set (concat (map (bn_blocks s) cs))) (insert (ptr_val p) (set (concat (map (bn_blocks s) cs)))) u \<and>
      bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>)"
proof -
  let ?I = "\<lambda>i (u::globals). \<exists>k\<le>length cs. i=(of_nat k :: 32 signed word) \<and>
    vero_aux_release s (vero_aux_prefix_blocks s cs k) (insert (ptr_val p) (vero_aux_prefix_blocks s cs k)) u \<and>
    bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
  let ?C = "\<lambda>i u. i <s (ucast (order_C (bn_tree u p)) :: 32 signed word)"
  let ?m = "\<lambda>i::32 signed word. length cs - unat i"
  have L: "length cs\<le>65535" using V unat_lt2p[of "order_C (bn_tree s p)"] by (simp; arith)
  have UORDER: "unat (order_C (bn_tree s p)) = length cs" using V by simp
  have CAST: "sint (ucast (order_C (bn_tree s p)) :: 32 signed word) = uint (order_C (bn_tree s p))"
    by (rule sint_ucast_signed_eq_uint) simp
  have ORDER: "sint (ucast (order_C (bn_tree s p)) :: 32 signed word) = int (length cs)"
    by (simp only: CAST uint_nat UORDER)
  have STEP: "\<And>i u. ?I i u \<Longrightarrow> ?C i u \<Longrightarrow>
    bn_contract (vero_aux_unref_body p i) u (\<lambda>j v. ?I j v \<and> ?m j < ?m i)"
  proof -
    fix i u assume INV: "?I i u" and C: "?C i u"
    obtain k where K: "k\<le>length cs" and IK: "i=of_nat k"
      and RU: "vero_aux_release s (vero_aux_prefix_blocks s cs k) (insert (ptr_val p) (vero_aux_prefix_blocks s cs k)) u"
      and HU: "bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>" using INV by blast
    have KB: "k\<le>65535" using K L by arith
    have SI: "sint (of_nat k :: 32 signed word) = int k" by (rule vero_aux_small_signed_index[OF KB])
    have KL: "k<length cs" using C by (simp add: IK HU word_sless_alt SI ORDER)
    have CALLBACK: "\<And>v. allocator_wf (phantom_machine_state_' v) \<Longrightarrow>
      P\<subseteq>reserved_bytes (phantom_machine_state_' v) \<Longrightarrow> bn_valid v P (cs!k) \<Longrightarrow>
      distinct (bn_blocks v (cs!k)) \<Longrightarrow> bn_contract (binomial_tree_unref' (bn_root (cs!k))) v
        (\<lambda>r w. vero_aux_release v (set (bn_blocks v (cs!k))) (set (bn_blocks v (cs!k))) w)"
      by (rule CHILD[OF nth_mem[OF KL]])
    have BODY: "bn_contract (vero_aux_unref_body p (of_nat k)) u (\<lambda>j v. j=of_nat (Suc k) \<and>
      vero_aux_release s (vero_aux_prefix_blocks s cs (Suc k)) (insert (ptr_val p) (vero_aux_prefix_blocks s cs (Suc k))) v \<and>
      bn_tree v p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>)"
      by (rule vero_aux_unref_child_step[OF A PS V D KL RU HU CALLBACK])
    have SK: "Suc k\<le>length cs" using KL by simp
    have SKB: "Suc k\<le>65535" using SK L by arith
    have UI: "unat i=k" by (simp only: IK vero_aux_small_signed_unat[OF KB])
    have UJ: "unat (of_nat (Suc k) :: 32 signed word)=Suc k" by (rule vero_aux_small_signed_unat[OF SKB])
    show "bn_contract (vero_aux_unref_body p i) u (\<lambda>j v. ?I j v \<and> ?m j < ?m i)"
      unfolding IK
    proof (rule vero_aux_contract_weaken[OF BODY])
      fix j :: "32 signed word" and v :: globals
      assume JV: "j=of_nat (Suc k) \<and>
        vero_aux_release s (vero_aux_prefix_blocks s cs (Suc k)) (insert (ptr_val p) (vero_aux_prefix_blocks s cs (Suc k))) v \<and>
        bn_tree v p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
      have J: "j=of_nat (Suc k)" using JV by blast
      have INVJ: "?I j v"
        apply (rule exI[where x="Suc k"]) using JV SK by blast
      have UI0: "unat (of_nat k :: 32 signed word)=k" by (rule vero_aux_small_signed_unat[OF KB])
      have UJ0: "unat j=Suc k" by (simp only: J UJ)
      have DEC0: "length cs - Suc k < length cs-k" by (rule diff_less_mono2[OF lessI KL])
      have DEC: "?m j < ?m (of_nat k)" by (simp only: UJ0 UI0 DEC0)
      show "?I j v \<and> ?m j < ?m (of_nat k)" using INVJ DEC by blast
    qed
  qed
  have EXIT: "\<And>i u. ?I i u \<Longrightarrow> \<not>?C i u \<Longrightarrow>
    vero_aux_release s (set (concat (map (bn_blocks s) cs))) (insert (ptr_val p) (set (concat (map (bn_blocks s) cs)))) u \<and>
    bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
  proof -
    fix i u assume INV: "?I i u" and NC: "\<not>?C i u"
    obtain k where K: "k\<le>length cs" and IK: "i=of_nat k"
      and RU: "vero_aux_release s (vero_aux_prefix_blocks s cs k) (insert (ptr_val p) (vero_aux_prefix_blocks s cs k)) u"
      and HU: "bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>" using INV by blast
    have KB: "k\<le>65535" using K L by arith
    have SI: "sint (of_nat k :: 32 signed word) = int k" by (rule vero_aux_small_signed_index[OF KB])
    have GE: "length cs\<le>k" using NC by (simp add: IK HU word_sless_alt SI ORDER)
    have E: "k=length cs" using K GE by arith
    show "vero_aux_release s (set (concat (map (bn_blocks s) cs))) (insert (ptr_val p) (set (concat (map (bn_blocks s) cs)))) u \<and>
      bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
      using RU HU by (simp add: E vero_aux_prefix_blocks_def)
  qed
  have INIT: "?I 0 t"
    apply (rule exI[where x=0]) using R HP by (simp add: vero_aux_prefix_blocks_def)
  show ?thesis by (rule vero_aux_contract_while_state[OF STEP EXIT INIT])
qed



lemma vero_aux_release_free:
  assumes R: "vero_aux_release s D W t"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some n"
    and NP: "ptr_val p\<notin>D" and DW: "D\<subseteq>W"
  shows "bn_contract (free' p) t (\<lambda>r u. vero_aux_release s (insert (ptr_val p) D) (insert (ptr_val p) W) u)"
proof -
  have A: "allocator_wf (phantom_machine_state_' t)" using R by (simp add: vero_aux_release_def)
  have LT: "live_blocks (phantom_machine_state_' t) (ptr_val p) = Some n" using R L NP by (simp add: vero_aux_release_def)
  have C: "bn_contract (free' p) t (\<lambda>r u. vero_aux_release t {ptr_val p} {ptr_val p} u)"
    by (rule vero_aux_free_release[OF A LT])
  show ?thesis
  proof (rule vero_aux_contract_weaken[OF C])
    fix r and u :: globals
      assume RU: "vero_aux_release t {ptr_val p} {ptr_val p} u"
    have "vero_aux_release s (D\<union>{ptr_val p}) (W\<union>{ptr_val p}) u"
      by (rule vero_aux_release_comp[OF R RU DW])
    then show "vero_aux_release s (insert (ptr_val p) D) (insert (ptr_val p) W) u" by (simp add: insert_commute Un_commute)
  qed
qed

lemma vero_aux_coerce_null:
  "(ptr_coerce (NULL :: 'a ptr) :: 'b ptr) = NULL"
  by simp

lemma vero_aux_unref_cleanup:
  assumes V: "bn_valid s P (BN p cs)" and D: "distinct (bn_blocks s (BN p cs))"
    and R: "vero_aux_release s (set (concat (map (bn_blocks s) cs))) (insert (ptr_val p) (set (concat (map (bn_blocks s) cs)))) t"
    and HP: "bn_tree t p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
  shows "bn_contract (do {a \<leftarrow> gets (\<lambda>u. ptr_coerce (subtrees_C (bn_tree u p))); free' a; free' (ptr_coerce p)}) t
    (\<lambda>r u. vero_aux_release s (set (bn_blocks s (BN p cs))) (set (bn_blocks s (BN p cs))) u)"
proof -
  let ?B = "set (concat (map (bn_blocks s) cs))"
  let ?a = "subtrees_C (bn_tree s p)"
  have LP: "live_blocks (phantom_machine_state_' s) (ptr_val (ptr_coerce p :: unit ptr)) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using V by simp
  have NP: "ptr_val (ptr_coerce p :: unit ptr)\<notin>?B" using D by simp
  have AT: "allocator_wf (phantom_machine_state_' t)" using R by (simp add: vero_aux_release_def)
  have C: "bn_contract (do {free' (ptr_coerce ?a); free' (ptr_coerce p)}) t
    (\<lambda>r u. vero_aux_release s (set (bn_blocks s (BN p cs))) (set (bn_blocks s (BN p cs))) u)"
  proof (cases "cs=[]")
    case True
    have AZ: "?a=NULL" using V True by simp
    have CP: "bn_contract (free' (ptr_coerce p)) t (\<lambda>r u. vero_aux_release s (insert (ptr_val p) ?B) (insert (ptr_val p) ?B) u)"
      using vero_aux_release_free[OF R LP NP] by auto
    show ?thesis
      apply (simp only: AZ vero_aux_coerce_null)
      apply (rule vero_aux_contract_bind[OF vero_aux_free_null[OF AT]])
      using CP True by simp
  next
    case False
    have LA: "live_blocks (phantom_machine_state_' s) (ptr_val (ptr_coerce ?a :: unit ptr)) = Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length cs)"
      using V False by simp
    have NA: "ptr_val (ptr_coerce ?a :: unit ptr)\<notin>?B" using D False by simp
    have CA: "bn_contract (free' (ptr_coerce ?a)) t (\<lambda>r u. vero_aux_release s (insert (ptr_val ?a) ?B) (insert (ptr_val ?a) (insert (ptr_val p) ?B)) u)"
      using vero_aux_release_free[OF R LA NA] by auto
    show ?thesis
    proof (rule vero_aux_contract_bind[OF CA])
      fix r and u :: globals
      assume RU: "vero_aux_release s (insert (ptr_val ?a) ?B) (insert (ptr_val ?a) (insert (ptr_val p) ?B)) u"
      have NPA: "ptr_val (ptr_coerce p :: unit ptr)\<notin>insert (ptr_val ?a) ?B" using D False by simp
      have CP: "bn_contract (free' (ptr_coerce p)) u
        (\<lambda>r v. vero_aux_release s (insert (ptr_val p) (insert (ptr_val ?a) ?B)) (insert (ptr_val p) (insert (ptr_val ?a) ?B)) v)"
        using vero_aux_release_free[OF RU LP NPA] by (auto simp: insert_commute)
      show "bn_contract (free' (ptr_coerce p)) u (\<lambda>r v. vero_aux_release s (set (bn_blocks s (BN p cs))) (set (bn_blocks s (BN p cs))) v)"
        using CP False by simp
    qed
  qed
  show ?thesis
    apply (rule vero_aux_gets_prefix)
    using C by (simp add: HP)
qed


definition vero_aux_unref_tail where
  "vero_aux_unref_tail p = do {
    i \<leftarrow> whileLoop (\<lambda>i s. i <s (ucast (order_C (bn_tree s p)) :: 32 signed word)) (vero_aux_unref_body p) 0;
    a \<leftarrow> gets (\<lambda>s. ptr_coerce (subtrees_C (bn_tree s p)));
    free' a;
    free' (ptr_coerce p)
  }"

lemma vero_aux_unref_equation:
  "binomial_tree_unref' p = unless (p=NULL) (do {
    guard (\<lambda>s. c_guard p);
    guard (\<lambda>s. -INT_MAX-1 < uint (refcount_C (bn_tree s p)));
    guard (\<lambda>s. uint (refcount_C (bn_tree s p)) \<le> INT_MAX+1);
    modify (\<lambda>s. t_hrs_'_update (hrs_mem_update (heap_update p ((bn_tree s p)\<lparr>refcount_C:=refcount_C (bn_tree s p)-1\<rparr>))) s);
    condition (\<lambda>s. (ucast (refcount_C (bn_tree s p)) :: 32 signed word)=0) (vero_aux_unref_tail p) skip
  })"
proof -
  have E: "t_hrs_'_update (\<lambda>a. hrs_mem_update (heap_update p (refcount_C_update (\<lambda>x. x-1) (h_val (hrs_mem a) p))) a) =
    (\<lambda>s. t_hrs_'_update (hrs_mem_update (heap_update p ((bn_tree s p)\<lparr>refcount_C:=refcount_C (bn_tree s p)-1\<rparr>))) s)"
    by (rule ext; rule globals.equality; simp add: bn_tree_def vero_aux_refcount_dec)
  show ?thesis
    apply (subst binomial_tree_unref'.simps)
    by (simp only: E vero_aux_unref_tail_def vero_aux_unref_body_def[abs_def] bn_tree_def)
qed

lemma vero_aux_condition_true:
  "G s \<Longrightarrow> bn_contract B s Q \<Longrightarrow> bn_contract (condition G B C) s Q"
  by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff)

lemma vero_aux_unref_prefix:
  assumes G: "c_guard p" and REF: "refcount_C (bn_tree s p)=1"
    and C: "bn_contract (vero_aux_unref_tail p)
      (t_hrs_'_update (hrs_mem_update (heap_update p ((bn_tree s p)\<lparr>refcount_C:=0\<rparr>))) s) Q"
  shows "bn_contract (binomial_tree_unref' p) s Q"
proof -
  let ?t = "t_hrs_'_update (hrs_mem_update (heap_update p ((bn_tree s p)\<lparr>refcount_C:=0\<rparr>))) s"
  have NN: "p\<noteq>NULL" using G by (auto dest: c_guard_NULL)
  have HP: "bn_tree ?t p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
    using G by (simp add: bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update)
  have COND: "bn_contract (condition (\<lambda>s. (ucast (refcount_C (bn_tree s p)) :: 32 signed word)=0) (vero_aux_unref_tail p) skip) ?t Q"
    apply (rule vero_aux_condition_true)
     apply (simp only: HP; simp)
    by (rule C)
  show ?thesis
    apply (subst vero_aux_unref_equation)
    apply (simp only: NN condition_to_unless[symmetric])
    apply (simp)
    apply (rule vero_aux_guard_prefix)
     apply (rule G)
    apply (rule vero_aux_guard_prefix)
     apply (simp add: REF INT_MAX_def)
    apply (rule vero_aux_guard_prefix)
     apply (simp add: REF INT_MAX_def)
    apply (rule vero_aux_modify_prefix)
    using COND by (simp only: REF; simp)
qed

lemma vero_aux_unref_release:
  assumes A: "allocator_wf (phantom_machine_state_' s)"
    and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and V: "bn_valid s P T" and D: "distinct (bn_blocks s T)"
  shows "bn_contract (binomial_tree_unref' (bn_root T)) s
    (\<lambda>r t. vero_aux_release s (set (bn_blocks s T)) (set (bn_blocks s T)) t)"
  using A PS V D
proof (induction T arbitrary: s)
  case (BN p cs)
  let ?t = "t_hrs_'_update (hrs_mem_update (heap_update p ((bn_tree s p)\<lparr>refcount_C:=0\<rparr>))) s"
  have G: "c_guard p" and REF: "refcount_C (bn_tree s p)=1"
    and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using BN.prems(3) by auto
  have R: "vero_aux_release s {} {ptr_val p} ?t" by (rule vero_aux_update_release[OF BN.prems(1) G LP])
  have HP: "bn_tree ?t p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>"
    using G by (simp add: bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update)
  have LOOP: "bn_contract (whileLoop (\<lambda>i u. i <s (ucast (order_C (bn_tree u p)) :: 32 signed word)) (vero_aux_unref_body p) 0) ?t
    (\<lambda>j u. vero_aux_release s (set (concat (map (bn_blocks s) cs))) (insert (ptr_val p) (set (concat (map (bn_blocks s) cs)))) u \<and>
      bn_tree u p = (bn_tree s p)\<lparr>refcount_C:=0\<rparr>)"
    by (rule vero_aux_unref_children[OF BN.prems R HP BN.IH])
  have TAIL: "bn_contract (vero_aux_unref_tail p) ?t
    (\<lambda>r u. vero_aux_release s (set (bn_blocks s (BN p cs))) (set (bn_blocks s (BN p cs))) u)"
    unfolding vero_aux_unref_tail_def
    apply (rule vero_aux_contract_bind[OF LOOP])
    subgoal for j u
      apply (rule vero_aux_unref_cleanup[OF BN.prems(3,4)]) by auto
    done
  show ?case using vero_aux_unref_prefix[OF G REF TAIL] by simp
qed



lemma vero_aux_unref_option:
  assumes A: "allocator_wf (phantom_machine_state_' s)"
    and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and V: "case T of None \<Rightarrow> True | Some U \<Rightarrow> bn_valid s P U"
    and D: "distinct (case_option [] (bn_blocks s) T)"
  shows "bn_contract (binomial_tree_unref' (case_option NULL bn_root T)) s
    (\<lambda>r t. vero_aux_release s (set (case_option [] (bn_blocks s) T)) (set (case_option [] (bn_blocks s) T)) t)"
proof (cases T)
  case None
  show ?thesis
    apply (simp only: None option.case)
    apply (rule vero_aux_contract_weaken[OF vero_aux_unref_null])
    using vero_aux_release_refl[OF A] by simp
next
  case (Some U)
  have VU: "bn_valid s P U" and DU: "distinct (bn_blocks s U)" using V D Some by auto
  show ?thesis using vero_aux_unref_release[OF A PS VU DU] by (simp only: Some option.case)
qed

lemma vero_aux_release_option:
  assumes A: "allocator_wf (phantom_machine_state_' s)" and R: "vero_aux_release s D W t"
    and DW: "D\<subseteq>W" and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and V: "case T of None \<Rightarrow> True | Some U \<Rightarrow> bn_valid s P U"
    and DIS: "set (case_option [] (bn_blocks s) T) \<inter> W = {}"
  shows "(case T of None \<Rightarrow> True | Some U \<Rightarrow> bn_valid t P U) \<and>
    case_option [] (bn_blocks t) T = case_option [] (bn_blocks s) T"
proof (cases T)
  case None then show ?thesis by simp
next
  case (Some U)
  have VU: "bn_valid s P U" and DU: "set (bn_blocks s U)\<inter>W={}" using V DIS Some by auto
  show ?thesis using vero_aux_release_valid[OF A R DW PS VU DU] by (simp only: Some option.case; blast)
qed

definition vero_aux_forest_prefix_blocks where
  "vero_aux_forest_prefix_blocks s F k = set (concat (map (case_option [] (bn_blocks s)) (take k F)))"

definition vero_aux_heap_free_body where
  "vero_aux_heap_free_body h (i::32 word) = do {
    guard (\<lambda>s. c_guard (roots_C (bn_heap s h) +\<^sub>p uint i));
    tree \<leftarrow> gets (\<lambda>s. h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint i));
    ret \<leftarrow> binomial_tree_unref' tree;
    return (i+1)
  }"

lemma vero_aux_heap_free_step:
  assumes R0: "bn_rep s h P F M" and K: "k<length F"
    and R: "vero_aux_release s (vero_aux_forest_prefix_blocks s F k) (vero_aux_forest_prefix_blocks s F k) t"
    and HH: "bn_heap t h = bn_heap s h"
  shows "bn_contract (vero_aux_heap_free_body h (of_nat k)) t (\<lambda>j u.
    j=of_nat (Suc k) \<and>
    vero_aux_release s (vero_aux_forest_prefix_blocks s F (Suc k)) (vero_aux_forest_prefix_blocks s F (Suc k)) u \<and>
    bn_heap u h = bn_heap s h)"
proof -
  let ?f = "case_option [] (bn_blocks s)"
  let ?B = "vero_aux_forest_prefix_blocks s F k"
  let ?a = "roots_C (bn_heap s h)"
  have A: "allocator_wf (phantom_machine_state_' s)" and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and D: "distinct (bn_owned s h F)" and L: "length F\<le>32"
    and V: "case F!k of None \<Rightarrow> True | Some U \<Rightarrow> bn_valid s P U"
    and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using R0 K by (auto simp: bn_rep_def split: option.splits)
  have DC: "distinct (concat (map ?f F))" using D by (simp add: bn_owned_def)
  have ALLD: "\<forall>xs\<in>set (map ?f F). distinct xs" using DC by (simp only: distinct_concat_iff; blast)
  have DK: "distinct (?f (F!k))" using ALLD nth_mem[OF K] by auto
  have DIS0: "?B\<inter>set (?f (F!k)) = {}"
    unfolding vero_aux_forest_prefix_blocks_def by (rule vero_aux_prefix_component_disjoint[OF DC K])
  have DIS: "set (?f (F!k))\<inter>?B = {}" using DIS0 by blast
  have PRES: "(case F!k of None \<Rightarrow> True | Some U \<Rightarrow> bn_valid t P U) \<and>
    case_option [] (bn_blocks t) (F!k) = ?f (F!k)"
    by (rule vero_aux_release_option[OF A R order_refl PS V DIS])
  have VT: "case F!k of None \<Rightarrow> True | Some U \<Rightarrow> bn_valid t P U"
    and BT: "case_option [] (bn_blocks t) (F!k) = ?f (F!k)" using PRES by blast+
  have DT: "distinct (case_option [] (bn_blocks t) (F!k))" using DK by (simp only: BT)
  have AT: "allocator_wf (phantom_machine_state_' t)" and PST: "P\<subseteq>reserved_bytes (phantom_machine_state_' t)"
    using R PS by (auto simp: vero_aux_release_def)
  have CT: "bn_contract (binomial_tree_unref' (case_option NULL bn_root (F!k))) t
    (\<lambda>r u. vero_aux_release t (set (?f (F!k))) (set (?f (F!k))) u)"
    using vero_aux_unref_option[OF AT PST VT DT] by (simp only: BT)
  have SUB: "?B\<subseteq>set (concat (map ?f F))"
    unfolding vero_aux_forest_prefix_blocks_def by (rule vero_aux_prefix_blocks_subset)
  have AN: "?a\<noteq>NULL" using R0 K by (auto simp: bn_rep_def split: if_splits)
  obtain n where LA: "live_blocks (phantom_machine_state_' s) (ptr_val ?a)=Some n"
    and SIZE: "size_of TYPE(StrictC'_BinomialTree_C ptr)*length F\<le>n"
    using R0 AN by (auto simp: bn_rep_def)
  have NA: "ptr_val ?a\<notin>?B" using D AN SUB by (auto simp: bn_owned_def)
  have HV: "h_val (hrs_mem (t_hrs_' t)) (?a +\<^sub>p int k) = h_val (hrs_mem (t_hrs_' s)) (?a +\<^sub>p int k)"
    by (rule vero_aux_release_array[OF A R LA NA SIZE K])
  have KB: "k<2^32" using K L by (simp; arith)
  have UNAT: "unat (of_nat k :: 32 word)=k"
    apply (rule unat_of_nat_eq) using KB by simp
  have UI: "uint (of_nat k :: 32 word)=int k" by (simp only: uint_nat UNAT)
  have G: "c_guard (roots_C (bn_heap t h) +\<^sub>p uint (of_nat k :: 32 word))"
    using R0 K by (simp add: HH UI bn_rep_def)
  have VAL: "h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h) +\<^sub>p uint (of_nat k :: 32 word)) = case_option NULL bn_root (F!k)"
    using R0 K by (simp add: HH UI HV bn_rep_def)
  show ?thesis unfolding vero_aux_heap_free_body_def
    apply (rule vero_aux_guard_prefix)
     apply (rule G)
    apply (rule vero_aux_gets_prefix)
    apply (simp only: VAL)
    apply (rule vero_aux_contract_bind[OF CT])
  proof -
    fix r and u :: globals
      assume RU: "vero_aux_release t (set (?f (F!k))) (set (?f (F!k))) u"
    have COMP: "vero_aux_release s (?B\<union>set (?f (F!k))) (?B\<union>set (?f (F!k))) u"
      by (rule vero_aux_release_comp[OF R RU order_refl])
    have BS: "vero_aux_forest_prefix_blocks s F (Suc k) = ?B\<union>set (?f (F!k))"
      by (simp add: vero_aux_forest_prefix_blocks_def take_Suc_conv_app_nth[OF K])
    have NH: "ptr_val h\<notin>vero_aux_forest_prefix_blocks s F (Suc k)"
      using D vero_aux_prefix_blocks_subset[where f="?f" and i="Suc k" and xs=F]
      by (auto simp: bn_owned_def vero_aux_forest_prefix_blocks_def)
    have RCOMP: "vero_aux_release s (vero_aux_forest_prefix_blocks s F (Suc k)) (vero_aux_forest_prefix_blocks s F (Suc k)) u"
      using COMP by (simp only: BS)
    have H0: "h_val (hrs_mem (t_hrs_' u)) (h +\<^sub>p int 0) = h_val (hrs_mem (t_hrs_' s)) (h +\<^sub>p int 0)"
      by (rule vero_aux_release_array[OF A RCOMP LH NH, where k=1 and i=0]) simp_all
    have HU: "bn_heap u h=bn_heap s h" using H0 by (simp add: bn_heap_def)
    show "bn_contract (return (of_nat k+1 :: 32 word)) u (\<lambda>j u.
      j=of_nat (Suc k) \<and> vero_aux_release s (vero_aux_forest_prefix_blocks s F (Suc k)) (vero_aux_forest_prefix_blocks s F (Suc k)) u \<and> bn_heap u h=bn_heap s h)"
      by (rule vero_aux_return_contract) (simp add: RCOMP HU)
  qed
qed


lemma vero_aux_heap_free_loop:
  assumes R0: "bn_rep s h P F M"
  shows "bn_contract (whileLoop (\<lambda>i u. i < roots_length_C (bn_heap u h)) (vero_aux_heap_free_body h) 0) s
    (\<lambda>j u. vero_aux_release s (set (concat (map (case_option [] (bn_blocks s)) F))) (set (concat (map (case_option [] (bn_blocks s)) F))) u \<and>
      bn_heap u h = bn_heap s h)"
proof -
  let ?I = "\<lambda>i (u::globals). \<exists>k\<le>length F. i=(of_nat k :: 32 word) \<and>
    vero_aux_release s (vero_aux_forest_prefix_blocks s F k) (vero_aux_forest_prefix_blocks s F k) u \<and> bn_heap u h=bn_heap s h"
  let ?C = "\<lambda>i u. i < roots_length_C (bn_heap u h)"
  let ?m = "\<lambda>i::32 word. length F-unat i"
  have L: "length F\<le>32" and LEN: "unat (roots_length_C (bn_heap s h))=length F"
    and A: "allocator_wf (phantom_machine_state_' s)" using R0 by (auto simp: bn_rep_def)
  have SMALL: "\<And>k. k\<le>length F \<Longrightarrow> unat (of_nat k :: 32 word)=k"
    apply (rule unat_of_nat_eq) using L by (simp; arith)
  have STEP: "\<And>i u. ?I i u \<Longrightarrow> ?C i u \<Longrightarrow>
    bn_contract (vero_aux_heap_free_body h i) u (\<lambda>j v. ?I j v \<and> ?m j < ?m i)"
  proof -
    fix i u assume INV: "?I i u" and C: "?C i u"
    obtain k where K: "k\<le>length F" and IK: "i=of_nat k"
      and RU: "vero_aux_release s (vero_aux_forest_prefix_blocks s F k) (vero_aux_forest_prefix_blocks s F k) u"
      and HU: "bn_heap u h=bn_heap s h" using INV by blast
    have KL: "k<length F" using C by (simp add: IK HU word_less_nat_alt SMALL[OF K] LEN)
    have SK: "Suc k\<le>length F" using KL by simp
    have BODY: "bn_contract (vero_aux_heap_free_body h (of_nat k)) u (\<lambda>j v. j=of_nat (Suc k) \<and>
      vero_aux_release s (vero_aux_forest_prefix_blocks s F (Suc k)) (vero_aux_forest_prefix_blocks s F (Suc k)) v \<and> bn_heap v h=bn_heap s h)"
      by (rule vero_aux_heap_free_step[OF R0 KL RU HU])
    show "bn_contract (vero_aux_heap_free_body h i) u (\<lambda>j v. ?I j v \<and> ?m j < ?m i)"
      unfolding IK
    proof (rule vero_aux_contract_weaken[OF BODY])
      fix j :: "32 word" and v :: globals
      assume JV: "j=of_nat (Suc k) \<and>
        vero_aux_release s (vero_aux_forest_prefix_blocks s F (Suc k)) (vero_aux_forest_prefix_blocks s F (Suc k)) v \<and> bn_heap v h=bn_heap s h"
      have J: "j=of_nat (Suc k)" using JV by blast
      have INVJ: "?I j v"
        apply (rule exI[where x="Suc k"]) using JV SK by blast
      have UI0: "unat (of_nat k :: 32 word)=k" by (rule SMALL[OF K])
      have UJ0: "unat j=Suc k" by (simp only: J SMALL[OF SK])
      have DEC0: "length F - Suc k < length F-k" by (rule diff_less_mono2[OF lessI KL])
      have DEC: "?m j < ?m (of_nat k)" by (simp only: UJ0 UI0 DEC0)
      show "?I j v \<and> ?m j < ?m (of_nat k)" using INVJ DEC by blast
    qed
  qed
  have EXIT: "\<And>i u. ?I i u \<Longrightarrow> \<not>?C i u \<Longrightarrow>
    vero_aux_release s (set (concat (map (case_option [] (bn_blocks s)) F))) (set (concat (map (case_option [] (bn_blocks s)) F))) u \<and>
      bn_heap u h=bn_heap s h"
  proof -
    fix i u assume INV: "?I i u" and NC: "\<not>?C i u"
    obtain k where K: "k\<le>length F" and IK: "i=of_nat k"
      and RU: "vero_aux_release s (vero_aux_forest_prefix_blocks s F k) (vero_aux_forest_prefix_blocks s F k) u"
      and HU: "bn_heap u h=bn_heap s h" using INV by blast
    have GE: "length F\<le>k" using NC by (simp add: IK HU word_less_nat_alt SMALL[OF K] LEN)
    have E: "k=length F" using K GE by arith
    show "vero_aux_release s (set (concat (map (case_option [] (bn_blocks s)) F))) (set (concat (map (case_option [] (bn_blocks s)) F))) u \<and> bn_heap u h=bn_heap s h"
      using RU HU by (simp add: E vero_aux_forest_prefix_blocks_def)
  qed
  have INIT: "?I 0 s"
    apply (rule exI[where x=0]) using vero_aux_release_refl[OF A] by (simp add: vero_aux_forest_prefix_blocks_def)
  show ?thesis by (rule vero_aux_contract_while_state[OF STEP EXIT INIT])
qed


lemma vero_aux_heap_free_cleanup:
  assumes R0: "bn_rep s h P F M"
    and R: "vero_aux_release s (set (concat (map (case_option [] (bn_blocks s)) F))) (set (concat (map (case_option [] (bn_blocks s)) F))) t"
    and HH: "bn_heap t h = bn_heap s h"
  shows "bn_contract (do {a \<leftarrow> gets (\<lambda>u. ptr_coerce (roots_C (bn_heap u h))); free' a; free' (ptr_coerce h)}) t
    (\<lambda>r u. vero_aux_release s (set (bn_owned s h F)) (set (bn_owned s h F)) u)"
proof -
  let ?B = "set (concat (map (case_option [] (bn_blocks s)) F))"
  let ?a = "roots_C (bn_heap s h)"
  have D: "distinct (bn_owned s h F)"
    and LH: "live_blocks (phantom_machine_state_' s) (ptr_val (ptr_coerce h :: unit ptr)) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using R0 by (auto simp: bn_rep_def)
  have NH: "ptr_val (ptr_coerce h :: unit ptr)\<notin>?B" using D by (simp add: bn_owned_def)
  have AT: "allocator_wf (phantom_machine_state_' t)" using R by (simp add: vero_aux_release_def)
  have C: "bn_contract (do {free' (ptr_coerce ?a); free' (ptr_coerce h)}) t
    (\<lambda>r u. vero_aux_release s (set (bn_owned s h F)) (set (bn_owned s h F)) u)"
  proof (cases "?a=NULL")
    case True
    have CH: "bn_contract (free' (ptr_coerce h)) t (\<lambda>r u. vero_aux_release s (insert (ptr_val h) ?B) (insert (ptr_val h) ?B) u)"
      using vero_aux_release_free[OF R LH NH order_refl] by simp
    show ?thesis
      apply (simp only: True vero_aux_coerce_null)
      apply (rule vero_aux_contract_bind[OF vero_aux_free_null[OF AT]])
      using CH True by (simp add: bn_owned_def)
  next
    case False
    obtain n where LA: "live_blocks (phantom_machine_state_' s) (ptr_val (ptr_coerce ?a :: unit ptr)) = Some n"
      using R0 False by (auto simp: bn_rep_def)
    have NA: "ptr_val (ptr_coerce ?a :: unit ptr)\<notin>?B" using D False by (simp add: bn_owned_def)
    have CA: "bn_contract (free' (ptr_coerce ?a)) t (\<lambda>r u. vero_aux_release s (insert (ptr_val ?a) ?B) (insert (ptr_val ?a) ?B) u)"
      using vero_aux_release_free[OF R LA NA order_refl] by simp
    show ?thesis
    proof (rule vero_aux_contract_bind[OF CA])
      fix r and u :: globals
      assume RU: "vero_aux_release s (insert (ptr_val ?a) ?B) (insert (ptr_val ?a) ?B) u"
      have NHA: "ptr_val (ptr_coerce h :: unit ptr)\<notin>insert (ptr_val ?a) ?B" using D False by (simp add: bn_owned_def)
      have CH: "bn_contract (free' (ptr_coerce h)) u
        (\<lambda>r v. vero_aux_release s (insert (ptr_val h) (insert (ptr_val ?a) ?B)) (insert (ptr_val h) (insert (ptr_val ?a) ?B)) v)"
        using vero_aux_release_free[OF RU LH NHA order_refl] by simp
      show "bn_contract (free' (ptr_coerce h)) u (\<lambda>r v. vero_aux_release s (set (bn_owned s h F)) (set (bn_owned s h F)) v)"
        using CH False by (simp add: bn_owned_def)
    qed
  qed
  show ?thesis
    apply (rule vero_aux_gets_prefix)
    using C by (simp only: HH)
qed

lemma vero_aux_heap_free_release:
  assumes R0: "bn_rep s h P F M"
  shows "bn_contract (binomial_heap_free' h) s
    (\<lambda>r t. vero_aux_release s (set (bn_owned s h F)) (set (bn_owned s h F)) t)"
proof -
  have G: "c_guard h" using R0 by (simp add: bn_rep_def)
  have LOOP: "bn_contract (whileLoop (\<lambda>i u. i < roots_length_C (bn_heap u h)) (vero_aux_heap_free_body h) 0) s
    (\<lambda>j u. vero_aux_release s (set (concat (map (case_option [] (bn_blocks s)) F))) (set (concat (map (case_option [] (bn_blocks s)) F))) u \<and>
      bn_heap u h = bn_heap s h)"
    by (rule vero_aux_heap_free_loop[OF R0])
  have TAIL: "bn_contract (do {
      i \<leftarrow> whileLoop (\<lambda>i u. i < roots_length_C (bn_heap u h)) (vero_aux_heap_free_body h) 0;
      a \<leftarrow> gets (\<lambda>u. ptr_coerce (roots_C (bn_heap u h)));
      free' a; free' (ptr_coerce h)}) s
      (\<lambda>r t. vero_aux_release s (set (bn_owned s h F)) (set (bn_owned s h F)) t)"
    apply (rule vero_aux_contract_bind[OF LOOP])
    subgoal for j u
      apply (rule vero_aux_heap_free_cleanup[OF R0]) by auto
    done
  show ?thesis
    unfolding binomial_heap_free'_def
    apply (rule vero_aux_guard_prefix)
     apply (rule G)
    using TAIL by (simp only: vero_aux_heap_free_body_def[abs_def] bn_heap_def)
qed

lemma c0024_prove:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_free' h) s (\<lambda>r t.
    bn_frame s h P F t \<and> allocator_wf (phantom_machine_state_' t) \<and>
    live_blocks (phantom_machine_state_' t) =
      (\<lambda>p. if p \<in> set (bn_owned s h F) then None else live_blocks (phantom_machine_state_' s) p))"

proof -
  assume R: "bn_rep s h P F M"
  have PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)" using R by (simp add: bn_rep_def)
  show ?thesis
  proof (rule vero_aux_contract_weaken[OF vero_aux_heap_free_release[OF R]])
    fix r and t :: globals
    assume REL: "vero_aux_release s (set (bn_owned s h F)) (set (bn_owned s h F)) t"
    have A: "allocator_wf (phantom_machine_state_' t)"
      and RS: "reserved_bytes (phantom_machine_state_' t)=reserved_bytes (phantom_machine_state_' s)"
      and LB: "\<forall>q. live_blocks (phantom_machine_state_' t) q = (if q\<in>set (bn_owned s h F) then None else live_blocks (phantom_machine_state_' s) q)"
      and PB0: "\<forall>a\<in>reserved_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) a=hrs_mem (t_hrs_' s) a"
      and MB: "\<forall>q n. live_blocks (phantom_machine_state_' s) q=Some n \<longrightarrow> q\<notin>set (bn_owned s h F) \<longrightarrow> (\<forall>a\<in>block_bytes q n. hrs_mem (t_hrs_' t) a=hrs_mem (t_hrs_' s) a)"
      using REL unfolding vero_aux_release_def by blast+
    have PB: "\<forall>a\<in>P. hrs_mem (t_hrs_' t) a=hrs_mem (t_hrs_' s) a" using PS PB0 by blast
    have OUT: "\<forall>q n. live_blocks (phantom_machine_state_' s) q=Some n \<longrightarrow> q\<notin>set (bn_owned s h F) \<longrightarrow>
      live_blocks (phantom_machine_state_' t) q=Some n \<and> (\<forall>a\<in>block_bytes q n. hrs_mem (t_hrs_' t) a=hrs_mem (t_hrs_' s) a)"
      using LB MB by auto
    have FRAME: "bn_frame s h P F t" using RS PB OUT unfolding bn_frame_def by blast
    have LF: "live_blocks (phantom_machine_state_' t) = (\<lambda>q. if q\<in>set (bn_owned s h F) then None else live_blocks (phantom_machine_state_' s) q)"
      by (rule ext; rule LB[rule_format])
    show "bn_frame s h P F t \<and> allocator_wf (phantom_machine_state_' t) \<and>
      live_blocks (phantom_machine_state_' t) = (\<lambda>q. if q\<in>set (bn_owned s h F) then None else live_blocks (phantom_machine_state_' s) q)"
      using FRAME A LF by blast
  qed
qed



end

context binomial_heap_input_global_addresses begin

lemma vero_aux_stack_live_array:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   S \<subseteq> reserved_bytes A \<Longrightarrow> bytes_frame S hp hp' \<Longrightarrow>
   h_val hp' (p +\<^sub>p int i) = h_val hp (p +\<^sub>p int i)"



proof -
  assume A: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and K: "size_of TYPE('a) * k \<le> n" and I: "i < k"
    and S: "S \<subseteq> reserved_bytes A" and F: "bytes_frame S hp hp'"
  have B: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"
    using c0008_prove[OF A L K I] .
  have D: "block_bytes (ptr_val p) n \<inter> reserved_bytes A = {}"
    using A L unfolding allocator_wf_def by blast
  show ?thesis
    apply (rule vero_aux_stack_h_val_agree)
    using B D S F by (auto simp: bytes_frame_def)
qed

lemma vero_aux_stack_live_h_val:
  fixes p :: "'a::mem_type ptr"
  assumes W: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and SZ: "size_of TYPE('a) \<le> n" and SS: "S \<subseteq> reserved_bytes A"
    and BF: "bytes_frame S hp hp'"
  shows "h_val hp' p = h_val hp p"
proof -
  have "h_val hp' (p +\<^sub>p int 0) = h_val hp (p +\<^sub>p int 0)"
    by (rule vero_aux_stack_live_array[OF W L, where k=1 and i=0 and S=S]) (simp_all add: SZ SS BF)
  thus ?thesis by simp
qed




lemma vero_aux_contract_exit:
  "bn_contract f s P \<Longrightarrow> (\<And>v t. P v t \<Longrightarrow> \<exists>u. (t,u) \<in> R) \<Longrightarrow> (\<And>v t u. P v t \<Longrightarrow> (t,u) \<in> R \<Longrightarrow> Q v u) \<Longrightarrow> bn_contract (on_exit f R) s Q"
proof -
  assume F: "bn_contract f s P"
    and E: "\<And>v t. P v t \<Longrightarrow> \<exists>u. (t,u) \<in> R"
    and H: "\<And>v t u. P v t \<Longrightarrow> (t,u) \<in> R \<Longrightarrow> Q v u"
  have FR: "runs_to f s (\<lambda>r t. \<exists>v. r = Result v \<and> P v t)"
    using F by (simp add: bn_contract_def)
  have W1: "runs_to f s (\<lambda>r t. (\<exists>u. (t,u) \<in> R) \<and>
      (\<forall>u. (t,u) \<in> R \<longrightarrow> (\<exists>v. r = Result v \<and> Q v u)))"
    apply (rule runs_to_weaken[OF FR])
    using E H by auto
  have W2: "runs_to f s (\<lambda>r t. \<exists>u. (t,u) \<in> R)"
    by (rule runs_to_weaken[OF W1]) auto
  obtain v t where FV: "reaches f s (Result v) t"
    using F by (auto simp: bn_contract_def)
  have PV: "P v t" using runs_toD2[OF FR FV] by (simp add: Result_eq_Result)
  obtain u where RU: "(t,u) \<in> R" using E[OF PV] by blast
  have RE: "\<exists>v u t. reaches f s (Result v) t \<and> (\<exists>b. (t,b) \<in> R) \<and> (t,u) \<in> R"
    using FV RU by blast
  show ?thesis using W1 W2 RE
    by (auto simp: bn_contract_def on_exit_def on_exit'_def
      runs_to_bind_exception_or_result_iff runs_to_bind_iff runs_to_yield_iff
      runs_to_assert_result_and_state_iff runs_to_assume_result_and_state_iff
      reaches_bind_exception_or_result reaches_bind succeeds_runs_to_iff
      reaches_assert_result_and_state reaches_assume_result_and_state reaches_yield[abs_def])
qed

lemma vero_aux_contract_assume:
  "R s \<noteq> {} \<Longrightarrow> (\<And>v t. (v,t) \<in> R s \<Longrightarrow> Q v t) \<Longrightarrow> bn_contract (assume_result_and_state R) s Q"
by (auto simp: bn_contract_def runs_to_assume_result_and_state_iff reaches_assume_result_and_state)

lemma vero_aux_stack_one:
  fixes c :: "'a::mem_type ptr \<Rightarrow> ('e::default, 'b, 'c globals_scheme) spec_monad"
  shows "globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) c =
    (assume_result_and_state (\<lambda>s. {(p,t). \<exists>d v bs.
       (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<and>
       length bs = size_of TYPE('a) \<and>
       t = t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
         (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)}) >>= (\<lambda>p.
    on_exit (c p) {(t,u). \<exists>bs. length bs = size_of TYPE('a) \<and>
       u = t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs))
         (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)}))"
  apply (simp add: globals.with_fresh_stack_ptr_def length_Suc_conv)
  apply (rule arg_cong[where f="\<lambda>a. Spec_Monad.bind a _"])
  apply (rule arg_cong[where f=assume_result_and_state])
  apply (rule ext)
  apply auto
  subgoal for s a d y bs
    apply (rule exI[where x=d])
    apply (rule conjI)
    apply assumption
    apply (rule exI[where x=y])
    apply (rule exI[where x=bs])
    by simp
  subgoal for s a d v bs
    apply (rule exI[where x=d])
    apply (rule conjI)
    apply assumption
    apply (rule exI[where x="[v]"])
    apply (rule conjI)
    apply simp
    apply (rule exI[where x=bs])
    by simp
  done


lemma vero_aux_stack_contract:
  "stack_allocs 1 \<S> TYPE('a::mem_type) (hrs_htd (t_hrs_' s)) \<noteq> {} \<Longrightarrow>
   (\<And>p d v bs.
      (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
      length bs = size_of TYPE('a) \<Longrightarrow>
      bn_contract ((c :: 'a ptr \<Rightarrow> ('e::default, 'b, 'c globals_scheme) spec_monad) p)
        (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))
        (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE('a) \<longrightarrow>
          Q r (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)))) \<Longrightarrow>
   bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) c) s Q"
proof -
  assume NE: "stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<noteq> {}"
    and H: "\<And>p d v bs. (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
      length bs = size_of TYPE('a) \<Longrightarrow>
      bn_contract (c p) (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
        (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))
        (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE('a) \<longrightarrow>
          Q r (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)))"
  let ?A = "\<lambda>s. {(p,t). \<exists>d v bs.
       (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<and>
       length bs = size_of TYPE('a) \<and>
       t = t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
         (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)}"
  let ?R = "\<lambda>p. {(t,u). \<exists>bs. length bs = size_of TYPE('a) \<and>
       u = t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs))
         (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)}"
  obtain p d where PD: "(p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s))"
    using NE by auto
  let ?bs = "replicate (size_of TYPE('a)) 0"
  let ?t = "t_hrs_'_update (hrs_mem_update (heap_update_padding p undefined ?bs))
         (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)"
  have IN: "(p,?t) \<in> ?A s"
    apply (simp only: mem_Collect_eq case_prod_conv)
    apply (rule exI[where x=d])
    apply (rule exI[where x=undefined])
    apply (rule exI[where x="?bs"])
    using PD by simp
  have ANE: "?A s \<noteq> {}" using IN by blast
  have INITIAL: "bn_contract (assume_result_and_state ?A) s (\<lambda>p t. (p,t) \<in> ?A s)"
    apply (rule vero_aux_contract_assume)
    apply (rule ANE)
    by assumption
  have CONT: "\<And>p t. (p,t) \<in> ?A s \<Longrightarrow> bn_contract (on_exit (c p) (?R p)) t Q"
  proof -
    fix p t assume PT: "(p,t) \<in> ?A s"
    obtain d v bs where D: "(p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s))"
      and BS: "length bs = size_of TYPE('a)"
      and T: "t = t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
         (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)" using PT by auto
    show "bn_contract (on_exit (c p) (?R p)) t Q"
      apply (rule vero_aux_contract_exit[OF H[where p=p and d=d and v=v and bs=bs, OF D BS, folded T]])
      subgoal for r u
        apply (rule exI[where x="t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) ?bs))
         (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) u)"])
        by (auto intro!: exI[where x="?bs"])
      by auto
  qed
  show ?thesis unfolding vero_aux_stack_one
    by (rule vero_aux_contract_bind[OF INITIAL CONT])
qed



lemma vero_aux_payload_key_frame:
  assumes V: "bn_payload P v" and PS: "P \<inter> S = {}"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
  shows "bn_key t v = bn_key s v"
proof -
  let ?p = "ptr_coerce v :: 32 signed word ptr"
  have G: "c_guard ?p" and B: "block_bytes (ptr_val ?p) 4 \<subseteq> P"
    using V by (auto simp: bn_payload_def)
  have SP: "ptr_span ?p \<subseteq> P"
    using B intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]]
    by (simp add: block_bytes_def)
  have HV: "h_val (hrs_mem (t_hrs_' t)) ?p = h_val (hrs_mem (t_hrs_' s)) ?p"
    apply (rule vero_aux_stack_h_val_agree)
    using SP PS BF by (auto simp: bytes_frame_def)
  show ?thesis by (simp add: bn_key_def HV)
qed

lemma vero_aux_valid_reserved_frame:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and SS: "S \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and PS: "P \<inter> S = {}"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
    and V: "bn_valid s P T"
  shows "bn_valid t P T \<and> bn_values t T = bn_values s T \<and>
    bn_blocks t T = bn_blocks s T \<and>
    (\<forall>v \<in> set (bn_values s T). bn_key t v = bn_key s v)"
  using V
proof (induction T)
  case (BN p cs)
  have L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using BN.prems by simp
  have TP: "bn_tree t p = bn_tree s p"
    unfolding bn_tree_def by (rule vero_aux_stack_live_h_val[OF W L _ SS BF]) simp
  have CHILD: "\<forall>U \<in> set cs. bn_valid t P U \<and> bn_values t U = bn_values s U \<and>
    bn_blocks t U = bn_blocks s U \<and> (\<forall>v \<in> set (bn_values s U). bn_key t v = bn_key s v)"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  have VC: "map (bn_values t) cs = map (bn_values s) cs"
    using CHILD by (auto intro!: map_cong)
  have BC: "map (bn_blocks t) cs = map (bn_blocks s) cs"
    using CHILD by (auto intro!: map_cong)
  have PAY: "bn_payload P (value_C (bn_tree s p))" using BN.prems by simp
  have KC: "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
    by (rule vero_aux_payload_key_frame[OF PAY PS BF])
  have ARR: "\<forall>i < length cs. h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
  proof (intro allI impI)
    fix i assume I: "i < length cs"
    have NE: "cs \<noteq> []" using I by auto
    have AL: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
      Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length cs)"
      using BN.prems NE by simp
    show "h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
      by (rule vero_aux_stack_live_array[OF W AL _ I SS BF]) simp
  qed
  show ?case using BN.prems CHILD TP VC BC KC ARR A
    by (auto simp: list_all_iff VC BC)
qed

lemma vero_aux_rep_reserved_frame:
  assumes R: "bn_rep s h P F M"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and SS: "S \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and PS: "P \<inter> S = {}"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
  shows "bn_rep t h P F M"
proof -
  have W: "allocator_wf (phantom_machine_state_' s)"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using R by (auto simp: bn_rep_def)
  have H: "bn_heap t h = bn_heap s h"
    unfolding bn_heap_def by (rule vero_aux_stack_live_h_val[OF W L _ SS BF]) simp
  have VS: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid s P T"
    using R by (auto simp: bn_rep_def in_set_conv_nth)
  have VT: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid t P T \<and>
      bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"
    using VS vero_aux_valid_reserved_frame[OF W A SS PS BF] by blast
  have MV: "map (case_option [] (bn_values t)) F = map (case_option [] (bn_values s)) F"
    using VT by (auto intro!: map_cong split: option.splits)
  have MB: "map (case_option [] (bn_blocks t)) F = map (case_option [] (bn_blocks s)) F"
    using VT by (auto intro!: map_cong split: option.splits)
  have FV: "bn_forest_values t F = bn_forest_values s F" by (simp add: bn_forest_values_def MV)
  have OWN: "bn_owned t h F = bn_owned s h F" by (simp add: bn_owned_def H MB)
  have ARR: "\<forall>i < length F. h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)"
  proof (intro allI impI)
    fix i assume I: "i < length F"
    have NN: "roots_C (bn_heap s h) \<noteq> NULL" using R I by (auto simp: bn_rep_def)
    obtain n where RL: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
      and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F \<le> n"
      using R NN by (auto simp: bn_rep_def)
    have "h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap s h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)"
      by (rule vero_aux_stack_live_array[OF W RL SZ I SS BF])
    thus "h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)" by (simp add: H)
  qed
  show ?thesis using R A H FV OWN ARR VT
    by (auto simp: bn_rep_def split: option.splits dest: nth_mem)
qed

lemma vero_aux_stack_bytes:
  "ptr_span (p :: 'a::mem_type ptr) \<subseteq> S \<Longrightarrow>
   length bs = size_of TYPE('a) \<Longrightarrow>
   bytes_frame S hp (heap_update_padding p v bs hp) \<and>
   bytes_frame S hp (heap_update_list (ptr_val p) bs hp)"
  by (auto simp: bytes_frame_def heap_update_padding_def intro!: heap_update_nmem_same)

lemma vero_aux_stack_frame:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   P \<inter> S = {} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_frame s h P F t"



by (auto simp: bn_frame_def allocator_wf_def bytes_frame_def; blast)



lemma vero_aux_heap_stack_cleanup:
  fixes p :: "StrictC'_BinomialHeap_C ptr"
  assumes R: "bn_rep s h P F M" and SS: "\<S> \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and PS: "P \<inter> \<S> = {}"
    and PD: "(p,d) \<in> stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s))"
    and LEN: "length bs = size_of TYPE(StrictC'_BinomialHeap_C)"
    and LEN': "length bs' = size_of TYPE(StrictC'_BinomialHeap_C)"
    and U: "u = t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
      (t_hrs_'_update (hrs_htd_update (stack_releases 1 p))
        (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)))"
  shows "bn_rep u h P F M \<and> bn_frame s h P F u \<and>
    phantom_machine_state_' u = phantom_machine_state_' s \<and>
    hrs_htd (t_hrs_' u) = hrs_htd (t_hrs_' s)"
proof -
  have W: "allocator_wf (phantom_machine_state_' s)" using R by (simp add: bn_rep_def)
  have SP: "ptr_span p \<subseteq> \<S>" using CLanguage.stack_allocs_\<S>[OF PD, where i=0] by simp
  have INV: "stack_releases 1 p d = hrs_htd (t_hrs_' s)"
    by (rule stack_releases_stack_allocs_inverse[OF PD])
  have AP: "phantom_machine_state_' u = phantom_machine_state_' s" using U by simp
  have BF1: "bytes_frame \<S> (hrs_mem (t_hrs_' s)) (heap_update_padding p v bs (hrs_mem (t_hrs_' s)))"
    using vero_aux_stack_bytes[OF SP LEN] by blast
  have BF2: "bytes_frame \<S> (heap_update_padding p v bs (hrs_mem (t_hrs_' s)))
    (heap_update_list (ptr_val p) bs' (heap_update_padding p v bs (hrs_mem (t_hrs_' s))))"
    using vero_aux_stack_bytes[OF SP LEN'] by blast
  have BF: "bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' u))"
    using BF1 BF2 U by (auto simp: bytes_frame_def hrs_mem_def hrs_mem_update_def hrs_htd_update_def case_prod_unfold)
  have REP: "bn_rep u h P F M" by (rule vero_aux_rep_reserved_frame[OF R AP SS PS BF])
  have FR: "bn_frame s h P F u" by (rule vero_aux_stack_frame[OF W SS PS AP BF])
  have HT: "hrs_htd (t_hrs_' u) = hrs_htd (t_hrs_' s)"
    using INV U by (simp add: hrs_htd_def hrs_mem_update_def hrs_htd_update_def case_prod_unfold)
  show ?thesis using REP FR AP HT by blast
qed



lemma vero_aux_stack_frame_contract:
  assumes NE: "stack_allocs 1 \<S> TYPE('a::mem_type) (hrs_htd (t_hrs_' s)) \<noteq> {}"
    and H: "\<And>p d v bs. (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
      length bs = size_of TYPE('a) \<Longrightarrow>
      bn_contract ((c :: 'a ptr \<Rightarrow> ('e::default, 'b, 'c globals_scheme) spec_monad) p)
        (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))
        (\<lambda>r t. r = x \<and> phantom_machine_state_' t = phantom_machine_state_' s \<and>
          bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"
  shows "bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) c) s
    (\<lambda>r t. r = x \<and> phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"
proof (rule vero_aux_stack_contract[OF NE])
  fix p d v and bs :: "8 word list"
  assume PD: "(p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s))"
    and LEN: "length bs = size_of TYPE('a)"
  let ?a = "t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
    (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)"
  have SP: "ptr_span p \<subseteq> \<S>" using CLanguage.stack_allocs_\<S>[OF PD, where i=0] by simp
  show "bn_contract (c p) ?a (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE('a) \<longrightarrow>
    r = x \<and> phantom_machine_state_' (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
      (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)) = phantom_machine_state_' s \<and>
    bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' (t_hrs_'_update
      (hrs_mem_update (heap_update_list (ptr_val p) bs'))
      (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)))))"
    apply (rule vero_aux_contract_weaken[OF H[OF PD LEN]])
    using vero_aux_stack_bytes[OF SP]
    by (auto simp: bytes_frame_def hrs_mem_def hrs_mem_update_def hrs_htd_update_def case_prod_unfold)
qed

lemma vero_aux_malloc_fail:
  assumes W: "allocator_wf (phantom_machine_state_' s)" and N: "0 < unat n"
    and NF: "\<And>p. \<not> fresh_block (phantom_machine_state_' s) p (unat n)"
  shows "bn_contract (malloc' n) s (\<lambda>r t. r = NULL \<and> t = s)"
proof -
  have REL: "\<And>p m A. malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) p m A
    \<longleftrightarrow> p=0 \<and> m=hrs_mem (t_hrs_' s) \<and> A=phantom_machine_state_' s"
    using W N NF by (auto simp: malloc_rel_def)
  have Z: "\<And>p :: unit ptr. ptr_val p = 0 \<longleftrightarrow> p = NULL"
    by (case_tac p) (simp add: ptr_val_def)
  show ?thesis
    by (auto simp: bn_contract_def malloc'_def binomial_heap_input.malloc.size_'_def REL[unfolded hrs_mem_def] W N Z runs_to_bind_iff runs_to_guard_iff
      runs_to_assume_result_and_state_iff reaches_bind reaches_guard reaches_assume_result_and_state
      hrs_mem_update_def hrs_mem_def case_prod_unfold succeeds_runs_to_iff)
qed


lemma vero_aux_insert_fail_body:
  fixes p :: "StrictC'_BinomialTree_C ptr ptr"
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and NF: "\<And>q. \<not> fresh_block (phantom_machine_state_' s) q (size_of TYPE(StrictC'_BinomialTree_C))"
    and G: "c_guard p" and SP: "ptr_span p \<subseteq> \<S>"
  shows "bn_contract (do {
      q \<leftarrow> malloc' (word_of_nat (size_of TYPE(StrictC'_BinomialTree_C)));
      guard (\<lambda>_. c_guard p);
      modify (t_hrs_'_update (hrs_mem_update (heap_update p (ptr_coerce q))));
      condition (\<lambda>t. h_val (hrs_mem (t_hrs_' t)) p = NULL) (return 0) (f q)
    }) s (\<lambda>r t. r = 0 \<and> phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"
proof -
  have MAL: "bn_contract (malloc' (word_of_nat (size_of TYPE(StrictC'_BinomialTree_C)))) s
      (\<lambda>q t. q = NULL \<and> t = s)"
    using NF by (intro vero_aux_malloc_fail[OF W]) simp_all
  have BF: "bytes_frame \<S> (hrs_mem (t_hrs_' s))
    (heap_update p (NULL :: StrictC'_BinomialTree_C ptr) (hrs_mem (t_hrs_' s)))"
    using SP by (auto simp: bytes_frame_def heap_update_def intro!: heap_update_nmem_same)
  show ?thesis
    apply (rule vero_aux_contract_bind[OF MAL])
    using G BF
    by (auto simp: bn_contract_def runs_to_bind_iff runs_to_guard_iff runs_to_modify_iff
      runs_to_condition_iff reaches_bind reaches_guard reaches_modify reaches_condition_iff
      reaches_return[abs_def] succeeds_runs_to_iff hrs_mem_update_def hrs_mem_def case_prod_unfold
      h_val_heap_update)
qed


lemma vero_aux_stack_acquire_frame:
  "(p,d) \<in> stack_allocs 1 \<S> TYPE('a::mem_type) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
   length bs = size_of TYPE('a) \<Longrightarrow>
   bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_'
     (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
       (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))))"
proof -
  assume PD: "(p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s))"
    and LEN: "length bs = size_of TYPE('a)"
  have SP: "ptr_span p \<subseteq> \<S>" using CLanguage.stack_allocs_\<S>[OF PD, where i=0] by simp
  show ?thesis using vero_aux_stack_bytes[OF SP LEN]
    by (simp add: hrs_mem_def hrs_mem_update_def hrs_htd_update_def case_prod_unfold)
qed


lemma vero_aux_stack_prefix:
  "runs_to (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) f) s Q \<Longrightarrow>
   ((p :: 'a::xmem_type ptr),d) \<in>
     stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
   runs_to (f p) (s\<lparr>t_hrs_' := (hrs_mem (t_hrs_' s), d)\<rparr>) (\<lambda>_ _. True)"
proof -
  assume H: "runs_to (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) f) s Q"
    and PD: "(p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s))"
  let ?hp = "hrs_mem (t_hrs_' s)"
  let ?bs = "heap_list ?hp (size_of TYPE('a)) (ptr_val p)"
  let ?v = "h_val ?hp p"
  let ?R = "\<lambda>p. {(t,u). \<exists>bs. length bs = size_of TYPE('a) \<and>
       u = t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs))
         (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)}"
  have ALL: "\<forall>p d v bs. (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<longrightarrow>
    length bs = size_of TYPE('a) \<longrightarrow>
    runs_to (on_exit (f p) (?R p))
      (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
        (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)) Q"
    using H unfolding vero_aux_stack_one
    by (auto simp: runs_to_bind_iff runs_to_assume_result_and_state_iff; blast)
  have PAD: "heap_update_padding p ?v ?bs ?hp = ?hp"
    unfolding heap_update_padding_def h_val_def
    apply (subst to_bytes_from_bytes_id)
    apply simp
    apply (rule heap_update_list_id')
    by (rule refl)
  have EQ: "t_hrs_'_update (hrs_mem_update (heap_update_padding p ?v ?bs))
        (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s) =
        s\<lparr>t_hrs_' := (?hp,d)\<rparr>"
    by (simp add: hrs_mem_update_def hrs_htd_update_def hrs_mem_def case_prod_unfold PAD[unfolded hrs_mem_def])
  have RUN: "runs_to (on_exit (f p) (?R p)) (s\<lparr>t_hrs_' := (?hp,d)\<rparr>) Q"
    using ALL[rule_format, where p=p and d=d and v="?v" and bs="?bs"] PD by (simp only: EQ heap_list_length; blast)
  show ?thesis
    by (rule runs_to_weaken[OF RUN[unfolded on_exit_def runs_to_on_exit'_iff]]) simp
qed

lemma c0025_prove:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    (\<And>p. \<not> fresh_block (phantom_machine_state_' s) p (size_of TYPE(StrictC'_BinomialTree_C))) \<Longrightarrow>
    bn_contract (binomial_heap_insert' h v) s (\<lambda>r t.
      r = 0 \<and> bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

proof -
  assume R: "bn_rep s h P F M" and BS: "bn_stack_ready \<S> s" and PS: "P \<inter> \<S> = {}"
    and NF: "\<And>q. \<not> fresh_block (phantom_machine_state_' s) q (size_of TYPE(StrictC'_BinomialTree_C))"
  have W: "allocator_wf (phantom_machine_state_' s)" using R by (simp add: bn_rep_def)
  have SS: "\<S> \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and NE: "stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<noteq> {}"
    using BS by (auto simp: bn_stack_ready_def)
  have RAW: "bn_contract (binomial_heap_insert' h v) s
    (\<lambda>r t. r=0 \<and> phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"
    unfolding binomial_heap_insert'_def
    apply (rule vero_aux_stack_frame_contract[OF NE])
    subgoal premises OUT for p d pv bs
    proof -
      have PD: "(p,d) \<in> stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s))"
        by (rule OUT(1))
      have LEN: "length bs = size_of TYPE(StrictC'_BinomialHeap_C)" by (rule OUT(2))
      let ?a = "t_hrs_'_update (hrs_mem_update (heap_update_padding p pv bs))
        (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)"
      have AP: "phantom_machine_state_' ?a = phantom_machine_state_' s" by simp
      have BF: "bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' ?a))"
        by (rule vero_aux_stack_acquire_frame[OF PD LEN])
      have NE2: "stack_allocs 1 \<S> TYPE(StrictC'_BinomialTree_C ptr) (hrs_htd (t_hrs_' ?a)) \<noteq> {}"
        using BS PD by (auto simp: bn_stack_ready_def hrs_htd_update_def hrs_mem_update_def hrs_htd_def case_prod_unfold)
      show ?thesis
        apply (rule vero_aux_contract_weaken[where P="\<lambda>r t. r=0 \<and>
          phantom_machine_state_' t = phantom_machine_state_' ?a \<and>
          bytes_frame \<S> (hrs_mem (t_hrs_' ?a)) (hrs_mem (t_hrs_' t))"])
         apply (rule vero_aux_stack_frame_contract[OF NE2])
        subgoal premises INNER for q e qv cs
        proof -
          have QE: "(q,e) \<in> stack_allocs 1 \<S> TYPE(StrictC'_BinomialTree_C ptr) (hrs_htd (t_hrs_' ?a))"
            by (rule INNER(1))
          have CL: "length cs = size_of TYPE(StrictC'_BinomialTree_C ptr)" by (rule INNER(2))
          let ?b = "t_hrs_'_update (hrs_mem_update (heap_update_padding q qv cs))
            (t_hrs_'_update (hrs_htd_update (\<lambda>_. e)) ?a)"
          have BP: "phantom_machine_state_' ?b = phantom_machine_state_' s" by simp
          have BF2: "bytes_frame \<S> (hrs_mem (t_hrs_' ?a)) (hrs_mem (t_hrs_' ?b))"
            by (rule vero_aux_stack_acquire_frame[OF QE CL])
          have G: "c_guard q" using QE by (auto elim: stack_allocs_cases)
          have SP: "ptr_span q \<subseteq> \<S>" using CLanguage.stack_allocs_\<S>[OF QE, where i=0] by simp
          have WB: "allocator_wf (phantom_machine_state_' ?b)" using W by simp
          have NFB: "\<And>z. \<not> fresh_block (phantom_machine_state_' ?b) z (size_of TYPE(StrictC'_BinomialTree_C))"
            using NF by simp
          show ?thesis
            apply (rule vero_aux_contract_weaken)
             apply (rule vero_aux_insert_fail_body[OF WB NFB G SP])
            using BF2 by (auto simp: bytes_frame_def)
        qed
        subgoal using AP BF by (auto simp: bytes_frame_def)
        done
    qed
    done
  show ?thesis
    apply (rule vero_aux_contract_weaken[OF RAW])
    using vero_aux_rep_reserved_frame[OF R _ SS PS] vero_aux_stack_frame[OF W SS PS]
    by blast
qed



end

context binomial_heap_input_global_addresses begin



lemma c0026_prove:
  "bn_rep s h P F M \<Longrightarrow> bn_review_scan_prefix s F 0 None"

by (simp add: bn_review_scan_prefix_def)



end



lemma c0027_prove:
  "length (bn_values s (BN p cs)) = Suc (sum_list (map (\<lambda>T. length (bn_values s T)) cs))"

by (simp add: length_concat o_def)



context Calg_Binomial_Reviewed_Stack begin

lemma vero_aux_stack_byte_guard:
  "a\<noteq>0 \<Longrightarrow> c_guard (Ptr a :: stack_byte ptr)"
  by (simp add: c_guard_def c_null_guard_def ptr_aligned_def intvl_Suc_eq)

lemma vero_aux_stack_byte_after_header:
  fixes p :: "StrictC'_BinomialHeap_C ptr"
  assumes A: "a\<noteq>0" and OUT: "a\<notin>ptr_span p"
  shows "root_ptr_valid (ptr_force_type p stack_byte_typing) (Ptr a :: stack_byte ptr)"
  using vero_aux_stack_byte_guard[OF A] OUT
  by (simp add: root_ptr_valid_def valid_root_footprint_ptr_force_type_iff
    stack_byte_typing_valid_root_footprint disjnt_def intvl_Suc_eq)

lemma vero_aux_stack_header_type:
  "typ_uinfo_t TYPE(StrictC'_BinomialHeap_C) \<noteq> typ_uinfo_t TYPE(stack_byte)"
proof
  assume E: "typ_uinfo_t TYPE(StrictC'_BinomialHeap_C)=typ_uinfo_t TYPE(stack_byte)"
  have "size_td (typ_uinfo_t TYPE(StrictC'_BinomialHeap_C))=size_td (typ_uinfo_t TYPE(stack_byte))"
    by (rule arg_cong[OF E])
  then show False by (simp add: size_of_tag)
qed

lemma vero_aux_stack_pointer_type:
  "typ_uinfo_t TYPE(StrictC'_BinomialTree_C ptr) \<noteq> typ_uinfo_t TYPE(stack_byte)"
proof
  assume E: "typ_uinfo_t TYPE(StrictC'_BinomialTree_C ptr)=typ_uinfo_t TYPE(stack_byte)"
  have "size_td (typ_uinfo_t TYPE(StrictC'_BinomialTree_C ptr))=size_td (typ_uinfo_t TYPE(stack_byte))"
    by (rule arg_cong[OF E])
  then show False by (simp add: size_of_tag)
qed

lemma vero_aux_stack_header_allocation:
  "(Ptr 4096, ptr_force_type (Ptr 4096 :: StrictC'_BinomialHeap_C ptr) stack_byte_typing)
    \<in> stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) stack_byte_typing"
proof -
  let ?p = "Ptr 4096 :: StrictC'_BinomialHeap_C ptr"
  have G: "c_guard ?p" by (rule vero_aux_guard_bounds) simp_all
  have SP: "ptr_span ?p \<subseteq> \<S>"
    by (simp only: audit_stack_configuration vero_aux_span_block[OF G];
      auto simp: audit_stack_addresses_def block_bytes_def)
  have FREE: "\<forall>a\<in>ptr_span ?p. root_ptr_valid stack_byte_typing (Ptr a :: stack_byte ptr)"
  proof (intro ballI)
    fix a assume A: "a\<in>ptr_span ?p"
    have NZ: "a\<noteq>0" using G A by (auto simp: c_guard_def c_null_guard_def)
    show "root_ptr_valid stack_byte_typing (Ptr a :: stack_byte ptr)"
      by (rule stack_heap_typing_root_ptr_valid_footprint; rule vero_aux_stack_byte_guard[OF NZ])
  qed
  have PA: "ptr_aligned ?p" using G by (simp add: c_guard_def)
  show ?thesis using SP FREE PA vero_aux_stack_header_type
    by (auto simp: stack_allocs_def)
qed

lemma vero_aux_stack_second_choice:
  fixes p :: "StrictC'_BinomialHeap_C ptr"
  assumes PD: "(p,d)\<in>stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) stack_byte_typing"
  defines "q \<equiv> (if unat (ptr_val p)\<le>4104 then Ptr 4144 else Ptr 4096) :: StrictC'_BinomialTree_C ptr ptr"
  shows "(q,ptr_force_type q d)\<in>stack_allocs 1 \<S> TYPE(StrictC'_BinomialTree_C ptr) d"
proof -
  have GP: "c_guard p" using PD by (auto elim: stack_allocs_cases)
  have DE: "d=ptr_force_type p stack_byte_typing"
    using stack_allocs_ptr_force_type[OF PD] by simp
  have GQ: "c_guard q"
    unfolding q_def by (cases "unat (ptr_val p)\<le>4104"; rule vero_aux_guard_bounds) simp_all
  have SQ: "ptr_span q \<subseteq> \<S>"
    apply (simp only: audit_stack_configuration vero_aux_span_block[OF GQ])
    unfolding q_def by (auto simp: audit_stack_addresses_def block_bytes_def)
  have D: "ptr_span q \<inter> ptr_span p={}"
    apply (rule vero_aux_separated_spans[OF GQ GP])
    unfolding q_def by (auto; arith)
  have FREE: "\<forall>a\<in>ptr_span q. root_ptr_valid d (Ptr a :: stack_byte ptr)"
  proof (intro ballI)
    fix a assume A: "a\<in>ptr_span q"
    have NZ: "a\<noteq>0" using GQ A by (auto simp: c_guard_def c_null_guard_def)
    have OUT: "a\<notin>ptr_span p" using A D by blast
    show "root_ptr_valid d (Ptr a :: stack_byte ptr)"
      by (simp only: DE; rule vero_aux_stack_byte_after_header[OF NZ OUT])
  qed
  have PA: "ptr_aligned q" using GQ by (simp add: c_guard_def)
  show ?thesis using SQ FREE PA vero_aux_stack_pointer_type by (auto simp: stack_allocs_def)
qed

lemma vero_aux_stack_ready_typing:
  assumes RES: "\<S>\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and HT: "hrs_htd (t_hrs_' s)=stack_byte_typing"
  shows "bn_stack_ready \<S> s"
proof -
  have FIRST: "stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) stack_byte_typing \<noteq> {}"
    using vero_aux_stack_header_allocation by blast
  have SECOND: "\<forall>p d. (p,d)\<in>stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) stack_byte_typing \<longrightarrow>
    stack_allocs 1 \<S> TYPE(StrictC'_BinomialTree_C ptr) d \<noteq> {}"
    using vero_aux_stack_second_choice by blast
  show ?thesis using RES HT FIRST SECOND by (simp add: bn_stack_ready_def)
qed






definition vero_aux_insert_header where
  "vero_aux_insert_header a =
    StrictC'_BinomialHeap_C BINOMIAL_HEAP_TYPE_MIN binomial_heap_input.int_compare 1 a 1"

definition vero_aux_insert_leaf where
  "vero_aux_insert_leaf = StrictC'_BinomialTree_C (Ptr 192) 0 1 NULL"

definition vero_aux_insert_mem :: heap_mem where
  "vero_aux_insert_mem =
    heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr) (vero_aux_insert_header (Ptr 560))
    (heap_update (Ptr 64 :: StrictC'_BinomialTree_C ptr) vero_aux_insert_leaf
    (heap_update (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 64) (\<lambda>_. 0)))"

definition vero_aux_insert_allocator :: calg_allocator where
  "vero_aux_insert_allocator = \<lparr>
    live_blocks=(\<lambda>q. if q=16 then Some 40 else if q=64 then Some 24 else if q=560 then Some 8 else None),
    reserved_bytes=block_bytes 192 4 \<union> audit_stack_addresses\<rparr>"

definition vero_aux_insert_state where
  "vero_aux_insert_state d = (undefined :: globals)\<lparr>
    t_hrs_' := (vero_aux_insert_mem,d), phantom_machine_state_' := vero_aux_insert_allocator\<rparr>"

lemma vero_aux_insert_guards:
  "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 192 :: 32 signed word ptr) \<and>
   c_guard (Ptr 4096 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr)"
  by (intro conjI; rule vero_aux_guard_bounds) simp_all

lemma vero_aux_insert_fields:
  "bn_heap (vero_aux_insert_state d) (Ptr 16)=vero_aux_insert_header (Ptr 560) \<and>
   bn_tree (vero_aux_insert_state d) (Ptr 64)=vero_aux_insert_leaf \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_insert_state d))) (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 64"
proof -
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GT: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and GR: "c_guard (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)"
    using vero_aux_insert_guards by blast+
  have DTH: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GT GH]) simp
  have DRH: "ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GR GH]) simp
  have DRT: "ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GR GT]) simp
  show ?thesis
    by (simp add: bn_heap_def bn_tree_def vero_aux_insert_state_def vero_aux_insert_mem_def hrs_mem_def
      h_val_heap_update h_val_heap_update_disjoint[OF DTH]
      h_val_heap_update_disjoint[OF DRH] h_val_heap_update_disjoint[OF DRT])
qed

lemma vero_aux_insert_allocator_wf:
  "allocator_wf vero_aux_insert_allocator"
  by (auto simp: vero_aux_insert_allocator_def allocator_wf_def block_ok_def block_bytes_def
    audit_stack_addresses_def split: if_splits; arith)

lemma vero_aux_insert_fresh:
  "fresh_block vero_aux_insert_allocator 96 24 \<and>
   fresh_block (vero_aux_insert_allocator\<lparr>live_blocks := (live_blocks vero_aux_insert_allocator)(96:=Some 24)\<rparr>) 256 16 \<and>
   fresh_block (vero_aux_insert_allocator\<lparr>live_blocks := (live_blocks vero_aux_insert_allocator)(96:=Some 24,256:=Some 16)\<rparr>) 128 24 \<and>
   fresh_block (vero_aux_insert_allocator\<lparr>live_blocks := (live_blocks vero_aux_insert_allocator)(96:=Some 24,256:=Some 16,128:=Some 24)\<rparr>) 160 8"
  by (auto simp: vero_aux_insert_allocator_def fresh_block_def block_ok_def block_bytes_def
    audit_stack_addresses_def split: if_splits; arith)

lemma vero_aux_insert_rep:
  "bn_rep (vero_aux_insert_state d) (Ptr 16) (block_bytes 192 4) [Some (BN (Ptr 64) [])] {#Ptr 192#}"
  using vero_aux_insert_fields[of d] vero_aux_insert_guards vero_aux_insert_allocator_wf
  by (auto simp: bn_rep_def bn_owned_def bn_forest_values_def bn_payload_def
    vero_aux_insert_state_def vero_aux_insert_allocator_def vero_aux_insert_header_def vero_aux_insert_leaf_def)

lemma vero_aux_insert_ready:
  "bn_stack_ready \<S> (vero_aux_insert_state stack_byte_typing) \<and>
   block_bytes 192 4 \<inter> \<S>={} \<and> bn_payload (block_bytes 192 4) (Ptr 192)"
proof -
  have R: "bn_stack_ready \<S> (vero_aux_insert_state stack_byte_typing)"
    by (rule vero_aux_stack_ready_typing)
      (simp_all add: vero_aux_insert_state_def vero_aux_insert_allocator_def hrs_htd_def audit_stack_configuration)
  have D: "block_bytes 192 4 \<inter> \<S>={}"
    by (auto simp: audit_stack_configuration audit_stack_addresses_def block_bytes_def)
  have P: "bn_payload (block_bytes 192 4) (Ptr 192)"
    using vero_aux_insert_guards by (simp add: bn_payload_def)
  show ?thesis using R D P by blast
qed


definition vero_aux_insert_after_malloc where
 "vero_aux_insert_after_malloc heap value fake slot allocated = do {
            guard (\<lambda>s. c_guard slot);
            modify
             (t_hrs_'_update
               (hrs_mem_update
                 (heap_update slot
                   (PTR_COERCE(unit \<rightarrow> StrictC'_BinomialTree_C)
                     allocated))));
            condition (\<lambda>s.
                          h_val (hrs_mem (t_hrs_' s)) slot =
                          NULL)
              (return 0)
              (do {
                 guard
                  (\<lambda>s.
                      c_guard
                       (h_val (hrs_mem (t_hrs_' s)) slot));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update
                           (PTR(unit ptr)
                             &(h_val (hrs_mem a)
                                slot\<rightarrow>[''value_C'']))
                           value)
                         a));
                 guard
                  (\<lambda>s.
                      c_guard
                       (h_val (hrs_mem (t_hrs_' s)) slot));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update
                           (PTR(16 word)
                             &(h_val (hrs_mem a)
                                slot\<rightarrow>[''order_C'']))
                           0)
                         a));
                 guard
                  (\<lambda>s.
                      c_guard
                       (h_val (hrs_mem (t_hrs_' s)) slot));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update
                           (PTR(16 word)
                             &(h_val (hrs_mem a)
                                slot\<rightarrow>[''refcount_C'']))
                           1)
                         a));
                 guard
                  (\<lambda>s.
                      c_guard
                       (h_val (hrs_mem (t_hrs_' s)) slot));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update
                           (PTR(StrictC'_BinomialTree_C ptr ptr)
                             &(h_val (hrs_mem a)
                                slot\<rightarrow>[''subtrees_C'']))
                           NULL)
                         a));
                 guard (\<lambda>s. c_guard fake);
                 guard (\<lambda>s. c_guard heap);
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update fake
                           (heap_type_C_update
                             (\<lambda>b.
                                 heap_type_C (h_val (hrs_mem a) heap))
                             (h_val (hrs_mem a) fake)))
                         a));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update fake
                           (compare_func_C_update
                             (\<lambda>b.
                                 compare_func_C (h_val (hrs_mem a) heap))
                             (h_val (hrs_mem a) fake)))
                         a));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update fake
                           (num_values_C_update (\<lambda>a. 1)
                             (h_val (hrs_mem a) fake)))
                         a));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update fake
                           (roots_C_update (\<lambda>a. slot)
                             (h_val (hrs_mem a) fake)))
                         a));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update fake
                           (roots_length_C_update (\<lambda>a. 1)
                             (h_val (hrs_mem a) fake)))
                         a));
                 result \<leftarrow>
                   binomial_heap_merge' heap fake;
                 bn_ds_insert_finish heap slot result
               })
}"

lemma vero_aux_insert_factor:
  "binomial_heap_insert' heap value =
   globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) (\<lambda>fake.
    globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) (\<lambda>slot.
     do {allocated \<leftarrow> malloc' 24;
       vero_aux_insert_after_malloc heap value fake slot allocated}))"
  by (simp only: binomial_heap_insert'_def vero_aux_insert_after_malloc_def
    bn_ds_insert_finish_def; simp)

definition vero_aux_insert_initialized where
  "vero_aux_insert_initialized s h v f a p =
   t_hrs_'_update (hrs_mem_update
    (heap_update f (StrictC'_BinomialHeap_C
      (heap_type_C (bn_heap s h)) (compare_func_C (bn_heap s h)) 1 a 1)
     \<circ> heap_update p (StrictC'_BinomialTree_C v 0 1 NULL)
     \<circ> heap_update a p)) s"

lemma vero_aux_insert_after_malloc_runs:
  fixes p :: "StrictC'_BinomialTree_C ptr"
    and a :: "StrictC'_BinomialTree_C ptr ptr"
    and f h :: "StrictC'_BinomialHeap_C ptr"
  assumes GP: "c_guard p" and GA: "c_guard a" and GF: "c_guard f" and GH: "c_guard h"
    and AP: "ptr_span a \<inter> ptr_span p={}"
    and AF: "ptr_span a \<inter> ptr_span f={}"
    and HA: "ptr_span h \<inter> ptr_span a={}"
    and HP: "ptr_span h \<inter> ptr_span p={}"
    and HF: "ptr_span h \<inter> ptr_span f={}"
  shows "runs_to (vero_aux_insert_after_malloc h v f a (ptr_coerce p)) s Q =
   runs_to (do {r \<leftarrow> binomial_heap_merge' h f; bn_ds_insert_finish h a r})
    (vero_aux_insert_initialized s h v f a p) Q"
proof -
  have PN: "p\<noteq>NULL" using GP by (rule c_guard_NULL)
  have TREE: "\<And>x. x\<lparr>value_C:=v,order_C:=0,refcount_C:=1,subtrees_C:=NULL\<rparr> =
    StrictC'_BinomialTree_C v 0 1 NULL" by (case_tac x; simp)
  have HEAP: "\<And>x ht cmp. x\<lparr>heap_type_C:=ht,compare_func_C:=cmp,num_values_C:=1,roots_C:=a,roots_length_C:=1\<rparr> =
    StrictC'_BinomialHeap_C ht cmp 1 a 1" by (case_tac x; simp)
  show ?thesis
    using GP GA GF GH PN
    by (cases s; simp add: vero_aux_insert_after_malloc_def vero_aux_insert_initialized_def
      runs_to_bind_iff runs_to_guard_iff runs_to_modify_iff runs_to_condition_iff
      hrs_mem_update_def hrs_mem_def case_prod_unfold comp_def bn_heap_def
      StrictC'_BinomialTree_C_heap_update_fields[OF GP]
      h_val_heap_update_disjoint[OF AP] h_val_heap_update_disjoint[OF AF]
      h_val_heap_update_disjoint[OF HA] h_val_heap_update_disjoint[OF HP]
      h_val_heap_update_disjoint[OF HF] h_val_heap_update heap_update_collapse TREE HEAP)
qed


definition vero_aux_insert_allocated where
  "vero_aux_insert_allocated d = (vero_aux_insert_state d)\<lparr>phantom_machine_state_' :=
   vero_aux_insert_allocator\<lparr>live_blocks := (live_blocks vero_aux_insert_allocator)(96:=Some 24)\<rparr>\<rparr>"

definition vero_aux_insert_mid where
  "vero_aux_insert_mid d = vero_aux_insert_initialized (vero_aux_insert_allocated d)
    (Ptr 16) (Ptr 192) (Ptr 4096) (Ptr 4144) (Ptr 96)"

lemma vero_aux_insert_mid_fields:
  "bn_heap (vero_aux_insert_mid d) (Ptr 16)=vero_aux_insert_header (Ptr 560) \<and>
   bn_heap (vero_aux_insert_mid d) (Ptr 4096)=vero_aux_insert_header (Ptr 4144) \<and>
   bn_tree (vero_aux_insert_mid d) (Ptr 64)=vero_aux_insert_leaf \<and>
   bn_tree (vero_aux_insert_mid d) (Ptr 96)=vero_aux_insert_leaf \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_insert_mid d))) (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 64 \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_insert_mid d))) (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 96"
proof -
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_insert_guards by blast
  have G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)" using vero_aux_insert_guards by blast
  have G96: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)" using vero_aux_insert_guards by blast
  have G560: "c_guard (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_insert_guards by blast
  have G4096: "c_guard (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_insert_guards by blast
  have G4144: "c_guard (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_insert_guards by blast
  have D16_4096: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G16 G4096]) simp
  have D16_96: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G16 G96]) simp
  have D16_4144: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G16 G4144]) simp
  have D64_4096: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G4096]) simp
  have D64_96: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G96]) simp
  have D64_4144: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G4144]) simp
  have D96_4096: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G96 G4096]) simp
  have D560_4096: "ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G560 G4096]) simp
  have D560_96: "ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G560 G96]) simp
  have D560_4144: "ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G560 G4144]) simp
  have D4144_4096: "ptr_span (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G4144 G4096]) simp
  have D4144_96: "ptr_span (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G4144 G96]) simp
  show ?thesis
    using vero_aux_insert_fields[of d]
    by (simp add: vero_aux_insert_mid_def vero_aux_insert_initialized_def vero_aux_insert_allocated_def
      bn_heap_def bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold comp_def
      vero_aux_insert_header_def vero_aux_insert_leaf_def h_val_heap_update
      h_val_heap_update_disjoint[OF D16_4096]
      h_val_heap_update_disjoint[OF D16_96]
      h_val_heap_update_disjoint[OF D16_4144]
      h_val_heap_update_disjoint[OF D64_4096]
      h_val_heap_update_disjoint[OF D64_96]
      h_val_heap_update_disjoint[OF D64_4144]
      h_val_heap_update_disjoint[OF D96_4096]
      h_val_heap_update_disjoint[OF D560_4096]
      h_val_heap_update_disjoint[OF D560_96]
      h_val_heap_update_disjoint[OF D560_4144]
      h_val_heap_update_disjoint[OF D4144_4096]
      h_val_heap_update_disjoint[OF D4144_96])
qed

lemma vero_aux_insert_mid_allocator:
  "phantom_machine_state_' (vero_aux_insert_mid d) =
   vero_aux_insert_allocator\<lparr>live_blocks := (live_blocks vero_aux_insert_allocator)(96:=Some 24)\<rparr>"
  by (simp add: vero_aux_insert_mid_def vero_aux_insert_initialized_def vero_aux_insert_allocated_def)

lemma vero_aux_insert_mid_merge_failure:
  "\<not>runs_to (binomial_heap_merge' (Ptr 16) (Ptr 4096)) (vero_aux_insert_mid d) Q"
proof -
  let ?s = "vero_aux_insert_mid d"
  let ?A = "vero_aux_insert_allocator\<lparr>live_blocks := (live_blocks vero_aux_insert_allocator)(96:=Some 24,256:=Some 16)\<rparr>"
  have W: "allocator_wf ?A"
    using vero_aux_insert_allocator_wf vero_aux_insert_fresh
    by (auto simp: allocator_wf_def fresh_block_def Int_commute)
  have W0: "allocator_wf (phantom_machine_state_' ?s)"
    using vero_aux_insert_allocator_wf vero_aux_insert_fresh
    by (auto simp: vero_aux_insert_mid_allocator allocator_wf_def fresh_block_def Int_commute)
  have REL: "malloc_rel (unat (8*(ucast (2::32 word)::64 word))) (hrs_mem (t_hrs_' ?s))
    (phantom_machine_state_' ?s) 256 (hrs_mem (t_hrs_' ?s)) ?A"
    using vero_aux_insert_fresh W0
    by (simp add: malloc_rel_def vero_aux_insert_mid_allocator bytes_frame_def)
  have G128: "c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr)"
    and G256: "c_guard (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)"
    by (rule vero_aux_guard_bounds; simp)+
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and G96: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    using vero_aux_insert_guards by blast+
  have D16: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G16 G256]) simp
  have D64: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G256]) simp
  have D96: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G96 G256]) simp
  have D128: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G128]) simp
  show ?thesis
    apply (rule vero_aux_heap_first_collision_fails[where l=1 and m=1 and n=2
      and roots_left="Ptr 560" and roots_right="Ptr 4144" and p="Ptr 64" and q="Ptr 96"
      and a="Ptr 256" and r="Ptr 128" and b="Ptr 160" and v="Ptr 192" and A="?A"])
    using vero_aux_insert_mid_fields[of d] vero_aux_insert_guards vero_aux_insert_fresh
      G128 G256 W REL D16 D64 D96 D128
    by (simp_all add: vero_aux_insert_header_def vero_aux_insert_leaf_def)
qed

lemma vero_aux_insert_after_malloc_failure:
  "\<not>runs_to (vero_aux_insert_after_malloc (Ptr 16) (Ptr 192) (Ptr 4096) (Ptr 4144) (Ptr 96))
    (vero_aux_insert_allocated d) Q"
proof -
  have GP: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    and GA: "c_guard (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr)"
    and GF: "c_guard (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)"
    and GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    using vero_aux_insert_guards by blast+
  have AP: "ptr_span (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GA GP]) simp
  have AF: "ptr_span (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GA GF]) simp
  have HA: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF GH GA]) simp
  have HP: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GH GP]) simp
  have HF: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GH GF]) simp
  show ?thesis
    using vero_aux_insert_after_malloc_runs[OF GP GA GF GH AP AF HA HP HF,
      where s="vero_aux_insert_allocated d" and v="Ptr 192" and Q=Q]
    by (simp add: vero_aux_insert_mid_def[symmetric] runs_to_bind_iff vero_aux_insert_mid_merge_failure)
qed

lemma vero_aux_insert_failure:
  "\<not>runs_to (binomial_heap_insert' (Ptr 16) (Ptr 192)) (vero_aux_insert_state stack_byte_typing) Q"
proof
  assume RT: "runs_to (binomial_heap_insert' (Ptr 16) (Ptr 192)) (vero_aux_insert_state stack_byte_typing) Q"
  let ?d1 = "ptr_force_type (Ptr 4096 :: StrictC'_BinomialHeap_C ptr) stack_byte_typing"
  let ?d2 = "ptr_force_type (Ptr 4144 :: StrictC'_BinomialTree_C ptr ptr) ?d1"
  let ?f = "\<lambda>fake slot. do {allocated \<leftarrow> malloc' 24;
    vero_aux_insert_after_malloc (Ptr 16) (Ptr 192) fake slot allocated}"
  have A1: "(Ptr 4096,?d1)\<in>stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C)
    (hrs_htd (t_hrs_' (vero_aux_insert_state stack_byte_typing)))"
    using vero_aux_stack_header_allocation by (simp add: vero_aux_insert_state_def hrs_htd_def)
  have A2: "(Ptr 4144,?d2)\<in>stack_allocs 1 \<S> TYPE(StrictC'_BinomialTree_C ptr)
    (hrs_htd (t_hrs_' (vero_aux_insert_state ?d1)))"
    using vero_aux_stack_second_choice[OF vero_aux_stack_header_allocation]
    by (simp add: vero_aux_insert_state_def hrs_htd_def)
  have RETYPE: "\<And>d e. (vero_aux_insert_state d)\<lparr>t_hrs_' := (hrs_mem (t_hrs_' (vero_aux_insert_state d)),e)\<rparr> = vero_aux_insert_state e"
    by (rule globals.equality; simp add: vero_aux_insert_state_def hrs_mem_def)
  have R1: "runs_to (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) (?f (Ptr 4096)))
    (vero_aux_insert_state ?d1) (\<lambda>_ _. True)"
    using vero_aux_stack_prefix[OF RT[unfolded vero_aux_insert_factor] A1]
    by (simp only: RETYPE)
  have R2: "runs_to (?f (Ptr 4096) (Ptr 4144)) (vero_aux_insert_state ?d2) (\<lambda>_ _. True)"
    using vero_aux_stack_prefix[OF R1 A2]
    by (simp only: RETYPE)
  let ?A = "vero_aux_insert_allocator\<lparr>live_blocks := (live_blocks vero_aux_insert_allocator)(96:=Some 24)\<rparr>"
  have REL: "malloc_rel (unat (24::64 word)) (hrs_mem (t_hrs_' (vero_aux_insert_state ?d2)))
    (phantom_machine_state_' (vero_aux_insert_state ?d2)) (ptr_val (Ptr 96 :: unit ptr))
    (hrs_mem (t_hrs_' (vero_aux_insert_state ?d2))) ?A"
    using vero_aux_insert_allocator_wf vero_aux_insert_fresh
    by (simp add: malloc_rel_def vero_aux_insert_state_def bytes_frame_def)
  have BAD: "runs_to (vero_aux_insert_after_malloc (Ptr 16) (Ptr 192) (Ptr 4096) (Ptr 4144) (Ptr 96))
    (vero_aux_insert_allocated ?d2) (\<lambda>_ _. True)"
    using vero_aux_malloc_bindD[OF R2 REL]
    by (simp add: vero_aux_mem_identity vero_aux_insert_allocated_def)
  show False using BAD vero_aux_insert_after_malloc_failure by blast
qed

lemma vero_aux_insert_counterexample:
  "bn_rep (vero_aux_insert_state stack_byte_typing) (Ptr 16) (block_bytes 192 4)
      [Some (BN (Ptr 64) [])] {#Ptr 192#} \<and>
   bn_payload (block_bytes 192 4) (Ptr 192 :: unit ptr) \<and>
   size ({#Ptr 192#} :: unit ptr multiset) + 1 < 2^32 \<and>
   bn_stack_ready \<S> (vero_aux_insert_state stack_byte_typing) \<and>
   block_bytes 192 4 \<inter> \<S>={} \<and>
   \<not>bn_contract (binomial_heap_insert' (Ptr 16) (Ptr 192))
      (vero_aux_insert_state stack_byte_typing) Q"
  using vero_aux_insert_rep[of stack_byte_typing] vero_aux_insert_ready
  by (simp add: bn_contract_def bn_payload_def vero_aux_insert_failure)



end

context binomial_heap_input_global_addresses begin



lemma c0029_prove:
  "runs_to (malloc' n >>= k) s Q \<Longrightarrow>
   malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) p m A \<Longrightarrow>
   runs_to (k (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. m)) s)
       \<lparr>phantom_machine_state_' := A\<rparr>) Q"

proof -
  assume H: "runs_to (malloc' n >>= k) s Q"
    and R: "malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) p m A"
  let ?t = "(t_hrs_'_update (hrs_mem_update (\<lambda>_. m)) s)\<lparr>phantom_machine_state_' := A\<rparr>"
  have ALL: "\<forall>a b. (\<exists>hp B. malloc_rel (unat n) (hrs_mem (t_hrs_' s))
       (phantom_machine_state_' s) (ptr_val a) hp B \<and>
       b = (t_hrs_'_update (hrs_mem_update (\<lambda>_. hp)) s)\<lparr>phantom_machine_state_' := B\<rparr>)
       \<longrightarrow> runs_to (k a) b Q"
    using H by (simp add: malloc'_def runs_to_bind_iff runs_to_guard_iff runs_to_assume_result_and_state_iff)
  note C = ALL[rule_format, of "Ptr p" ?t]
  show ?thesis using C R by auto
qed



end



lemma c0030_prove:
  "calloc_rel item_count item_width hp A p hp' B \<Longrightarrow> p \<noteq> 0 \<Longrightarrow>
    i < item_count * item_width \<Longrightarrow> hp' (p + of_nat i) = 0"

by (auto simp: calloc_rel_def)



lemma vero_aux_h_val_agree:
  "(\<And>a. a \<in> ptr_span p \<Longrightarrow> hp' a = hp a) \<Longrightarrow> h_val hp' p = h_val hp p"
  by (unfold h_val_def; rule arg_cong; rule heap_list_h_eq2; assumption)

lemma c0031_prove:
  "allocator_wf A \<Longrightarrow>
   live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n \<Longrightarrow>
   size_of TYPE('a) * k \<le> n \<Longrightarrow> i < k \<Longrightarrow>
   S \<subseteq> reserved_bytes A \<Longrightarrow> bytes_frame S hp hp' \<Longrightarrow>
   h_val hp' (p +\<^sub>p int i) = h_val hp (p +\<^sub>p int i)"

proof -
  assume A: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and K: "size_of TYPE('a) * k \<le> n" and I: "i < k"
    and S: "S \<subseteq> reserved_bytes A" and F: "bytes_frame S hp hp'"
  have B: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"
    using c0008_prove[OF A L K I] .
  have D: "block_bytes (ptr_val p) n \<inter> reserved_bytes A = {}"
    using A L unfolding allocator_wf_def by blast
  show ?thesis
    apply (rule vero_aux_h_val_agree)
    using B D S F by (auto simp: bytes_frame_def)
qed



context binomial_heap_input_global_addresses begin



lemma c0032_prove:
  "bn_rep s h P F M \<Longrightarrow> M \<noteq> {#} \<Longrightarrow>
  bn_review_scan_prefix s F (length F) (Some j) \<Longrightarrow>
  \<exists>T. F ! j = Some T \<and> value_C (bn_tree s (bn_root T)) \<in># M \<and>
   (\<forall>q \<in># M. bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q)"

by (rule vero_aux_scan_minimum) assumption+



end

lemma vero_aux_values_nonempty: "bn_values s T \<noteq> []"
  by (cases T) simp

lemma vero_aux_forest_empty:
  "bn_forest_values s F = [] \<longleftrightarrow> (\<forall>x \<in> set F. x = None)"
  by (induction F) (auto simp: bn_forest_values_def vero_aux_values_nonempty split: option.splits)

lemma vero_aux_live_h_val:
  fixes p :: "'a::mem_type ptr"
  assumes W: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and SZ: "size_of TYPE('a) \<le> n" and SS: "S \<subseteq> reserved_bytes A"
    and BF: "bytes_frame S hp hp'"
  shows "h_val hp' p = h_val hp p"
proof -
  have "h_val hp' (p +\<^sub>p int 0) = h_val hp (p +\<^sub>p int 0)"
    by (rule c0031_prove[OF W L, where k=1 and i=0 and S=S]) (simp_all add: SZ SS BF)
  thus ?thesis by simp
qed

lemma c0033_prove:
  "bn_rep s h P F {#} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_rep t h P F {#}"

proof -
  assume R: "bn_rep s h P F {#}"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and SS: "S \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
  have W: "allocator_wf (phantom_machine_state_' s)"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using R by (auto simp: bn_rep_def)
  have H: "bn_heap t h = bn_heap s h"
    unfolding bn_heap_def by (rule vero_aux_live_h_val[OF W L _ SS BF]) simp
  have NONE: "\<forall>x \<in> set F. x = None"
    using R by (auto simp: bn_rep_def vero_aux_forest_empty)
  have NI: "\<forall>i < length F. F ! i = None" using NONE by (simp add: nth_mem)
  have FV: "bn_forest_values t F = []" using NONE by (simp add: vero_aux_forest_empty)
  have MAP: "map (case_option [] (bn_blocks t)) F = map (case_option [] (bn_blocks s)) F"
    using NONE by (auto intro!: map_cong)
  have OWN: "bn_owned t h F = bn_owned s h F"
    by (simp add: bn_owned_def H MAP)
  have ARR: "\<forall>i < length F. h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)"
  proof (intro allI impI)
    fix i assume I: "i < length F"
    have NN: "roots_C (bn_heap s h) \<noteq> NULL" using R I by (auto simp: bn_rep_def)
    obtain n where RL: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
      and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F \<le> n"
      using R NN by (auto simp: bn_rep_def)
    have "h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap s h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)"
      by (rule c0031_prove[OF W RL SZ I SS BF])
    thus "h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)" by (simp add: H)
  qed
  show ?thesis using R A H FV OWN ARR NI by (auto simp: bn_rep_def)
qed





lemma c0034_prove:
  "i < length F \<Longrightarrow>
    mset (bn_forest_values s (F[i := None])) +
      mset (case_option [] (bn_values s) (F ! i)) = mset (bn_forest_values s F)"

by (induction F arbitrary: i) (auto simp: bn_forest_values_def nth_Cons split: nat.splits)



context binomial_heap_input_global_addresses begin



lemma c0035_prove:
  "runs_to (malloc' n) s Q \<Longrightarrow>
   fresh_block (phantom_machine_state_' s) p (unat n) \<Longrightarrow>
   Q (Result (Ptr p))
     ((t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' s))) s)
       \<lparr>phantom_machine_state_' :=
         (phantom_machine_state_' s)\<lparr>live_blocks :=
           (live_blocks (phantom_machine_state_' s))(p := Some (unat n))\<rparr>\<rparr>)"

proof -
  assume H: "runs_to (malloc' n) s Q"
    and F: "fresh_block (phantom_machine_state_' s) p (unat n)"
  have WF: "allocator_wf (phantom_machine_state_' s)"
    using H by (auto simp: malloc'_def runs_to_bind_iff runs_to_guard_iff)
  have POS: "0 < unat n" using F by (simp add: fresh_block_def block_ok_def)
  have R: "malloc_rel (unat n) (hrs_mem (t_hrs_' s)) (phantom_machine_state_' s) p
      (hrs_mem (t_hrs_' s)) ((phantom_machine_state_' s)\<lparr>live_blocks :=
       (live_blocks (phantom_machine_state_' s))(p := Some (unat n))\<rparr>)"
    using WF POS F by (auto simp: malloc_rel_def bytes_frame_def)
  have H': "runs_to (malloc' n >>= return) s Q" using H by simp
  show ?thesis using c0029_prove[OF H' R] by simp
qed



end

context binomial_heap_input_global_addresses begin

lemma vero_aux_pointer_low32_zero:
  "h_val (heap_update (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296) hp)
    (Ptr 32 :: 32 word ptr) = 0"
  by (simp add: h_val_def heap_update_def to_bytes_def from_bytes_def typ_info_ptr
    typ_info_word word_tag_def update_ti_t_def word_rcat_def word_rsplit_def
    bin_rsplit_def bin_rsplit_aux.simps; simp add: heap_list.simps numeral_eq_Suc)

lemma vero_aux_pointer_low32_increment:
  "h_val (heap_update (Ptr 32 :: 32 word ptr) 1
      (heap_update (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296) hp))
    (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = Ptr 4294967297"
  by (simp add: h_val_def heap_update_def to_bytes_def from_bytes_def typ_info_ptr
    typ_info_word word_tag_def update_ti_t_def word_rcat_def word_rsplit_def
    bin_rsplit_def bin_rsplit_aux.simps; simp add: heap_list.simps numeral_eq_Suc)






lemma vero_aux_header_slot_alias:
  assumes Z: "num_values_C (h_val hp (Ptr 16 :: StrictC'_BinomialHeap_C ptr))=0"
  shows "h_val (heap_update (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296) hp)
    (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = h_val hp (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
proof -
  have G32: "c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have G16: "c_guard (Ptr 16 :: 32 signed word ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have G24: "c_guard (Ptr 24 :: unit ptr ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have G40: "c_guard (Ptr 40 :: StrictC'_BinomialTree_C ptr ptr ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have G48: "c_guard (Ptr 48 :: 32 word ptr)"
    by (rule vero_aux_guard_bounds) simp_all
  have D16: "ptr_span (Ptr 16 :: 32 signed word ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G16 G32]) simp
  have D24: "ptr_span (Ptr 24 :: unit ptr ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G24 G32]) simp
  have D40: "ptr_span (Ptr 40 :: StrictC'_BinomialTree_C ptr ptr ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G40 G32]) simp
  have D48: "ptr_span (Ptr 48 :: 32 word ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G48 G32]) simp
  show ?thesis using Z
    by (simp add: StrictC'_BinomialHeap_C_h_val_unfold field_lvalue_def
      h_val_heap_update_disjoint[OF D16] h_val_heap_update_disjoint[OF D24]
      h_val_heap_update_disjoint[OF D40] h_val_heap_update_disjoint[OF D48]
      vero_aux_pointer_low32_zero)
qed

lemma vero_aux_unref_unguarded:
  "p\<noteq>NULL \<Longrightarrow> \<not>c_guard p \<Longrightarrow> \<not>runs_to (binomial_tree_unref' p) s Q"
  by (simp add: vero_aux_unref_equation condition_to_unless[symmetric]
    runs_to_condition_iff runs_to_bind_iff runs_to_guard_iff)


definition vero_aux_finish_alias_header where
  "vero_aux_finish_alias_header = vero_aux_leaf_merge_header\<lparr>roots_C:=Ptr 64,roots_length_C:=1\<rparr>"

definition vero_aux_finish_alias_tree where
  "vero_aux_finish_alias_tree = vero_aux_leaf_merge_tree\<lparr>value_C:=Ptr 96,refcount_C:=2\<rparr>"

definition vero_aux_finish_alias_mem :: heap_mem where
  "vero_aux_finish_alias_mem =
    heap_update (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296)
    (heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr) vero_aux_finish_alias_header
    (heap_update (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) vero_aux_finish_alias_tree
    (heap_update (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 4294967296) (\<lambda>_. 0))))"

definition vero_aux_finish_alias_allocator :: calg_allocator where
  "vero_aux_finish_alias_allocator = \<lparr>
    live_blocks=(\<lambda>q. if q=16 then Some 40 else if q=64 then Some 8 else if q=4294967296 then Some 24 else None),
    reserved_bytes=block_bytes 96 4\<rparr>"

definition vero_aux_finish_alias_state :: globals where
  "vero_aux_finish_alias_state = (undefined :: globals)\<lparr>
    t_hrs_' := (vero_aux_finish_alias_mem, undefined), phantom_machine_state_' := vero_aux_finish_alias_allocator\<rparr>"

lemma vero_aux_finish_alias_guards:
  "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 96 :: 32 signed word ptr)"
  by (intro conjI; rule vero_aux_guard_bounds) simp_all

lemma vero_aux_finish_alias_fields:
  "bn_heap vero_aux_finish_alias_state (Ptr 16)=vero_aux_finish_alias_header \<and>
   bn_tree vero_aux_finish_alias_state (Ptr 4294967296)=vero_aux_finish_alias_tree \<and>
   h_val (hrs_mem (t_hrs_' vero_aux_finish_alias_state)) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296 \<and>
   h_val (hrs_mem (t_hrs_' vero_aux_finish_alias_state)) (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296"
proof -
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and G32: "c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)"
    and G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr)"
    and GT: "c_guard (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr)"
    using vero_aux_finish_alias_guards by blast+
  have D4294967296_32: "ptr_span (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF GT G32]) simp
  have D4294967296_16: "ptr_span (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF GT G16]) simp
  have D64_32: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G32]) simp
  have D64_16: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G16]) simp
  have D64_4294967296: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 GT]) simp

  have HEADER: "h_val vero_aux_finish_alias_mem (Ptr 16 :: StrictC'_BinomialHeap_C ptr)=vero_aux_finish_alias_header"
    unfolding vero_aux_finish_alias_mem_def
    by (subst vero_aux_header_slot_alias; simp add: h_val_heap_update vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def)
  have HH: "bn_heap vero_aux_finish_alias_state (Ptr 16)=vero_aux_finish_alias_header"
    by (simp add: bn_heap_def vero_aux_finish_alias_state_def hrs_mem_def HEADER)
  show ?thesis
    apply (rule conjI[OF HH])
    by (simp add: bn_tree_def vero_aux_finish_alias_state_def hrs_mem_def
      vero_aux_finish_alias_mem_def h_val_heap_update
      h_val_heap_update_disjoint[OF D4294967296_32] h_val_heap_update_disjoint[OF D4294967296_16] h_val_heap_update_disjoint[OF D64_32] h_val_heap_update_disjoint[OF D64_16] h_val_heap_update_disjoint[OF D64_4294967296])
qed

lemma vero_aux_finish_alias_allocator_wf:
  "allocator_wf vero_aux_finish_alias_allocator"
  by (auto simp: vero_aux_finish_alias_allocator_def allocator_wf_def block_ok_def block_bytes_def split: if_splits; arith)

lemma vero_aux_num_increment_at_32:
  "heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr)
      (num_values_C_update (\<lambda>x. x+1) (h_val hp (Ptr 16))) hp =
    heap_update (Ptr 32 :: 32 word ptr) (num_values_C (h_val hp (Ptr 16 :: StrictC'_BinomialHeap_C ptr))+1) hp"
proof -
  have G: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    using vero_aux_finish_alias_guards by blast
  have UPD: "num_values_C_update (\<lambda>x. x+1) r =
    num_values_C_update (\<lambda>_. num_values_C r+1) r" for r
    by (cases r) simp
  show ?thesis
    using StrictC'_BinomialHeap_C_heap_update_fields(3)[OF G,
      where h=hp and v="num_values_C (h_val hp (Ptr 16 :: StrictC'_BinomialHeap_C ptr))+1"]
    by (simp add: field_lvalue_def UPD)
qed


lemma vero_aux_finish_alias_pre:
  "bn_ds_finish_base vero_aux_finish_alias_state (Ptr 16) (block_bytes 96 4)
    [Some (BN (Ptr 4294967296) [])] {Ptr 4294967296} (\<lambda>_. []) [Ptr 32] {#} \<and>
   c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   h_val (hrs_mem (t_hrs_' vero_aux_finish_alias_state)) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296 \<and>
   bn_ds_tree_layout vero_aux_finish_alias_state (block_bytes 96 4) (BN (Ptr 4294967296) []) \<and>
   value_C (bn_tree vero_aux_finish_alias_state (Ptr 4294967296))=Ptr 96 \<and>
   unat (num_values_C (bn_heap vero_aux_finish_alias_state (Ptr 16)))=0 \<and>
   mset (bn_forest_values vero_aux_finish_alias_state [Some (BN (Ptr 4294967296) [])])={#Ptr 96#}"
proof -
  let ?s = "vero_aux_finish_alias_state"
  let ?P = "block_bytes 96 4"
  let ?T = "BN (Ptr 4294967296) []"
  have AS: "phantom_machine_state_' ?s=vero_aux_finish_alias_allocator"
    by (simp add: vero_aux_finish_alias_state_def)
  have HH: "bn_heap ?s (Ptr 16)=vero_aux_finish_alias_header"
    and HT: "bn_tree ?s (Ptr 4294967296)=vero_aux_finish_alias_tree"
    and S32: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296"
    and S64: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967296"
    using vero_aux_finish_alias_fields by blast+
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GS: "c_guard (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)"
    and GR: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr)"
    and GT: "c_guard (Ptr 4294967296 :: StrictC'_BinomialTree_C ptr)"
    and GV: "c_guard (Ptr 96 :: 32 signed word ptr)"
    using vero_aux_finish_alias_guards by blast+
  have RH: "block_bytes 16 40 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    and RR: "block_bytes 64 8 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    by (rule vero_aux_live_readable; simp add: AS vero_aux_finish_alias_allocator_def)+
  have RS: "block_bytes 32 8 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    by (rule subset_trans[OF _ RH]; auto simp: block_bytes_def)
  have LT: "bn_ds_tree_layout ?s ?P ?T"
    using GT GV by (simp add: HT AS vero_aux_finish_alias_allocator_def
      vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def bn_payload_def)
  have FV: "bn_ds_forest_view ?s (Ptr 16) ?P [Some ?T]"
    using GH GR RH RR LT
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def
      HH S64 vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def)
  have GRAPH: "bn_ds_graph ?s ?P {Ptr 4294967296} (\<lambda>_. []) [Ptr 64,Ptr 32] {#} {}"
    using vero_aux_finish_alias_allocator_wf GT GV GS GR
    by (auto simp: bn_ds_graph_def bn_ds_slot_handles_def AS HT S64 S32
      vero_aux_finish_alias_allocator_def vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def bn_payload_def)
  have ST: "bn_ds_graph_storage ?s {Ptr 4294967296} [Ptr 64,Ptr 32]"
    using RS RR by (auto simp: bn_ds_graph_storage_def HT vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def)
  have GB: "bn_ds_graph_blocks ?s {Ptr 4294967296}={4294967296}"
    by (auto simp: bn_ds_graph_blocks_def HT vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def)
  have OW: "bn_ds_owned_array ?s (Ptr 64 :: StrictC'_BinomialTree_C ptr ptr) 1"
    using GR by (auto simp: bn_ds_owned_array_def AS vero_aux_finish_alias_allocator_def)
  have BASE: "bn_ds_finish_base ?s (Ptr 16) ?P [Some ?T] {Ptr 4294967296} (\<lambda>_. []) [Ptr 32] {#}"
    using FV GRAPH ST GB OW
    by (auto simp: bn_ds_finish_base_def HH HT bn_ds_slots_def bn_owned_def AS
      vero_aux_finish_alias_allocator_def vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def
      vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def)
  show ?thesis using BASE GS S32 LT
    by (simp add: HH HT vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def
      vero_aux_finish_alias_tree_def vero_aux_leaf_merge_tree_def bn_forest_values_def)
qed


lemma vero_aux_finish_alias_failure:
  "\<not>runs_to (bn_ds_insert_finish (Ptr 16) (Ptr 32) 1) vero_aux_finish_alias_state Q"
proof -
  let ?s = "vero_aux_finish_alias_state"
  let ?upd = "t_hrs_'_update (\<lambda>a. hrs_mem_update
    (heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr)
      (num_values_C_update (\<lambda>x. x+1) (h_val (hrs_mem a) (Ptr 16)))) a)"
  have Z: "num_values_C (bn_heap ?s (Ptr 16))=0"
    using vero_aux_finish_alias_fields
    by (simp add: vero_aux_finish_alias_header_def vero_aux_leaf_merge_header_def)
  have SLOT0: "h_val (hrs_mem (t_hrs_' (?upd ?s))) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) =
    h_val (heap_update (Ptr 32 :: 32 word ptr) 1 (hrs_mem (t_hrs_' ?s)))
      (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)"
    by (simp add: hrs_mem_update_def hrs_mem_def case_prod_unfold vero_aux_num_increment_at_32
      Z[unfolded bn_heap_def hrs_mem_def])
  have SLOT: "h_val (hrs_mem (t_hrs_' (?upd ?s))) (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 4294967297"
    using SLOT0 by (simp add: vero_aux_finish_alias_state_def vero_aux_finish_alias_mem_def hrs_mem_def
      vero_aux_pointer_low32_increment)
  have BAD: "\<And>u R. \<not>runs_to (binomial_tree_unref' (Ptr 4294967297)) u R"
    by (rule vero_aux_unref_unguarded) (simp_all add: c_guard_def ptr_aligned_def)
  show ?thesis
    by (simp add: bn_ds_insert_finish_def condition_to_unless[symmetric] runs_to_condition_iff
      runs_to_bind_iff runs_to_modify_iff runs_to_gets_iff SLOT[simplified] BAD)
qed



end

context binomial_heap_input_global_addresses begin



lemma c0037_prove:
  "stack_allocs 1 \<S> TYPE('a::mem_type) (hrs_htd (t_hrs_' s)) \<noteq> {} \<Longrightarrow>
   (\<And>p d v bs.
      (p,d) \<in> stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
      length bs = size_of TYPE('a) \<Longrightarrow>
      bn_contract ((c :: 'a ptr \<Rightarrow> ('e::default, 'b, globals) spec_monad) p)
        (t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s))
        (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE('a) \<longrightarrow>
          Q r (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)))) \<Longrightarrow>
   bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) c) s Q"

by (rule vero_aux_stack_contract) assumption+



end



lemma c0038_prove:
  "free_rel 0 hp A hp' B \<Longrightarrow> hp' = hp \<and> B = A"

by (auto simp: free_rel_def)





lemma c0039_prove:
  "bytes_frame W hp hp' \<Longrightarrow> P \<inter> W = {} \<Longrightarrow>
    \<forall>a \<in> P. hp' a = hp a"

by (auto simp: bytes_frame_def)





lemma c0040_prove:
  "hd (bn_values s T) = value_C (bn_tree s (bn_root T))"

by (cases T) simp



context binomial_heap_input_global_addresses begin

definition vero_aux_pair_header where
  "vero_aux_pair_header a = vero_aux_leaf_merge_header\<lparr>num_values_C:=1, roots_C:=a, roots_length_C:=1\<rparr>"

definition vero_aux_pair_mem :: heap_mem where
  "vero_aux_pair_mem =
    heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr) (vero_aux_pair_header (Ptr 560))
    (heap_update (Ptr 512 :: StrictC'_BinomialHeap_C ptr) (vero_aux_pair_header (Ptr 576))
    (heap_update (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 64)
    (heap_update (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 96) vero_aux_leaf_merge_mem)))"

definition vero_aux_pair_allocator :: calg_allocator where
  "vero_aux_pair_allocator = vero_aux_leaf_merge_allocator\<lparr>live_blocks :=
    (live_blocks vero_aux_leaf_merge_allocator)(512:=Some 40,560:=Some 8,576:=Some 8)\<rparr>"

definition vero_aux_pair_state :: globals where
  "vero_aux_pair_state = vero_aux_leaf_merge_state\<lparr>
    t_hrs_' := (vero_aux_pair_mem, undefined), phantom_machine_state_' := vero_aux_pair_allocator\<rparr>"

lemma vero_aux_pair_guards:
  "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 512 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)"
  by (intro conjI; rule vero_aux_guard_bounds) simp_all

lemma vero_aux_pair_fields:
  "bn_heap vero_aux_pair_state (Ptr 16) = vero_aux_pair_header (Ptr 560) \<and>
   bn_heap vero_aux_pair_state (Ptr 512) = vero_aux_pair_header (Ptr 576) \<and>
   bn_tree vero_aux_pair_state (Ptr 64) = vero_aux_leaf_merge_tree \<and>
   bn_tree vero_aux_pair_state (Ptr 96) = vero_aux_leaf_merge_tree \<and>
   h_val (hrs_mem (t_hrs_' vero_aux_pair_state)) (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) = Ptr 64 \<and>
   h_val (hrs_mem (t_hrs_' vero_aux_pair_state)) (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr) = Ptr 96"
proof -
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_pair_guards by blast
  have G512: "c_guard (Ptr 512 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_pair_guards by blast
  have G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pair_guards by blast
  have G96: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pair_guards by blast
  have G560: "c_guard (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pair_guards by blast
  have G576: "c_guard (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pair_guards by blast
  have D512_16: "ptr_span (Ptr 512 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G512 G16]) simp
  have D64_16: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G16]) simp
  have D64_512: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 512 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G512]) simp
  have D64_560: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G560]) simp
  have D64_576: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G576]) simp
  have D96_16: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G96 G16]) simp
  have D96_512: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 512 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G96 G512]) simp
  have D96_560: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G96 G560]) simp
  have D96_576: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G96 G576]) simp
  have D560_16: "ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G560 G16]) simp
  have D560_512: "ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 512 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G560 G512]) simp
  have D576_16: "ptr_span (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G576 G16]) simp
  have D576_512: "ptr_span (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 512 :: StrictC'_BinomialHeap_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF G576 G512]) simp
  have D576_560: "ptr_span (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G576 G560]) simp

  have OLD64: "h_val vero_aux_leaf_merge_mem (Ptr 64 :: StrictC'_BinomialTree_C ptr) = vero_aux_leaf_merge_tree"
    and OLD96: "h_val vero_aux_leaf_merge_mem (Ptr 96 :: StrictC'_BinomialTree_C ptr) = vero_aux_leaf_merge_tree"
    using vero_aux_leaf_merge_fields
    by (simp_all add: bn_tree_def vero_aux_leaf_merge_state_def hrs_mem_def)
  show ?thesis
    using G16 G512 G64 G96 G560 G576
    by (simp add: bn_heap_def bn_tree_def vero_aux_pair_state_def vero_aux_pair_mem_def
      hrs_mem_def h_val_heap_update OLD64 OLD96
      h_val_heap_update_disjoint[OF D512_16] h_val_heap_update_disjoint[OF D64_16] h_val_heap_update_disjoint[OF D64_512] h_val_heap_update_disjoint[OF D64_560] h_val_heap_update_disjoint[OF D64_576] h_val_heap_update_disjoint[OF D96_16] h_val_heap_update_disjoint[OF D96_512] h_val_heap_update_disjoint[OF D96_560] h_val_heap_update_disjoint[OF D96_576] h_val_heap_update_disjoint[OF D560_16] h_val_heap_update_disjoint[OF D560_512] h_val_heap_update_disjoint[OF D576_16] h_val_heap_update_disjoint[OF D576_512] h_val_heap_update_disjoint[OF D576_560])
qed

lemma vero_aux_pair_allocator_wf:
  "allocator_wf vero_aux_pair_allocator"
proof -
  have LIVE: "live_blocks vero_aux_pair_allocator p=Some n \<longleftrightarrow> (p=16 \<and> n=40) \<or> (p=64 \<and> n=24) \<or> (p=96 \<and> n=24) \<or> (p=512 \<and> n=40) \<or> (p=560 \<and> n=8) \<or> (p=576 \<and> n=8)" for p n
    by (auto simp: vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def split: if_splits)
  show ?thesis
    unfolding allocator_wf_def
    apply (simp only: LIVE)
    by (auto simp: vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def block_ok_def block_bytes_def; arith)
qed

lemma vero_aux_pair_fresh:
  "fresh_block vero_aux_pair_allocator 256 16 \<and>
   fresh_block (vero_aux_pair_allocator\<lparr>live_blocks := (live_blocks vero_aux_pair_allocator)(256:=Some 16)\<rparr>) 128 24 \<and>
   fresh_block (vero_aux_pair_allocator\<lparr>live_blocks := (live_blocks vero_aux_pair_allocator)(256:=Some 16,128:=Some 24)\<rparr>) 160 8"
  by (auto simp: vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def
    fresh_block_def block_ok_def block_bytes_def split: if_splits; arith)






lemma vero_aux_pair_pre:
  "bn_ds_merge_pre vero_aux_pair_state (Ptr 16) (Ptr 512) (block_bytes 192 4)
    [Some (BN (Ptr 64) [])] [Some (BN (Ptr 96) [])] [] {#Ptr 96#}
    {Ptr 64,Ptr 96} (\<lambda>_. [])"
proof -
  let ?s = "vero_aux_pair_state"
  let ?P = "block_bytes 192 4"
  let ?N = "{Ptr 64,Ptr 96 :: StrictC'_BinomialTree_C ptr}"
  have AS: "phantom_machine_state_' ?s = vero_aux_pair_allocator"
    by (simp add: vero_aux_pair_state_def)
  have HH: "bn_heap ?s (Ptr 16)=vero_aux_pair_header (Ptr 560)"
    and HO: "bn_heap ?s (Ptr 512)=vero_aux_pair_header (Ptr 576)"
    and HP: "bn_tree ?s (Ptr 64)=vero_aux_leaf_merge_tree"
    and HQ: "bn_tree ?s (Ptr 96)=vero_aux_leaf_merge_tree"
    and S1: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 64"
    and S2: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 96"
    using vero_aux_pair_fields by blast+
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GO: "c_guard (Ptr 512 :: StrictC'_BinomialHeap_C ptr)"
    and GP: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and GQ: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    and G1: "c_guard (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)"
    and G2: "c_guard (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr)"
    using vero_aux_pair_guards by blast+
  have GV: "c_guard (Ptr 192 :: 32 signed word ptr)"
    using vero_aux_leaf_merge_guards by blast
  have RH: "block_bytes 16 40 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    and RO: "block_bytes 512 40 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    and R1: "block_bytes 560 8 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    and R2: "block_bytes 576 8 \<subseteq> readable_bytes (phantom_machine_state_' ?s)"
    by (rule vero_aux_live_readable; simp add: AS vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def)+
  have LP: "bn_ds_tree_layout ?s ?P (BN (Ptr 64) [])"
    using GP GV by (simp add: HP AS vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def
      vero_aux_leaf_merge_tree_def bn_payload_def)
  have LQ: "bn_ds_tree_layout ?s ?P (BN (Ptr 96) [])"
    using GQ GV by (simp add: HQ AS vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def
      vero_aux_leaf_merge_tree_def bn_payload_def)
  have FV: "bn_ds_forest_view ?s (Ptr 16) ?P [Some (BN (Ptr 64) [])]"
    using GH G1 RH R1 LP
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def
      HH S1 vero_aux_pair_header_def vero_aux_leaf_merge_header_def)
  have GVW: "bn_ds_forest_view ?s (Ptr 512) ?P [Some (BN (Ptr 96) [])]"
    using GO G2 RO R2 LQ
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def
      HO S2 vero_aux_pair_header_def vero_aux_leaf_merge_header_def)
  have GR: "bn_ds_graph ?s ?P ?N (\<lambda>_. []) [Ptr 560] {#Ptr 96#} {}"
    using vero_aux_pair_allocator_wf GP GQ G1 GV
    by (auto simp: bn_ds_graph_def bn_ds_slot_handles_def HP HQ S1 AS
      vero_aux_leaf_merge_tree_def vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def bn_payload_def)
  have ST: "bn_ds_graph_storage ?s ?N [Ptr 560]"
    using R1 by (auto simp: bn_ds_graph_storage_def HP HQ vero_aux_leaf_merge_tree_def)
  have GB: "bn_ds_graph_blocks ?s ?N={64,96}"
    by (auto simp: bn_ds_graph_blocks_def HP HQ vero_aux_leaf_merge_tree_def)
  have OW: "bn_ds_owned_array ?s (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr) 1"
    using G1 by (auto simp: bn_ds_owned_array_def AS vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def)
  show ?thesis using FV GVW GR ST GB OW
    by (auto simp: bn_ds_merge_pre_def HH HP HQ bn_ds_slots_def AS
      vero_aux_pair_allocator_def vero_aux_leaf_merge_allocator_def vero_aux_pair_header_def
      vero_aux_leaf_merge_header_def vero_aux_leaf_merge_tree_def bn_forest_values_def)
qed


definition vero_aux_pair_alloc_state :: globals where
  "vero_aux_pair_alloc_state = vero_aux_pair_state\<lparr>phantom_machine_state_' :=
    vero_aux_pair_allocator\<lparr>live_blocks := (live_blocks vero_aux_pair_allocator)(256:=Some 16)\<rparr>\<rparr>"

definition vero_aux_pair_carry_state :: globals where
  "vero_aux_pair_carry_state = t_hrs_'_update
    (hrs_mem_update (heap_update (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) NULL)) vero_aux_pair_alloc_state"

lemma vero_aux_pair_allocation:
  "bn_ds_roots_allocation vero_aux_pair_state vero_aux_pair_alloc_state (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) 2"
  using vero_aux_pair_fresh vero_aux_pair_allocator_wf vero_aux_pair_guards
  by (simp add: bn_ds_roots_allocation_def malloc_rel_def bytes_frame_def
    vero_aux_pair_alloc_state_def vero_aux_pair_state_def)

lemma vero_aux_pair_carry_fields:
  "bn_heap vero_aux_pair_carry_state (Ptr 16)=vero_aux_pair_header (Ptr 560) \<and>
   bn_tree vero_aux_pair_carry_state (Ptr 64)=vero_aux_leaf_merge_tree \<and>
   bn_tree vero_aux_pair_carry_state (Ptr 96)=vero_aux_leaf_merge_tree \<and>
   phantom_machine_state_' vero_aux_pair_carry_state =
     vero_aux_pair_allocator\<lparr>live_blocks := (live_blocks vero_aux_pair_allocator)(256:=Some 16)\<rparr>"
proof -
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and G96: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    and G256: "c_guard (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)"
    using vero_aux_pair_guards by blast+
  have D16: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G16 G256]) simp
  have D64: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G64 G256]) simp
  have D96: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) = {}"
    by (rule vero_aux_separated_spans[OF G96 G256]) simp
  have HH: "bn_heap vero_aux_pair_state (Ptr 16)=vero_aux_pair_header (Ptr 560)"
    and HP: "bn_tree vero_aux_pair_state (Ptr 64)=vero_aux_leaf_merge_tree"
    and HQ: "bn_tree vero_aux_pair_state (Ptr 96)=vero_aux_leaf_merge_tree"
    using vero_aux_pair_fields by blast+
  show ?thesis
    by (simp add: vero_aux_pair_carry_state_def vero_aux_pair_alloc_state_def bn_heap_def bn_tree_def
      h_val_heap_update_disjoint[OF D16] h_val_heap_update_disjoint[OF D64]
      h_val_heap_update_disjoint[OF D96] hrs_mem_update_def hrs_mem_def case_prod_unfold
      HH[unfolded bn_heap_def hrs_mem_def] HP[unfolded bn_tree_def hrs_mem_def] HQ[unfolded bn_tree_def hrs_mem_def])
qed

lemma vero_aux_pair_carry_leaf_failure:
  "\<not>runs_to (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96)) vero_aux_pair_carry_state Q"
proof -
  let ?s = "vero_aux_pair_carry_state"
  let ?A = "vero_aux_pair_allocator\<lparr>live_blocks := (live_blocks vero_aux_pair_allocator)(256:=Some 16)\<rparr>"
  have AS: "phantom_machine_state_' ?s=?A"
    and HH: "bn_heap ?s (Ptr 16)=vero_aux_pair_header (Ptr 560)"
    and HP: "bn_tree ?s (Ptr 64)=vero_aux_leaf_merge_tree"
    and HQ: "bn_tree ?s (Ptr 96)=vero_aux_leaf_merge_tree"
    using vero_aux_pair_carry_fields by blast+
  have WA: "allocator_wf ?A"
    using vero_aux_pair_allocator_wf vero_aux_pair_fresh
    by (auto simp: allocator_wf_def fresh_block_def Int_commute)
  have W: "allocator_wf (phantom_machine_state_' ?s)" by (simp only: AS WA)
  have GP: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)"
    and GQ: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    and GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GR: "c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr)"
    and GV0: "c_guard (Ptr 192 :: 32 signed word ptr)"
    using vero_aux_leaf_merge_guards by blast+
  have GV: "c_guard (ptr_coerce (Ptr 192 :: unit ptr) :: 32 signed word ptr)" using GV0 by simp
  have MIN: "heap_type_C (bn_heap ?s (Ptr 16))=BINOMIAL_HEAP_TYPE_MIN"
    and CMP: "compare_func_C (bn_heap ?s (Ptr 16))=binomial_heap_input.int_compare"
    by (simp add: HH vero_aux_pair_header_def vero_aux_leaf_merge_header_def)+
  have PV: "value_C (bn_tree ?s (Ptr 64))=(Ptr 192 :: unit ptr)"
    and QV: "value_C (bn_tree ?s (Ptr 96))=(Ptr 192 :: unit ptr)"
    and OP: "order_C (bn_tree ?s (Ptr 64))=0"
    and Z: "subtrees_C (bn_tree ?s (Ptr 64))=NULL"
    by (simp add: HP HQ vero_aux_leaf_merge_tree_def)+
  have D: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) = {}"
    by (rule vero_aux_separated_spans[OF GP GR]) simp
  have F1: "fresh_block (phantom_machine_state_' ?s) (ptr_val (Ptr 128 :: StrictC'_BinomialTree_C ptr)) 24"
    and F2: "fresh_block ((phantom_machine_state_' ?s)\<lparr>live_blocks := (live_blocks (phantom_machine_state_' ?s))(ptr_val (Ptr 128 :: StrictC'_BinomialTree_C ptr):=Some 24)\<rparr>) (ptr_val (Ptr 160 :: unit ptr)) 8"
    using vero_aux_pair_fresh by (auto simp: AS)
  show ?thesis by (rule vero_aux_leaf_merge_runs_to_fails[OF W GP GQ GH MIN CMP PV QV GV GR D OP Z F1 F2])
qed

lemma vero_aux_pair_carry_step_failure:
  "\<not>runs_to (bn_ds_carry_loop_step (Ptr 16) (Ptr 512) 2 (Ptr 256) (NULL,0,0,vals)) vero_aux_pair_alloc_state Q"
proof -
  have HH: "bn_heap vero_aux_pair_state (Ptr 16)=vero_aux_pair_header (Ptr 560)"
    and HO: "bn_heap vero_aux_pair_state (Ptr 512)=vero_aux_pair_header (Ptr 576)"
    and S1: "h_val (hrs_mem (t_hrs_' vero_aux_pair_state)) (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 64"
    and S2: "h_val (hrs_mem (t_hrs_' vero_aux_pair_state)) (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 96"
    using vero_aux_pair_fields by blast+
  have G1: "c_guard (Ptr 560 :: StrictC'_BinomialTree_C ptr ptr)"
    and G2: "c_guard (Ptr 576 :: StrictC'_BinomialTree_C ptr ptr)"
    and GA: "c_guard (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)"
    using vero_aux_pair_guards by blast+
  show ?thesis
    by (simp add: bn_ds_carry_loop_step_def runs_to_bind_iff runs_to_liftE_iff
      runs_to_gets_iff runs_to_guard_iff runs_to_condition_iff runs_to_modify_iff
      vero_aux_pair_alloc_state_def HH[unfolded bn_heap_def] HO[unfolded bn_heap_def]
      S1 S2 G1 G2 GA vero_aux_pair_header_def vero_aux_leaf_merge_header_def
      Arrays.index_update Arrays.index_update2 INT_MAX_def
      vero_aux_pair_carry_leaf_failure[unfolded vero_aux_pair_carry_state_def vero_aux_pair_alloc_state_def])
qed


lemma vero_aux_pair_carry_loop_failure:
  "\<not>runs_to (bn_ds_carry_loop (Ptr 16) (Ptr 512) 2 (Ptr 256) vals) vero_aux_pair_alloc_state Q"
  apply (simp only: vero_aux_carry_loop_factor bn_ds_carry_loop_from_def)
  apply (subst whileLoop_unroll)
  by (simp add: runs_to_condition_iff runs_to_bind_iff vero_aux_pair_carry_step_failure)

lemma vero_aux_pair_after_roots_failure:
  "\<not>runs_to (vero_aux_heap_merge_after_roots (Ptr 16) (Ptr 512) 2 (Ptr 256) vals) vero_aux_pair_alloc_state Q"
  by (simp add: vero_aux_heap_merge_after_roots_def runs_to_condition_iff
    runs_to_finally_iff runs_to_bind_iff vero_aux_pair_carry_loop_failure)

lemma vero_aux_pair_heap_merge_failure:
  "\<not>runs_to (binomial_heap_merge' (Ptr 16) (Ptr 512)) vero_aux_pair_state Q"
proof
  assume RT: "runs_to (binomial_heap_merge' (Ptr 16) (Ptr 512)) vero_aux_pair_state Q"
  let ?s = "vero_aux_pair_state"
  let ?A = "vero_aux_pair_allocator\<lparr>live_blocks := (live_blocks vero_aux_pair_allocator)(256:=Some 16)\<rparr>"
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GO: "c_guard (Ptr 512 :: StrictC'_BinomialHeap_C ptr)"
    using vero_aux_pair_guards by blast+
  have HH: "bn_heap ?s (Ptr 16)=vero_aux_pair_header (Ptr 560)"
    and HO: "bn_heap ?s (Ptr 512)=vero_aux_pair_header (Ptr 576)"
    using vero_aux_pair_fields by blast+
  have PRE: "\<forall>vals. runs_to (do {p \<leftarrow> malloc' 16;
    vero_aux_heap_merge_after_roots (Ptr 16) (Ptr 512) 2 (ptr_coerce p) vals}) ?s Q"
    using RT by (simp add: vero_aux_heap_merge_factor runs_to_bind_iff runs_to_unknown_iff
      runs_to_guard_iff runs_to_condition_iff runs_to_gets_iff GH GO
      HH[unfolded bn_heap_def] HO[unfolded bn_heap_def] vero_aux_pair_header_def)
  have REL: "malloc_rel (unat (16::64 word)) (hrs_mem (t_hrs_' ?s)) (phantom_machine_state_' ?s)
    (ptr_val (Ptr 256 :: unit ptr)) (hrs_mem (t_hrs_' ?s)) ?A"
    using vero_aux_pair_allocator_wf vero_aux_pair_fresh
    by (simp add: malloc_rel_def bytes_frame_def vero_aux_pair_state_def)
  have ID: "t_hrs_'_update (hrs_mem_update (\<lambda>_. hrs_mem (t_hrs_' ?s))) ?s = ?s"
    by (rule globals.equality; simp add: hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have BAD: "runs_to (vero_aux_heap_merge_after_roots (Ptr 16) (Ptr 512) 2 (Ptr 256) undefined)
    vero_aux_pair_alloc_state Q"
    using vero_aux_malloc_bindD[OF PRE[rule_format, of undefined] REL]
    by (simp add: ID vero_aux_pair_alloc_state_def)
  show False using BAD vero_aux_pair_after_roots_failure by blast
qed

lemma vero_aux_detach_semantics:
  fixes i :: "32 word" and s u :: globals and v :: "StrictC'_BinomialHeap_C"
    and h fake :: "StrictC'_BinomialHeap_C ptr" and tree :: "StrictC'_BinomialTree_C ptr"
  defines "u \<equiv> t_hrs_'_update (hrs_mem_update (heap_update (roots_C (bn_heap s h) +\<^sub>p uint i) NULL)) s"
    and "v \<equiv> (bn_heap u fake)\<lparr>heap_type_C := heap_type_C (bn_heap u h),
      compare_func_C := compare_func_C (bn_heap u h), roots_C := subtrees_C (bn_tree u tree),
      roots_length_C := UCAST(16 \<rightarrow> 32) (order_C (bn_tree u tree))\<rparr>"
  assumes G: "c_guard (roots_C (bn_heap s h) +\<^sub>p uint i)"
    and VAL: "h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint i) = tree"
    and GF: "c_guard fake" and GT: "c_guard tree"
    and DH: "ptr_span h \<inter> ptr_span fake = {}" and DT: "ptr_span tree \<inter> ptr_span fake = {}"
  shows "bn_contract (bn_ds_pop_detach h fake i) s
    (\<lambda>r t. r=tree \<and> t=t_hrs_'_update (hrs_mem_update (heap_update fake v)) u)"
  using G VAL GF GT
  by (auto simp: bn_contract_def bn_ds_pop_detach_def u_def v_def bn_heap_def bn_tree_def
    hrs_mem_def hrs_mem_update_def case_prod_unfold heap_update_collapse
    h_val_heap_update_disjoint[OF DH] h_val_heap_update_disjoint[OF DT]
    runs_to_bind_iff runs_to_guard_iff runs_to_gets_iff runs_to_modify_iff
    reaches_bind reaches_guard reaches_gets reaches_modify reaches_return[abs_def] succeeds_runs_to_iff)



end



lemma c0042_prove:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
   S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
   P \<inter> S = {} \<Longrightarrow>
   phantom_machine_state_' t = phantom_machine_state_' s \<Longrightarrow>
   bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)) \<Longrightarrow>
   bn_frame s h P F t"

by (auto simp: bn_frame_def allocator_wf_def bytes_frame_def; blast)



context binomial_heap_input_global_addresses begin



lemma c0043_prove:
  "\<not> runs_to (memcpy' dst NULL n >>= k) s Q"

by (simp add: memcpy'_def runs_to_bind_iff runs_to_guard_iff memcpy_ok_def)



end



lemma c0044_prove:
  "bn_rep s h P F M \<Longrightarrow> distinct (bn_owned s h F) \<and>
    ptr_val h \<in> set (bn_owned s h F)"

by (auto simp: bn_rep_def bn_owned_def)



context Calg_Binomial_Reviewed_Stack begin

definition vero_aux_pop_header where
  "vero_aux_pop_header = StrictC'_BinomialHeap_C BINOMIAL_HEAP_TYPE_MIN binomial_heap_input.int_compare 3 (Ptr 256) 2"
definition vero_aux_pop_leaf where
  "vero_aux_pop_leaf = StrictC'_BinomialTree_C (Ptr 196) 0 1 NULL"
definition vero_aux_pop_parent where
  "vero_aux_pop_parent = StrictC'_BinomialTree_C (Ptr 192) 1 1 (Ptr 224)"
definition vero_aux_pop_mem :: heap_mem where
  "vero_aux_pop_mem =
    heap_update (Ptr 16 :: StrictC'_BinomialHeap_C ptr) vero_aux_pop_header
    (heap_update (Ptr 64 :: StrictC'_BinomialTree_C ptr) vero_aux_pop_leaf
    (heap_update (Ptr 96 :: StrictC'_BinomialTree_C ptr) vero_aux_pop_parent
    (heap_update (Ptr 128 :: StrictC'_BinomialTree_C ptr) vero_aux_pop_leaf
    (heap_update (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 128)
    (heap_update (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 64)
    (heap_update (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) (Ptr 96)
    (heap_update (Ptr 192 :: 32 signed word ptr) 0
    (heap_update (Ptr 196 :: 32 signed word ptr) 1 (\<lambda>_.0)))))))))"
definition vero_aux_pop_allocator :: calg_allocator where
  "vero_aux_pop_allocator = \<lparr>
    live_blocks = (\<lambda>_.None)(16:=Some 40,64:=Some 24,96:=Some 24,128:=Some 24,224:=Some 8,256:=Some 16),
    reserved_bytes = block_bytes 192 8 \<union> audit_stack_addresses\<rparr>"
definition vero_aux_pop_state where
  "vero_aux_pop_state d = (undefined::globals)\<lparr>
    t_hrs_' := (vero_aux_pop_mem,d),phantom_machine_state_' := vero_aux_pop_allocator\<rparr>"

lemma vero_aux_pop_guards:
  "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 192 :: 32 signed word ptr) \<and>
   c_guard (Ptr 196 :: 32 signed word ptr) \<and>
   c_guard (Ptr 4096 :: StrictC'_BinomialHeap_C ptr) \<and>
   c_guard (Ptr 320 :: StrictC'_BinomialTree_C ptr ptr) \<and>
   c_guard (Ptr 352 :: StrictC'_BinomialTree_C ptr) \<and>
   c_guard (Ptr 384 :: StrictC'_BinomialTree_C ptr ptr)"
  by (intro conjI; rule vero_aux_guard_bounds) simp_all

lemma vero_aux_pop_fields:
  "h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 16 :: StrictC'_BinomialHeap_C ptr)=vero_aux_pop_header \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 64 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_leaf \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 96 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_parent \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 128 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_leaf \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 128 \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 64 \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 96 \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 192 :: 32 signed word ptr)=0 \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d))) (Ptr 196 :: 32 signed word ptr)=1"
proof -
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_pop_guards by blast
  have G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G96: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G128: "c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G224: "c_guard (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have G256: "c_guard (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have G264: "c_guard (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have G192: "c_guard (Ptr 192 :: 32 signed word ptr)" using vero_aux_pop_guards by blast
  have G196: "c_guard (Ptr 196 :: 32 signed word ptr)" using vero_aux_pop_guards by blast
  have D64_16: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G16]) simp
  have D96_16: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G96 G16]) simp
  have D96_64: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G96 G64]) simp
  have D128_16: "ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G128 G16]) simp
  have D128_64: "ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G128 G64]) simp
  have D128_96: "ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G128 G96]) simp
  have D224_16: "ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G224 G16]) simp
  have D224_64: "ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G224 G64]) simp
  have D224_96: "ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G224 G96]) simp
  have D224_128: "ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G224 G128]) simp
  have D256_16: "ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G256 G16]) simp
  have D256_64: "ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G256 G64]) simp
  have D256_96: "ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G256 G96]) simp
  have D256_128: "ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G256 G128]) simp
  have D256_224: "ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G256 G224]) simp
  have D264_16: "ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G264 G16]) simp
  have D264_64: "ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G264 G64]) simp
  have D264_96: "ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G264 G96]) simp
  have D264_128: "ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G264 G128]) simp
  have D264_224: "ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G264 G224]) simp
  have D264_256: "ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G264 G256]) simp
  have D192_16: "ptr_span (Ptr 192 :: 32 signed word ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G192 G16]) simp
  have D192_64: "ptr_span (Ptr 192 :: 32 signed word ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G192 G64]) simp
  have D192_96: "ptr_span (Ptr 192 :: 32 signed word ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G192 G96]) simp
  have D192_128: "ptr_span (Ptr 192 :: 32 signed word ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G192 G128]) simp
  have D192_224: "ptr_span (Ptr 192 :: 32 signed word ptr) \<inter> ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G192 G224]) simp
  have D192_256: "ptr_span (Ptr 192 :: 32 signed word ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G192 G256]) simp
  have D192_264: "ptr_span (Ptr 192 :: 32 signed word ptr) \<inter> ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G192 G264]) simp
  have D196_16: "ptr_span (Ptr 196 :: 32 signed word ptr) \<inter> ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G196 G16]) simp
  have D196_64: "ptr_span (Ptr 196 :: 32 signed word ptr) \<inter> ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G196 G64]) simp
  have D196_96: "ptr_span (Ptr 196 :: 32 signed word ptr) \<inter> ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G196 G96]) simp
  have D196_128: "ptr_span (Ptr 196 :: 32 signed word ptr) \<inter> ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G196 G128]) simp
  have D196_224: "ptr_span (Ptr 196 :: 32 signed word ptr) \<inter> ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G196 G224]) simp
  have D196_256: "ptr_span (Ptr 196 :: 32 signed word ptr) \<inter> ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G196 G256]) simp
  have D196_264: "ptr_span (Ptr 196 :: 32 signed word ptr) \<inter> ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G196 G264]) simp
  have D196_192: "ptr_span (Ptr 196 :: 32 signed word ptr) \<inter> ptr_span (Ptr 192 :: 32 signed word ptr)={}"
    by (rule vero_aux_separated_spans[OF G196 G192]) simp
  show ?thesis
    by (simp add: vero_aux_pop_state_def vero_aux_pop_mem_def hrs_mem_def h_val_heap_update
      h_val_heap_update_disjoint[OF D64_16]
      h_val_heap_update_disjoint[OF D96_16]
      h_val_heap_update_disjoint[OF D96_64]
      h_val_heap_update_disjoint[OF D128_16]
      h_val_heap_update_disjoint[OF D128_64]
      h_val_heap_update_disjoint[OF D128_96]
      h_val_heap_update_disjoint[OF D224_16]
      h_val_heap_update_disjoint[OF D224_64]
      h_val_heap_update_disjoint[OF D224_96]
      h_val_heap_update_disjoint[OF D224_128]
      h_val_heap_update_disjoint[OF D256_16]
      h_val_heap_update_disjoint[OF D256_64]
      h_val_heap_update_disjoint[OF D256_96]
      h_val_heap_update_disjoint[OF D256_128]
      h_val_heap_update_disjoint[OF D256_224]
      h_val_heap_update_disjoint[OF D264_16]
      h_val_heap_update_disjoint[OF D264_64]
      h_val_heap_update_disjoint[OF D264_96]
      h_val_heap_update_disjoint[OF D264_128]
      h_val_heap_update_disjoint[OF D264_224]
      h_val_heap_update_disjoint[OF D264_256]
      h_val_heap_update_disjoint[OF D192_16]
      h_val_heap_update_disjoint[OF D192_64]
      h_val_heap_update_disjoint[OF D192_96]
      h_val_heap_update_disjoint[OF D192_128]
      h_val_heap_update_disjoint[OF D192_224]
      h_val_heap_update_disjoint[OF D192_256]
      h_val_heap_update_disjoint[OF D192_264]
      h_val_heap_update_disjoint[OF D196_16]
      h_val_heap_update_disjoint[OF D196_64]
      h_val_heap_update_disjoint[OF D196_96]
      h_val_heap_update_disjoint[OF D196_128]
      h_val_heap_update_disjoint[OF D196_224]
      h_val_heap_update_disjoint[OF D196_256]
      h_val_heap_update_disjoint[OF D196_264]
      h_val_heap_update_disjoint[OF D196_192])
qed

lemma vero_aux_pop_allocator_wf:
  "allocator_wf vero_aux_pop_allocator"
proof -
  have LIVE: "live_blocks vero_aux_pop_allocator p=Some n \<longleftrightarrow> (p=16 \<and> n=40) \<or> (p=64 \<and> n=24) \<or> (p=96 \<and> n=24) \<or> (p=128 \<and> n=24) \<or> (p=224 \<and> n=8) \<or> (p=256 \<and> n=16)" for p n
    by (auto simp: vero_aux_pop_allocator_def audit_stack_addresses_def split: if_splits)
  show ?thesis
    unfolding allocator_wf_def
    apply (simp only: LIVE)
    by (auto simp: vero_aux_pop_allocator_def audit_stack_addresses_def block_ok_def block_bytes_def; arith)
qed

lemma vero_aux_pop_fresh:
  "fresh_block vero_aux_pop_allocator 320 24 \<and>
   fresh_block (vero_aux_pop_allocator\<lparr>live_blocks := (live_blocks vero_aux_pop_allocator)(320:=Some 24)\<rparr>) 352 24 \<and>
   fresh_block (vero_aux_pop_allocator\<lparr>live_blocks := (live_blocks vero_aux_pop_allocator)(320:=Some 24,352:=Some 24)\<rparr>) 384 8"
  by (auto simp: vero_aux_pop_allocator_def fresh_block_def block_ok_def block_bytes_def
    audit_stack_addresses_def split: if_splits; arith)

lemma vero_aux_pop_rep:
  "bn_rep (vero_aux_pop_state d) (Ptr 16) (block_bytes 192 8)
    [Some (BN (Ptr 64) []),Some (BN (Ptr 96) [BN (Ptr 128) []])] {#Ptr 196,Ptr 192,Ptr 196#}"
  using vero_aux_pop_fields[of d] vero_aux_pop_guards vero_aux_pop_allocator_wf
  by (auto simp: bn_rep_def bn_owned_def bn_forest_values_def bn_payload_def bn_heap_def bn_tree_def bn_key_def
    vero_aux_pop_state_def vero_aux_pop_allocator_def vero_aux_pop_header_def vero_aux_pop_leaf_def
    vero_aux_pop_parent_def block_bytes_def ptr_add_def All_less_Suc)

lemma vero_aux_pop_ready:
  "bn_stack_ready \<S> (vero_aux_pop_state stack_byte_typing) \<and> block_bytes 192 8 \<inter> \<S>={}"
proof -
  have R: "bn_stack_ready \<S> (vero_aux_pop_state stack_byte_typing)"
    by (rule vero_aux_stack_ready_typing)
      (simp_all add: vero_aux_pop_state_def vero_aux_pop_allocator_def hrs_htd_def audit_stack_configuration)
  have D: "block_bytes 192 8 \<inter> \<S>={}"
    by (auto simp: audit_stack_configuration audit_stack_addresses_def block_bytes_def)
  show ?thesis using R D by blast
qed

lemma vero_aux_pop_scan_runs:
  "runs_to (bn_ds_scan (Ptr 16)) (vero_aux_pop_state d) Q =
   Q (Result (2,1)) (vero_aux_pop_state d)"
proof -
  note F = vero_aux_pop_fields[of d]
  note G = vero_aux_pop_guards
  show ?thesis
    unfolding bn_ds_scan_def
    apply (subst whileLoop_unroll)
    apply (simp add: runs_to_condition_iff runs_to_bind_iff runs_to_guard_iff runs_to_gets_iff
      ptr_add_def F G vero_aux_pop_header_def vero_aux_pop_leaf_def vero_aux_pop_parent_def)
    apply (subst whileLoop_unroll)
    apply (simp add: runs_to_condition_iff runs_to_bind_iff runs_to_guard_iff runs_to_gets_iff
      ptr_add_def F G vero_aux_pop_header_def vero_aux_pop_leaf_def vero_aux_pop_parent_def
      binomial_heap_cmp'_def \<P>_fun_ptr_simps int_compare'_def)
    apply (subst whileLoop_unroll)
    by (simp add: runs_to_condition_iff F vero_aux_pop_header_def)
qed

definition vero_aux_pop_cleared where
  "vero_aux_pop_cleared d = t_hrs_'_update (hrs_mem_update
    (heap_update (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr) NULL)) (vero_aux_pop_state d)"
definition vero_aux_pop_mid where
  "vero_aux_pop_mid d = t_hrs_'_update (hrs_mem_update
    (heap_update (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)
      ((bn_heap (vero_aux_pop_cleared d) (Ptr 4096))\<lparr>
        heap_type_C:=BINOMIAL_HEAP_TYPE_MIN,compare_func_C:=binomial_heap_input.int_compare,
        roots_C:=Ptr 224,roots_length_C:=1\<rparr>))) (vero_aux_pop_cleared d)"

lemma vero_aux_pop_cleared_fields:
  "h_val (hrs_mem (t_hrs_' (vero_aux_pop_cleared d))) (Ptr 16 :: StrictC'_BinomialHeap_C ptr)=vero_aux_pop_header \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_cleared d))) (Ptr 64 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_leaf \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_cleared d))) (Ptr 96 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_parent \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_cleared d))) (Ptr 128 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_leaf \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_cleared d))) (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 128 \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_cleared d))) (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 64"
proof -
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_pop_guards by blast
  have G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G96: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G128: "c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G224: "c_guard (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have G256: "c_guard (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have G264: "c_guard (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have D16_264: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G16 G264]) simp
  have D64_264: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G264]) simp
  have D96_264: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G96 G264]) simp
  have D128_264: "ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G128 G264]) simp
  have D224_264: "ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G224 G264]) simp
  have D256_264: "ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G256 G264]) simp
  show ?thesis using vero_aux_pop_fields[of d]
    by (simp add: vero_aux_pop_cleared_def bn_heap_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update
      h_val_heap_update_disjoint[OF D16_264]
      h_val_heap_update_disjoint[OF D64_264]
      h_val_heap_update_disjoint[OF D96_264]
      h_val_heap_update_disjoint[OF D128_264]
      h_val_heap_update_disjoint[OF D224_264]
      h_val_heap_update_disjoint[OF D256_264])
qed

lemma vero_aux_pop_mid_fields:
  "h_val (hrs_mem (t_hrs_' (vero_aux_pop_mid d))) (Ptr 16 :: StrictC'_BinomialHeap_C ptr)=vero_aux_pop_header \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_mid d))) (Ptr 64 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_leaf \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_mid d))) (Ptr 96 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_parent \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_mid d))) (Ptr 128 :: StrictC'_BinomialTree_C ptr)=vero_aux_pop_leaf \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_mid d))) (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 128 \<and>
   h_val (hrs_mem (t_hrs_' (vero_aux_pop_mid d))) (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)=Ptr 64 \<and>
   heap_type_C (bn_heap (vero_aux_pop_mid d) (Ptr 4096))=BINOMIAL_HEAP_TYPE_MIN \<and>
   compare_func_C (bn_heap (vero_aux_pop_mid d) (Ptr 4096))=binomial_heap_input.int_compare \<and>
   roots_C (bn_heap (vero_aux_pop_mid d) (Ptr 4096))=Ptr 224 \<and>
   roots_length_C (bn_heap (vero_aux_pop_mid d) (Ptr 4096))=1"
proof -
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_pop_guards by blast
  have G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G96: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G128: "c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G224: "c_guard (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have G256: "c_guard (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have G4096: "c_guard (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_pop_guards by blast
  have D16_4096: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G16 G4096]) simp
  have D64_4096: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G4096]) simp
  have D96_4096: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G96 G4096]) simp
  have D128_4096: "ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G128 G4096]) simp
  have D224_4096: "ptr_span (Ptr 224 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G224 G4096]) simp
  have D256_4096: "ptr_span (Ptr 256 :: StrictC'_BinomialTree_C ptr ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G256 G4096]) simp
  show ?thesis using vero_aux_pop_cleared_fields[of d]
    by (simp add: vero_aux_pop_mid_def bn_heap_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update
      h_val_heap_update_disjoint[OF D16_4096]
      h_val_heap_update_disjoint[OF D64_4096]
      h_val_heap_update_disjoint[OF D96_4096]
      h_val_heap_update_disjoint[OF D128_4096]
      h_val_heap_update_disjoint[OF D224_4096]
      h_val_heap_update_disjoint[OF D256_4096])
qed

lemma vero_aux_pop_mid_allocator:
  "phantom_machine_state_' (vero_aux_pop_mid d)=vero_aux_pop_allocator"
  by (simp add: vero_aux_pop_mid_def vero_aux_pop_cleared_def vero_aux_pop_state_def)

lemma vero_aux_pop_mid_merge_failure:
  "\<not>runs_to (binomial_heap_merge' (Ptr 16) (Ptr 4096)) (vero_aux_pop_mid d) Q"
proof -
  let ?s = "vero_aux_pop_mid d"
  let ?A = "vero_aux_pop_allocator\<lparr>live_blocks := (live_blocks vero_aux_pop_allocator)(320:=Some 24)\<rparr>"
  have W: "allocator_wf ?A"
    using vero_aux_pop_allocator_wf vero_aux_pop_fresh
    by (auto simp: allocator_wf_def fresh_block_def Int_commute)
  have REL: "malloc_rel (unat (8*(ucast (3::32 word)::64 word))) (hrs_mem (t_hrs_' ?s))
    (phantom_machine_state_' ?s) 320 (hrs_mem (t_hrs_' ?s)) ?A"
    using vero_aux_pop_allocator_wf vero_aux_pop_fresh
    by (simp add: malloc_rel_def vero_aux_pop_mid_allocator bytes_frame_def)
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)" using vero_aux_pop_guards by blast
  have G64: "c_guard (Ptr 64 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G128: "c_guard (Ptr 128 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have G320: "c_guard (Ptr 320 :: StrictC'_BinomialTree_C ptr ptr)" using vero_aux_pop_guards by blast
  have G352: "c_guard (Ptr 352 :: StrictC'_BinomialTree_C ptr)" using vero_aux_pop_guards by blast
  have D16_320: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 320 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G16 G320]) simp
  have D64_320: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 320 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G320]) simp
  have D128_320: "ptr_span (Ptr 128 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 320 :: StrictC'_BinomialTree_C ptr ptr)={}"
    by (rule vero_aux_separated_spans[OF G128 G320]) simp
  have D64_352: "ptr_span (Ptr 64 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 352 :: StrictC'_BinomialTree_C ptr)={}"
    by (rule vero_aux_separated_spans[OF G64 G352]) simp

  show ?thesis
    apply (rule vero_aux_heap_first_collision_fails[where l=2 and m=1 and n=3
      and roots_left="Ptr 256" and roots_right="Ptr 224" and p="Ptr 64" and q="Ptr 128"
      and a="Ptr 320" and r="Ptr 352" and b="Ptr 384" and v="Ptr 196" and A="?A"])
    using vero_aux_pop_mid_fields[of d] vero_aux_pop_guards vero_aux_pop_fresh
      W REL D16_320 D64_320 D128_320 D64_352
    by (simp_all add: bn_heap_def bn_tree_def vero_aux_pop_header_def vero_aux_pop_leaf_def)
qed

definition vero_aux_pop_after_detach where
 "vero_aux_pop_after_detach heap fake (least_index :: 32 word) least_tree = do {
ret'int'1 \<leftarrow>
              binomial_heap_merge' heap fake;
            condition (\<lambda>s. ret'int'1 \<noteq> 0)
              (do {
                 result \<leftarrow>
                   gets
                    (\<lambda>xm.
                        value_C (h_val (hrs_mem (t_hrs_' xm)) least_tree));
                 ret \<leftarrow> binomial_tree_unref' least_tree;
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update heap
                           (num_values_C_update (\<lambda>a. a - 1)
                             (h_val (hrs_mem a) heap)))
                         a));
                 return result
               })
              (do {
                 guard
                  (\<lambda>s.
                      c_guard
                       (roots_C
                         (h_val (hrs_mem (t_hrs_' s)) heap) +\<^sub>p
                        uint least_index));
                 modify
                  (t_hrs_'_update
                    (\<lambda>a.
                        hrs_mem_update
                         (heap_update
                           (roots_C (h_val (hrs_mem a) heap) +\<^sub>p
                            uint least_index)
                           least_tree)
                         a));
                 return binomial_heap_null_value
               })
}"

definition vero_aux_pop_body where
  "vero_aux_pop_body h fake = do {
    guard (\<lambda>_.c_guard h);
    condition (\<lambda>s. num_values_C (bn_heap s h)=0)
      (return binomial_heap_null_value)
      (do {(i,j) \<leftarrow> bn_ds_scan h;
        p \<leftarrow> bn_ds_pop_detach h fake j;
        vero_aux_pop_after_detach h fake j p})
  }"

lemma vero_aux_pop_factor:
  "binomial_heap_pop' h =
    globals.with_fresh_stack_ptr 1 (\<lambda>_.UNIV) (vero_aux_pop_body h)"
  by (simp add: binomial_heap_pop'_def vero_aux_pop_body_def[abs_def] vero_aux_pop_after_detach_def
    bn_ds_scan_def bn_ds_pop_detach_def bn_heap_def bind_assoc)

lemma vero_aux_pop_detaches:
  "bn_contract (bn_ds_pop_detach (Ptr 16) (Ptr 4096) 1) (vero_aux_pop_state d)
    (\<lambda>r t. r=Ptr 96 \<and> t=vero_aux_pop_mid d)"
proof -
  note F = vero_aux_pop_fields[of d]
  note C = vero_aux_pop_cleared_fields[of d]
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    and GF: "c_guard (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)"
    and GT: "c_guard (Ptr 96 :: StrictC'_BinomialTree_C ptr)"
    and GA: "c_guard (Ptr 264 :: StrictC'_BinomialTree_C ptr ptr)"
    using vero_aux_pop_guards by blast+
  have GS: "c_guard (roots_C (bn_heap (vero_aux_pop_state d) (Ptr 16)) +\<^sub>p uint (1::32 word))"
    using F GA by (simp add: bn_heap_def vero_aux_pop_header_def ptr_add_def)
  have VAL: "h_val (hrs_mem (t_hrs_' (vero_aux_pop_state d)))
    (roots_C (bn_heap (vero_aux_pop_state d) (Ptr 16)) +\<^sub>p uint (1::32 word))=Ptr 96"
    using F by (simp add: bn_heap_def vero_aux_pop_header_def ptr_add_def)
  have DH: "ptr_span (Ptr 16 :: StrictC'_BinomialHeap_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GH GF]) simp
  have DT: "ptr_span (Ptr 96 :: StrictC'_BinomialTree_C ptr) \<inter> ptr_span (Ptr 4096 :: StrictC'_BinomialHeap_C ptr)={}"
    by (rule vero_aux_separated_spans[OF GT GF]) simp
  have CLEAR: "t_hrs_'_update (hrs_mem_update
    (heap_update (roots_C (bn_heap (vero_aux_pop_state d) (Ptr 16)) +\<^sub>p uint (1::32 word)) NULL))
      (vero_aux_pop_state d)=vero_aux_pop_cleared d"
    using F by (simp add: vero_aux_pop_cleared_def bn_heap_def vero_aux_pop_header_def ptr_add_def)
  show ?thesis
    using vero_aux_detach_semantics[OF GS VAL GF GT DH DT]
    by (simp only: CLEAR; simp add: vero_aux_pop_mid_def bn_heap_def bn_tree_def C
      vero_aux_pop_header_def vero_aux_pop_parent_def)
qed

lemma vero_aux_pop_detach_reaches:
  "reaches (bn_ds_pop_detach (Ptr 16) (Ptr 4096) 1) (vero_aux_pop_state d)
    (Result (Ptr 96)) (vero_aux_pop_mid d)"
proof -
  let ?f = "bn_ds_pop_detach (Ptr 16) (Ptr 4096) 1"
  let ?s = "vero_aux_pop_state d"
  have RT: "runs_to ?f ?s (\<lambda>r t. \<exists>v. r=Result v \<and> v=Ptr 96 \<and> t=vero_aux_pop_mid d)"
    using vero_aux_pop_detaches[of d] by (simp add: bn_contract_def)
  obtain v t where R: "reaches ?f ?s (Result v) t"
    using vero_aux_pop_detaches[of d] by (auto simp: bn_contract_def)
  have E: "v=Ptr 96 \<and> t=vero_aux_pop_mid d"
    using runs_toD2[OF RT R] by simp
  show ?thesis using R E by simp
qed

lemma vero_aux_pop_body_failure:
  "\<not>runs_to (vero_aux_pop_body (Ptr 16) (Ptr 4096)) (vero_aux_pop_state d) Q"
proof
  assume RT: "runs_to (vero_aux_pop_body (Ptr 16) (Ptr 4096)) (vero_aux_pop_state d) Q"
  note F = vero_aux_pop_fields[of d]
  have GH: "c_guard (Ptr 16 :: StrictC'_BinomialHeap_C ptr)"
    using vero_aux_pop_guards by blast
  have TAIL: "\<And>p R. \<not>runs_to (vero_aux_pop_after_detach (Ptr 16) (Ptr 4096) 1 p) (vero_aux_pop_mid d) R"
    by (simp add: vero_aux_pop_after_detach_def runs_to_bind_iff vero_aux_pop_mid_merge_failure)
  have PREFIX: "runs_to (do {p \<leftarrow> bn_ds_pop_detach (Ptr 16) (Ptr 4096) 1;
    vero_aux_pop_after_detach (Ptr 16) (Ptr 4096) 1 p}) (vero_aux_pop_state d) Q"
    using RT GH F
    by (simp add: vero_aux_pop_body_def runs_to_bind_iff runs_to_guard_iff runs_to_condition_iff
      vero_aux_pop_scan_runs bn_heap_def vero_aux_pop_header_def)
  show False using runs_toD2[OF PREFIX[unfolded runs_to_bind_iff] vero_aux_pop_detach_reaches] TAIL by simp
qed

lemma vero_aux_pop_failure:
  "\<not>runs_to (binomial_heap_pop' (Ptr 16)) (vero_aux_pop_state stack_byte_typing) Q"
proof
  assume RT: "runs_to (binomial_heap_pop' (Ptr 16)) (vero_aux_pop_state stack_byte_typing) Q"
  let ?d = "ptr_force_type (Ptr 4096 :: StrictC'_BinomialHeap_C ptr) stack_byte_typing"
  have A: "(Ptr 4096,?d)\<in>stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C)
    (hrs_htd (t_hrs_' (vero_aux_pop_state stack_byte_typing)))"
    using vero_aux_stack_header_allocation by (simp add: vero_aux_pop_state_def hrs_htd_def)
  have RETYPE: "\<And>d e. (vero_aux_pop_state d)\<lparr>t_hrs_' := (hrs_mem (t_hrs_' (vero_aux_pop_state d)),e)\<rparr> = vero_aux_pop_state e"
    by (rule globals.equality; simp add: vero_aux_pop_state_def hrs_mem_def)
  have BAD: "runs_to (vero_aux_pop_body (Ptr 16) (Ptr 4096)) (vero_aux_pop_state ?d) (\<lambda>_ _.True)"
    using vero_aux_stack_prefix[OF RT[unfolded vero_aux_pop_factor] A]
    by (simp only: RETYPE)
  show False using BAD vero_aux_pop_body_failure by blast
qed

lemma vero_aux_pop_counterexample:
  "bn_rep (vero_aux_pop_state stack_byte_typing) (Ptr 16) (block_bytes 192 8)
      [Some (BN (Ptr 64) []),Some (BN (Ptr 96) [BN (Ptr 128) []])] {#Ptr 196,Ptr 192,Ptr 196#} \<and>
   bn_stack_ready \<S> (vero_aux_pop_state stack_byte_typing) \<and>
   block_bytes 192 8 \<inter> \<S>={} \<and>
   \<not>bn_contract (binomial_heap_pop' (Ptr 16)) (vero_aux_pop_state stack_byte_typing) Q"
  using vero_aux_pop_rep[of stack_byte_typing] vero_aux_pop_ready
  by (simp add: bn_contract_def vero_aux_pop_failure)



end

lemma vero_aux_valid_layout:
  "bn_valid s P T \<Longrightarrow> bn_ds_tree_layout s P T"
  by (induction T) (auto simp: list_all_iff)

lemma vero_aux_rep_forest_view:
  "bn_rep s h P F M \<Longrightarrow> bn_ds_forest_view s h P F"



proof -
  assume R: "bn_rep s h P F M"
  have H: "block_bytes (ptr_val h) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq>
       readable_bytes (phantom_machine_state_' s)"
    apply (rule vero_aux_live_readable)
    using R by (simp add: bn_rep_def)
  have ARR: "block_bytes (ptr_val (roots_C (bn_heap s h))) (8 * length F) \<subseteq>
       readable_bytes (phantom_machine_state_' s)"
  proof (cases "roots_C (bn_heap s h) = NULL")
    case True
    have "F = []" using R True by (simp add: bn_rep_def)
    thus ?thesis by (auto simp: block_bytes_def)
  next
    case False
    obtain n where L: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
      and N: "8 * length F \<le> n"
      using R False by (auto simp: bn_rep_def)
    have B: "block_bytes (ptr_val (roots_C (bn_heap s h))) (8 * length F) \<subseteq>
        block_bytes (ptr_val (roots_C (bn_heap s h))) n"
      using N by (auto simp: block_bytes_def)
    show ?thesis by (rule subset_trans[OF B vero_aux_live_readable[OF L]])
  qed
  show ?thesis using R H ARR
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def bn_rep_def
      split: option.splits intro: vero_aux_valid_layout)
qed


definition vero_aux_node_blocks where
  "vero_aux_node_blocks s p = ptr_val p #
    (if order_C (bn_tree s p) = 0 then [] else [ptr_val (subtrees_C (bn_tree s p))])"

lemma vero_aux_concat_map_flat:
  "concat (map f (concat (map g xs))) = concat (map (\<lambda>x. concat (map f (g x))) xs)"
  by (induction xs) simp_all

lemma vero_aux_layout_blocks:
  assumes L: "bn_ds_tree_layout s P T"
  shows "bn_blocks s T = concat (map (vero_aux_node_blocks s) (bn_ds_node_list T))"
  using L
proof (induction T)
  case (BN p cs)
  have CHILD: "map (bn_blocks s) cs = map (\<lambda>T. concat (map (vero_aux_node_blocks s) (bn_ds_node_list T))) cs"
    using BN.IH BN.prems by (auto simp: list_all_iff intro!: map_cong)
  have ZERO: "order_C (bn_tree s p) = 0 \<longleftrightarrow> cs=[]"
    using BN.prems by (simp add: unat_eq_zero[symmetric])
  show ?case by (simp add: vero_aux_node_blocks_def[abs_def] ZERO CHILD vero_aux_concat_map_flat)
qed

lemma vero_aux_forest_blocks:
  assumes L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
  shows "concat (map (case_option [] (bn_blocks s)) F) =
    concat (map (vero_aux_node_blocks s) (concat (map (case_option [] bn_ds_node_list) F)))"
  using L by (induction F) (auto simp: vero_aux_layout_blocks split: option.splits)

lemma vero_aux_distinct_components:
  "distinct (concat (map f xs)) \<Longrightarrow> x \<in> set xs \<Longrightarrow> distinct (f x)"
  by (auto simp: distinct_concat_iff)

lemma vero_aux_disjoint_components:
  "distinct (concat (map f xs)) \<Longrightarrow> x \<in> set xs \<Longrightarrow> y \<in> set xs \<Longrightarrow> x \<noteq> y \<Longrightarrow>
    set (f x) \<inter> set (f y) = {}"
proof (induction xs)
  case Nil
  then show ?case by simp
next
  case (Cons z zs)
  have D: "distinct (concat (map f zs))"
    and DIS: "set (f z) \<inter> set (concat (map f zs)) = {}"
    using Cons.prems(1) by auto
  have MEM: "\<And>v. v \<in> set zs \<Longrightarrow> set (f v) \<subseteq> set (concat (map f zs))" by auto
  show ?case using Cons.prems Cons.IH D DIS MEM by (auto; blast)
qed

lemma vero_aux_value_root_member:
  "value_C (bn_tree s (bn_root T)) \<in> set (bn_values s T)"
  by (cases T) simp



definition vero_aux_node_ok where
  "vero_aux_node_ok s P p \<longleftrightarrow> (let es = bn_ds_physical_edges s p in
    c_guard p \<and>
    live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C)) \<and>
    bn_payload P (value_C (bn_tree s p)) \<and>
    unat (order_C (bn_tree s p)) = length es \<and> refcount_C (bn_tree s p) = 1 \<and>
    map (\<lambda>q. unat (order_C (bn_tree s q))) es = [0..<length es] \<and>
    (if es=[] then subtrees_C (bn_tree s p) = NULL else
      c_guard (subtrees_C (bn_tree s p)) \<and>
      live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
        Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length es)) \<and>
    (\<forall>i<length es. c_guard (subtrees_C (bn_tree s p) +\<^sub>p int i) \<and>
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i) = es ! i) \<and>
    (\<forall>q \<in> set es. bn_key s (value_C (bn_tree s p)) \<le> bn_key s (value_C (bn_tree s q))))"

lemma vero_aux_valid_node_fields:
  assumes V: "bn_valid s P T"
  shows "\<forall>p \<in> set (bn_ds_node_list T). vero_aux_node_ok s P p"
  using V
proof (induction T)
  case (BN p cs)
  have L: "bn_ds_tree_layout s P (BN p cs)" by (rule vero_aux_valid_layout[OF BN.prems])
  have ED: "bn_ds_physical_edges s p = map bn_root cs" by (rule vero_aux_layout_physical[OF L])
  have CV: "\<forall>T \<in> set cs. bn_valid s P T" using BN.prems by (simp add: list_all_iff)
  have CR: "\<forall>T \<in> set cs. unat (order_C (bn_tree s (bn_root T))) = bn_rank T"
  proof (intro ballI)
    fix T assume "T \<in> set cs"
    then have "bn_valid s P T" using CV by blast
    then show "unat (order_C (bn_tree s (bn_root T))) = bn_rank T" by (cases T) auto
  qed
  have MP: "map (\<lambda>T. unat (order_C (bn_tree s (bn_root T)))) cs = map bn_rank cs"
    using CR by (auto intro!: map_cong)
  have KEY: "\<forall>T \<in> set cs. bn_key s (value_C (bn_tree s p)) \<le> bn_key s (value_C (bn_tree s (bn_root T)))"
    using BN.prems vero_aux_value_root_member by (auto simp: list_all_iff; blast)
  have ROOT: "vero_aux_node_ok s P p"
    using BN.prems KEY MP by (auto simp: vero_aux_node_ok_def Let_def ED map_map o_def MP)
  have CHILD: "\<forall>T \<in> set cs. \<forall>q \<in> set (bn_ds_node_list T). vero_aux_node_ok s P q"
    using BN.IH CV by blast
  show ?case using ROOT CHILD by auto
qed

lemma vero_aux_layout_reachable:
  assumes L: "bn_ds_tree_layout s P T"
    and SUB: "set (bn_ds_node_list T) \<subseteq> N"
  shows "\<forall>p \<in> set (bn_ds_node_list T).
    (bn_root T,p) \<in> {(q,r). q \<in> N \<and> r \<in> set (bn_ds_physical_edges s q)}\<^sup>*"
  using L SUB
proof (induction T)
  case (BN p cs)
  let ?E = "{(q,r). q \<in> N \<and> r \<in> set (bn_ds_physical_edges s q)}"
  have PN: "p \<in> N" using BN.prems by auto
  have ED: "bn_ds_physical_edges s p = map bn_root cs" by (rule vero_aux_layout_physical[OF BN.prems(1)])
  have CHILD: "\<forall>T \<in> set cs. \<forall>q \<in> set (bn_ds_node_list T). (bn_root T,q) \<in> ?E\<^sup>*"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  have STEP: "\<forall>T \<in> set cs. (p,bn_root T) \<in> ?E"
    using PN ED by auto
  show ?case
  proof (intro ballI)
    fix q assume Q: "q \<in> set (bn_ds_node_list (BN p cs))"
    show "(bn_root (BN p cs),q) \<in> ?E\<^sup>*"
    proof (cases "q=p")
      case True
      then show ?thesis by simp
    next
      case False
      obtain U where UC: "U \<in> set cs" and QU: "q \<in> set (bn_ds_node_list U)" using Q False by auto
      have S: "(p,bn_root U) \<in> ?E" using STEP UC by blast
      have C: "(bn_root U,q) \<in> ?E\<^sup>*" using CHILD UC QU by blast
      show ?thesis using rtrancl_trans[OF r_into_rtrancl[OF S] C] by simp
    qed
  qed
qed


lemma vero_aux_slots_distinct:
  fixes a :: "StrictC'_BinomialTree_C ptr ptr"
  assumes N: "n \<le> 32"
  shows "distinct (bn_ds_slots a n)"
proof -
  have INJ: "inj_on (\<lambda>i. a +\<^sub>p int i) {0..<n}"
  proof (rule inj_onI)
    fix i j assume I: "i \<in> {0..<n}" and J: "j \<in> {0..<n}"
      and E: "a +\<^sub>p int i = a +\<^sub>p int j"
    have WI: "8*i < 2^64" using I N by (simp; arith)
    have WJ: "8*j < 2^64" using J N by (simp; arith)
    have WE: "(of_nat (8*i) :: 64 word) = of_nat (8*j)" using E by (simp add: ptr_add_def algebra_simps)
    have UI: "unat (of_nat (8*i) :: 64 word) = 8*i"
      apply (rule unat_of_nat_eq) using WI by simp
    have UJ: "unat (of_nat (8*j) :: 64 word) = 8*j"
      apply (rule unat_of_nat_eq) using WJ by simp
    have "8*i = 8*j" using arg_cong[OF WE, where f=unat] by (simp only: UI UJ)
    then show "i=j" by arith
  qed
  show ?thesis using INJ by (simp add: bn_ds_slots_def distinct_map)
qed

lemma vero_aux_live_spans_disjoint:
  fixes p :: "'a::mem_type ptr" and q :: "'b::mem_type ptr"
  assumes W: "allocator_wf A" and LP: "live_blocks A (ptr_val p) = Some np"
    and LQ: "live_blocks A (ptr_val q) = Some nq" and NE: "ptr_val p \<noteq> ptr_val q"
    and KP: "size_of TYPE('a) * kp \<le> np" and KQ: "size_of TYPE('b) * kq \<le> nq"
    and I: "i<kp" and J: "j<kq"
  shows "ptr_span (p +\<^sub>p int i) \<inter> ptr_span (q +\<^sub>p int j) = {}"
proof -
  have SP: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) np" by (rule c0008_prove[OF W LP KP I])
  have SQ: "ptr_span (q +\<^sub>p int j) \<subseteq> block_bytes (ptr_val q) nq" by (rule c0008_prove[OF W LQ KQ J])
  have DIS: "block_bytes (ptr_val p) np \<inter> block_bytes (ptr_val q) nq = {}"
    using W LP LQ NE unfolding allocator_wf_def by blast
  show ?thesis using SP SQ DIS by blast
qed

lemma vero_aux_live_slot_readable:
  fixes p :: "'a::mem_type ptr"
  assumes W: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and K: "size_of TYPE('a) * k \<le> n" and I: "i<k"
    and G: "c_guard (p +\<^sub>p int i)"
  shows "block_bytes (ptr_val (p +\<^sub>p int i)) (size_of TYPE('a)) \<subseteq> readable_bytes A"
proof -
  have SP: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n" by (rule c0008_prove[OF W L K I])
  have EQ: "block_bytes (ptr_val (p +\<^sub>p int i)) (size_of TYPE('a)) = ptr_span (p +\<^sub>p int i)"
    using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]] by (simp add: block_bytes_def)
  show ?thesis unfolding EQ by (rule subset_trans[OF SP vero_aux_live_readable[OF L]])
qed


lemma vero_aux_rep_graph:
  assumes R: "bn_rep s h P F M"
  shows "bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {}"
proof -
  let ?N = "bn_ds_forest_nodes F"
  let ?nodes = "concat (map (case_option [] bn_ds_node_list) F)"
  let ?roots = "concat (map (case_option [] (\<lambda>T. [bn_root T])) F)"
  let ?slots = "bn_ds_slots (roots_C (bn_heap s h)) (length F)"
  let ?E = "{(q,r). q \<in> ?N \<and> r \<in> set (bn_ds_physical_edges s q)}"
  have NEQ: "?N = set ?nodes" by (simp add: bn_ds_forest_nodes_def)
  have V: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid s P T"
    using R by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    using V vero_aux_valid_layout by blast
  have NN: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_root T \<noteq> NULL"
  proof (intro allI impI)
    fix T assume "Some T \<in> set F"
    then have "bn_valid s P T" using V by blast
    then show "bn_root T \<noteq> NULL" by (cases T) (auto dest: c_guard_NULL)
  qed
  have SV: "map (h_val (hrs_mem (t_hrs_' s))) ?slots = map (case_option NULL bn_root) F"
    using R unfolding bn_rep_def bn_ds_slots_def
    by (intro nth_equalityI) (auto simp: o_def)
  have FIL: "filter (\<lambda>p. p \<noteq> NULL) (map (case_option NULL bn_root) F) = ?roots"
    using NN by (induction F) (auto split: option.splits)
  have RH: "bn_ds_slot_handles s ?slots = mset ?roots"
    by (simp only: bn_ds_slot_handles_def SV FIL)
  have ROOTS: "set ?roots \<subseteq> ?N"
    using vero_aux_nodes_root by (auto simp: NEQ split: option.splits)
  have CLOSED: "\<And>p. p \<in> ?N \<Longrightarrow> set (bn_ds_physical_edges s p) \<subseteq> ?N"
  proof -
    fix p assume PN: "p \<in> ?N"
    obtain T where TF: "Some T \<in> set F" and PT: "p \<in> set (bn_ds_node_list T)"
      using PN by (auto simp: vero_aux_forest_node_member)
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    have SUB: "set (bn_ds_node_list T) \<subseteq> ?N" using TF by (auto simp: vero_aux_forest_node_member)
    show "set (bn_ds_physical_edges s p) \<subseteq> ?N"
      using vero_aux_layout_edges_closed[OF LT] PT SUB by blast
  qed
  have REACH: "?N = {p. \<exists>r \<in> set ?roots. (r,p) \<in> ?E\<^sup>*}"
  proof (rule set_eqI, rule iffI)
    fix p assume PN: "p \<in> ?N"
    obtain T where TF: "Some T \<in> set F" and PT: "p \<in> set (bn_ds_node_list T)"
      using PN by (auto simp: vero_aux_forest_node_member)
    have LT: "bn_ds_tree_layout s P T" using L TF by blast
    have SUB: "set (bn_ds_node_list T) \<subseteq> ?N" using TF by (auto simp: vero_aux_forest_node_member)
    have PATH: "(bn_root T,p) \<in> ?E\<^sup>*" using vero_aux_layout_reachable[OF LT SUB] PT by blast
    have RT: "bn_root T \<in> set ?roots" using TF by auto
    show "p \<in> {p. \<exists>r \<in> set ?roots. (r,p) \<in> ?E\<^sup>*}" using PATH RT by blast
  next
    fix p assume "p \<in> {p. \<exists>r \<in> set ?roots. (r,p) \<in> ?E\<^sup>*}"
    then obtain r where RT: "r \<in> set ?roots" and PATH: "(r,p) \<in> ?E\<^sup>*" by blast
    have RN: "r \<in> ?N" using ROOTS RT by blast
    show "p \<in> ?N" apply (rule vero_aux_rtrancl_closed[OF PATH RN]) using CLOSED by auto
  qed
  have DB: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
    using R by (auto simp: bn_rep_def bn_owned_def)
  have DN: "distinct ?nodes" by (rule vero_aux_forest_distinct_nodes[OF DB])
  have COUNT: "\<And>p. p \<in> ?N \<Longrightarrow> count (bn_ds_slot_handles s ?slots) p +
      (\<Sum>q \<in> ?N. count (mset (bn_ds_physical_edges s q)) p) = 1"
  proof -
    fix p assume PN: "p \<in> ?N"
    have SUM: "sum_list (map (\<lambda>q. count (mset (bn_ds_physical_edges s q)) p) ?nodes) =
      (\<Sum>q \<in> ?N. count (mset (bn_ds_physical_edges s q)) p)"
      using sum_list_distinct_conv_sum_set[OF DN, where f="\<lambda>q. count (mset (bn_ds_physical_edges s q)) p"] by (simp only: NEQ)
    have ONE: "count (mset ?nodes) p = 1" using DN PN NEQ by (simp add: distinct_count_atmost_1)
    show "count (bn_ds_slot_handles s ?slots) p + (\<Sum>q \<in> ?N. count (mset (bn_ds_physical_edges s q)) p) = 1"
      using vero_aux_forest_edge_count[OF L, where x=p] by (simp only: SUM ONE RH add.commute)
  qed
  have OK: "\<forall>p \<in> ?N. vero_aux_node_ok s P p"
    using V vero_aux_valid_node_fields by (auto simp: vero_aux_forest_node_member; blast)
  have W: "allocator_wf (phantom_machine_state_' s)" and PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and LEN: "length F \<le> 32" using R by (auto simp: bn_rep_def)
  have DS: "distinct ?slots" by (rule vero_aux_slots_distinct[OF LEN])
  have SG: "\<forall>a \<in> set ?slots. c_guard a" using R by (auto simp: bn_rep_def bn_ds_slots_def)
  show ?thesis
    unfolding bn_ds_graph_def
    apply (rule conjI[OF W])
    apply (rule conjI[OF PS])
    apply (rule conjI)
     apply (simp only: NEQ finite_set)
    apply (rule conjI[OF DS])
    apply (rule conjI[OF SG])
    apply (rule conjI)
     using ROOTS apply (simp only: RH add.right_neutral set_mset_mset)
    apply (rule conjI)
     apply simp
    apply (rule conjI)
     apply (simp only: RH add.right_neutral set_mset_mset Un_empty_right)
     apply (rule REACH)
    using OK CLOSED COUNT
    by (auto simp: vero_aux_node_ok_def Let_def)

qed


lemma vero_aux_rep_storage:
  assumes R: "bn_rep s h P F M"
  shows "bn_ds_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"
proof -
  let ?A = "phantom_machine_state_' s"
  let ?a = "roots_C (bn_heap s h)"
  let ?N = "bn_ds_forest_nodes F"
  let ?nodes = "concat (map (case_option [] bn_ds_node_list) F)"
  let ?blocks = "concat (map (case_option [] (bn_blocks s)) F)"
  let ?slots = "bn_ds_slots ?a (length F)"
  have NEQ: "?N = set ?nodes" by (simp add: bn_ds_forest_nodes_def)
  have W: "allocator_wf ?A" and DB: "distinct ?blocks"
    using R by (auto simp: bn_rep_def bn_owned_def)
  have V: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid s P T"
    using R by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_ds_tree_layout s P T"
    using V vero_aux_valid_layout by blast
  have OK: "\<forall>p \<in> ?N. vero_aux_node_ok s P p"
    using V vero_aux_valid_node_fields by (auto simp: vero_aux_forest_node_member; blast)
  have BEQ: "?blocks = concat (map (vero_aux_node_blocks s) ?nodes)" by (rule vero_aux_forest_blocks[OF L])
  have DC: "\<And>p. p \<in> ?N \<Longrightarrow> distinct (vero_aux_node_blocks s p)"
    using vero_aux_distinct_components[of "vero_aux_node_blocks s" ?nodes] DB by (simp only: BEQ NEQ)
  have DD: "\<And>p q. p \<in> ?N \<Longrightarrow> q \<in> ?N \<Longrightarrow> p \<noteq> q \<Longrightarrow>
    set (vero_aux_node_blocks s p) \<inter> set (vero_aux_node_blocks s q) = {}"
    using vero_aux_disjoint_components[of "vero_aux_node_blocks s" ?nodes] DB by (simp only: BEQ NEQ; blast)
  have AB: "\<And>p. p \<in> ?N \<Longrightarrow> order_C (bn_tree s p) \<noteq> 0 \<Longrightarrow>
    ptr_val (subtrees_C (bn_tree s p)) \<in> set ?blocks"
    by (auto simp: BEQ NEQ vero_aux_node_blocks_def)
  have AN: "\<And>p. p \<in> ?N \<Longrightarrow> order_C (bn_tree s p) \<noteq> 0 \<Longrightarrow>
    ptr_val (subtrees_C (bn_tree s p)) \<notin> ptr_val ` ?N"
  proof -
    fix p assume PN: "p \<in> ?N" and NZ: "order_C (bn_tree s p) \<noteq> 0"
    show "ptr_val (subtrees_C (bn_tree s p)) \<notin> ptr_val ` ?N"
    proof
      assume "ptr_val (subtrees_C (bn_tree s p)) \<in> ptr_val ` ?N"
      then obtain q where QN: "q \<in> ?N" and EQ: "ptr_val (subtrees_C (bn_tree s p)) = ptr_val q" by blast
      show False
      proof (cases "p=q")
        case True
        show False using DC[OF PN] NZ EQ True by (simp add: vero_aux_node_blocks_def)
      next
        case False
        show False using DD[OF PN QN False] NZ EQ by (auto simp: vero_aux_node_blocks_def)
      qed
    qed
  qed
  have AA: "\<And>p q. p \<in> ?N \<Longrightarrow> q \<in> ?N \<Longrightarrow> p \<noteq> q \<Longrightarrow>
    order_C (bn_tree s p) \<noteq> 0 \<Longrightarrow> order_C (bn_tree s q) \<noteq> 0 \<Longrightarrow>
    subtrees_C (bn_tree s p) \<noteq> subtrees_C (bn_tree s q)"
  proof -
    fix p q assume PN: "p \<in> ?N" and QN: "q \<in> ?N" and NE: "p \<noteq> q"
      and PZ: "order_C (bn_tree s p) \<noteq> 0" and QZ: "order_C (bn_tree s q) \<noteq> 0"
    show "subtrees_C (bn_tree s p) \<noteq> subtrees_C (bn_tree s q)"
      using DD[OF PN QN NE] PZ QZ by (auto simp: vero_aux_node_blocks_def)
  qed
  have SG: "\<forall>i<length F. c_guard (?a +\<^sub>p int i)" using R by (simp add: bn_rep_def)
  have SR: "\<forall>x \<in> set ?slots. block_bytes (ptr_val x) (size_of TYPE(StrictC'_BinomialTree_C ptr)) \<subseteq> readable_bytes ?A"
  proof (cases "F=[]")
    case True then show ?thesis by (simp add: bn_ds_slots_def)
  next
    case False
    have NN: "?a \<noteq> NULL" using R False by (auto simp: bn_rep_def)
    obtain n where AL: "live_blocks ?A (ptr_val ?a) = Some n"
      and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F \<le> n"
      using R NN by (auto simp: bn_rep_def)
    show ?thesis using vero_aux_live_slot_readable[OF W AL SZ] SG by (auto simp: bn_ds_slots_def)
  qed
  have AS: "\<And>p. p \<in> ?N \<Longrightarrow> order_C (bn_tree s p) \<noteq> 0 \<Longrightarrow>
    set ?slots \<inter> set (bn_ds_slots (subtrees_C (bn_tree s p)) (unat (order_C (bn_tree s p)))) = {}"
  proof -
    fix p assume PN: "p \<in> ?N" and NZ: "order_C (bn_tree s p) \<noteq> 0"
    let ?b = "subtrees_C (bn_tree s p)"
    let ?k = "unat (order_C (bn_tree s p))"
    show "set ?slots \<inter> set (bn_ds_slots ?b ?k) = {}"
    proof (cases "F=[]")
      case True then show ?thesis by (simp add: bn_ds_slots_def)
    next
      case False
      have NN: "?a \<noteq> NULL" using R False by (auto simp: bn_rep_def)
      obtain n where AL: "live_blocks ?A (ptr_val ?a) = Some n"
        and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F \<le> n"
        using R NN by (auto simp: bn_rep_def)
      have FREE: "ptr_val ?a \<notin> set ?blocks" using R NN by (simp add: bn_rep_def bn_owned_def)
      have NE: "ptr_val ?a \<noteq> ptr_val ?b"
      proof
        assume E: "ptr_val ?a = ptr_val ?b"
        have IN: "ptr_val ?a \<in> set ?blocks" using AB[OF PN NZ] by (simp only: E)
        show False using FREE IN by contradiction
      qed
      have NP: "vero_aux_node_ok s P p" using OK PN by blast
      have LEN: "length (bn_ds_physical_edges s p) = ?k" using NP by (simp add: vero_aux_node_ok_def Let_def)
      have ES: "bn_ds_physical_edges s p \<noteq> []" using NZ LEN by (auto simp: unat_eq_zero)
      have BL: "live_blocks ?A (ptr_val ?b) = Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * ?k)"
        using NP ES LEN by (simp add: vero_aux_node_ok_def Let_def)
      show ?thesis
      proof (rule equals0I)
        fix x assume X: "x \<in> set ?slots \<inter> set (bn_ds_slots ?b ?k)"
        obtain i j where I: "i<length F" and J: "j<?k"
          and XI: "x = ?a +\<^sub>p int i" and XJ: "x = ?b +\<^sub>p int j"
          using X by (auto simp: bn_ds_slots_def)
        have DIS: "ptr_span (?a +\<^sub>p int i) \<inter> ptr_span (?b +\<^sub>p int j) = {}"
          by (rule vero_aux_live_spans_disjoint[OF W AL BL NE SZ order_refl I J])
          have MEM: "ptr_val x \<in> ptr_span x" by (rule intvl_self) simp
        have EMPTY: "ptr_span x = {}" using DIS
          by (simp only: XI[symmetric] XJ[symmetric] Int_absorb)
        show False using MEM by (simp only: EMPTY; simp)
      qed
    qed
  qed
  show ?thesis using SR AN AA AS by (auto simp: bn_ds_graph_storage_def)
qed

lemma c0046_prove:
  "bn_rep s h P F M \<Longrightarrow>
  bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {} \<and>
  bn_ds_graph_storage s (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"

proof -
  assume R: "bn_rep s h P F M"
  show ?thesis
    by (rule conjI[OF vero_aux_rep_graph[OF R] vero_aux_rep_storage[OF R]])
qed



context binomial_heap_input_global_addresses begin

lemma vero_aux_undo_zero_release:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and G: "c_guard a" and Z: "h_val (hrs_mem (t_hrs_' s)) a = NULL"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val a)=Some n"
  shows "bn_contract (do {binomial_heap_merge_undo' a 0; binomial_tree_unref' NULL}) s
    (\<lambda>r t. vero_aux_release s {ptr_val a} {ptr_val a} t)"
proof -
  let ?B = "\<lambda>i::32 word. do {
    guard (\<lambda>u. c_guard (a +\<^sub>p uint i));
    p \<leftarrow> gets (\<lambda>u. h_val (hrs_mem (t_hrs_' u)) (a +\<^sub>p uint i));
    ret \<leftarrow> binomial_tree_unref' p;
    return (i+1)}"
  have B0: "bn_contract (?B 0) s (\<lambda>j t. j=1 \<and> t=s)"
    apply simp
    apply (rule vero_aux_guard_prefix)
     apply (rule G)
    apply (rule vero_aux_gets_prefix)
    apply (simp only: Z)
    apply (rule vero_aux_contract_bind[OF vero_aux_unref_null])
    apply (rule vero_aux_return_contract) by simp
  have LOOP: "bn_contract (whileLoop (\<lambda>i u. i\<le>(0::32 word)) ?B 0) s (\<lambda>j t. t=s)"
  proof (rule vero_aux_contract_while[where I="\<lambda>i. i=0 \<or> i=1" and m="\<lambda>i. if i=0 then 1 else 0"])
    fix i assume I: "i=0 \<or> i=1" and C: "i\<le>(0::32 word)"
    have E: "i=0" using C by simp
    show "bn_contract (?B i) s (\<lambda>j t. t=s \<and> (j=0 \<or> j=1) \<and> (if j=0 then (1::nat) else 0) < (if i=0 then 1 else 0))"
      unfolding E apply (rule vero_aux_contract_weaken[OF B0]) by auto
  qed simp_all
  have LP: "live_blocks (phantom_machine_state_' s) (ptr_val (ptr_coerce a :: unit ptr))=Some n" using L by simp
  have FREE: "bn_contract (free' (ptr_coerce a)) s (\<lambda>r t. vero_aux_release s {ptr_val a} {ptr_val a} t)"
    using vero_aux_free_release[OF W LP] by simp
  have UNDO: "bn_contract (binomial_heap_merge_undo' a 0) s (\<lambda>r t. vero_aux_release s {ptr_val a} {ptr_val a} t)"
    unfolding binomial_heap_merge_undo'_def
    apply (rule vero_aux_contract_bind[OF LOOP]) using FREE by simp
  show ?thesis
    apply (rule vero_aux_contract_bind[OF UNDO])
    subgoal for r t
      apply (rule vero_aux_contract_weaken[OF vero_aux_unref_null]) by simp
    done
qed

lemma vero_aux_undo_external_storage_lost:
  assumes R: "vero_aux_release s {ptr_val a} {ptr_val a} t"
    and LIVE: "live_blocks (phantom_machine_state_' s) = (\<lambda>q. if q=ptr_val a then Some n else None)"
    and RES: "reserved_bytes (phantom_machine_state_' s)={}"
  shows "\<not>bn_ds_graph_storage t N [b]"
proof -
  have LT: "live_blocks (phantom_machine_state_' t) = (\<lambda>_. None)"
    using R LIVE by (auto simp: vero_aux_release_def fun_eq_iff)
  have RT: "readable_bytes (phantom_machine_state_' t) = {}"
    using R RES LT by (simp add: vero_aux_release_def readable_bytes_def)
  have NONEMPTY: "ptr_val b\<in>block_bytes (ptr_val b) (size_of TYPE(StrictC'_BinomialTree_C ptr))"
    by (simp add: block_bytes_def)
  show ?thesis using NONEMPTY by (auto simp: bn_ds_graph_storage_def RT)
qed


definition vero_aux_undo_alias_state :: globals where
  "vero_aux_undo_alias_state = (undefined::globals)\<lparr>
    t_hrs_' := ((\<lambda>_. 0), undefined),
    phantom_machine_state_' := \<lparr>live_blocks = (\<lambda>q. if q=16 then Some 16 else None), reserved_bytes={}\<rparr>\<rparr>"

lemma vero_aux_zero_memory_pointer:
  "h_val (\<lambda>_. 0) (p :: 'a::mem_type ptr ptr) = NULL"
proof -
  have H0: "\<And>n a. heap_list (\<lambda>_. 0) n a = replicate n 0"
    by (intro nth_equalityI) (auto simp: heap_list_nth)
  have H: "heap_list (\<lambda>_. 0) 8 (ptr_val p) = replicate 8 0" by (rule H0)
  have "h_val (\<lambda>_. 0) p = ZERO('a ptr)" by (simp add: h_val_def zero_def H)
  then show ?thesis by (simp add: vero_aux_zero_pointer)
qed

lemma vero_aux_undo_alias_pre:
  "bn_ds_owned_array vero_aux_undo_alias_state (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr) 1 \<and>
   bn_ds_graph vero_aux_undo_alias_state {} {} (\<lambda>_. []) [Ptr 16, Ptr 24] {#} {} \<and>
   bn_ds_graph_storage vero_aux_undo_alias_state {} [Ptr 16, Ptr 24] \<and>
   ptr_val (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr) \<notin> bn_ds_graph_blocks vero_aux_undo_alias_state {}"
proof -
  let ?s = "vero_aux_undo_alias_state"
  have W: "allocator_wf (phantom_machine_state_' ?s)"
    by (auto simp: vero_aux_undo_alias_state_def allocator_wf_def block_ok_def split: if_splits)
  have NG16: "0\<notin>{(16::addr)..+8}"
    using intvl_no_overflow_nat'[where a="16::addr" and b=8 and x=0] by simp
  have NG24: "0\<notin>{(24::addr)..+8}"
    using intvl_no_overflow_nat'[where a="24::addr" and b=8 and x=0] by simp
  have G16: "c_guard (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr)"
    using NG16 by (simp add: c_guard_def ptr_aligned_def c_null_guard_def ptr_val_def)
  have G24: "c_guard (Ptr 24 :: StrictC'_BinomialTree_C ptr ptr)"
    using NG24 by (simp add: c_guard_def ptr_aligned_def c_null_guard_def ptr_val_def)
  have H16: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr) = NULL"
    by (simp add: vero_aux_undo_alias_state_def hrs_mem_def vero_aux_zero_memory_pointer)
  have H24: "h_val (hrs_mem (t_hrs_' ?s)) (Ptr 24 :: StrictC'_BinomialTree_C ptr ptr) = NULL"
    by (simp add: vero_aux_undo_alias_state_def hrs_mem_def vero_aux_zero_memory_pointer)
  have READ: "readable_bytes (phantom_machine_state_' ?s) = block_bytes 16 16"
    by (auto simp: vero_aux_undo_alias_state_def readable_bytes_def split: if_splits)
  have B16: "block_bytes (16::addr) 8 \<subseteq> block_bytes 16 16"
    and B24: "block_bytes (24::addr) 8 \<subseteq> block_bytes 16 16"
    by (auto simp: block_bytes_def)
  have OA: "bn_ds_owned_array ?s (Ptr 16 :: StrictC'_BinomialTree_C ptr ptr) 1"
    using G16 by (auto simp: bn_ds_owned_array_def vero_aux_undo_alias_state_def)
  have GR: "bn_ds_graph ?s {} {} (\<lambda>_. []) [Ptr 16, Ptr 24] {#} {}"
    using W G16 G24 H16 H24 by (simp add: bn_ds_graph_def bn_ds_slot_handles_def)
  have ST: "bn_ds_graph_storage ?s {} [Ptr 16, Ptr 24]"
    using B16 B24 by (simp add: bn_ds_graph_storage_def READ)
  show ?thesis using OA GR ST by (simp add: bn_ds_graph_blocks_def)
qed

lemma vero_aux_undo_alias_failure:
  "\<not> bn_contract (do {binomial_heap_merge_undo' (Ptr 16) 0; binomial_tree_unref' NULL}) vero_aux_undo_alias_state
    (\<lambda>r t. \<exists>N. bn_ds_graph_storage t N [Ptr 24])"
proof
  let ?s = "vero_aux_undo_alias_state"
  let ?a = "Ptr 16 :: StrictC'_BinomialTree_C ptr ptr"
  let ?f = "do {binomial_heap_merge_undo' ?a 0; binomial_tree_unref' NULL}"
  assume C: "bn_contract ?f ?s (\<lambda>r t. \<exists>N. bn_ds_graph_storage t N [Ptr 24])"
  have W: "allocator_wf (phantom_machine_state_' ?s)" and G: "c_guard ?a"
    using vero_aux_undo_alias_pre by (auto simp: bn_ds_owned_array_def bn_ds_graph_def)
  have Z: "h_val (hrs_mem (t_hrs_' ?s)) ?a=NULL"
    by (simp add: vero_aux_undo_alias_state_def hrs_mem_def vero_aux_zero_memory_pointer)
  have L: "live_blocks (phantom_machine_state_' ?s) (ptr_val ?a)=Some 16"
    by (simp add: vero_aux_undo_alias_state_def)
  have EXEC: "bn_contract ?f ?s (\<lambda>r t. vero_aux_release ?s {ptr_val ?a} {ptr_val ?a} t)"
    by (rule vero_aux_undo_zero_release[OF W G Z L])
  obtain r t where REACH: "reaches ?f ?s (Result r) t" using C by (auto simp: bn_contract_def)
  have RT: "vero_aux_release ?s {ptr_val ?a} {ptr_val ?a} t"
    using EXEC REACH by (auto simp: bn_contract_def runs_to_def_old)
  have POST: "\<exists>N. bn_ds_graph_storage t N [Ptr 24]"
    using C REACH by (auto simp: bn_contract_def runs_to_def_old)
  have LIVE: "live_blocks (phantom_machine_state_' ?s) = (\<lambda>q. if q=ptr_val ?a then Some 16 else None)"
    and RES: "reserved_bytes (phantom_machine_state_' ?s)={}"
    by (simp_all add: vero_aux_undo_alias_state_def)
  have "\<And>N. \<not>bn_ds_graph_storage t N [Ptr 24]"
    by (rule vero_aux_undo_external_storage_lost[OF RT LIVE RES])
  then show False using POST by blast
qed



end



lemma c0048_prove:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q) \<Longrightarrow>
   bn_contract (f >>= g) s Q"

proof -
  assume F: "bn_contract f s P"
    and G: "\<And>v t. P v t \<Longrightarrow> bn_contract (g v) t Q"
  have FR: "runs_to f s (\<lambda>r t. \<exists>v. r = Result v \<and> P v t)"
    using F by (simp add: bn_contract_def)
  have RUN: "runs_to (f >>= g) s (\<lambda>r t. \<exists>v. r = Result v \<and> Q v t)"
    apply (rule runs_to_bind)
    apply (rule runs_to_weaken[OF FR])
    using G by (auto simp: bn_contract_def)
  obtain v t where FV: "reaches f s (Result v) t"
    using F by (auto simp: bn_contract_def)
  have PV: "P v t" using runs_toD2[OF FR FV] by (simp add: Result_eq_Result)
  obtain w u where GW: "reaches (g v) t (Result w) u"
    using G[OF PV] by (auto simp: bn_contract_def)
  have SU: "succeeds (f >>= g) s" using RUN by (auto simp: runs_to_def_old)
  have REACH: "reaches (f >>= g) s (Result w) u"
    apply (simp only: reaches_bind)
    apply (rule conjI[OF SU])
    apply (rule exI[where x="Result v"])
    apply (rule exI[where x=t])
    using FV GW by simp
  show ?thesis using RUN REACH by (auto simp: bn_contract_def)
qed



context binomial_heap_input_global_addresses begin



lemma c0049_prove:
  "allocator_wf (phantom_machine_state_' s) \<Longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
    bn_valid s P T \<Longrightarrow> distinct (bn_blocks s T) \<Longrightarrow>
    bn_contract (binomial_tree_unref' (bn_root T)) s (\<lambda>r t.
      allocator_wf (phantom_machine_state_' t) \<and>
      reserved_bytes (phantom_machine_state_' t) = reserved_bytes (phantom_machine_state_' s) \<and>
      (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a) \<and>
      live_blocks (phantom_machine_state_' t) =
        (\<lambda>p. if p \<in> set (bn_blocks s T) then None else live_blocks (phantom_machine_state_' s) p) \<and>
      (\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow>
        p \<notin> set (bn_blocks s T) \<longrightarrow>
        (\<forall>a \<in> block_bytes p n. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a)))"

proof -
  assume A: "allocator_wf (phantom_machine_state_' s)"
    and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and V: "bn_valid s P T" and D: "distinct (bn_blocks s T)"
  show ?thesis
    apply (rule vero_aux_contract_weaken[OF vero_aux_unref_release[OF A PS V D]])
    using PS by (auto simp: vero_aux_release_def fun_eq_iff)
qed



end

context binomial_heap_input_global_addresses begin



lemma c0050_prove:
  "bn_valid s P T \<Longrightarrow> q \<in> set (bn_values s T) \<Longrightarrow>
    bn_key s (value_C (bn_tree s (bn_root T))) \<le> bn_key s q"

by (cases T) auto



end



lemma c0051_prove:
  "ptr_val (bn_root T) \<in> set (bn_blocks s T)"

by (cases T) auto



context binomial_heap_input_global_addresses begin

lemma vero_aux_readable_array:
  assumes W: "allocator_wf A" and L: "live_blocks A (ptr_val (p :: 'a::mem_type ptr)) = Some n"
    and K: "size_of TYPE('a) * k \<le> n" and I: "i < k"
    and BF: "\<forall>a \<in> readable_bytes A. hp' a = hp a"
  shows "h_val hp' (p +\<^sub>p int i) = h_val hp (p +\<^sub>p int i)"
proof -
  have SP: "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) n"
    by (rule c0008_prove[OF W L K I])
  have B: "block_bytes (ptr_val p) n \<subseteq> readable_bytes A"
    using L by (auto simp: readable_bytes_def)
  show ?thesis apply (rule vero_aux_h_val_agree) using SP B BF by blast
qed

lemma vero_aux_readable_live:
  fixes p :: "'a::mem_type ptr"
  assumes W: "allocator_wf A" and L: "live_blocks A (ptr_val p) = Some n"
    and K: "size_of TYPE('a) \<le> n"
    and BF: "\<forall>a \<in> readable_bytes A. hp' a = hp a"
  shows "h_val hp' p = h_val hp p"
proof -
  have "h_val hp' (p +\<^sub>p int 0) = h_val hp (p +\<^sub>p int 0)"
    by (rule vero_aux_readable_array[OF W L _ _ BF, where k=1]) (simp_all add: K)
  thus ?thesis by simp
qed

lemma vero_aux_readable_key:
  assumes V: "bn_payload P v" and PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and BF: "\<forall>a \<in> readable_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a"
  shows "bn_key t v = bn_key s v"
proof -
  let ?p = "ptr_coerce v :: 32 signed word ptr"
  have G: "c_guard ?p" and B: "block_bytes (ptr_val ?p) 4 \<subseteq> P"
    using V by (auto simp: bn_payload_def)
  have SP: "ptr_span ?p \<subseteq> P"
    using B intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]]
    by (simp add: block_bytes_def)
  have HV: "h_val (hrs_mem (t_hrs_' t)) ?p = h_val (hrs_mem (t_hrs_' s)) ?p"
    apply (rule vero_aux_h_val_agree)
    using SP PS BF by (auto simp: readable_bytes_def)
  show ?thesis by (simp add: bn_key_def HV)
qed

lemma vero_aux_readable_valid:
  assumes W: "allocator_wf (phantom_machine_state_' s)"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and BF: "\<forall>a \<in> readable_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a"
    and V: "bn_valid s P T"
  shows "bn_valid t P T \<and> bn_values t T = bn_values s T \<and>
    bn_blocks t T = bn_blocks s T \<and>
    (\<forall>v \<in> set (bn_values s T). bn_key t v = bn_key s v)"
  using V
proof (induction T)
  case (BN p cs)
  have L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using BN.prems by simp
  have TP: "bn_tree t p = bn_tree s p"
    unfolding bn_tree_def by (rule vero_aux_readable_live[OF W L _ BF]) simp
  have CHILD: "\<forall>U \<in> set cs. bn_valid t P U \<and> bn_values t U = bn_values s U \<and>
    bn_blocks t U = bn_blocks s U \<and> (\<forall>v \<in> set (bn_values s U). bn_key t v = bn_key s v)"
    using BN.IH BN.prems by (auto simp: list_all_iff)
  have VC: "map (bn_values t) cs = map (bn_values s) cs"
    using CHILD by (auto intro!: map_cong)
  have BC: "map (bn_blocks t) cs = map (bn_blocks s) cs"
    using CHILD by (auto intro!: map_cong)
  have PAY: "bn_payload P (value_C (bn_tree s p))" using BN.prems by simp
  have KC: "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
    by (rule vero_aux_readable_key[OF PAY PS BF])
  have ARR: "\<forall>i < length cs. h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
  proof (intro allI impI)
    fix i assume I: "i < length cs"
    have NE: "cs \<noteq> []" using I by auto
    have AL: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
      Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length cs)"
      using BN.prems NE by simp
    show "h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
      by (rule vero_aux_readable_array[OF W AL _ I BF]) simp
  qed
  show ?case using BN.prems CHILD TP VC BC KC ARR A
    by (auto simp: list_all_iff VC BC)
qed

lemma vero_aux_readable_rep:
  assumes R: "bn_rep s h P F M"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and BF: "\<forall>a \<in> readable_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a"
  shows "bn_rep t h P F M"
proof -
  have W: "allocator_wf (phantom_machine_state_' s)"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using R by (auto simp: bn_rep_def)
  have H: "bn_heap t h = bn_heap s h"
    unfolding bn_heap_def by (rule vero_aux_readable_live[OF W L _ BF]) simp
  have VS: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid s P T"
    using R by (auto simp: bn_rep_def in_set_conv_nth)
  have VT: "\<forall>T. Some T \<in> set F \<longrightarrow> bn_valid t P T \<and>
      bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"
    using VS vero_aux_readable_valid[OF W A PS BF] by blast
  have MV: "map (case_option [] (bn_values t)) F = map (case_option [] (bn_values s)) F"
    using VT by (auto intro!: map_cong split: option.splits)
  have MB: "map (case_option [] (bn_blocks t)) F = map (case_option [] (bn_blocks s)) F"
    using VT by (auto intro!: map_cong split: option.splits)
  have FV: "bn_forest_values t F = bn_forest_values s F" by (simp add: bn_forest_values_def MV)
  have OWN: "bn_owned t h F = bn_owned s h F" by (simp add: bn_owned_def H MB)
  have ARR: "\<forall>i < length F. h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)"
  proof (intro allI impI)
    fix i assume I: "i < length F"
    have NN: "roots_C (bn_heap s h) \<noteq> NULL" using R I by (auto simp: bn_rep_def)
    obtain n where RL: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
      and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F \<le> n"
      using R NN by (auto simp: bn_rep_def)
    have "h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap s h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)"
      by (rule vero_aux_readable_array[OF W RL SZ I BF])
    thus "h_val (hrs_mem (t_hrs_' t)) (roots_C (bn_heap t h) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p int i)" by (simp add: H)
  qed
  show ?thesis using R A H FV OWN ARR VT
    by (auto simp: bn_rep_def split: option.splits dest: nth_mem)
qed






lemma vero_aux_restore_rep:
  assumes R: "bn_rep s h P F M" and REST: "bn_ds_restore s t"
  shows "bn_rep t h P F M \<and> bn_frame s h P F t \<and>
    phantom_machine_state_' t = phantom_machine_state_' s \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s)"
proof -
  have A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and BF: "\<forall>a \<in> readable_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a"
    using REST by (auto simp: bn_ds_restore_def)
  have PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)" using R by (simp add: bn_rep_def)
  have REP: "bn_rep t h P F M" by (rule vero_aux_readable_rep[OF R A PS BF])
  show ?thesis using REP REST PS
    by (auto simp: bn_ds_restore_def bn_frame_def readable_bytes_def;
      metis (mono_tags, lifting) UN_I UnI2 domI option.sel)
qed

lemma vero_aux_list_update_agree:
  "hp' a = hp a \<Longrightarrow> heap_update_list p bs hp' a = heap_update_list p bs hp a"
proof (induction bs arbitrary: p hp hp')
  case Nil
  then show ?case by simp
next
  case (Cons b bs)
  have E: "(hp'(p := b)) a = (hp(p := b)) a" using Cons.prems by simp
  show ?case
    by (simp only: heap_update_list.simps; rule Cons.IH; rule E)
qed

lemma vero_aux_update_agree:
  fixes p :: "'a::mem_type ptr"
  assumes SP: "ptr_span p \<subseteq> R" and BF: "\<forall>a \<in> R. hp' a = hp a"
  shows "\<forall>a \<in> R. heap_update p v hp' a = heap_update p v hp a"
proof -
  have L: "heap_list hp' (size_of TYPE('a)) (ptr_val (p :: 'a::mem_type ptr)) =
    heap_list hp (size_of TYPE('a)) (ptr_val p)"
    apply (rule heap_list_h_eq2) using SP BF by blast
  show ?thesis using BF
    by (simp only: heap_update_def L; blast intro: vero_aux_list_update_agree)
qed


lemma vero_aux_guard_modify_return:
  "G s \<Longrightarrow> Q v (f s) \<Longrightarrow>
    bn_contract (do {guard G; modify f; return v}) s Q"
  by (auto simp: bn_contract_def runs_to_bind_iff runs_to_guard_iff runs_to_modify_iff
    reaches_bind reaches_guard reaches_modify reaches_return[abs_def] succeeds_runs_to_iff)

lemma c0052_prove:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  bn_ds_restore (bn_review_clear_root entry h i) s \<Longrightarrow>
  bn_contract (bn_ds_pop_restore h (of_nat i) (bn_root T)) s (\<lambda>r t.
   r = NULL \<and> bn_rep t h P F M \<and> bn_frame entry h P F t \<and>
   phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry))"

proof -
  assume R: "bn_rep entry h P F M" and I: "i < length F" and FI: "F ! i = Some T"
    and REST: "bn_ds_restore (bn_review_clear_root entry h i) s"
  let ?A = "phantom_machine_state_' entry"
  let ?hp = "hrs_mem (t_hrs_' entry)"
  let ?roots = "roots_C (bn_heap entry h)"
  let ?p = "?roots +\<^sub>p int i"
  let ?c = "bn_review_clear_root entry h i"
  let ?u = "t_hrs_'_update (hrs_mem_update (heap_update ?p (bn_root T))) s"
  have W: "allocator_wf ?A" and GH: "c_guard h"
    and LH: "live_blocks ?A (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    and GP: "c_guard ?p" and VAL: "h_val ?hp ?p = bn_root T"
    and FL: "length F \<le> 32" and NN: "?roots \<noteq> NULL"
    using R I FI by (auto simp: bn_rep_def)
  obtain n where LR: "live_blocks ?A (ptr_val ?roots) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F \<le> n"
    using R NN by (auto simp: bn_rep_def)
  have DH: "ptr_val h \<noteq> ptr_val ?roots" using R NN by (auto simp: bn_rep_def bn_owned_def)
  have DB: "block_bytes (ptr_val h) (size_of TYPE(StrictC'_BinomialHeap_C)) \<inter> block_bytes (ptr_val ?roots) n = {}"
    using W LH LR DH by (auto simp: allocator_wf_def)
  have SH: "ptr_span h \<subseteq> block_bytes (ptr_val h) (size_of TYPE(StrictC'_BinomialHeap_C))"
    using c0008_prove[OF W LH, where k=1 and i=0] by simp
  have SR: "ptr_span ?p \<subseteq> block_bytes (ptr_val ?roots) n" by (rule c0008_prove[OF W LR SZ I])
  have DIS: "ptr_span h \<inter> ptr_span ?p = {}" using SH SR DB by blast
  have HC: "h_val (hrs_mem (t_hrs_' ?c)) h = h_val ?hp h"
    using DIS by (simp add: bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update_disjoint)
  have AC: "phantom_machine_state_' ?c = ?A" by (simp add: bn_review_clear_root_def)
  have AS: "phantom_machine_state_' s = ?A" and HT: "hrs_htd (t_hrs_' s) = hrs_htd (t_hrs_' entry)"
    and MEM: "\<forall>a \<in> readable_bytes ?A. hrs_mem (t_hrs_' s) a = heap_update ?p NULL ?hp a"
    using REST by (auto simp: bn_ds_restore_def bn_review_clear_root_def hrs_mem_update_def hrs_mem_def hrs_htd_def case_prod_unfold)
  have HSC: "h_val (hrs_mem (t_hrs_' s)) h = h_val (hrs_mem (t_hrs_' ?c)) h"
    apply (rule vero_aux_readable_live[where A="?A" and n="size_of TYPE(StrictC'_BinomialHeap_C)"])
        apply (rule W)
       apply (rule LH)
      apply simp
    using REST AC by (simp add: bn_ds_restore_def)
  have HS: "h_val (hrs_mem (t_hrs_' s)) h = bn_heap entry h" using HSC HC by (simp add: bn_heap_def)
  have BR: "block_bytes (ptr_val ?roots) n \<subseteq> readable_bytes ?A"
    using LR by (auto simp: readable_bytes_def)
  have SP: "ptr_span ?p \<subseteq> readable_bytes ?A" using SR BR by blast
  have UP: "\<forall>a \<in> readable_bytes ?A.
      heap_update ?p (bn_root T) (hrs_mem (t_hrs_' s)) a = heap_update ?p (bn_root T) (heap_update ?p NULL ?hp) a"
    by (rule vero_aux_update_agree[OF SP MEM])
  have INV: "heap_update ?p (bn_root T) (heap_update ?p NULL ?hp) = ?hp"
    by (simp add: heap_update_collapse heap_update_id[OF VAL])
  have UP0: "\<forall>a \<in> readable_bytes ?A. heap_update ?p (bn_root T) (hrs_mem (t_hrs_' s)) a = ?hp a"
    using UP by (simp only: INV)
  have RU: "bn_ds_restore entry ?u" using UP0 AS HT
    by (auto simp: bn_ds_restore_def hrs_mem_update_def hrs_mem_def hrs_htd_def case_prod_unfold)
  have POST: "bn_rep ?u h P F M \<and> bn_frame entry h P F ?u \<and>
    phantom_machine_state_' ?u = ?A \<and> hrs_htd (t_hrs_' ?u) = hrs_htd (t_hrs_' entry)"
    by (rule vero_aux_restore_rep[OF R RU])
  have IB: "i < 2^32" using I FL by (simp; arith)
  have IDX: "uint (of_nat i :: 32 word) = int i" using IB by (simp add: uint_nat unat_of_nat)
  have UE: "t_hrs_'_update (\<lambda>a. hrs_mem_update
      (heap_update (roots_C (h_val (hrs_mem a) h) +\<^sub>p int i) (bn_root T)) a) s = ?u"
    by (rule globals.equality) (simp_all add: HS)
  show ?thesis
    unfolding bn_ds_pop_restore_def
    apply (rule vero_aux_guard_modify_return)
     apply (simp add: HS IDX GP)
    using POST by (simp only: IDX UE binomial_heap_null_value_def; blast)

qed



end



lemma c0053_prove:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame V hp' hp'' \<Longrightarrow>
    bytes_frame (W \<union> V) hp hp''"

by (auto simp: bytes_frame_def)



context binomial_heap_input_global_addresses begin

lemma vero_aux_guarded_array_bound:
  fixes p :: "'a::mem_type ptr"
  assumes G: "\<forall>i<n. c_guard (p +\<^sub>p int i)"
  shows "unat (ptr_val p) + n * size_of TYPE('a) \<le> 2^64"
  using G
proof (induction n)
  case 0
  then show ?case using unat_lt2p[of "ptr_val p"] by simp
next
  case (Suc n)
  have OLD: "unat (ptr_val p) + n * size_of TYPE('a) \<le> 2^64"
    using Suc.IH Suc.prems by auto
  have GN: "c_guard (p +\<^sub>p int n)" using Suc.prems by simp
  have B: "unat (ptr_val (p +\<^sub>p int n)) + size_of TYPE('a) \<le> 2^64"
    using c_guard_no_wrap'[OF GN] by (simp add: addr_card_def card_word)
  have E: "unat (ptr_val (p +\<^sub>p int n)) = (unat (ptr_val p) + n * size_of TYPE('a)) mod 2^64"
    by (simp add: ptr_add_def unat_word_ariths unat_of_nat mod_add_left_eq mod_add_right_eq mod_mult_left_eq mod_mult_right_eq)
  have LT: "unat (ptr_val p) + n * size_of TYPE('a) < 2^64"
  proof (rule ccontr)
    assume "\<not> unat (ptr_val p) + n * size_of TYPE('a) < 2^64"
    then have EQ: "unat (ptr_val p) + n * size_of TYPE('a) = 2^64" using OLD by arith
    have ZERO: "ptr_val (p +\<^sub>p int n) = 0" using E EQ by (simp add: unat_eq_zero)
    have NN: "p +\<^sub>p int n \<noteq> NULL" using GN by (rule c_guard_NULL)
    show False using ZERO NN by (cases "p +\<^sub>p int n") (simp add: ptr_val_def)
  qed
  have U: "unat (ptr_val (p +\<^sub>p int n)) = unat (ptr_val p) + n * size_of TYPE('a)"
    using E LT by simp
  show ?case using B by (simp add: U algebra_simps)
qed

lemma vero_aux_guarded_array_span:
  fixes p :: "'a::mem_type ptr"
  assumes G: "\<forall>i<n. c_guard (p +\<^sub>p int i)" and I: "i<n"
  shows "ptr_span (p +\<^sub>p int i) \<subseteq> block_bytes (ptr_val p) (size_of TYPE('a) * n)"
proof -
  have B: "unat (ptr_val p) + n * size_of TYPE('a) \<le> 2^64" by (rule vero_aux_guarded_array_bound[OF G])
  show ?thesis
  proof
    fix x assume X: "x \<in> ptr_span (p +\<^sub>p int i)"
    obtain j where J: "j < size_of TYPE('a)" and E: "x = ptr_val p + of_nat (i * size_of TYPE('a) + j)"
      using X by (auto simp: intvl_def ptr_add_def algebra_simps)
    have M: "(i+1) * size_of TYPE('a) \<le> n * size_of TYPE('a)"
      using I by (intro mult_le_mono1) simp
    have N: "i * size_of TYPE('a) + j < n * size_of TYPE('a)" using J M by (simp only: algebra_simps; arith)
    have C: "unat (ptr_val p) + (i * size_of TYPE('a) + j) < 2^64" using B N by arith
    have D: "i * size_of TYPE('a) + j < 2^64" using C by arith
    have U: "unat x = unat (ptr_val p) + (i * size_of TYPE('a) + j)"
      using C D by (simp only: E unat_word_ariths unat_of_nat; simp_all)
    show "x \<in> block_bytes (ptr_val p) (size_of TYPE('a) * n)"
      using N by (simp add: block_bytes_def U mult.commute)
  qed
qed






lemma vero_aux_malloc_extension:
  assumes R: "malloc_rel n hp A p hp' B"
  shows "allocator_wf B \<and> reserved_bytes B = reserved_bytes A \<and>
    (\<forall>q m. live_blocks A q = Some m \<longrightarrow> live_blocks B q = Some m) \<and>
    (\<forall>a \<in> readable_bytes A. hp' a = hp a) \<and> readable_bytes A \<subseteq> readable_bytes B"
proof -
  have W: "allocator_wf A" using R by (simp add: malloc_rel_def)
  show ?thesis
  proof (cases "p=0")
    case True
    then have "hp'=hp" "B=A" using R by (auto simp: malloc_rel_def fresh_block_def block_ok_def)
    then show ?thesis using W by simp
  next
    case False
    have F: "fresh_block A p n" and BF: "bytes_frame (block_bytes p n) hp hp'"
      and B: "B=A\<lparr>live_blocks := (live_blocks A)(p := Some n)\<rparr>"
      using R False by (auto simp: malloc_rel_def)
    have NL: "live_blocks A p = None" by (rule vero_aux_new_not_live[OF W F])
    have WB: "allocator_wf B" using c0021_prove[OF W F] by (simp add: B)
    have LIVE: "\<forall>q m. live_blocks A q = Some m \<longrightarrow> live_blocks B q = Some m"
      using NL by (auto simp: B)
    have READ: "\<forall>a \<in> readable_bytes A. hp' a = hp a"
      using F BF by (auto simp: readable_bytes_def fresh_block_def bytes_frame_def; blast)
    have SUB: "readable_bytes A \<subseteq> readable_bytes B"
      using LIVE by (auto simp: readable_bytes_def B)
    show ?thesis using WB LIVE READ SUB by (simp add: B)
  qed
qed

lemma vero_aux_readable_guarded_value:
  fixes p :: "'a::mem_type ptr"
  assumes G: "c_guard p" and SP: "block_bytes (ptr_val p) (size_of TYPE('a)) \<subseteq> R"
    and BF: "\<forall>a \<in> R. hp' a = hp a"
  shows "h_val hp' p = h_val hp p"
proof -
  have S: "ptr_span p \<subseteq> R"
    using SP intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]]
    by (simp add: block_bytes_def)
  show ?thesis apply (rule vero_aux_h_val_agree) using S BF by blast
qed

lemma vero_aux_array_view_extension:
  assumes V: "bn_review_root_array_view s a F"
    and B: "block_bytes (ptr_val a) (8 * length F) \<subseteq> readable_bytes (phantom_machine_state_' s)"
    and BF: "\<forall>x \<in> readable_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) x = hrs_mem (t_hrs_' s) x"
  shows "bn_review_root_array_view t a F"
proof -
  have G: "\<forall>i<length F. c_guard (a +\<^sub>p int i)" using V by (simp add: bn_review_root_array_view_def)
  have HV: "\<forall>i<length F. h_val (hrs_mem (t_hrs_' t)) (a +\<^sub>p int i) = h_val (hrs_mem (t_hrs_' s)) (a +\<^sub>p int i)"
  proof (intro allI impI)
    fix i assume I: "i<length F"
    have SP: "ptr_span (a +\<^sub>p int i) \<subseteq> readable_bytes (phantom_machine_state_' s)"
      using vero_aux_guarded_array_span[OF G I] B by auto
    show "h_val (hrs_mem (t_hrs_' t)) (a +\<^sub>p int i) = h_val (hrs_mem (t_hrs_' s)) (a +\<^sub>p int i)"
      apply (rule vero_aux_h_val_agree) using SP BF by blast
  qed
  show ?thesis using V HV by (simp add: bn_review_root_array_view_def)
qed


lemma vero_aux_graph_extension:
  assumes GR: "bn_ds_graph s P N edges slots held pending"
    and ST: "bn_ds_graph_storage s N slots"
    and WT: "allocator_wf (phantom_machine_state_' t)"
    and RES: "reserved_bytes (phantom_machine_state_' t) = reserved_bytes (phantom_machine_state_' s)"
    and LIVE: "\<forall>p n. live_blocks (phantom_machine_state_' s) p = Some n \<longrightarrow> live_blocks (phantom_machine_state_' t) p = Some n"
    and BF: "\<forall>a \<in> readable_bytes (phantom_machine_state_' s). hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a"
    and SUB: "readable_bytes (phantom_machine_state_' s) \<subseteq> readable_bytes (phantom_machine_state_' t)"
  shows "bn_ds_graph t P N edges slots held pending \<and> bn_ds_graph_storage t N slots \<and>
    (\<forall>p \<in> N. bn_tree t p = bn_tree s p)"
proof -
  have W: "allocator_wf (phantom_machine_state_' s)"
    and PS: "P \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and EN: "\<forall>p \<in> N. set (edges p) \<subseteq> N"
    using GR by (auto simp: bn_ds_graph_def)
  have HN: "\<forall>p \<in> N. bn_tree t p = bn_tree s p"
  proof (intro ballI)
    fix p assume PN: "p \<in> N"
    have L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
      using GR PN by (simp add: bn_ds_graph_def)
    show "bn_tree t p = bn_tree s p"
      unfolding bn_tree_def by (rule vero_aux_readable_live[OF W L _ BF]) simp
  qed
  have HS: "\<forall>a \<in> set slots. h_val (hrs_mem (t_hrs_' t)) a = h_val (hrs_mem (t_hrs_' s)) a"
  proof (intro ballI)
    fix a assume AS: "a \<in> set slots"
    have G: "c_guard a" and B: "block_bytes (ptr_val a) (size_of TYPE(StrictC'_BinomialTree_C ptr)) \<subseteq> readable_bytes (phantom_machine_state_' s)"
      using GR ST AS by (auto simp: bn_ds_graph_def bn_ds_graph_storage_def)
    show "h_val (hrs_mem (t_hrs_' t)) a = h_val (hrs_mem (t_hrs_' s)) a"
      by (rule vero_aux_readable_guarded_value[OF G B BF])
  qed
  have SH: "bn_ds_slot_handles t slots = bn_ds_slot_handles s slots"
    unfolding bn_ds_slot_handles_def using HS by (simp cong: map_cong)
  have HE: "\<forall>p \<in> N. \<forall>i<length (edges p).
    h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
  proof (intro ballI allI impI)
    fix p i assume PN: "p \<in> N" and I: "i<length (edges p)"
    have NE: "edges p \<noteq> []" using I by auto
    have L: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
      Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length (edges p))"
      using GR PN NE by (simp add: bn_ds_graph_def)
    show "h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
      by (rule vero_aux_readable_array[OF W L _ I BF]) simp
  qed
  have KN: "\<forall>p \<in> N. bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
  proof (intro ballI)
    fix p assume PN: "p \<in> N"
    have PAY: "bn_payload P (value_C (bn_tree s p))" using GR PN by (simp add: bn_ds_graph_def)
    show "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
      by (rule vero_aux_readable_key[OF PAY PS BF])
  qed
  have RK: "\<forall>p \<in> N. map (\<lambda>q. unat (order_C (bn_tree t q))) (edges p) =
    map (\<lambda>q. unat (order_C (bn_tree s q))) (edges p)"
    using HN EN by (auto intro!: map_cong; metis subsetD)
  have ORDER: "\<forall>p \<in> N. \<forall>q \<in> set (edges p).
    bn_key t (value_C (bn_tree t p)) \<le> bn_key t (value_C (bn_tree t q))"
  proof (intro ballI)
    fix p q assume PN: "p \<in> N" and QE: "q \<in> set (edges p)"
    have QN: "q \<in> N" using EN PN QE by blast
    have OLD: "bn_key s (value_C (bn_tree s p)) \<le> bn_key s (value_C (bn_tree s q))"
      using GR PN QE unfolding bn_ds_graph_def by blast
    show "bn_key t (value_C (bn_tree t p)) \<le> bn_key t (value_C (bn_tree t q))"
      by (simp only: HN[rule_format, OF PN] HN[rule_format, OF QN]
        KN[rule_format, OF PN] KN[rule_format, OF QN]; rule OLD)
  qed
  have GT: "bn_ds_graph t P N edges slots held pending"
    using GR WT RES LIVE HN HE KN EN RK ORDER
    by (auto simp: bn_ds_graph_def SH HN[rule_format] KN[rule_format] RK[rule_format])
  have STT: "bn_ds_graph_storage t N slots"
    using ST HN SUB by (auto simp: bn_ds_graph_storage_def HN[rule_format])
  show ?thesis using GT STT HN by blast
qed


lemma vero_aux_carry_initial:

  "bn_ds_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  bn_ds_carry_inv s0 h other P F G ext held N a n (NULL,0,0,vals) s"



proof -
  assume PRE: "bn_ds_merge_pre s0 h other P F G ext held N edges"
    and LEN: "n = max (length F) (length G) + 1"
    and AL: "bn_ds_roots_allocation s0 s a n"
  let ?A = "phantom_machine_state_' s0"
  let ?B = "phantom_machine_state_' s"
  let ?slots = "bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext"
  have FV: "bn_ds_forest_view s0 h P F" and GV: "bn_ds_forest_view s0 other P G"
    and GR: "bn_ds_graph s0 P N edges ?slots held {}"
    and ST: "bn_ds_graph_storage s0 N ?slots"
    using PRE by (auto simp: bn_ds_merge_pre_def)
  have MAL: "malloc_rel (8*n) (hrs_mem (t_hrs_' s0)) ?A (ptr_val a) (hrs_mem (t_hrs_' s)) ?B"
    and AN: "a \<noteq> NULL" and HT: "hrs_htd (t_hrs_' s) = hrs_htd (t_hrs_' s0)"
    using AL by (auto simp: bn_ds_roots_allocation_def)
  have PN: "ptr_val a \<noteq> 0" using AN by (cases a) (simp add: ptr_val_def)
  have W: "allocator_wf ?A" and FR: "fresh_block ?A (ptr_val a) (8*n)"
    and BA: "?B = ?A\<lparr>live_blocks := (live_blocks ?A)(ptr_val a := Some (8*n))\<rparr>"
    using MAL PN by (auto simp: malloc_rel_def)
  have WB: "allocator_wf ?B" and RES: "reserved_bytes ?B = reserved_bytes ?A"
    and LIVE: "\<forall>q m. live_blocks ?A q = Some m \<longrightarrow> live_blocks ?B q = Some m"
    and BF: "\<forall>x \<in> readable_bytes ?A. hrs_mem (t_hrs_' s) x = hrs_mem (t_hrs_' s0) x"
    and SUB: "readable_bytes ?A \<subseteq> readable_bytes ?B"
    using vero_aux_malloc_extension[OF MAL] by blast+
  have HH: "bn_heap s h = bn_heap s0 h"
  proof -
    have GH: "c_guard h" and BH: "block_bytes (ptr_val h) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq> readable_bytes ?A"
      using FV by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
    show ?thesis unfolding bn_heap_def by (rule vero_aux_readable_guarded_value[OF GH BH BF])
  qed
  have HO: "bn_heap s other = bn_heap s0 other"
  proof -
    have GO: "c_guard other" and BO: "block_bytes (ptr_val other) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq> readable_bytes ?A"
      using GV by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
    show ?thesis unfolding bn_heap_def by (rule vero_aux_readable_guarded_value[OF GO BO BF])
  qed
  have RF: "bn_review_root_array_view s (roots_C (bn_heap s0 h)) F"
    apply (rule vero_aux_array_view_extension[OF _ _ BF])
    using FV by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
  have RG: "bn_review_root_array_view s (roots_C (bn_heap s0 other)) G"
    apply (rule vero_aux_array_view_extension[OF _ _ BF])
    using GV by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
  have GT: "bn_ds_graph s P N edges ?slots held {}" and STT: "bn_ds_graph_storage s N ?slots"
    and HN: "\<forall>p \<in> N. bn_tree s p = bn_tree s0 p"
    using vero_aux_graph_extension[OF GR ST WB RES LIVE BF SUB] by blast+
  have GB: "bn_ds_graph_blocks s N = bn_ds_graph_blocks s0 N"
    using HN by (auto simp: bn_ds_graph_blocks_def HN[rule_format])
  have OLD: "bn_ds_old_node_fields s0 N s N"
    using HN by (auto simp: bn_ds_old_node_fields_def HN[rule_format])
  have NL: "live_blocks ?A (ptr_val a) = None" by (rule vero_aux_new_not_live[OF W FR])
  have LA: "live_blocks ?B (ptr_val a) = Some (8*n)" by (simp add: BA)
  have TRAN: "bn_ds_storage_transition s0 (bn_ds_graph_blocks s0 N) s (insert (ptr_val a) (bn_ds_graph_blocks s N))"
    using RES LIVE BF NL BA
    by (auto simp: bn_ds_storage_transition_def GB readable_bytes_def;
      metis (mono_tags, lifting) UN_I UnI2 domI option.sel)
  show ?thesis
    unfolding bn_ds_carry_inv_def
    apply (rule exI[where x="NULL :: StrictC'_BinomialTree_C ptr"])
    apply (rule exI[where x="0 :: 32 word"])
    apply (rule exI[where x="0 :: 32 word"])
    apply (rule exI[where x=vals])
    apply (rule exI[where x="[] :: bn_shape option list"])
    apply (rule exI[where x="None :: bn_shape option"])
    apply (rule exI[where x=N])
    apply (rule exI[where x=edges])
    using HH HO RF RG GT STT OLD LA TRAN HT
    by (auto simp: bn_review_root_array_view_def bn_forest_values_def bn_ds_slots_def)
qed



lemma vero_aux_pair_initial_inv:
  "bn_ds_carry_inv vero_aux_pair_state (Ptr 16) (Ptr 512) (block_bytes 192 4)
    [Some (BN (Ptr 64) [])] [Some (BN (Ptr 96) [])] [] {#Ptr 96#} {Ptr 64,Ptr 96}
    (Ptr 256) 2 (NULL,0,0,vals) vero_aux_pair_alloc_state"
  by (rule vero_aux_carry_initial[OF vero_aux_pair_pre _ vero_aux_pair_allocation]) simp



end

context binomial_heap_input_global_addresses begin



lemma c0055_prove:
  "bn_ds_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_roots_allocation s0 s a n \<Longrightarrow>
  bn_ds_carry_inv s0 h other P F G ext held N a n (NULL,0,0,vals) s"

by (rule vero_aux_carry_initial; assumption)



end

context binomial_heap_input_global_addresses begin



lemma c0056_prove:
  "runs_to (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV) f) s Q \<Longrightarrow>
   ((p :: 'a::xmem_type ptr),d) \<in>
     stack_allocs 1 \<S> TYPE('a) (hrs_htd (t_hrs_' s)) \<Longrightarrow>
   runs_to (f p) (s\<lparr>t_hrs_' := (hrs_mem (t_hrs_' s), d)\<rparr>) (\<lambda>_ _. True)"

by (rule vero_aux_stack_prefix; assumption)



end

context binomial_heap_input_global_addresses begin



lemma c0057_prove:
  "bn_contract (binomial_tree_ref' NULL) s (\<lambda>r t. t = s)"

by (simp add: binomial_tree_ref'_def bn_contract_def reaches_return[abs_def])



end

context binomial_heap_input_global_addresses begin



lemma c0058_prove:
  "bn_rep s h P F M \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow> P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (globals.with_fresh_stack_ptr 1 (\<lambda>_. UNIV)
    (\<lambda>(p :: StrictC'_BinomialHeap_C ptr). return p)) s
    (\<lambda>p t. bn_rep t h P F M \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"

proof -
  assume R: "bn_rep s h P F M" and BS: "bn_stack_ready \<S> s" and PS: "P \<inter> \<S> = {}"
  have SS: "\<S> \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and NE: "stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<noteq> {}"
    using BS by (auto simp: bn_stack_ready_def)
  have W: "allocator_wf (phantom_machine_state_' s)" using R by (simp add: bn_rep_def)
  show ?thesis
  proof (rule vero_aux_stack_contract[OF NE])
    fix p d
    fix v :: StrictC'_BinomialHeap_C
    fix bs :: "8 word list"
    assume PD: "(p,d) \<in> stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s))"
      and LEN: "length bs = size_of TYPE(StrictC'_BinomialHeap_C)"
    let ?a = "t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)"
    let ?u = "\<lambda>bs'. t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) ?a)"
    have SP: "ptr_span p \<subseteq> \<S>" using CLanguage.stack_allocs_\<S>[OF PD, where i=0] by simp
    have INV: "stack_releases 1 p d = hrs_htd (t_hrs_' s)"
      by (rule stack_releases_stack_allocs_inverse[OF PD])
    have CLEAN: "\<forall>bs'. length bs' = size_of TYPE(StrictC'_BinomialHeap_C) \<longrightarrow>
      bn_rep (?u bs') h P F M \<and> bn_frame s h P F (?u bs') \<and>
      phantom_machine_state_' (?u bs') = phantom_machine_state_' s \<and>
      hrs_htd (t_hrs_' (?u bs')) = hrs_htd (t_hrs_' s)"
    proof (intro allI impI)
      fix bs' :: "8 word list"
      assume LEN': "length bs' = size_of TYPE(StrictC'_BinomialHeap_C)"
      have AP: "phantom_machine_state_' (?u bs') = phantom_machine_state_' s" by simp
      have BF1: "bytes_frame \<S> (hrs_mem (t_hrs_' s)) (heap_update_padding p v bs (hrs_mem (t_hrs_' s)))"
        using vero_aux_stack_bytes[OF SP LEN] by blast
      have BF2: "bytes_frame \<S> (heap_update_padding p v bs (hrs_mem (t_hrs_' s)))
        (heap_update_list (ptr_val p) bs' (heap_update_padding p v bs (hrs_mem (t_hrs_' s))))"
        using vero_aux_stack_bytes[OF SP LEN'] by blast
      have BF: "bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' (?u bs')))"
        using BF1 BF2 by (auto simp: bytes_frame_def hrs_mem_def hrs_mem_update_def hrs_htd_update_def case_prod_unfold)
      have REP: "bn_rep (?u bs') h P F M" by (rule vero_aux_rep_reserved_frame[OF R AP SS PS BF])
      have FR: "bn_frame s h P F (?u bs')" by (rule c0042_prove[OF W SS PS AP BF])
      have HT: "hrs_htd (t_hrs_' (?u bs')) = hrs_htd (t_hrs_' s)"
        using INV by (simp add: hrs_htd_def hrs_mem_update_def hrs_htd_update_def case_prod_unfold)
      show "bn_rep (?u bs') h P F M \<and> bn_frame s h P F (?u bs') \<and>
        phantom_machine_state_' (?u bs') = phantom_machine_state_' s \<and>
        hrs_htd (t_hrs_' (?u bs')) = hrs_htd (t_hrs_' s)"
        using REP FR AP HT by blast
    qed
    show "bn_contract (return p) ?a (\<lambda>r t. \<forall>bs'. length bs' = size_of TYPE(StrictC'_BinomialHeap_C) \<longrightarrow>
      bn_rep (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
        (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)) h P F M \<and>
      bn_frame s h P F (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
        (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)) \<and>
      phantom_machine_state_' (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
        (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t)) = phantom_machine_state_' s \<and>
      hrs_htd (t_hrs_' (t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
        (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) t))) = hrs_htd (t_hrs_' s))"
      using CLEAN by (auto simp: bn_contract_def reaches_return[abs_def] o_assoc)
  qed
qed



end



lemma c0059_prove:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> \<exists>u. (t,u) \<in> R) \<Longrightarrow>
   (\<And>v t u. P v t \<Longrightarrow> (t,u) \<in> R \<Longrightarrow> Q v u) \<Longrightarrow>
   bn_contract (on_exit f R) s Q"

proof -
  assume F: "bn_contract f s P"
    and E: "\<And>v t. P v t \<Longrightarrow> \<exists>u. (t,u) \<in> R"
    and H: "\<And>v t u. P v t \<Longrightarrow> (t,u) \<in> R \<Longrightarrow> Q v u"
  have FR: "runs_to f s (\<lambda>r t. \<exists>v. r = Result v \<and> P v t)"
    using F by (simp add: bn_contract_def)
  have W1: "runs_to f s (\<lambda>r t. (\<exists>u. (t,u) \<in> R) \<and>
      (\<forall>u. (t,u) \<in> R \<longrightarrow> (\<exists>v. r = Result v \<and> Q v u)))"
    apply (rule runs_to_weaken[OF FR])
    using E H by auto
  have W2: "runs_to f s (\<lambda>r t. \<exists>u. (t,u) \<in> R)"
    by (rule runs_to_weaken[OF W1]) auto
  obtain v t where FV: "reaches f s (Result v) t"
    using F by (auto simp: bn_contract_def)
  have PV: "P v t" using runs_toD2[OF FR FV] by (simp add: Result_eq_Result)
  obtain u where RU: "(t,u) \<in> R" using E[OF PV] by blast
  have RE: "\<exists>v u t. reaches f s (Result v) t \<and> (\<exists>b. (t,b) \<in> R) \<and> (t,u) \<in> R"
    using FV RU by blast
  show ?thesis using W1 W2 RE
    by (auto simp: bn_contract_def on_exit_def on_exit'_def
      runs_to_bind_exception_or_result_iff runs_to_bind_iff runs_to_yield_iff
      runs_to_assert_result_and_state_iff runs_to_assume_result_and_state_iff
      reaches_bind_exception_or_result reaches_bind succeeds_runs_to_iff
      reaches_assert_result_and_state reaches_assume_result_and_state reaches_yield[abs_def])
qed



context binomial_heap_input_global_addresses begin





end

context binomial_heap_input_global_addresses begin

lemma vero_aux_guarded_array_disjoint:
  fixes p :: "'a::mem_type ptr"
  assumes G: "\<forall>k<n. c_guard (p +\<^sub>p int k)"
    and I: "i<n" and J: "j<n" and NE: "i\<noteq>j"
  shows "ptr_span (p +\<^sub>p int i) \<inter> ptr_span (p +\<^sub>p int j) = {}"
proof -
  have B: "unat (ptr_val p) + n * size_of TYPE('a) \<le> 2^64"
    by (rule vero_aux_guarded_array_bound[OF G])
  have GP: "c_guard p" using G I by (drule_tac x=0 in spec) simp
  have NN: "ptr_val p \<noteq> 0" using GP by (cases p) (auto simp: ptr_val_def dest: c_guard_NULL)
  have Z: "0 \<notin> {ptr_val p ..+ n * size_of TYPE('a)}"
    using intvl_no_overflow_nat'[where a="ptr_val p" and b="n * size_of TYPE('a)" and x=0] B NN
    by (simp add: unat_eq_zero)
  show ?thesis by (rule ptr_span_no_overflow_indexes_disjoint[OF Z I J NE])
qed


lemma vero_aux_graph_rehandle:
  assumes GR: "bn_ds_graph s P N edges slots held pending"
    and ST: "bn_ds_graph_storage s N slots"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and HN: "\<forall>p \<in> N. bn_tree t p = bn_tree s p"
    and KN: "\<forall>p \<in> N. bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
    and HE: "\<forall>p \<in> N. \<forall>i<length (edges p).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and SH: "bn_ds_slot_handles t slots + held' = bn_ds_slot_handles s slots + held"
  shows "bn_ds_graph t P N edges slots held' pending \<and> bn_ds_graph_storage t N slots"
proof -
  have EN: "\<forall>p \<in> N. set (edges p) \<subseteq> N" using GR by (simp add: bn_ds_graph_def)
  have RK: "\<forall>p \<in> N. map (\<lambda>q. unat (order_C (bn_tree t q))) (edges p) =
    map (\<lambda>q. unat (order_C (bn_tree s q))) (edges p)"
    using HN EN by (auto intro!: map_cong; metis subsetD)
  have ORDER: "\<forall>p \<in> N. \<forall>q \<in> set (edges p).
    bn_key t (value_C (bn_tree t p)) \<le> bn_key t (value_C (bn_tree t q))"
  proof (intro ballI)
    fix p q assume PN: "p \<in> N" and QE: "q \<in> set (edges p)"
    have QN: "q \<in> N" using EN PN QE by blast
    have OLD: "bn_key s (value_C (bn_tree s p)) \<le> bn_key s (value_C (bn_tree s q))"
      using GR PN QE unfolding bn_ds_graph_def by blast
    show "bn_key t (value_C (bn_tree t p)) \<le> bn_key t (value_C (bn_tree t q))"
      by (simp only: HN[rule_format, OF PN] HN[rule_format, OF QN]
        KN[rule_format, OF PN] KN[rule_format, OF QN]; rule OLD)
  qed
  have GT: "bn_ds_graph t P N edges slots held' pending"
    using GR A HN HE KN EN RK ORDER
    by (auto simp: bn_ds_graph_def SH HN[rule_format] KN[rule_format] RK[rule_format])
  have STT: "bn_ds_graph_storage t N slots"
    using ST HN A by (auto simp: bn_ds_graph_storage_def HN[rule_format])
  show ?thesis using GT STT by blast
qed


lemma vero_aux_layout_payloads:
  "bn_ds_tree_layout s P T \<Longrightarrow> \<forall>v \<in> set (bn_values s T). bn_payload P v"
  by (induction T) (auto simp: list_all_iff)

lemma vero_aux_layout_fields:
  assumes L: "bn_ds_tree_layout s P T"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and HN: "\<forall>p \<in> set (bn_ds_node_list T). bn_tree t p = bn_tree s p"
    and HE: "\<forall>p \<in> set (bn_ds_node_list T). \<forall>i<unat (order_C (bn_tree s p)).
      h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
    and KEY: "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key t v = bn_key s v"
  shows "bn_ds_tree_layout t P T \<and> bn_values t T = bn_values s T \<and> bn_blocks t T = bn_blocks s T"
  using L HN HE
proof (induction T)
  case (BN p cs)
  have HP: "bn_tree t p = bn_tree s p" using BN.prems by simp
  have CHILD: "\<forall>U \<in> set cs. bn_ds_tree_layout t P U \<and> bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U"
    using BN.IH BN.prems by (auto simp: list_all_iff; blast)
  have MV: "map (bn_values t) cs = map (bn_values s) cs" using CHILD by (auto intro!: map_cong)
  have MB: "map (bn_blocks t) cs = map (bn_blocks s) cs" using CHILD by (auto intro!: map_cong)
  have PAY: "\<forall>v \<in> set (bn_values s (BN p cs)). bn_payload P v"
    by (rule vero_aux_layout_payloads[OF BN.prems(1)])
  have ORDER: "\<forall>q \<in> set (concat (map (bn_values s) cs)).
    bn_key t (value_C (bn_tree s p)) \<le> bn_key t q"
  proof (intro ballI)
    fix q assume Q: "q \<in> set (concat (map (bn_values s) cs))"
    have PP: "bn_payload P (value_C (bn_tree s p))" and PQ: "bn_payload P q" using PAY Q by auto
    have KP: "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))" by (rule KEY[rule_format, OF PP])
    have KQ: "bn_key t q = bn_key s q" by (rule KEY[rule_format, OF PQ])
    have OLD: "bn_key s (value_C (bn_tree s p)) \<le> bn_key s q" using BN.prems(1) Q by (auto; blast)
    show "bn_key t (value_C (bn_tree s p)) \<le> bn_key t q" by (simp only: KP KQ; rule OLD)
  qed
  show ?case using BN.prems CHILD ORDER A
    by (auto simp: HP MV MB list_all_iff)
qed


lemma vero_aux_array_view_clear:
  assumes V: "bn_review_root_array_view s a F" and I: "i<length F"
    and MEM: "hrs_mem (t_hrs_' t) = heap_update (a +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))"
  shows "bn_review_root_array_view t a (F[i:=None])"
proof -
  have G: "\<forall>j<length F. c_guard (a +\<^sub>p int j)" using V by (simp add: bn_review_root_array_view_def)
  have HV: "\<forall>j<length F. h_val (hrs_mem (t_hrs_' t)) (a +\<^sub>p int j) = case_option NULL bn_root ((F[i:=None])!j)"
  proof (intro allI impI)
    fix j assume J: "j<length F"
    show "h_val (hrs_mem (t_hrs_' t)) (a +\<^sub>p int j) = case_option NULL bn_root ((F[i:=None])!j)"
    proof (cases "j=i")
      case True then show ?thesis using I by (simp add: MEM)
    next
      case False
      have DIS: "ptr_span (a +\<^sub>p int j) \<inter> ptr_span (a +\<^sub>p int i) = {}"
        by (rule vero_aux_guarded_array_disjoint[OF G J I False])
      have VAL: "h_val (hrs_mem (t_hrs_' s)) (a +\<^sub>p int j) = case_option NULL bn_root (F!j)"
        using V J by (simp add: bn_review_root_array_view_def)
      show ?thesis using J False by (simp add: MEM h_val_heap_update_disjoint[OF DIS] VAL)
    qed
  qed
  show ?thesis using G HV by (simp add: bn_review_root_array_view_def)
qed

lemma vero_aux_filter_remove:
  fixes xs :: "'a ptr list"
  assumes I: "i<length xs" and R: "xs!i=r" and NN: "r\<noteq>NULL"
  shows "mset (filter (\<lambda>p. p\<noteq>NULL) (xs[i:=NULL])) + {#r#} = mset (filter (\<lambda>p. p\<noteq>NULL) xs)"
  using I R
  by (induction xs arbitrary: i) (auto simp: NN add.assoc add.left_commute split: nat.splits)

lemma vero_aux_array_clear_handles:
  assumes V: "bn_review_root_array_view s a F" and VT: "bn_review_root_array_view t a (F[i:=None])"
    and I: "i<length F" and T: "F!i=Some T" and NN: "bn_root T\<noteq>NULL"
  shows "bn_ds_slot_handles t (bn_ds_slots a (length F)) + {#bn_root T#} = bn_ds_slot_handles s (bn_ds_slots a (length F))"
proof -
  have VS: "map (h_val (hrs_mem (t_hrs_' s))) (bn_ds_slots a (length F)) = map (case_option NULL bn_root) F"
    by (rule vero_aux_root_array_values[OF V])
  have TV: "map (h_val (hrs_mem (t_hrs_' t))) (bn_ds_slots a (length F)) = (map (case_option NULL bn_root) F)[i:=NULL]"
    using vero_aux_root_array_values[OF VT] by (simp add: map_update)
  have EQ: "mset (filter (\<lambda>p. p\<noteq>NULL) ((map (case_option NULL bn_root) F)[i:=NULL])) + {#bn_root T#} =
    mset (filter (\<lambda>p. p\<noteq>NULL) (map (case_option NULL bn_root) F))"
    apply (rule vero_aux_filter_remove) using I T NN by simp_all
  show ?thesis by (simp only: bn_ds_slot_handles_def VS TV EQ)
qed


lemma vero_aux_concat_remove:
  assumes I: "i<length xs"
  shows "mset (concat xs) = mset (xs!i) + mset (concat (xs[i:=[]]))"
  using I
proof (induction xs arbitrary: i)
  case Nil then show ?case by simp
next
  case (Cons x xs)
  show ?case
  proof (cases i)
    case 0 then show ?thesis by simp
  next
    case (Suc j)
    have J: "j<length xs" using Cons.prems Suc by simp
    show ?thesis using Cons.IH[OF J] by (simp add: Suc add.assoc add.left_commute)
  qed
qed

lemma vero_aux_forest_remove_values:
  assumes I: "i<length F" and FT: "F!i=Some T"
  shows "mset (bn_forest_values s F) = mset (bn_values s T) + mset (bn_forest_values s (F[i:=None]))"
proof -
  have IL: "i<length (map (case_option [] (bn_values s)) F)" using I by simp
  show ?thesis using vero_aux_concat_remove[OF IL] I FT by (simp add: bn_forest_values_def map_update)
qed

lemma vero_aux_concat_remove_distinct:
  assumes D: "distinct (concat xs)" and I: "i<length xs"
  shows "distinct (concat (xs[i:=[]])) \<and> set (concat (xs[i:=[]])) \<inter> set (xs!i) = {}"
  using D I
proof (induction xs arbitrary: i)
  case Nil then show ?case by simp
next
  case (Cons x xs)
  show ?case
  proof (cases i)
    case 0 then show ?thesis using Cons.prems by (auto simp: distinct_append)
  next
    case (Suc j)
    have DX: "distinct (concat xs)" and J: "j<length xs" using Cons.prems Suc by auto
    have IH: "distinct (concat (xs[j:=[]])) \<and> set (concat (xs[j:=[]])) \<inter> set (xs!j) = {}"
      by (rule Cons.IH[OF DX J])
    have EQ: "set (concat xs) = set (xs!j) \<union> set (concat (xs[j:=[]]))"
      using arg_cong[OF vero_aux_concat_remove[OF J], where f=set_mset]
      by (simp only: set_mset_mset set_mset_union)
    have SUB: "set (concat (xs[j:=[]])) \<subseteq> set (concat xs)" using EQ by blast
    have SUBJ: "set (xs!j) \<subseteq> set (concat xs)" using nth_mem[OF J] by auto
    show ?thesis using Cons.prems IH SUB SUBJ by (auto simp: Suc distinct_append; blast)
  qed
qed


lemma vero_aux_node_block_set:
  "set (concat (map (vero_aux_node_blocks s) xs)) = ptr_val ` set xs \<union>
    {ptr_val (subtrees_C (bn_tree s p)) |p. p\<in>set xs \<and> order_C (bn_tree s p)\<noteq>0}"
  by (auto simp: vero_aux_node_blocks_def split: if_splits; blast)

lemma vero_aux_rep_graph_blocks:
  assumes R: "bn_rep s h P F M"
  shows "bn_ds_graph_blocks s (bn_ds_forest_nodes F) = set (concat (map (case_option [] (bn_blocks s)) F))"
proof -
  have V: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_valid s P T"
    using R by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "\<forall>T. Some T\<in>set F \<longrightarrow> bn_ds_tree_layout s P T"
    using V vero_aux_valid_layout by blast
  have BEQ: "concat (map (case_option [] (bn_blocks s)) F) =
    concat (map (vero_aux_node_blocks s) (concat (map (case_option [] bn_ds_node_list) F)))"
    by (rule vero_aux_forest_blocks[OF L])
  show ?thesis by (simp only: BEQ bn_ds_graph_blocks_def bn_ds_forest_nodes_def vero_aux_node_block_set)
qed

lemma vero_aux_array_update_other:
  fixes a :: "StrictC'_BinomialTree_C ptr ptr" and q :: "'a::mem_type ptr"
  assumes W: "allocator_wf A" and LA: "live_blocks A (ptr_val a) = Some n"
    and LQ: "live_blocks A (ptr_val q) = Some m" and NE: "ptr_val q\<noteq>ptr_val a"
    and SZ: "8*k\<le>n" and I: "i<k" and SQ: "size_of TYPE('a) * l\<le>m" and J: "j<l"
  shows "h_val (heap_update (a +\<^sub>p int i) v hp) (q +\<^sub>p int j) = h_val hp (q +\<^sub>p int j)"
proof -
  have DIS: "ptr_span (q +\<^sub>p int j) \<inter> ptr_span (a +\<^sub>p int i) = {}"
    apply (rule vero_aux_live_spans_disjoint[OF W LQ LA NE SQ _ J I]) using SZ by simp
  show ?thesis by (rule h_val_heap_update_disjoint[OF DIS])
qed

lemma vero_aux_array_update_key:
  fixes a :: "StrictC'_BinomialTree_C ptr ptr"
  assumes W: "allocator_wf A" and LA: "live_blocks A (ptr_val a) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * k\<le>n" and I: "i<k"
    and PAY: "bn_payload P v" and PS: "P\<subseteq>reserved_bytes A"
    and MEM: "hrs_mem (t_hrs_' t) = heap_update (a +\<^sub>p int i) x (hrs_mem (t_hrs_' s))"
  shows "bn_key t v = bn_key s v"
proof -
  let ?p = "ptr_coerce v :: 32 signed word ptr"
  have G: "c_guard ?p" and B: "block_bytes (ptr_val ?p) 4 \<subseteq> P" using PAY by (auto simp: bn_payload_def)
  have SP: "ptr_span ?p \<subseteq> P"
    using B intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]] by (simp add: block_bytes_def)
  have SA: "ptr_span (a +\<^sub>p int i) \<subseteq> block_bytes (ptr_val a) n" by (rule c0008_prove[OF W LA SZ I])
  have BR: "block_bytes (ptr_val a) n \<inter> reserved_bytes A = {}" using W LA unfolding allocator_wf_def by blast
  have DIS: "ptr_span ?p \<inter> ptr_span (a +\<^sub>p int i) = {}" using SP SA BR PS by blast
  show ?thesis unfolding bn_key_def MEM by (simp only: h_val_heap_update_disjoint[OF DIS])
qed


lemma vero_aux_rep_clear_other:
  fixes q :: "'a::mem_type ptr"
  assumes R: "bn_rep s h P F M" and I: "i<length F"
    and LQ: "live_blocks (phantom_machine_state_' s) (ptr_val q) = Some m"
    and NE: "ptr_val q\<noteq>ptr_val (roots_C (bn_heap s h))"
    and SQ: "size_of TYPE('a) * l\<le>m" and J: "j<l"
  shows "h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (q +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (q +\<^sub>p int j)"
proof -
  have W: "allocator_wf (phantom_machine_state_' s)" and NN: "roots_C (bn_heap s h)\<noteq>NULL"
    using R I by (auto simp: bn_rep_def)
  obtain n where LA: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
    and SZ: "8*length F\<le>n" using R NN by (auto simp: bn_rep_def)
  have H: "h_val (heap_update (roots_C (bn_heap s h) +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))) (q +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (q +\<^sub>p int j)"
    by (rule vero_aux_array_update_other[OF W LA LQ NE SZ I SQ J])
  show ?thesis using H by (simp add: bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
qed

lemma vero_aux_rep_clear_header:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "bn_heap (bn_review_clear_root s h i) h = bn_heap s h"
proof -
  have L: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    and NN: "roots_C (bn_heap s h)\<noteq>NULL" using R I by (auto simp: bn_rep_def)
  have NE: "ptr_val h\<noteq>ptr_val (roots_C (bn_heap s h))" using R NN by (simp add: bn_rep_def bn_owned_def)
  have H: "h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (h +\<^sub>p int 0) =
    h_val (hrs_mem (t_hrs_' s)) (h +\<^sub>p int 0)"
    by (rule vero_aux_rep_clear_other[OF R I L NE, where l=1 and j=0]) simp_all
  show ?thesis using H by (simp add: bn_heap_def)
qed

lemma vero_aux_rep_roots_separate:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "ptr_val (roots_C (bn_heap s h)) \<notin> bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
proof -
  have NN: "roots_C (bn_heap s h)\<noteq>NULL" using R I by (auto simp: bn_rep_def)
  show ?thesis using R NN by (simp add: vero_aux_rep_graph_blocks[OF R] bn_rep_def bn_owned_def)
qed

lemma vero_aux_rep_clear_nodes:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "\<forall>p\<in>bn_ds_forest_nodes F. bn_tree (bn_review_clear_root s h i) p = bn_tree s p"
proof (intro ballI)
  fix p assume PN: "p\<in>bn_ds_forest_nodes F"
  have GR: "bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {}" using c0046_prove[OF R] by blast
  have LP: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using GR PN by (simp add: bn_ds_graph_def)
  have IN: "ptr_val p \<in> bn_ds_graph_blocks s (bn_ds_forest_nodes F)" using PN by (auto simp: bn_ds_graph_blocks_def)
  have OUT: "ptr_val (roots_C (bn_heap s h)) \<notin> bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
    by (rule vero_aux_rep_roots_separate[OF R I])
  have NE: "ptr_val p\<noteq>ptr_val (roots_C (bn_heap s h))"
  proof
    assume E: "ptr_val p = ptr_val (roots_C (bn_heap s h))"
    have IN': "ptr_val (roots_C (bn_heap s h)) \<in> bn_ds_graph_blocks s (bn_ds_forest_nodes F)" using IN by (simp only: E)
    show False using OUT IN' by contradiction
  qed
  have H: "h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (p +\<^sub>p int 0) =
    h_val (hrs_mem (t_hrs_' s)) (p +\<^sub>p int 0)"
    by (rule vero_aux_rep_clear_other[OF R I LP NE, where l=1 and j=0]) simp_all
  show "bn_tree (bn_review_clear_root s h i) p = bn_tree s p" using H by (simp add: bn_tree_def)
qed


lemma vero_aux_rep_clear_children:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "\<forall>p\<in>bn_ds_forest_nodes F. \<forall>j<length (bn_ds_physical_edges s p).
    h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (subtrees_C (bn_tree s p) +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int j)"
proof (intro ballI allI impI)
  fix p j assume PN: "p\<in>bn_ds_forest_nodes F" and J: "j<length (bn_ds_physical_edges s p)"
  have GR: "bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#} {}" using c0046_prove[OF R] by blast
  have ES: "bn_ds_physical_edges s p\<noteq>[]" using J by auto
  have LA: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
    Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length (bn_ds_physical_edges s p))"
    using GR PN ES by (simp add: bn_ds_graph_def)
  have NZ: "order_C (bn_tree s p)\<noteq>0" using GR PN J by (auto simp: bn_ds_graph_def)
  have IN: "ptr_val (subtrees_C (bn_tree s p)) \<in> bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
    using PN NZ by (auto simp: bn_ds_graph_blocks_def)
  have OUT: "ptr_val (roots_C (bn_heap s h)) \<notin> bn_ds_graph_blocks s (bn_ds_forest_nodes F)"
    by (rule vero_aux_rep_roots_separate[OF R I])
  have NE: "ptr_val (subtrees_C (bn_tree s p))\<noteq>ptr_val (roots_C (bn_heap s h))"
  proof
    assume E: "ptr_val (subtrees_C (bn_tree s p)) = ptr_val (roots_C (bn_heap s h))"
    have IN': "ptr_val (roots_C (bn_heap s h)) \<in> bn_ds_graph_blocks s (bn_ds_forest_nodes F)" using IN by (simp only: E)
    show False using OUT IN' by contradiction
  qed
  show "h_val (hrs_mem (t_hrs_' (bn_review_clear_root s h i))) (subtrees_C (bn_tree s p) +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int j)"
    by (rule vero_aux_rep_clear_other[OF R I LA NE order_refl J])
qed

lemma vero_aux_rep_clear_keys:
  assumes R: "bn_rep s h P F M" and I: "i<length F"
  shows "\<forall>v :: unit ptr. bn_payload P v \<longrightarrow> bn_key (bn_review_clear_root s h i) v = bn_key s v"
proof (intro allI impI)
  fix v :: "unit ptr" assume PAY: "bn_payload P v"
  have W: "allocator_wf (phantom_machine_state_' s)" and NN: "roots_C (bn_heap s h)\<noteq>NULL"
    and PS: "P\<subseteq>reserved_bytes (phantom_machine_state_' s)" using R I by (auto simp: bn_rep_def)
  obtain n where LA: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F\<le>n" using R NN by (auto simp: bn_rep_def)
  have MEM: "hrs_mem (t_hrs_' (bn_review_clear_root s h i)) =
    heap_update (roots_C (bn_heap s h) +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))"
    by (simp add: bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  show "bn_key (bn_review_clear_root s h i) v = bn_key s v"
    by (rule vero_aux_array_update_key[OF W LA SZ I PAY PS MEM])
qed

lemma vero_aux_rep_clear_layouts:
  assumes R: "bn_rep s h P F M" and I: "i<length F" and TF: "Some T\<in>set F"
  shows "bn_ds_tree_layout (bn_review_clear_root s h i) P T \<and>
    bn_values (bn_review_clear_root s h i) T = bn_values s T \<and>
    bn_blocks (bn_review_clear_root s h i) T = bn_blocks s T"
proof -
  let ?t = "bn_review_clear_root s h i"
  have V: "bn_valid s P T" using R TF by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "bn_ds_tree_layout s P T" by (rule vero_aux_valid_layout[OF V])
  have A: "phantom_machine_state_' ?t = phantom_machine_state_' s" by (simp add: bn_review_clear_root_def)
  have SUB: "set (bn_ds_node_list T) \<subseteq> bn_ds_forest_nodes F" using TF by (auto simp: vero_aux_forest_node_member)
  have HN: "\<forall>p\<in>set (bn_ds_node_list T). bn_tree ?t p = bn_tree s p"
    using vero_aux_rep_clear_nodes[OF R I] SUB by blast
  have HE: "\<forall>p\<in>set (bn_ds_node_list T). \<forall>j<unat (order_C (bn_tree s p)).
    h_val (hrs_mem (t_hrs_' ?t)) (subtrees_C (bn_tree s p) +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int j)"
    using vero_aux_rep_clear_children[OF R I] SUB by (auto simp: bn_ds_physical_edges_def bn_ds_slots_def)
  show ?thesis by (rule vero_aux_layout_fields[OF L A HN HE vero_aux_rep_clear_keys[OF R I]])
qed

lemma vero_aux_rep_clear_graph:
  assumes R: "bn_rep s h P F M" and I: "i<length F" and FT: "F!i=Some T"
  shows "bn_ds_graph (bn_review_clear_root s h i) P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#bn_root T#} {} \<and>
    bn_ds_graph_storage (bn_review_clear_root s h i) (bn_ds_forest_nodes F)
    (bn_ds_slots (roots_C (bn_heap s h)) (length F))"
proof -
  let ?t = "bn_review_clear_root s h i"
  let ?slots = "bn_ds_slots (roots_C (bn_heap s h)) (length F)"
  have GR: "bn_ds_graph s P (bn_ds_forest_nodes F) (bn_ds_physical_edges s) ?slots {#} {}"
    and ST: "bn_ds_graph_storage s (bn_ds_forest_nodes F) ?slots" using c0046_prove[OF R] by blast+
  have A: "phantom_machine_state_' ?t = phantom_machine_state_' s" by (simp add: bn_review_clear_root_def)
  have HN: "\<forall>p\<in>bn_ds_forest_nodes F. bn_tree ?t p = bn_tree s p" by (rule vero_aux_rep_clear_nodes[OF R I])
  have KN: "\<forall>p\<in>bn_ds_forest_nodes F. bn_key ?t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
    using GR vero_aux_rep_clear_keys[OF R I] by (auto simp: bn_ds_graph_def)
  have HE: "\<forall>p\<in>bn_ds_forest_nodes F. \<forall>j<length (bn_ds_physical_edges s p).
    h_val (hrs_mem (t_hrs_' ?t)) (subtrees_C (bn_tree s p) +\<^sub>p int j) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int j)"
    by (rule vero_aux_rep_clear_children[OF R I])
  have V: "bn_review_root_array_view s (roots_C (bn_heap s h)) F" using R by (simp add: bn_rep_def bn_review_root_array_view_def)
  have MEM: "hrs_mem (t_hrs_' ?t) = heap_update (roots_C (bn_heap s h) +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))"
    by (simp add: bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have VT: "bn_review_root_array_view ?t (roots_C (bn_heap s h)) (F[i:=None])" by (rule vero_aux_array_view_clear[OF V I MEM])
  have VALID: "bn_valid s P T" using R I FT by (auto simp: bn_rep_def)
  have NN: "bn_root T\<noteq>NULL" using VALID by (cases T) (auto dest: c_guard_NULL)
  have SH: "bn_ds_slot_handles ?t ?slots + {#bn_root T#} = bn_ds_slot_handles s ?slots + {#}"
    using vero_aux_array_clear_handles[OF V VT I FT NN] by simp
  show ?thesis by (rule vero_aux_graph_rehandle[OF GR ST A HN KN HE SH])
qed


lemma vero_aux_graph_reserved_frame:
  assumes GR: "bn_ds_graph s P N edges slots held pending" and ST: "bn_ds_graph_storage s N slots"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s"
    and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)" and PS: "P\<inter>S={}"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
    and SH: "bn_ds_slot_handles t slots = bn_ds_slot_handles s slots"
  shows "bn_ds_graph t P N edges slots held pending \<and> bn_ds_graph_storage t N slots \<and>
    (\<forall>p\<in>N. bn_tree t p = bn_tree s p)"
proof -
  have W: "allocator_wf (phantom_machine_state_' s)" using GR by (simp add: bn_ds_graph_def)
  have HN: "\<forall>p\<in>N. bn_tree t p = bn_tree s p"
  proof (intro ballI)
    fix p assume PN: "p\<in>N"
    have L: "live_blocks (phantom_machine_state_' s) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
      using GR PN by (simp add: bn_ds_graph_def)
    show "bn_tree t p = bn_tree s p" unfolding bn_tree_def
      by (rule vero_aux_stack_live_h_val[OF W L order_refl SS BF])
  qed
  have KN: "\<forall>p\<in>N. bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
  proof (intro ballI)
    fix p assume PN: "p\<in>N"
    have PAY: "bn_payload P (value_C (bn_tree s p))" using GR PN by (simp add: bn_ds_graph_def)
    show "bn_key t (value_C (bn_tree s p)) = bn_key s (value_C (bn_tree s p))"
      by (rule vero_aux_payload_key_frame[OF PAY PS BF])
  qed
  have HE: "\<forall>p\<in>N. \<forall>i<length (edges p).
    h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
    h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
  proof (intro ballI allI impI)
    fix p i assume PN: "p\<in>N" and I: "i<length (edges p)"
    have NE: "edges p\<noteq>[]" using I by auto
    have L: "live_blocks (phantom_machine_state_' s) (ptr_val (subtrees_C (bn_tree s p))) =
      Some (size_of TYPE(StrictC'_BinomialTree_C ptr) * length (edges p))"
      using GR PN NE by (simp add: bn_ds_graph_def)
    show "h_val (hrs_mem (t_hrs_' t)) (subtrees_C (bn_tree s p) +\<^sub>p int i) =
      h_val (hrs_mem (t_hrs_' s)) (subtrees_C (bn_tree s p) +\<^sub>p int i)"
      by (rule vero_aux_stack_live_array[OF W L order_refl I SS BF])
  qed
  have SHH: "bn_ds_slot_handles t slots + held = bn_ds_slot_handles s slots + held" by (simp only: SH)
  have GT: "bn_ds_graph t P N edges slots held pending \<and> bn_ds_graph_storage t N slots"
    by (rule vero_aux_graph_rehandle[OF GR ST A HN KN HE SHH])
  show ?thesis using GT HN by blast
qed

lemma vero_aux_array_view_reserved:
  assumes W: "allocator_wf (phantom_machine_state_' s)" and V: "bn_review_root_array_view s a F"
    and L: "live_blocks (phantom_machine_state_' s) (ptr_val a) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F\<le>n"
    and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and BF: "bytes_frame S (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t))"
  shows "bn_review_root_array_view t a F"
proof -
  have H: "\<forall>i<length F. h_val (hrs_mem (t_hrs_' t)) (a +\<^sub>p int i) = h_val (hrs_mem (t_hrs_' s)) (a +\<^sub>p int i)"
    by (intro allI impI; rule vero_aux_stack_live_array[OF W L SZ _ SS BF]; assumption)
  show ?thesis using V H by (simp add: bn_review_root_array_view_def)
qed

lemma vero_aux_rep_clear_valid:
  assumes R: "bn_rep s h P F M" and I: "i<length F" and TF: "Some T\<in>set F"
  shows "bn_valid (bn_review_clear_root s h i) P T"
proof -
  let ?t = "bn_review_clear_root s h i"
  have V: "bn_valid s P T" using R TF by (auto simp: bn_rep_def in_set_conv_nth)
  have L: "bn_ds_tree_layout ?t P T" using vero_aux_rep_clear_layouts[OF R I TF] by blast
  have SUB: "set (bn_ds_node_list T)\<subseteq>bn_ds_forest_nodes F" using TF by (auto simp: vero_aux_forest_node_member)
  have REFS: "\<forall>p\<in>set (bn_ds_node_list T). refcount_C (bn_tree ?t p) = 1"
    using vero_aux_valid_node_fields[OF V] vero_aux_rep_clear_nodes[OF R I] SUB
    by (auto simp: vero_aux_node_ok_def Let_def; blast)
  show ?thesis by (rule vero_aux_layout_valid_refs[OF L REFS])
qed




lemma vero_aux_update_span_frame:
  fixes p :: "'a::mem_type ptr"
  assumes G: "c_guard p" and SP: "ptr_span p\<subseteq>S"
  shows "bytes_frame S hp (heap_update p v hp)"
proof -
  have EQ: "block_bytes (ptr_val p) (size_of TYPE('a)) = ptr_span p"
    using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF G]] by (simp add: block_bytes_def)
  have BF: "bytes_frame (ptr_span p) hp (heap_update p v hp)" using vero_aux_update_frame[OF G] by (simp only: EQ)
  show ?thesis using BF SP by (auto simp: bytes_frame_def)
qed

lemma vero_aux_live_reserved_span:
  fixes p :: "'a::mem_type ptr" and q :: "'b::mem_type ptr"
  assumes A: "allocator_wf B" and L: "live_blocks B (ptr_val p) = Some n"
    and SZ: "size_of TYPE('a) * k\<le>n" and I: "i<k"
    and SP: "ptr_span q\<subseteq>S" and SS: "S\<subseteq>reserved_bytes B"
  shows "ptr_span (p +\<^sub>p int i) \<inter> ptr_span q = {}"
proof -
  have BP: "ptr_span (p +\<^sub>p int i)\<subseteq>block_bytes (ptr_val p) n" by (rule c0008_prove[OF A L SZ I])
  have DIS: "block_bytes (ptr_val p) n \<inter> reserved_bytes B = {}" using A L unfolding allocator_wf_def by blast
  show ?thesis using BP DIS SP SS by blast
qed


lemma vero_aux_forest_detach_distinct:
  assumes D: "distinct (concat (map (case_option [] (bn_blocks s)) F))"
    and I: "i<length F" and FT: "F!i=Some (BN p cs)"
  shows "distinct (concat (map (case_option [] (bn_blocks s)) (F[i:=None] @ map Some cs)))"
proof -
  let ?xs = "map (case_option [] (bn_blocks s)) F"
  let ?rest = "concat (map (case_option [] (bn_blocks s)) (F[i:=None]))"
  let ?children = "concat (map (bn_blocks s) cs)"
  have IX: "i<length ?xs" using I by simp
  have E: "?xs!i=bn_blocks s (BN p cs)" using I FT by simp
  have U: "concat (?xs[i:=[]]) = ?rest" by (simp add: map_update)
  have DR: "distinct ?rest" and DIS: "set ?rest \<inter> set (bn_blocks s (BN p cs)) = {}"
    using vero_aux_concat_remove_distinct[OF D IX] by (simp_all only: U E)
  have TF: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FT by simp
  have DT: "distinct (bn_blocks s (BN p cs))"
    using vero_aux_distinct_components[OF D TF] by simp
  have DC: "distinct ?children" using DT by simp
  have SUB: "set ?children\<subseteq>set (bn_blocks s (BN p cs))" by auto
  have RC: "set ?rest \<inter> set ?children = {}" using DIS SUB by blast
  show ?thesis using DR DC RC by (simp add: o_def)
qed

lemma vero_aux_forest_detach_length:
  assumes I: "i<length F" and FT: "F!i=Some (BN p cs)"
  shows "length (bn_forest_values s F) =
    Suc (length (bn_forest_values s (F[i:=None])) + length (bn_forest_values s (map Some cs)))"
  using arg_cong[OF vero_aux_forest_remove_values[OF I FT], where f=size]
  by (simp add: bn_forest_values_def o_def add.commute)


lemma vero_aux_detach_core:
  fixes i :: nat and s u t :: globals and v :: "StrictC'_BinomialHeap_C"
    and h fake :: "StrictC'_BinomialHeap_C ptr" and p :: "StrictC'_BinomialTree_C ptr"
  defines "u \<equiv> bn_review_clear_root s h i"
    and "v \<equiv> (bn_heap u fake)\<lparr>heap_type_C := heap_type_C (bn_heap u h),
      compare_func_C := compare_func_C (bn_heap u h), roots_C := subtrees_C (bn_tree u p),
      roots_length_C := UCAST(16 \<rightarrow> 32) (order_C (bn_tree u p))\<rparr>"
    and "t \<equiv> t_hrs_'_update (hrs_mem_update (heap_update fake v)) u"
  assumes R: "bn_rep s h P F M" and I: "i<length F" and FT: "F!i=Some (BN p cs)"
    and GF: "c_guard fake" and SP: "ptr_span fake\<subseteq>S"
    and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)" and PS: "P\<inter>S={}"
  shows "phantom_machine_state_' t = phantom_machine_state_' s \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    bn_heap t h = bn_heap s h \<and> bn_heap t fake = v \<and> bn_heap u h = bn_heap s h \<and>
    bn_tree u p = bn_tree s p \<and>
    bn_review_root_array_view t (roots_C (bn_heap s h)) (F[i:=None]) \<and>
    (\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid t P U \<and> bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U) \<and>
    (\<forall>q\<in>bn_ds_forest_nodes F. bn_tree t q = bn_tree s q) \<and>
    bn_ds_graph t P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
      (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#p#} {} \<and>
    bn_ds_graph_storage t (bn_ds_forest_nodes F) (bn_ds_slots (roots_C (bn_heap s h)) (length F)) \<and>
    distinct (concat (map (case_option [] (bn_blocks t)) (F[i:=None] @ map Some cs))) \<and>
    length (bn_forest_values t (F[i:=None])) + length (bn_forest_values t (map Some cs)) < 2^32"
proof -
  let ?N = "bn_ds_forest_nodes F"
  let ?a = "roots_C (bn_heap s h)"
  let ?slots = "bn_ds_slots ?a (length F)"
  have A0: "phantom_machine_state_' u = phantom_machine_state_' s" by (simp add: u_def bn_review_clear_root_def)
  have A1: "phantom_machine_state_' t = phantom_machine_state_' u" by (simp add: t_def)
  have AT: "phantom_machine_state_' t = phantom_machine_state_' s" by (simp only: A1 A0)
  have W: "allocator_wf (phantom_machine_state_' s)" and LEN: "length F\<le>32"
    and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    and NN: "?a\<noteq>NULL" using R I by (auto simp: bn_rep_def)
  have WU: "allocator_wf (phantom_machine_state_' u)" using W by (simp only: A0)
  have SSU: "S\<subseteq>reserved_bytes (phantom_machine_state_' u)" using SS by (simp only: A0)
  have BF: "bytes_frame S (hrs_mem (t_hrs_' u)) (hrs_mem (t_hrs_' t))"
    using vero_aux_update_span_frame[OF GF SP, where hp="hrs_mem (t_hrs_' u)" and v=v]
    by (simp add: t_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  obtain n where LA: "live_blocks (phantom_machine_state_' s) (ptr_val ?a) = Some n"
    and SZ: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length F\<le>n" using R NN by (auto simp: bn_rep_def)
  have LAU: "live_blocks (phantom_machine_state_' u) (ptr_val ?a) = Some n" by (simp only: A0 LA)
  have SZU: "size_of TYPE(StrictC'_BinomialTree_C ptr) * length (F[i:=None])\<le>n" using SZ by simp
  have V0: "bn_review_root_array_view s ?a F" using R by (simp add: bn_rep_def bn_review_root_array_view_def)
  have MU: "hrs_mem (t_hrs_' u) = heap_update (?a +\<^sub>p int i) NULL (hrs_mem (t_hrs_' s))"
    by (simp add: u_def bn_review_clear_root_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have VU: "bn_review_root_array_view u ?a (F[i:=None])" by (rule vero_aux_array_view_clear[OF V0 I MU])
  have VT: "bn_review_root_array_view t ?a (F[i:=None])" by (rule vero_aux_array_view_reserved[OF WU VU LAU SZU SSU BF])
  have HVU: "map (h_val (hrs_mem (t_hrs_' u))) ?slots = map (case_option NULL bn_root) (F[i:=None])"
    using vero_aux_root_array_values[OF VU] by simp
  have HVT: "map (h_val (hrs_mem (t_hrs_' t))) ?slots = map (case_option NULL bn_root) (F[i:=None])"
    using vero_aux_root_array_values[OF VT] by simp
  have SH: "bn_ds_slot_handles t ?slots = bn_ds_slot_handles u ?slots"
    by (simp only: bn_ds_slot_handles_def HVU HVT)
  have GU: "bn_ds_graph u P ?N (bn_ds_physical_edges s) ?slots {#p#} {}"
    and SU: "bn_ds_graph_storage u ?N ?slots"
    using vero_aux_rep_clear_graph[OF R I FT] by (simp_all add: u_def)
  have HN0: "\<forall>q\<in>?N. bn_tree u q = bn_tree s q" using vero_aux_rep_clear_nodes[OF R I] by (simp only: u_def)
  have GT: "bn_ds_graph t P ?N (bn_ds_physical_edges s) ?slots {#p#} {}"
    and ST: "bn_ds_graph_storage t ?N ?slots"
    and HN1: "\<forall>q\<in>?N. bn_tree t q = bn_tree u q"
    using vero_aux_graph_reserved_frame[OF GU SU A1 SSU PS BF SH] by blast+
  have HN: "\<forall>q\<in>?N. bn_tree t q = bn_tree s q" using HN1 HN0 by auto
  have HU: "bn_heap u h = bn_heap s h" using vero_aux_rep_clear_header[OF R I] by (simp only: u_def)
  have LHU: "live_blocks (phantom_machine_state_' u) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    by (simp only: A0 LH)
  have HT: "bn_heap t h = bn_heap u h" unfolding bn_heap_def
    by (rule vero_aux_stack_live_h_val[OF WU LHU order_refl SSU BF])
  have HH: "bn_heap t h = bn_heap s h" by (simp only: HT HU)
  have HF: "bn_heap t fake = v" by (simp add: t_def bn_heap_def hrs_mem_update_def hrs_mem_def case_prod_unfold)
  have TFM: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FT by simp
  have PN: "p\<in>?N" using TFM by (auto simp: vero_aux_forest_node_member)
  have HP: "bn_tree t p = bn_tree s p" using HN PN by blast
  have HPU: "bn_tree u p = bn_tree s p" using HN0 PN by blast
  have ALL: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid t P U \<and>
    bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U"
  proof (intro allI impI)
    fix U assume UF: "Some U\<in>set F"
    have VU': "bn_valid u P U" using vero_aux_rep_clear_valid[OF R I UF] by (simp only: u_def)
    have FRAME: "bn_valid t P U \<and> bn_values t U = bn_values u U \<and> bn_blocks t U = bn_blocks u U \<and>
      (\<forall>x\<in>set (bn_values u U). bn_key t x = bn_key u x)"
      by (rule vero_aux_valid_reserved_frame[OF WU A1 SSU PS BF VU'])
    have OLD: "bn_values u U = bn_values s U \<and> bn_blocks u U = bn_blocks s U"
      using vero_aux_rep_clear_layouts[OF R I UF] by (simp add: u_def)
    show "bn_valid t P U \<and> bn_values t U = bn_values s U \<and> bn_blocks t U = bn_blocks s U"
      using FRAME OLD by simp
  qed
  have VP: "bn_valid t P (BN p cs)" and PV: "bn_values t (BN p cs) = bn_values s (BN p cs)"
    and PB: "bn_blocks t (BN p cs) = bn_blocks s (BN p cs)" using ALL TFM by blast+
  have RANK: "length cs=i" using R I FT by (auto simp: bn_rep_def)
  have CL: "length cs\<le>32" using RANK I LEN by arith
  have CV: "concat (map (bn_values t) cs) = concat (map (bn_values s) cs)" using PV HP by simp
  have CB: "concat (map (bn_blocks t) cs) = concat (map (bn_blocks s) cs)" using PB HP by (cases "cs=[]") simp_all
  have MFV: "map (case_option [] (bn_values t)) F = map (case_option [] (bn_values s)) F"
    using ALL by (auto intro!: map_cong split: option.splits)
  have MFB: "map (case_option [] (bn_blocks t)) F = map (case_option [] (bn_blocks s)) F"
    using ALL by (auto intro!: map_cong split: option.splits)
  have FV: "bn_forest_values t (F[i:=None]) = bn_forest_values s (F[i:=None])"
    by (simp add: bn_forest_values_def map_update MFV)
  have GV: "bn_forest_values t (map Some cs) = bn_forest_values s (map Some cs)"
    by (simp add: bn_forest_values_def o_def CV)
  have FB: "concat (map (case_option [] (bn_blocks t)) (F[i:=None])) = concat (map (case_option [] (bn_blocks s)) (F[i:=None]))"
    by (simp add: map_update MFB)
  have GB: "concat (map (case_option [] (bn_blocks t)) (map Some cs)) = concat (map (case_option [] (bn_blocks s)) (map Some cs))"
    by (simp add: o_def CB)
  have DB: "distinct (concat (map (case_option [] (bn_blocks s)) F))" using R by (auto simp: bn_rep_def bn_owned_def)
  have DIST: "distinct (concat (map (case_option [] (bn_blocks t)) (F[i:=None] @ map Some cs)))"
    using vero_aux_forest_detach_distinct[OF DB I FT] by (simp only: map_append concat_append FB GB)
  have MASS: "length (bn_forest_values t (F[i:=None])) + length (bn_forest_values t (map Some cs)) < 2^32"
  proof -
    have B: "length (bn_forest_values s F) < 2^32"
      using R unat_lt2p[of "num_values_C (bn_heap s h)"] by (simp add: bn_rep_def)
    show ?thesis using vero_aux_forest_detach_length[OF I FT, where s=s] B by (simp only: FV GV; arith)
  qed
  have HTD: "hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s)"
    by (simp add: t_def u_def bn_review_clear_root_def hrs_mem_update_def hrs_htd_def case_prod_unfold)
  show ?thesis using AT HTD HH HF HU HPU VT ALL HN GT ST DIST MASS by blast
qed


lemma vero_aux_detach_views:
  fixes s :: globals
  assumes R: "bn_rep s h P F M" and I: "i<length F" and FT: "F!i=Some (BN p cs)"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s" and HH: "bn_heap t h = bn_heap s h"
    and GF: "c_guard fake" and SP: "ptr_span fake\<subseteq>S" and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and FK: "heap_type_C (bn_heap t fake) = BINOMIAL_HEAP_TYPE_MIN"
    and FC: "compare_func_C (bn_heap t fake) = binomial_heap_input.int_compare"
    and FR: "roots_C (bn_heap t fake) = subtrees_C (bn_tree t p)"
    and FL: "unat (roots_length_C (bn_heap t fake)) = length cs"
    and RV: "bn_review_root_array_view t (roots_C (bn_heap s h)) (F[i:=None])"
    and VP: "bn_valid t P (BN p cs)"
    and ALL: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid t P U"
  shows "bn_ds_forest_view t h P (F[i:=None]) \<and> bn_ds_forest_view t fake P (map Some cs)"
proof -
  have OLD: "bn_ds_forest_view s h P F" by (rule vero_aux_rep_forest_view[OF R])
  have LF: "length F\<le>32" and LC: "length cs=i" using R I FT by (auto simp: bn_rep_def)
  have CS: "length cs\<le>32" using LF LC I by arith
  have LAYOUT: "\<forall>j<length (F[i:=None]). case (F[i:=None])!j of None \<Rightarrow> True | Some U \<Rightarrow> bn_rank U=j \<and> bn_ds_tree_layout t P U"
  proof (intro allI impI)
    fix j assume J: "j<length (F[i:=None])"
    show "case (F[i:=None])!j of None \<Rightarrow> True | Some U \<Rightarrow> bn_rank U=j \<and> bn_ds_tree_layout t P U"
    proof (cases "(F[i:=None])!j")
      case None then show ?thesis by simp
    next
      case (Some U)
      have JF: "j<length F" using J by simp
      have OLDJ: "F!j=Some U" using Some I JF by (auto simp: nth_list_update split: if_splits)
      have RANK: "bn_rank U=j" using R JF OLDJ by (auto simp: bn_rep_def)
      have UF: "Some U\<in>set F" using nth_mem[OF JF] OLDJ by simp
      have VU: "bn_valid t P U" using ALL UF by blast
      have LU: "bn_ds_tree_layout t P U" by (rule vero_aux_valid_layout[OF VU])
      show ?thesis using Some RANK LU by simp
    qed
  qed
  have VH: "bn_ds_forest_view t h P (F[i:=None])"
    using OLD RV LAYOUT A HH
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
  have EQ: "block_bytes (ptr_val fake) (size_of TYPE(StrictC'_BinomialHeap_C)) = ptr_span fake"
    using intvl_no_overflow_nat_conv[OF c_guard_no_wrap'[OF GF]] by (simp add: block_bytes_def)
  have RF: "block_bytes (ptr_val fake) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq> readable_bytes (phantom_machine_state_' t)"
    using SP SS by (simp only: EQ A; auto simp: readable_bytes_def)
  have RA: "block_bytes (ptr_val (subtrees_C (bn_tree t p))) (8*length cs) \<subseteq> readable_bytes (phantom_machine_state_' t)"
  proof (cases "cs=[]")
    case True then show ?thesis by (auto simp: block_bytes_def)
  next
    case False
    have L: "live_blocks (phantom_machine_state_' t) (ptr_val (subtrees_C (bn_tree t p))) = Some (8*length cs)"
      using VP False by simp
    show ?thesis by (rule vero_aux_live_readable[OF L])
  qed
  have RVG: "bn_review_root_array_view t (subtrees_C (bn_tree t p)) (map Some cs)"
    using VP by (auto simp: bn_review_root_array_view_def)
  have RANKS: "map bn_rank cs = [0..<length cs]" using VP by simp
  have LG: "\<forall>j<length (map Some cs). case (map Some cs)!j of None \<Rightarrow> True | Some U \<Rightarrow> bn_rank U=j \<and> bn_ds_tree_layout t P U"
  proof (intro allI impI)
    fix j assume J: "j<length (map Some cs)"
    have JC: "j<length cs" using J by simp
    have VJ: "bn_valid t P (cs!j)" using VP nth_mem[OF JC] by (simp add: list_all_iff)
    have LJ: "bn_ds_tree_layout t P (cs!j)" by (rule vero_aux_valid_layout[OF VJ])
    have RJ: "bn_rank (cs!j)=j" using arg_cong[OF RANKS, where f="\<lambda>xs. xs!j"] JC by simp
    show "case (map Some cs)!j of None \<Rightarrow> True | Some U \<Rightarrow> bn_rank U=j \<and> bn_ds_tree_layout t P U"
      using JC LJ RJ by simp
  qed
  have VG: "bn_ds_forest_view t fake P (map Some cs)"
    using GF FK FC FR FL RF RA RVG CS LG
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def)
  show ?thesis using VH VG by blast
qed


lemma vero_aux_detach_merge_pre:
  assumes R: "bn_rep s h P F M" and I: "i<length F" and FT: "F!i=Some (BN p cs)"
    and A: "phantom_machine_state_' t = phantom_machine_state_' s" and HH: "bn_heap t h = bn_heap s h"
    and SP: "ptr_span fake\<subseteq>S" and SS: "S\<subseteq>reserved_bytes (phantom_machine_state_' s)"
    and HN: "\<forall>q\<in>bn_ds_forest_nodes F. bn_tree t q = bn_tree s q"
    and VH: "bn_ds_forest_view t h P (F[i:=None])" and VG: "bn_ds_forest_view t fake P (map Some cs)"
    and GT: "bn_ds_graph t P (bn_ds_forest_nodes F) (bn_ds_physical_edges s)
      (bn_ds_slots (roots_C (bn_heap s h)) (length F)) {#p#} {}"
    and ST: "bn_ds_graph_storage t (bn_ds_forest_nodes F) (bn_ds_slots (roots_C (bn_heap s h)) (length F))"
    and DIST: "distinct (concat (map (case_option [] (bn_blocks t)) (F[i:=None] @ map Some cs)))"
    and MASS: "length (bn_forest_values t (F[i:=None])) + length (bn_forest_values t (map Some cs)) < 2^32"
  shows "bn_ds_merge_pre t h fake P (F[i:=None]) (map Some cs) [] {#p#}
    (bn_ds_forest_nodes F) (bn_ds_physical_edges s)"
proof -
  let ?N = "bn_ds_forest_nodes F"
  let ?a = "roots_C (bn_heap s h)"
  have W: "allocator_wf (phantom_machine_state_' s)"
    and LH: "live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    and NN: "?a\<noteq>NULL" using R I by (auto simp: bn_rep_def)
  have LT: "live_blocks (phantom_machine_state_' t) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    by (simp only: A LH)
  have OA: "bn_ds_owned_array t ?a (length (F[i:=None]))" using R NN A by (auto simp: bn_rep_def bn_ds_owned_array_def)
  have GB: "bn_ds_graph_blocks t ?N = bn_ds_graph_blocks s ?N"
    using HN by (auto simp: bn_ds_graph_blocks_def HN[rule_format])
  have HB: "ptr_val h\<notin>bn_ds_graph_blocks s ?N"
    using R by (simp add: vero_aux_rep_graph_blocks[OF R] bn_rep_def bn_owned_def)
  have AB: "ptr_val ?a\<notin>bn_ds_graph_blocks s ?N" by (rule vero_aux_rep_roots_separate[OF R I])
  have D0: "ptr_span (h +\<^sub>p int 0) \<inter> ptr_span fake = {}"
    by (rule vero_aux_live_reserved_span[OF W LH _ _ SP SS, where k=1 and i=0]) simp_all
  have DIS: "ptr_span h \<inter> ptr_span fake = {}" using D0 by simp
  have NE: "h\<noteq>fake"
  proof
    assume E: "h=fake"
    have EMPTY: "ptr_span h = {}" using DIS by (simp only: E[symmetric] Int_absorb)
    have MEM: "ptr_val h\<in>ptr_span h" by (rule intvl_self) simp
    show False using MEM by (simp only: EMPTY; simp)
  qed
  have TFM: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FT by simp
  have ROOTS: "\<forall>U. Some U\<in>set (map Some cs) \<longrightarrow> bn_root U\<in>?N"
  proof (intro allI impI)
    fix U assume UF: "Some U\<in>set (map Some cs)"
    have UC: "U\<in>set cs" using UF by auto
    have NODE: "bn_root U\<in>set (bn_ds_node_list (BN p cs))" using UC vero_aux_nodes_root[of U] by auto
    show "bn_root U\<in>?N" using TFM NODE by (simp only: vero_aux_forest_node_member; blast)
  qed
  have V0: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid s P U" using R by (auto simp: bn_rep_def in_set_conv_nth)
  have REF0: "\<forall>q\<in>?N. refcount_C (bn_tree s q) = 1"
  proof (intro ballI)
    fix q assume QN: "q\<in>?N"
    obtain U where UF: "Some U\<in>set F" and QU: "q\<in>set (bn_ds_node_list U)"
      using QN by (auto simp: vero_aux_forest_node_member)
    have VU: "bn_valid s P U" using V0 UF by blast
    have OK: "vero_aux_node_ok s P q" using vero_aux_valid_node_fields[OF VU] QU by blast
    show "refcount_C (bn_tree s q) = 1" using OK by (simp add: vero_aux_node_ok_def Let_def)
  qed
  have REF: "\<forall>q\<in>?N. unat (refcount_C (bn_tree t q)) < 65533" using HN REF0 by auto
  show ?thesis using VH VG DIST LT OA HB AB NE GT ST ROOTS MASS REF
    by (auto simp: bn_ds_merge_pre_def HH GB)
qed

lemma c0061_prove:
  "bn_rep entry h P F M \<Longrightarrow> i < length F \<Longrightarrow> F ! i = Some T \<Longrightarrow>
  c_guard fake \<Longrightarrow> root_ptr_valid (hrs_htd (t_hrs_' entry)) fake \<Longrightarrow>
  ptr_span fake \<subseteq> \<S> \<Longrightarrow> \<S> \<subseteq> reserved_bytes (phantom_machine_state_' entry) \<Longrightarrow>
  P \<inter> \<S> = {} \<Longrightarrow>
  bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t.
   r = bn_root T \<and> phantom_machine_state_' t = phantom_machine_state_' entry \<and>
   hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' entry) \<and>
   (\<exists>N edges. bn_ds_merge_pre t h fake P (F[i := None]) (map Some (bn_ds_children T)) [] {#r#} N edges))"

proof -
  assume R: "bn_rep entry h P F M" and I: "i<length F" and FT: "F!i=Some T"
    and GF: "c_guard fake" and RPV: "root_ptr_valid (hrs_htd (t_hrs_' entry)) fake"
    and SP: "ptr_span fake\<subseteq>\<S>" and SS: "\<S>\<subseteq>reserved_bytes (phantom_machine_state_' entry)"
    and PS: "P\<inter>\<S>={}"
  obtain p cs where SHAPE: "T=BN p cs" by (cases T) auto
  have FTP: "F!i=Some (BN p cs)" using FT SHAPE by simp
  let ?u = "bn_review_clear_root entry h i"
  let ?v = "(bn_heap ?u fake)\<lparr>heap_type_C := heap_type_C (bn_heap ?u h),
    compare_func_C := compare_func_C (bn_heap ?u h), roots_C := subtrees_C (bn_tree ?u p),
    roots_length_C := UCAST(16 \<rightarrow> 32) (order_C (bn_tree ?u p))\<rparr>"
  let ?t = "t_hrs_'_update (hrs_mem_update (heap_update fake ?v)) ?u"
  let ?N = "bn_ds_forest_nodes F"
  let ?slots = "bn_ds_slots (roots_C (bn_heap entry h)) (length F)"
  note CORE = vero_aux_detach_core[OF R I FTP GF SP SS PS]
  have A: "phantom_machine_state_' ?t = phantom_machine_state_' entry"
    and HTD: "hrs_htd (t_hrs_' ?t) = hrs_htd (t_hrs_' entry)"
    and HH: "bn_heap ?t h = bn_heap entry h" and HF: "bn_heap ?t fake = ?v"
    and HU: "bn_heap ?u h = bn_heap entry h" and HPU: "bn_tree ?u p = bn_tree entry p"
    and RV: "bn_review_root_array_view ?t (roots_C (bn_heap entry h)) (F[i:=None])"
    and ALL: "\<forall>U. Some U\<in>set F \<longrightarrow> bn_valid ?t P U"
    and HN: "\<forall>q\<in>?N. bn_tree ?t q = bn_tree entry q"
    and GT: "bn_ds_graph ?t P ?N (bn_ds_physical_edges entry) ?slots {#p#} {}"
    and ST: "bn_ds_graph_storage ?t ?N ?slots"
    and DIST: "distinct (concat (map (case_option [] (bn_blocks ?t)) (F[i:=None] @ map Some cs)))"
    and MASS: "length (bn_forest_values ?t (F[i:=None])) + length (bn_forest_values ?t (map Some cs)) < 2^32"
    using CORE by blast+
  have TFM: "Some (BN p cs)\<in>set F" using nth_mem[OF I] FTP by simp
  have PN: "p\<in>?N" using TFM by (auto simp: vero_aux_forest_node_member)
  have HP: "bn_tree ?t p = bn_tree entry p" using HN PN by blast
  have VP: "bn_valid ?t P (BN p cs)" using ALL TFM by blast
  have V0: "bn_valid entry P (BN p cs)" using R I FTP by (auto simp: bn_rep_def)
  have ORDER: "unat (order_C (bn_tree entry p)) = length cs" using V0 by simp
  have FK: "heap_type_C (bn_heap ?t fake) = BINOMIAL_HEAP_TYPE_MIN" using HF HU R by (simp add: bn_rep_def)
  have FC: "compare_func_C (bn_heap ?t fake) = binomial_heap_input.int_compare" using HF HU R by (simp add: bn_rep_def)
  have FR: "roots_C (bn_heap ?t fake) = subtrees_C (bn_tree ?t p)" by (simp only: HF HP; simp add: HPU)
  have FL: "unat (roots_length_C (bn_heap ?t fake)) = length cs" by (simp only: HF; simp add: HPU ORDER unat_ucast_up_simp)
  have VH: "bn_ds_forest_view ?t h P (F[i:=None])" and VG: "bn_ds_forest_view ?t fake P (map Some cs)"
    using vero_aux_detach_views[OF R I FTP A HH GF SP SS FK FC FR FL RV VP ALL] by blast+
  have MP: "bn_ds_merge_pre ?t h fake P (F[i:=None]) (map Some cs) [] {#p#} ?N (bn_ds_physical_edges entry)"
    by (rule vero_aux_detach_merge_pre[OF R I FTP A HH SP SS HN VH VG GT ST DIST MASS])
  have LEN: "length F\<le>32" and W: "allocator_wf (phantom_machine_state_' entry)"
    and LH: "live_blocks (phantom_machine_state_' entry) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C))"
    using R by (auto simp: bn_rep_def)
  have IB: "i<2^32" using I LEN by (simp; arith)
  have IDX: "uint (of_nat i :: 32 word) = int i" using IB by (simp add: uint_nat unat_of_nat)
  have GS: "c_guard (roots_C (bn_heap entry h) +\<^sub>p uint (of_nat i :: 32 word))"
    using R I by (auto simp: bn_rep_def IDX)
  have VAL: "h_val (hrs_mem (t_hrs_' entry)) (roots_C (bn_heap entry h) +\<^sub>p uint (of_nat i :: 32 word)) = p"
    using R I FTP by (auto simp: bn_rep_def IDX)
  have GP: "c_guard p" and LP: "live_blocks (phantom_machine_state_' entry) (ptr_val p) = Some (size_of TYPE(StrictC'_BinomialTree_C))"
    using V0 by auto
  have DH0: "ptr_span (h +\<^sub>p int 0) \<inter> ptr_span fake = {}"
    by (rule vero_aux_live_reserved_span[OF W LH _ _ SP SS, where k=1 and i=0]) simp_all
  have DP0: "ptr_span (p +\<^sub>p int 0) \<inter> ptr_span fake = {}"
    by (rule vero_aux_live_reserved_span[OF W LP _ _ SP SS, where k=1 and i=0]) simp_all
  have DH: "ptr_span h \<inter> ptr_span fake = {}" using DH0 by simp
  have DP: "ptr_span p \<inter> ptr_span fake = {}" using DP0 by simp
  have SEM: "bn_contract (bn_ds_pop_detach h fake (of_nat i)) entry (\<lambda>r t. r=p \<and> t=?t)"
    using vero_aux_detach_semantics[OF GS VAL GF GP DH DP]
    by (simp only: IDX bn_review_clear_root_def)
  show ?thesis
    apply (rule vero_aux_contract_weaken[OF SEM])
    using A HTD MP SHAPE by (auto; blast)
qed



end

context binomial_heap_input_global_addresses begin



lemma c0062_prove:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = None \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,j)) s (\<lambda>r t. r = (i + 1,j) \<and> t = s)"

proof -
  assume R: "bn_rep s h P F M" and I: "unat i < length F" and N: "F ! unat i = None"
  have G: "c_guard (roots_C (bn_heap s h) +\<^sub>p uint i)"
    and V: "h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint i) = NULL"
    using R I N by (auto simp: bn_rep_def int_unat)
  show ?thesis using G V
    by (auto simp: bn_ds_scan_step_def bn_contract_def bn_heap_def
      runs_to_bind_iff runs_to_guard_iff runs_to_condition_iff reaches_bind reaches_condition_iff
      succeeds_runs_to_iff reaches_guard reaches_return)
qed



end



lemma c0063_prove:
  "bytes_frame W hp hp' \<Longrightarrow> bytes_frame W hp' hp'' \<Longrightarrow>
    bytes_frame W hp hp''"

by (auto simp: bytes_frame_def)





lemma c0064_prove:
  "bn_rep s h P F M \<Longrightarrow> bn_ds_forest_view s h P F"

proof -
  assume R: "bn_rep s h P F M"
  have H: "block_bytes (ptr_val h) (size_of TYPE(StrictC'_BinomialHeap_C)) \<subseteq>
       readable_bytes (phantom_machine_state_' s)"
    apply (rule vero_aux_live_readable)
    using R by (simp add: bn_rep_def)
  have ARR: "block_bytes (ptr_val (roots_C (bn_heap s h))) (8 * length F) \<subseteq>
       readable_bytes (phantom_machine_state_' s)"
  proof (cases "roots_C (bn_heap s h) = NULL")
    case True
    have "F = []" using R True by (simp add: bn_rep_def)
    thus ?thesis by (auto simp: block_bytes_def)
  next
    case False
    obtain n where L: "live_blocks (phantom_machine_state_' s) (ptr_val (roots_C (bn_heap s h))) = Some n"
      and N: "8 * length F \<le> n"
      using R False by (auto simp: bn_rep_def)
    have B: "block_bytes (ptr_val (roots_C (bn_heap s h))) (8 * length F) \<subseteq>
        block_bytes (ptr_val (roots_C (bn_heap s h))) n"
      using N by (auto simp: block_bytes_def)
    show ?thesis by (rule subset_trans[OF B vero_aux_live_readable[OF L]])
  qed
  show ?thesis using R H ARR
    by (auto simp: bn_ds_forest_view_def bn_review_header_view_def bn_review_root_array_view_def bn_rep_def
      split: option.splits intro: vero_aux_valid_layout)
qed





lemma c0065_prove:
  "allocator_wf A \<Longrightarrow> fresh_block A p n \<Longrightarrow> live_blocks A p = None"

proof -
  assume A: "allocator_wf A" and F: "fresh_block A p n"
  show ?thesis
  proof (cases "live_blocks A p")
    case None thus ?thesis .
  next
    case (Some m)
    have N: "0 < n" using F by (simp add: fresh_block_def block_ok_def)
    have M: "0 < m" using A Some by (auto simp: allocator_wf_def block_ok_def)
    have D: "block_bytes p n \<inter> block_bytes p m = {}"
      using F Some unfolding fresh_block_def by blast
    have "p \<in> block_bytes p n" "p \<in> block_bytes p m"
      using N M by (simp_all add: block_bytes_def)
    thus ?thesis using D by blast
  qed
qed





lemma c0066_prove:
  "bn_valid s P T \<Longrightarrow> bn_ds_tree_layout s P T"

by (induction T) (auto simp: list_all_iff)



context binomial_heap_input_global_addresses begin

lemma vero_aux_guard_condition_return:
  "G s \<Longrightarrow> C s \<Longrightarrow> Q v s \<Longrightarrow>
   bn_contract (do {guard G; condition C (return v) f}) s Q"
  by (auto simp: bn_contract_def runs_to_bind_iff runs_to_guard_iff
    runs_to_condition_iff reaches_bind reaches_guard reaches_condition_iff
    reaches_return[abs_def] succeeds_runs_to_iff)

lemma c0067_prove:
  "bn_rep s h P F {#} \<Longrightarrow> bn_stack_ready \<S> s \<Longrightarrow>
    P \<inter> \<S> = {} \<Longrightarrow>
    bn_contract (binomial_heap_pop' h) s (\<lambda>r t.
      r = NULL \<and> bn_rep t h P F {#} \<and> bn_frame s h P F t \<and>
      phantom_machine_state_' t = phantom_machine_state_' s)"

proof -
  assume R: "bn_rep s h P F {#}" and BS: "bn_stack_ready \<S> s" and PS: "P \<inter> \<S> = {}"
  have SS: "\<S> \<subseteq> reserved_bytes (phantom_machine_state_' s)"
    and NE: "stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s)) \<noteq> {}"
    using BS by (auto simp: bn_stack_ready_def)
  show ?thesis
    unfolding binomial_heap_pop'_def
    apply (rule vero_aux_stack_contract)
    apply (rule NE)
    subgoal premises PRE for p d v bs
    proof -
      have PD: "(p,d) \<in> stack_allocs 1 \<S> TYPE(StrictC'_BinomialHeap_C) (hrs_htd (t_hrs_' s))"
        by (rule PRE(1))
      have LEN: "length bs = size_of TYPE(StrictC'_BinomialHeap_C)" by (rule PRE(2))
      let ?a = "t_hrs_'_update (hrs_mem_update (heap_update_padding p v bs))
          (t_hrs_'_update (hrs_htd_update (\<lambda>_. d)) s)"
      let ?u = "\<lambda>bs'. t_hrs_'_update (hrs_mem_update (heap_update_list (ptr_val p) bs'))
            (t_hrs_'_update (hrs_htd_update (stack_releases 1 p)) ?a)"
      have SP: "ptr_span p \<subseteq> \<S>" using CLanguage.stack_allocs_\<S>[OF PD, where i=0] by simp
      have AP: "phantom_machine_state_' ?a = phantom_machine_state_' s" by simp
      have BF0: "bytes_frame \<S> (hrs_mem (t_hrs_' s)) (heap_update_padding p v bs (hrs_mem (t_hrs_' s)))"
        using vero_aux_stack_bytes[OF SP LEN] by blast
      have BF: "bytes_frame \<S> (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' ?a))"
        using BF0 by (simp add: hrs_mem_def hrs_mem_update_def hrs_htd_update_def case_prod_unfold)
      have REP: "bn_rep ?a h P F {#}" by (rule vero_aux_rep_reserved_frame[OF R AP SS PS BF])
      have GH: "c_guard h" and ZERO: "num_values_C (h_val (hrs_mem (t_hrs_' ?a)) h) = 0"
        using REP by (auto simp: bn_rep_def bn_heap_def unat_eq_zero)
      have CLEAN: "\<forall>bs'. length bs' = size_of TYPE(StrictC'_BinomialHeap_C) \<longrightarrow>
        bn_rep (?u bs') h P F {#} \<and> bn_frame s h P F (?u bs') \<and>
        phantom_machine_state_' (?u bs') = phantom_machine_state_' s"
      proof (intro allI impI)
        fix bs' :: "8 word list"
        assume LEN': "length bs' = size_of TYPE(StrictC'_BinomialHeap_C)"
        show "bn_rep (?u bs') h P F {#} \<and> bn_frame s h P F (?u bs') \<and>
          phantom_machine_state_' (?u bs') = phantom_machine_state_' s"
          using vero_aux_heap_stack_cleanup[OF R SS PS PD LEN LEN' refl, where v=v] by blast
      qed
      show ?thesis
        apply (rule vero_aux_guard_condition_return)
        apply (rule GH)
        apply (rule ZERO)
        using CLEAN by (simp add: binomial_heap_null_value_def o_assoc)

    qed
    done
qed



end



lemma c0068_prove:
  "malloc_rel n hp A 0 hp' B \<Longrightarrow> hp' = hp \<and> B = A"

by (auto simp: malloc_rel_def fresh_block_def block_ok_def)



definition vero_aux_closed_c0005 :: bool where
 "vero_aux_closed_c0005 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h P p q. allocator_wf (phantom_machine_state_' s) \<longrightarrow> c_guard h \<longrightarrow>
    heap_type_C (bn_heap s h) = BINOMIAL_HEAP_TYPE_MIN \<longrightarrow>
    compare_func_C (bn_heap s h) = binomial_heap_input.int_compare \<longrightarrow>
    P \<subseteq> reserved_bytes (phantom_machine_state_' s) \<longrightarrow>
    bn_valid s P (BN p []) \<longrightarrow> bn_valid s P (BN q []) \<longrightarrow> p \<noteq> q \<longrightarrow>
    live_blocks (phantom_machine_state_' s) (ptr_val h) = Some (size_of TYPE(StrictC'_BinomialHeap_C)) \<longrightarrow>
    ptr_val h \<noteq> ptr_val p \<longrightarrow> ptr_val h \<noteq> ptr_val q \<longrightarrow>
    bn_contract (binomial_tree_merge' h p q) s (\<lambda>r t. True)))"

lemma vero_aux_closed_c0005_iff:
  "vero_aux_closed_c0005 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0005"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    note PRE = binomial_heap_input_global_addresses.vero_aux_leaf_merge_pre[OF A]
    note FAIL = binomial_heap_input_global_addresses.vero_aux_leaf_merge_failure[OF A]
    have RUN: "bn_contract (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96))
      binomial_heap_input_global_addresses.vero_aux_leaf_merge_state (\<lambda>r t. True)"
      using H A PRE unfolding vero_aux_closed_c0005_def by blast
    show False using RUN FAIL by blast
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0005" by (simp add: vero_aux_closed_c0005_def)
qed


definition vero_aux_closed_c0004 :: bool where
 "vero_aux_closed_c0004 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h P T U N edges slots held. bn_ds_tree_merge_pre s h P T U N edges slots held \<longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s (\<lambda>r t.
    if r = NULL then bn_ds_restore s t else
    (\<exists>V N' edges'. bn_root V = r \<and> bn_rank V = bn_rank T + 1 \<and>
      bn_ds_tree_layout t P V \<and> distinct (bn_blocks t V) \<and>
      mset (bn_values t V) = mset (bn_values s T) + mset (bn_values s U) \<and>
      refcount_C (bn_tree t r) = 0 \<and>
      bn_ds_graph t P N' edges' slots held {r} \<and> bn_ds_graph_storage t N' slots \<and>
      N' = insert r N \<and> bn_ds_old_node_fields s N t N' \<and>
      bn_ds_storage_transition s (bn_ds_graph_blocks s N) t (bn_ds_graph_blocks t N')) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a))))"

lemma vero_aux_closed_c0004_iff:
 "vero_aux_closed_c0004 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0004"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s h P T U N edges slots held. bn_ds_tree_merge_pre s h P T U N edges slots held \<longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s (\<lambda>r t.
    if r = NULL then bn_ds_restore s t else
    (\<exists>V N' edges'. bn_root V = r \<and> bn_rank V = bn_rank T + 1 \<and>
      bn_ds_tree_layout t P V \<and> distinct (bn_blocks t V) \<and>
      mset (bn_values t V) = mset (bn_values s T) + mset (bn_values s U) \<and>
      refcount_C (bn_tree t r) = 0 \<and>
      bn_ds_graph t P N' edges' slots held {r} \<and> bn_ds_graph_storage t N' slots \<and>
      N' = insert r N \<and> bn_ds_old_node_fields s N t N' \<and>
      bn_ds_storage_transition s (bn_ds_graph_blocks s N) t (bn_ds_graph_blocks t N')) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a))"
      using H A by (simp add: vero_aux_closed_c0004_def)
    note PRE = binomial_heap_input_global_addresses.vero_aux_leaf_tree_merge_pre[OF A]
    have RUN: "bn_contract (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96)) binomial_heap_input_global_addresses.vero_aux_leaf_merge_state (\<lambda>r t. True)"
      by (rule binomial_heap_input_global_addresses.vero_aux_contract_weaken[OF A C[rule_format, OF PRE, simplified]]) simp
    show False using RUN binomial_heap_input_global_addresses.vero_aux_leaf_merge_failure[OF A] by blast
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0004" by (simp add: vero_aux_closed_c0004_def)
qed

definition vero_aux_closed_c0041 :: bool where
 "vero_aux_closed_c0041 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h other P F G ext held N edges. bn_ds_merge_pre s h other P F G ext held N edges \<longrightarrow>
  bn_contract (binomial_heap_merge' h other) s (\<lambda>r t.
   if r = 0 then bn_ds_restore s t
   else bn_ds_merge_success s h P F G ext held N t)))"

lemma vero_aux_closed_c0041_iff:
 "vero_aux_closed_c0041 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0041"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s h other P F G ext held N edges. bn_ds_merge_pre s h other P F G ext held N edges \<longrightarrow>
  bn_contract (binomial_heap_merge' h other) s (\<lambda>r t.
   if r = 0 then bn_ds_restore s t
   else bn_ds_merge_success s h P F G ext held N t)"
      using H A by (simp add: vero_aux_closed_c0041_def)
    note PRE = binomial_heap_input_global_addresses.vero_aux_pair_pre[OF A]
    have RUN: "bn_contract (binomial_heap_merge' (Ptr 16) (Ptr 512)) binomial_heap_input_global_addresses.vero_aux_pair_state (\<lambda>r t. True)"
      by (rule binomial_heap_input_global_addresses.vero_aux_contract_weaken[OF A C[rule_format, OF PRE, simplified]]) simp
    show False using RUN by (simp add: bn_contract_def binomial_heap_input_global_addresses.vero_aux_pair_heap_merge_failure[OF A])
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0041" by (simp add: vero_aux_closed_c0041_def)
qed

definition vero_aux_closed_c0073 :: bool where
 "vero_aux_closed_c0073 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h P T U N edges slots held. bn_ds_tree_merge_pre s h P T U N edges slots held \<longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s
    (\<lambda>r t. r = NULL \<longrightarrow> bn_ds_restore s t)))"

lemma vero_aux_closed_c0073_iff:
 "vero_aux_closed_c0073 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0073"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s h P T U N edges slots held. bn_ds_tree_merge_pre s h P T U N edges slots held \<longrightarrow>
  bn_contract (binomial_tree_merge' h (bn_root T) (bn_root U)) s
    (\<lambda>r t. r = NULL \<longrightarrow> bn_ds_restore s t)"
      using H A by (simp add: vero_aux_closed_c0073_def)
    note PRE = binomial_heap_input_global_addresses.vero_aux_leaf_tree_merge_pre[OF A]
    have RUN: "bn_contract (binomial_tree_merge' (Ptr 16) (Ptr 64) (Ptr 96)) binomial_heap_input_global_addresses.vero_aux_leaf_merge_state (\<lambda>r t. True)"
      by (rule binomial_heap_input_global_addresses.vero_aux_contract_weaken[OF A C[rule_format, OF PRE, simplified]]) simp
    show False using RUN binomial_heap_input_global_addresses.vero_aux_leaf_merge_failure[OF A] by blast
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0073" by (simp add: vero_aux_closed_c0073_def)
qed


definition vero_aux_closed_c0028 :: bool where
 "vero_aux_closed_c0028 = (Calg_Binomial_Reviewed_Stack \<longrightarrow> (\<forall>s h P F M v. bn_rep s h P F M \<longrightarrow> bn_payload P v \<longrightarrow>
    size M + 1 < 2 ^ 32 \<longrightarrow> bn_stack_ready \<S> s \<longrightarrow> P \<inter> \<S> = {} \<longrightarrow>
    bn_contract (binomial_heap_insert' h v) s (\<lambda>r t.
      bn_frame s h P F t \<and>
      (if r = 0 then (\<exists>F'. bn_rep t h P F' M) \<and>
        live_blocks (phantom_machine_state_' t) = live_blocks (phantom_machine_state_' s)
       else \<exists>F'. bn_rep t h P F' (add_mset v M) \<and> bn_storage_transition s h F t F'))))"

lemma vero_aux_closed_c0028_iff:
 "vero_aux_closed_c0028 \<longleftrightarrow> \<not>Calg_Binomial_Reviewed_Stack"
proof
  assume H: "vero_aux_closed_c0028"
  show "\<not>Calg_Binomial_Reviewed_Stack"
  proof
    assume A: "Calg_Binomial_Reviewed_Stack"
    note PRE = Calg_Binomial_Reviewed_Stack.vero_aux_insert_counterexample[OF A]
    show False using H A PRE unfolding vero_aux_closed_c0028_def by blast
  qed
next
  assume "\<not>Calg_Binomial_Reviewed_Stack"
  then show "vero_aux_closed_c0028" by (simp add: vero_aux_closed_c0028_def)
qed

definition vero_aux_closed_c0045 :: bool where
 "vero_aux_closed_c0045 = (Calg_Binomial_Reviewed_Stack \<longrightarrow> (\<forall>s h P F M. bn_rep s h P F M \<longrightarrow> bn_stack_ready \<S> s \<longrightarrow> P \<inter> \<S> = {} \<longrightarrow>
    bn_contract (binomial_heap_pop' h) s (\<lambda>r t. bn_frame s h P F t \<and>
      (if r = NULL then (\<exists>F'. bn_rep t h P F' M) \<and>
        live_blocks (phantom_machine_state_' t) = live_blocks (phantom_machine_state_' s)
       else r \<in># M \<and> (\<forall>q \<in># M. bn_key s r \<le> bn_key s q) \<and>
         (\<exists>F'. bn_rep t h P F' (M - {#r#}) \<and> bn_storage_transition s h F t F')))))"

lemma vero_aux_closed_c0045_iff:
 "vero_aux_closed_c0045 \<longleftrightarrow> \<not>Calg_Binomial_Reviewed_Stack"
proof
  assume H: "vero_aux_closed_c0045"
  show "\<not>Calg_Binomial_Reviewed_Stack"
  proof
    assume A: "Calg_Binomial_Reviewed_Stack"
    note PRE = Calg_Binomial_Reviewed_Stack.vero_aux_pop_counterexample[OF A]
    show False using H A PRE unfolding vero_aux_closed_c0045_def by blast
  qed
next
  assume "\<not>Calg_Binomial_Reviewed_Stack"
  then show "vero_aux_closed_c0045" by (simp add: vero_aux_closed_c0045_def)
qed


definition vero_aux_closed_c0036 :: bool where
 "vero_aux_closed_c0036 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s h P G N edges slot tree v M result. bn_ds_finish_base s h P G N edges [slot] {#} \<longrightarrow>
  c_guard slot \<longrightarrow> h_val (hrs_mem (t_hrs_' s)) slot = tree \<longrightarrow>
  bn_ds_tree_layout s P (BN tree []) \<longrightarrow> value_C (bn_tree s tree) = v \<longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<longrightarrow> size M + 1 < 2^32 \<longrightarrow>
  mset (bn_forest_values s G) = (if result = 0 then M else add_mset v M) \<longrightarrow>
  bn_contract (binomial_heap_input_global_addresses.bn_ds_insert_finish h slot result) s (\<lambda>r t.
    r = result \<and> bn_rep t h P G (if result = 0 then M else add_mset v M) \<and>
    bn_ds_storage_transition s
      (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
      t (set (bn_owned t h G)) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))))"

lemma vero_aux_closed_c0036_iff:
 "vero_aux_closed_c0036 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0036"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s h P G N edges slot tree v M result. bn_ds_finish_base s h P G N edges [slot] {#} \<longrightarrow>
  c_guard slot \<longrightarrow> h_val (hrs_mem (t_hrs_' s)) slot = tree \<longrightarrow>
  bn_ds_tree_layout s P (BN tree []) \<longrightarrow> value_C (bn_tree s tree) = v \<longrightarrow>
  unat (num_values_C (bn_heap s h)) = size M \<longrightarrow> size M + 1 < 2^32 \<longrightarrow>
  mset (bn_forest_values s G) = (if result = 0 then M else add_mset v M) \<longrightarrow>
  bn_contract (binomial_heap_input_global_addresses.bn_ds_insert_finish h slot result) s (\<lambda>r t.
    r = result \<and> bn_rep t h P G (if result = 0 then M else add_mset v M) \<and>
    bn_ds_storage_transition s
      (insert (ptr_val h) (insert (ptr_val (roots_C (bn_heap s h))) (bn_ds_graph_blocks s N)))
      t (set (bn_owned t h G)) \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s))"
      using H A by (simp add: vero_aux_closed_c0036_def)
    note PRE = binomial_heap_input_global_addresses.vero_aux_finish_alias_pre[OF A]
    note INST = C[rule_format, where
      s="binomial_heap_input_global_addresses.vero_aux_finish_alias_state"
      and h="Ptr 16" and P="block_bytes 96 4"
      and G="[Some (BN (Ptr 4294967296) [])]" and N="{Ptr 4294967296}" and edges="\<lambda>_. []"
      and slot="Ptr 32" and tree="Ptr 4294967296" and v="Ptr 96" and M="{#}" and result=1]
    have RUN: "bn_contract (binomial_heap_input_global_addresses.bn_ds_insert_finish (Ptr 16) (Ptr 32) 1)
      binomial_heap_input_global_addresses.vero_aux_finish_alias_state (\<lambda>r t. True)"
      apply (rule binomial_heap_input_global_addresses.vero_aux_contract_weaken[OF A INST])
      using PRE by auto
    show False using RUN
      by (simp add: bn_contract_def binomial_heap_input_global_addresses.vero_aux_finish_alias_failure[OF A])
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0036" by (simp add: vero_aux_closed_c0036_def)
qed

definition vero_aux_closed_c0047 :: bool where
 "vero_aux_closed_c0047 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>i s a P N edges ext held bn_carry. unat i < 33 \<longrightarrow> bn_ds_owned_array s a (unat i + 1) \<longrightarrow>
  bn_ds_graph s P N edges (bn_ds_slots a (unat i + 1) @ ext)
    (held + mset (filter (\<lambda>p. p \<noteq> NULL) [bn_carry])) {} \<longrightarrow>
  bn_ds_graph_storage s N (bn_ds_slots a (unat i + 1) @ ext) \<longrightarrow>
  ptr_val a \<notin> bn_ds_graph_blocks s N \<longrightarrow>
  bn_contract (do {binomial_heap_merge_undo' a i; binomial_tree_unref' bn_carry}) s (\<lambda>r t.
   \<exists>N' edges'. bn_ds_graph t P N' edges' ext held {} \<and>
    bn_ds_graph_storage t N' ext \<and> N' \<subseteq> N \<and>
    bn_ds_old_node_fields s N t N' \<and>
    bn_ds_storage_transition s (insert (ptr_val a) (bn_ds_graph_blocks s N))
      t (bn_ds_graph_blocks t N') \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a))))"

lemma vero_aux_closed_c0047_iff:
 "vero_aux_closed_c0047 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0047"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>i s a P N edges ext held bn_carry. unat i < 33 \<longrightarrow> bn_ds_owned_array s a (unat i + 1) \<longrightarrow>
  bn_ds_graph s P N edges (bn_ds_slots a (unat i + 1) @ ext)
    (held + mset (filter (\<lambda>p. p \<noteq> NULL) [bn_carry])) {} \<longrightarrow>
  bn_ds_graph_storage s N (bn_ds_slots a (unat i + 1) @ ext) \<longrightarrow>
  ptr_val a \<notin> bn_ds_graph_blocks s N \<longrightarrow>
  bn_contract (do {binomial_heap_merge_undo' a i; binomial_tree_unref' bn_carry}) s (\<lambda>r t.
   \<exists>N' edges'. bn_ds_graph t P N' edges' ext held {} \<and>
    bn_ds_graph_storage t N' ext \<and> N' \<subseteq> N \<and>
    bn_ds_old_node_fields s N t N' \<and>
    bn_ds_storage_transition s (insert (ptr_val a) (bn_ds_graph_blocks s N))
      t (bn_ds_graph_blocks t N') \<and>
    hrs_htd (t_hrs_' t) = hrs_htd (t_hrs_' s) \<and>
    (\<forall>a \<in> P. hrs_mem (t_hrs_' t) a = hrs_mem (t_hrs_' s) a))"
      using H A by (simp add: vero_aux_closed_c0047_def)
    note PRE = binomial_heap_input_global_addresses.vero_aux_undo_alias_pre[OF A]
    note INST = C[rule_format, where i=0
      and s="binomial_heap_input_global_addresses.vero_aux_undo_alias_state"
      and a="Ptr 16" and P="{}" and N="{}" and edges="\<lambda>_. []" and ext="[Ptr 24]"
      and held="{#}" and bn_carry=NULL]
    have RUN: "bn_contract (do {binomial_heap_merge_undo' (Ptr 16) 0; binomial_tree_unref' NULL})
      binomial_heap_input_global_addresses.vero_aux_undo_alias_state
      (\<lambda>r t. \<exists>N. bn_ds_graph_storage t N [Ptr 24])"
      apply (rule binomial_heap_input_global_addresses.vero_aux_contract_weaken[OF A INST])
      using PRE by (auto simp: bn_ds_slots_def)
    show False using RUN binomial_heap_input_global_addresses.vero_aux_undo_alias_failure[OF A] by blast
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0047" by (simp add: vero_aux_closed_c0047_def)
qed


definition vero_aux_closed_c0054 :: bool where
 "vero_aux_closed_c0054 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s0 h other P F G ext held N edges n a bn_carry i len vals s. bn_ds_merge_pre s0 h other P F G ext held N edges \<longrightarrow>
  n = max (length F) (length G) + 1 \<longrightarrow>
  bn_ds_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<longrightarrow>
  unat i < n \<longrightarrow>
  runs_to (binomial_heap_input_global_addresses.bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s
   (\<lambda>r t. case r of Result state \<Rightarrow>
       bn_ds_carry_inv s0 h other P F G ext held N a n state t \<and>
       (\<exists>c l vs. state = (c,i+1,l,vs))
     | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (binomial_heap_input_global_addresses.bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s r t)))"

lemma vero_aux_closed_c0054_iff:
 "vero_aux_closed_c0054 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0054"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s0 h other P F G ext held N edges n a bn_carry i len vals s. bn_ds_merge_pre s0 h other P F G ext held N edges \<longrightarrow>
  n = max (length F) (length G) + 1 \<longrightarrow>
  bn_ds_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<longrightarrow>
  unat i < n \<longrightarrow>
  runs_to (binomial_heap_input_global_addresses.bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s
   (\<lambda>r t. case r of Result state \<Rightarrow>
       bn_ds_carry_inv s0 h other P F G ext held N a n state t \<and>
       (\<exists>c l vs. state = (c,i+1,l,vs))
     | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (binomial_heap_input_global_addresses.bn_ds_carry_loop_step h other (of_nat n) a (bn_carry,i,len,vals)) s r t)"
      using H A by (simp add: vero_aux_closed_c0054_def)
    note PRE = binomial_heap_input_global_addresses.vero_aux_pair_pre[OF A]
    have N: "(2::nat)=max (length [Some (BN (Ptr 64) [])]) (length [Some (BN (Ptr 96) [])])+1" by simp
    note INV = binomial_heap_input_global_addresses.vero_aux_pair_initial_inv[OF A, where vals=undefined]
    have I: "unat (0::32 word)<2" by simp
    note STEP = C[rule_format, OF PRE N INV I]
    show False using STEP
      by (simp add: binomial_heap_input_global_addresses.vero_aux_pair_carry_step_failure[OF A])
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0054" by (simp add: vero_aux_closed_c0054_def)
qed

definition vero_aux_closed_c0060 :: bool where
 "vero_aux_closed_c0060 = (binomial_heap_input_global_addresses \<longrightarrow> (\<forall>s0 h other P F G ext held N edges n s a vals. bn_ds_merge_pre s0 h other P F G ext held N edges \<longrightarrow>
  n = max (length F) (length G) + 1 \<longrightarrow>
  bn_ds_roots_allocation s0 s a n \<longrightarrow>
  runs_to (binomial_heap_input_global_addresses.bn_ds_carry_loop h other (of_nat n) a vals) s
    (\<lambda>r t. case r of Result result \<Rightarrow> bn_ds_carry_done s0 h P F G ext held N a n result t
      | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (binomial_heap_input_global_addresses.bn_ds_carry_loop h other (of_nat n) a vals) s r t)))"

lemma vero_aux_closed_c0060_iff:
 "vero_aux_closed_c0060 \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
proof
  assume H: "vero_aux_closed_c0060"
  show "\<not>binomial_heap_input_global_addresses"
  proof
    assume A: "binomial_heap_input_global_addresses"
    have C: "\<forall>s0 h other P F G ext held N edges n s a vals. bn_ds_merge_pre s0 h other P F G ext held N edges \<longrightarrow>
  n = max (length F) (length G) + 1 \<longrightarrow>
  bn_ds_roots_allocation s0 s a n \<longrightarrow>
  runs_to (binomial_heap_input_global_addresses.bn_ds_carry_loop h other (of_nat n) a vals) s
    (\<lambda>r t. case r of Result result \<Rightarrow> bn_ds_carry_done s0 h P F G ext held N a n result t
      | Exn e \<Rightarrow> e = 0 \<and> bn_ds_restore s0 t) \<and>
  (\<exists>r t. reaches (binomial_heap_input_global_addresses.bn_ds_carry_loop h other (of_nat n) a vals) s r t)"
      using H A by (simp add: vero_aux_closed_c0060_def)
    note PRE = binomial_heap_input_global_addresses.vero_aux_pair_pre[OF A]
    have N: "(2::nat)=max (length [Some (BN (Ptr 64) [])]) (length [Some (BN (Ptr 96) [])])+1" by simp
    note ALLOC = binomial_heap_input_global_addresses.vero_aux_pair_allocation[OF A]
    note LOOP = C[rule_format, OF PRE N ALLOC]
    show False using LOOP
      by (simp add: binomial_heap_input_global_addresses.vero_aux_pair_carry_loop_failure[OF A])
  qed
next
  assume "\<not>binomial_heap_input_global_addresses"
  then show "vero_aux_closed_c0060" by (simp add: vero_aux_closed_c0060_def)
qed


lemma vero_aux_remaining_positive_conjunction:
  "(vero_aux_closed_c0004 \<and>
    vero_aux_closed_c0005 \<and>
    vero_aux_closed_c0028 \<and>
    vero_aux_closed_c0036 \<and>
    vero_aux_closed_c0041 \<and>
    vero_aux_closed_c0045 \<and>
    vero_aux_closed_c0047 \<and>
    vero_aux_closed_c0054 \<and>
    vero_aux_closed_c0060 \<and>
    vero_aux_closed_c0073) \<longleftrightarrow> \<not>binomial_heap_input_global_addresses"
  by (simp add: vero_aux_closed_c0004_iff vero_aux_closed_c0005_iff vero_aux_closed_c0028_iff vero_aux_closed_c0036_iff vero_aux_closed_c0041_iff vero_aux_closed_c0045_iff vero_aux_closed_c0047_iff vero_aux_closed_c0054_iff vero_aux_closed_c0060_iff vero_aux_closed_c0073_iff Calg_Binomial_Reviewed_Stack_def; blast)

lemma vero_aux_remaining_negative_conjunction:
  "(\<not>vero_aux_closed_c0004 \<and>
    \<not>vero_aux_closed_c0005 \<and>
    \<not>vero_aux_closed_c0028 \<and>
    \<not>vero_aux_closed_c0036 \<and>
    \<not>vero_aux_closed_c0041 \<and>
    \<not>vero_aux_closed_c0045 \<and>
    \<not>vero_aux_closed_c0047 \<and>
    \<not>vero_aux_closed_c0054 \<and>
    \<not>vero_aux_closed_c0060 \<and>
    \<not>vero_aux_closed_c0073) \<longleftrightarrow> Calg_Binomial_Reviewed_Stack"
  by (simp add: vero_aux_closed_c0004_iff vero_aux_closed_c0005_iff vero_aux_closed_c0028_iff vero_aux_closed_c0036_iff vero_aux_closed_c0041_iff vero_aux_closed_c0045_iff vero_aux_closed_c0047_iff vero_aux_closed_c0054_iff vero_aux_closed_c0060_iff vero_aux_closed_c0073_iff Calg_Binomial_Reviewed_Stack_def; blast)


definition vero_aux_address_configuration ::
  "unit ptr list \<Rightarrow> addr set \<Rightarrow> addr set \<Rightarrow> bool" where
  "vero_aux_address_configuration fs g st = (length fs = 19 \<and> ((((c_fnptr_guard (fs ! 0) \<and>
   c_fnptr_guard (fs ! 1)) \<and>
  c_fnptr_guard (fs ! 2) \<and>
  c_fnptr_guard (fs ! 3) \<and>
  c_fnptr_guard (fs ! 4)) \<and>
 (c_fnptr_guard (fs ! 5) \<and>
  c_fnptr_guard (fs ! 6)) \<and>
 c_fnptr_guard (fs ! 7) \<and>
 c_fnptr_guard (fs ! 8) \<and>
 c_fnptr_guard (fs ! 9)) \<and>
((c_fnptr_guard (fs ! 10) \<and>
  c_fnptr_guard (fs ! 11)) \<and>
 c_fnptr_guard (fs ! 12) \<and>
 c_fnptr_guard (fs ! 13) \<and>
 c_fnptr_guard (fs ! 14)) \<and>
(c_fnptr_guard (fs ! 15) \<and>
 c_fnptr_guard (fs ! 16) \<and>
 c_fnptr_guard (fs ! 17)) \<and>
c_fnptr_guard (fs ! 18) \<and>
all_distinct
 (Node
   (Node
     (Node (Node Tip (fs ! 0) False Tip)
       (fs ! 1) False
       (Node Tip (fs ! 2) False
         (Node Tip (fs ! 3) False Tip)))
     (fs ! 4) False
     (Node (Node Tip (fs ! 5) False Tip)
       (fs ! 6) False
       (Node Tip (fs ! 7) False
         (Node Tip (fs ! 8) False Tip))))
   (fs ! 9) False
   (Node
     (Node (Node Tip (fs ! 10) False Tip)
       (fs ! 11) False
       (Node Tip (fs ! 12) False
         (Node Tip (fs ! 13) False Tip)))
     (fs ! 14) False
     (Node (Node Tip (fs ! 15) False Tip)
       (fs ! 16) False
       (Node Tip (fs ! 17) False
         (Node Tip (fs ! 18) False
           Tip))))) \<and>
g \<inter> st = {}))"

lemma vero_aux_address_configuration_iff:
  "binomial_heap_input_global_addresses \<longleftrightarrow>
   vero_aux_address_configuration [binomial_heap_input.free, binomial_heap_input.calloc, binomial_heap_input.malloc, binomial_heap_input.memcpy, binomial_heap_input.int_equal, binomial_heap_input.int_compare, binomial_heap_input.init'globals, binomial_heap_input.binomial_heap_cmp, binomial_heap_input.binomial_heap_new, binomial_heap_input.binomial_tree_unref, binomial_heap_input.binomial_heap_merge_undo, binomial_heap_input.binomial_tree_ref, binomial_heap_input.binomial_tree_merge, binomial_heap_input.binomial_heap_merge, binomial_heap_input.binomial_heap_pop, binomial_heap_input.calg_binomial_new, binomial_heap_input.binomial_heap_free, binomial_heap_input.binomial_heap_insert, binomial_heap_input.binomial_heap_num_entries] Binomial_Heap_C.\<G> Binomial_Heap_C.\<S>"
  by (simp add: binomial_heap_input_global_addresses_def vero_aux_address_configuration_def)

lemma vero_aux_address_configuration_possible:
  "\<exists>fs. vero_aux_address_configuration fs {} audit_stack_addresses"
  apply (rule exI[where x="[Ptr 1, Ptr 2, Ptr 3, Ptr 4, Ptr 5, Ptr 6, Ptr 7, Ptr 8, Ptr 9, Ptr 10, Ptr 11, Ptr 12, Ptr 13, Ptr 14, Ptr 15, Ptr 16, Ptr 17, Ptr 18, Ptr 19]"])
  by (simp add: vero_aux_address_configuration_def c_fnptr_guard_def)

lemma vero_aux_address_configuration_null:
  "\<not>vero_aux_address_configuration (replicate 19 NULL) {} audit_stack_addresses"
  by (simp add: vero_aux_address_configuration_def c_fnptr_guard_def)

lemma c0069_prove:
  "mset (bn_forest_values s (F @ G)) = mset (bn_forest_values s F) + mset (bn_forest_values s G)"

by (simp add: bn_forest_values_def)





lemma c0070_prove:
  "bn_values s T \<noteq> []"

by (cases T) simp





lemma c0071_prove:
  "bn_contract f s P \<Longrightarrow>
   (\<And>v t. P v t \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract f s Q"

by (auto simp: bn_contract_def runs_to_def_old; blast)





lemma c0072_prove:
  "bn_valid s P T \<Longrightarrow> unat (order_C (bn_tree s (bn_root T))) = bn_rank T"

by (cases T) auto



context binomial_heap_input_global_addresses begin





end

context binomial_heap_input_global_addresses begin

lemma vero_aux_sum_twopowers:
  "sum_list (map (\<lambda>i. (2::nat)^i) [0..<n]) + 1 = 2^n"
proof (induction n)
  case 0
  then show ?case by simp
next
  case (Suc n)
  have E: "sum_list (map (\<lambda>i. (2::nat)^i) [0..<Suc n]) =
    sum_list (map (\<lambda>i. (2::nat)^i) [0..<n]) + 2^n"
    by (simp add: upt_Suc_snoc)
  have P: "(2::nat)^Suc n = 2 * 2^n" by (rule Power.power_class.power.power_Suc)
  show ?case using Suc.IH by (simp only: E P; arith)
qed

lemma vero_aux_layout_size:
  "bn_ds_tree_layout s P T \<Longrightarrow> length (bn_values s T) = 2 ^ bn_rank T"
proof (induction T)
  case (BN p cs)
  have IH: "map (\<lambda>U. length (bn_values s U)) cs = map (\<lambda>U. (2::nat) ^ bn_rank U) cs"
    using BN.IH BN.prems by (auto simp: list_all_iff intro!: map_cong)
  have RK: "map bn_rank cs = [0..<length cs]" using BN.prems by simp
  have MP: "map (\<lambda>U. (2::nat) ^ bn_rank U) cs = map (\<lambda>i. (2::nat)^i) [0..<length cs]"
    by (simp only: RK[symmetric] map_map o_def)
  have POW: "sum_list (map (\<lambda>U. (2::nat) ^ bn_rank U) cs) + 1 = 2 ^ length cs"
    by (simp only: MP vero_aux_sum_twopowers)
  show ?case using POW by (simp add: length_concat o_def IH)
qed

lemma vero_aux_forest_size_bound:
  assumes R: "\<forall>i < length F. case F ! i of None \<Rightarrow> True | Some T \<Rightarrow>
    length (bn_values s T) = 2 ^ (r + i)"
  shows "length (bn_forest_values s F) + 2^r \<le> 2^(r + length F)"
  using R
proof (induction F arbitrary: r)
  case Nil
  then show ?case by (simp add: bn_forest_values_def)
next
  case (Cons a F)
  have HD: "length (case_option [] (bn_values s) a) \<le> 2^r"
    using Cons.prems[rule_format, of 0] by (cases a) auto
  have TAIL: "\<forall>i < length F. case F ! i of None \<Rightarrow> True | Some T \<Rightarrow>
    length (bn_values s T) = 2 ^ (Suc r + i)"
  proof (intro allI impI)
    fix i assume I: "i < length F"
    show "case F ! i of None \<Rightarrow> True | Some T \<Rightarrow> length (bn_values s T) = 2 ^ (Suc r + i)"
      using Cons.prems[rule_format, of "Suc i"] I
      by (cases "F ! i") (auto simp: add_Suc_shift)
  qed
  show ?case using HD Cons.IH[OF TAIL]
    by (simp add: bn_forest_values_def power_Suc; arith)
qed

lemma vero_aux_layout_root_nonnull:
  "bn_ds_tree_layout s P T \<Longrightarrow> bn_root T \<noteq> NULL"
  by (cases T) (auto dest: c_guard_NULL)

lemma vero_aux_forest_view_size_bound:
  assumes V: "bn_ds_forest_view s h P F"
  shows "length (bn_forest_values s F) + 1 \<le> 2 ^ length F"
proof -
  have R: "\<forall>i < length F. case F ! i of None \<Rightarrow> True | Some T \<Rightarrow>
    length (bn_values s T) = 2 ^ (0 + i)"
  proof (intro allI impI)
    fix i assume I: "i < length F"
    show "case F ! i of None \<Rightarrow> True | Some T \<Rightarrow> length (bn_values s T) = 2 ^ (0 + i)"
    proof (cases "F ! i")
      case None
      then show ?thesis by simp
    next
      case (Some T)
      have L: "bn_ds_tree_layout s P T" and RK: "bn_rank T = i"
        using V I Some by (auto simp: bn_ds_forest_view_def)
      show ?thesis using vero_aux_layout_size[OF L] RK by (simp add: Some)
    qed
  qed
  show ?thesis using vero_aux_forest_size_bound[OF R] by simp
qed

lemma c0074_prove:
  "bn_ds_merge_pre s0 h other P F G ext held N edges \<Longrightarrow>
  n = max (length F) (length G) + 1 \<Longrightarrow>
  bn_ds_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s \<Longrightarrow>
  unat i = n \<Longrightarrow>
  bn_ds_carry_done s0 h P F G ext held N a n (bn_carry,i,len,vals) s"

proof -
  assume PRE: "bn_ds_merge_pre s0 h other P F G ext held N edges"
    and N: "n = max (length F) (length G) + 1"
    and INV: "bn_ds_carry_inv s0 h other P F G ext held N a n (bn_carry,i,len,vals) s"
    and END: "unat i = n"
  have BF: "length (bn_forest_values s0 F) + 1 \<le> 2 ^ length F"
    apply (rule vero_aux_forest_view_size_bound[where h=h and P=P])
    using PRE by (simp add: bn_ds_merge_pre_def)
  have BG: "length (bn_forest_values s0 G) + 1 \<le> 2 ^ length G"
    apply (rule vero_aux_forest_view_size_bound[where h=other and P=P])
    using PRE by (simp add: bn_ds_merge_pre_def)
  have PF: "(2::nat)^length F \<le> 2^max (length F) (length G)" by (simp add: power_increasing_iff)
  have PG: "(2::nat)^length G \<le> 2^max (length F) (length G)" by (simp add: power_increasing_iff)
  have TOT: "length (bn_forest_values s0 F) + length (bn_forest_values s0 G) < 2^n"
    using BF BG PF PG by (simp add: N power_Suc; arith)
  have LF: "length F < n" and LG: "length G < n" by (simp_all add: N)
  have DF: "drop n F = []" using LF by simp
  have DG: "drop n G = []" using LG by simp
  obtain prefix C where CAR: "bn_carry = case_option NULL bn_root C"
    and CL: "case C of None \<Rightarrow> True | Some T \<Rightarrow> bn_rank T = n \<and> bn_ds_tree_layout s P T"
    and MASS: "mset (bn_forest_values s0 F) + mset (bn_forest_values s0 G) =
      mset (bn_forest_values s prefix) + mset (case_option [] (bn_values s) C)"
    using INV END DF DG by (auto simp: bn_ds_carry_inv_def bn_forest_values_def)
  have CN: "C = None"
  proof (cases C)
    case None
    thus ?thesis .
  next
    case (Some T)
    have SZ: "length (bn_values s T) = 2^n"
      using CL vero_aux_layout_size[of s P T] by (simp add: Some)
    have SIZE: "length (bn_forest_values s0 F) + length (bn_forest_values s0 G) =
      length (bn_forest_values s prefix) + length (bn_values s T)"
      using arg_cong[where f=size, OF MASS] by (simp add: Some)
    show ?thesis using TOT SZ SIZE by arith
  qed
  have NULL: "bn_carry = NULL" using CAR CN by simp
  show ?thesis using INV END NULL DF DG
    by (auto simp: bn_ds_carry_inv_def bn_ds_carry_done_def bn_forest_values_def
      split: option.splits dest: vero_aux_layout_root_nonnull; blast)
qed



end

context binomial_heap_input_global_addresses begin



lemma c0075_prove:
  "bn_rep s h P F M \<Longrightarrow> unat i < length F \<Longrightarrow>
   F ! unat i = Some T \<Longrightarrow>
   bn_contract (bn_ds_scan_step h (i,0xFFFFFFFF)) s
     (\<lambda>r t. r = (i + 1,i) \<and> t = s)"

proof -
  assume R: "bn_rep s h P F M" and I: "unat i < length F" and N: "F ! unat i = Some T"
  have G: "c_guard (roots_C (bn_heap s h) +\<^sub>p uint i)"
    and V: "h_val (hrs_mem (t_hrs_' s)) (roots_C (bn_heap s h) +\<^sub>p uint i) = bn_root T"
    and T: "bn_valid s P T"
    using R I N by (auto simp: bn_rep_def int_unat)
  have "c_guard (bn_root T)" using T by (cases T) auto
  hence NN: "bn_root T \<noteq> NULL" by (rule c_guard_NULL)
  show ?thesis using G V NN
    by (auto simp: bn_ds_scan_step_def bn_contract_def bn_heap_def
      runs_to_bind_iff runs_to_guard_iff runs_to_condition_iff reaches_bind reaches_condition_iff
      succeeds_runs_to_iff reaches_guard reaches_return)
qed



end



lemma c0076_prove:
  "ptr_span (p :: 'a::mem_type ptr) \<subseteq> S \<Longrightarrow>
   length bs = size_of TYPE('a) \<Longrightarrow>
   bytes_frame S hp (heap_update_padding p v bs hp) \<and>
   bytes_frame S hp (heap_update_list (ptr_val p) bs hp)"

by (auto simp: bytes_frame_def heap_update_padding_def intro!: heap_update_nmem_same)





lemma c0077_prove:
  "R s \<noteq> {} \<Longrightarrow>
   (\<And>v t. (v,t) \<in> R s \<Longrightarrow> Q v t) \<Longrightarrow>
   bn_contract (assume_result_and_state R) s Q"

by (auto simp: bn_contract_def runs_to_assume_result_and_state_iff reaches_assume_result_and_state)



context binomial_heap_input_global_addresses begin



lemma c0078_prove:
  "bn_rep s h P F M \<Longrightarrow> bn_contract (binomial_heap_num_entries' h) s
    (\<lambda>r t. unat r = size M \<and> t = s)"

by (auto simp: bn_rep_def bn_heap_def bn_contract_def binomial_heap_num_entries'_def runs_to_bind_iff reaches_bind succeeds_runs_to_iff runs_to_guard_iff runs_to_gets_iff reaches_guard reaches_gets[abs_def])



end

context binomial_heap_input_global_addresses begin



lemma c0079_prove:
  "c_guard p \<Longrightarrow> unat (refcount_C (bn_tree s p)) < 65535 \<Longrightarrow>
    bn_contract (binomial_tree_ref' p) s (\<lambda>r t.
      bn_tree t p = (bn_tree s p)\<lparr>refcount_C := refcount_C (bn_tree s p) + 1\<rparr> \<and>
      phantom_machine_state_' t = phantom_machine_state_' s \<and>
      bytes_frame (block_bytes (ptr_val p) (size_of TYPE(StrictC'_BinomialTree_C)))
        (hrs_mem (t_hrs_' s)) (hrs_mem (t_hrs_' t)))"

proof -
  assume G: "c_guard p" and B: "unat (refcount_C (bn_tree s p)) < 65535"
  have NN: "p \<noteq> NULL" using G by (auto dest: c_guard_NULL)
  have UB: "uint (refcount_C (bn_tree s p)) < INT_MAX"
    using B by (simp only: INT_MAX_def uint_nat; arith)
  show ?thesis using G NN UB vero_aux_update_frame[OF G]
    by (auto simp: binomial_tree_ref'_def bn_contract_def bn_tree_def
      hrs_mem_def hrs_mem_update_def case_prod_unfold h_val_heap_update vero_aux_refcount_dec vero_aux_refcount_inc
      runs_to_bind_iff runs_to_guard_iff runs_to_modify_iff
      reaches_bind succeeds_runs_to_iff reaches_guard reaches_modify[abs_def])
qed



end

end
theory R2_Leaf_Unref imports Repair_Phase_Model Revision_Witness_Provider R2_Graph_Progress begin
context binomial_heap_input_global_addresses begin



lemma r2_dec_fields:
 "c_guard p \<Longrightarrow> bn_tree (r2_dec s p) p =
   (bn_tree s p)\<lparr>refcount_C:=refcount_C (bn_tree s p)-1\<rparr>"
 by (simp add: r2_dec_def bn_tree_def hrs_mem_update_def hrs_mem_def case_prod_unfold h_val_heap_update)

lemma r2_modify_prefix:
 "bn_contract B (f s) Q \<Longrightarrow> bn_contract (do {modify f; B}) s Q"
 by (auto simp: bn_contract_def runs_to_bind_iff runs_to_modify_iff reaches_bind reaches_modify
   succeeds_runs_to_iff; erule runs_to_weaken; simp)

lemma r2_unref_prefix:
 assumes G: "c_guard p"
 and CONT: "bn_contract
  (condition (\<lambda>s. (ucast (refcount_C (bn_tree s p)) :: 32 signed word)=0)
    (vero_aux_unref_tail p) skip) (r2_dec s p) Q"
 shows "bn_contract (binomial_tree_unref' p) s Q"
proof -
 have NN: "p\<noteq>NULL" using G by (auto dest: c_guard_NULL)
 have LO: "-INT_MAX-1 < uint (refcount_C (bn_tree s p))"
  using uint_nonnegative[of "refcount_C (bn_tree s p)"] by (simp add: INT_MAX_def; arith)
 have HI: "uint (refcount_C (bn_tree s p)) \<le> INT_MAX+1"
  using uint_lt2p[of "refcount_C (bn_tree s p)"] by (simp add: INT_MAX_def; arith)
 show ?thesis
  apply (subst vero_aux_unref_equation)
  apply (simp only: NN condition_to_unless[symmetric])
  apply simp
  apply (rule vero_aux_guard_prefix)
   apply (rule G)
  apply (rule vero_aux_guard_prefix)
   apply (rule LO)
  apply (rule vero_aux_guard_prefix)
   apply (rule HI)
  apply (rule r2_modify_prefix)
  using CONT unfolding r2_dec_def .
qed

lemma r2_unref_retained:
 assumes G: "c_guard p" and R: "1 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t. t = r2_dec s p)"
proof -
 have NZ: "refcount_C (bn_tree s p)-1 \<noteq> 0"
  using R by auto
 have U: "(ucast (refcount_C (bn_tree s p)-1) :: 32 signed word) \<noteq> 0"
  using NZ by (simp add: ucast_eq_0)
 show ?thesis
  apply (rule r2_unref_prefix[OF G])
  by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff
    r2_dec_fields[OF G] U reaches_return[abs_def])
qed

lemma r2_leaf_tail_release:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and G: "c_guard p" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and ORDER: "order_C (bn_tree s p)=0" and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 shows "bn_contract (vero_aux_unref_tail p) s (\<lambda>r t. vero_aux_release s {ptr_val p} {ptr_val p} t)"
proof -
 have LOOP: "bn_contract
   (whileLoop (\<lambda>i u. i <s (ucast (order_C (bn_tree u p)) :: 32 signed word))
     (vero_aux_unref_body p) 0) s (\<lambda>i t. t=s)"
  by (rule vero_aux_contract_while[where I="\<lambda>i. i=0" and m="\<lambda>_.0"]) (simp_all add: ORDER)
 have FREE0: "bn_contract (free' NULL) s (\<lambda>r t. t=s)"
  apply (rule vero_aux_contract_weaken[OF vero_aux_free_contract[OF W]])
   apply simp
  by (auto simp: free_rel_def)
 have FREEP: "bn_contract (free' (ptr_coerce p)) s (\<lambda>r t. vero_aux_release s {ptr_val p} {ptr_val p} t)"
  using vero_aux_free_release[OF W, of "ptr_coerce p" 24] LP by simp
 have CAST: "ptr_coerce (NULL :: StrictC'_BinomialTree_C ptr ptr) = (NULL::unit ptr)" by simp
 show ?thesis unfolding vero_aux_unref_tail_def
 proof (rule vero_aux_contract_bind[OF LOOP])
  fix i t assume EQ: "t=s"
  show "bn_contract (do {
    a \<leftarrow> gets (\<lambda>u. ptr_coerce (subtrees_C (bn_tree u p)));
    free' a; free' (ptr_coerce p)}) t
    (\<lambda>r u. vero_aux_release s {ptr_val p} {ptr_val p} u)"
   unfolding EQ
   apply (rule vero_aux_gets_prefix)
   apply (simp only: ARRAY CAST)
   apply (rule vero_aux_contract_bind[OF FREE0])
   using FREEP by auto
 qed

qed

lemma r2_unref_leaf:
 assumes W: "allocator_wf (phantom_machine_state_' s)"
 and G: "c_guard p" and LP: "live_blocks (phantom_machine_state_' s) (ptr_val p)=Some 24"
 and ORDER: "order_C (bn_tree s p)=0" and ARRAY: "subtrees_C (bn_tree s p)=NULL"
 and POS: "0 < unat (refcount_C (bn_tree s p))"
 shows "bn_contract (binomial_tree_unref' p) s (\<lambda>r t.
   if refcount_C (bn_tree s p)=1 then
     vero_aux_release (r2_dec s p) {ptr_val p} {ptr_val p} t
   else t=r2_dec s p)"
proof (cases "refcount_C (bn_tree s p)=1")
 case True
 have WF: "allocator_wf (phantom_machine_state_' (r2_dec s p))"
  using W by (simp add: r2_dec_def)
 have LIVE: "live_blocks (phantom_machine_state_' (r2_dec s p)) (ptr_val p)=Some 24"
  using LP by (simp add: r2_dec_def)
 have O: "order_C (bn_tree (r2_dec s p) p)=0"
  and A: "subtrees_C (bn_tree (r2_dec s p) p)=NULL"
  using ORDER ARRAY r2_dec_fields[OF G, of s] by simp_all
 have TAIL: "bn_contract (vero_aux_unref_tail p) (r2_dec s p)
   (\<lambda>r t. vero_aux_release (r2_dec s p) {ptr_val p} {ptr_val p} t)"
  by (rule r2_leaf_tail_release[OF WF G LIVE O A])
 show ?thesis
  apply (simp only: True if_True)
  apply (rule r2_unref_prefix[OF G])
  by (simp add: bn_contract_def runs_to_condition_iff reaches_condition_iff
    r2_dec_fields[OF G] True; use TAIL[unfolded bn_contract_def] in auto)
next
 case False
 have GT: "1 < unat (refcount_C (bn_tree s p))"
  using POS False by (auto simp: unat_eq_1[symmetric]; arith)
 show ?thesis using r2_unref_retained[OF G GT] False by simp
qed

ML \<open>
 val facts = @{thms r2_unref_prefix r2_unref_retained r2_leaf_tail_release r2_unref_leaf};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "R2_LEAF_UNREF_PASS";
\<close>
end
end

theory R2_Graph_Progress imports Repair_Phase_Model Revised_Ownership_Model begin

lemma r2_graph_edge_rank:
 assumes G: "bn_ds_graph s P N edges slots held pending"
 and PN: "p \<in> N" and QE: "q \<in> set (edges p)"
 shows "q \<in> N \<and> unat (order_C (bn_tree s q)) < unat (order_C (bn_tree s p))"
proof -
 obtain i where I: "i < length (edges p)" and EQ: "edges p ! i = q"
  using QE by (auto simp: in_set_conv_nth)
 have MAP: "map (\<lambda>q. unat (order_C (bn_tree s q))) (edges p) = [0..<length (edges p)]"
  and LEN: "unat (order_C (bn_tree s p)) = length (edges p)"
  and SUB: "set (edges p) \<subseteq> N"
  using G PN unfolding bn_ds_graph_def by blast+
 have "unat (order_C (bn_tree s q)) = i"
  using arg_cong[OF MAP, where f="\<lambda>xs. xs ! i"] I EQ by simp
 then show ?thesis using SUB QE LEN I by auto
qed

lemma r2_graph_path_rank:
 assumes G: "bn_ds_graph s P N edges slots held pending"
 and PATH: "(p,q) \<in> {(x,y). x \<in> N \<and> y \<in> set (edges x)}\<^sup>+"
 shows "unat (order_C (bn_tree s q)) < unat (order_C (bn_tree s p))"
 using PATH
proof (induction rule: trancl_induct)
 case (base y)
 then show ?case using r2_graph_edge_rank[OF G] by auto
next
 case (step y z)
 have "unat (order_C (bn_tree s z)) < unat (order_C (bn_tree s y))"
  using step.hyps(2) r2_graph_edge_rank[OF G] by auto
 then show ?case using step.IH by arith
qed

lemma r2_graph_acyclic:
 "bn_ds_graph s P N edges slots held pending \<Longrightarrow>
  acyclic {(x,y). x \<in> N \<and> y \<in> set (edges x)}"
 by (auto simp: acyclic_def irrefl_def dest: r2_graph_path_rank)

lemma r2_graph_reference_positive:
 assumes G: "bn_ds_graph s P N edges slots held {}" and PN: "p \<in> N"
 shows "0 < unat (refcount_C (bn_tree s p))"
proof -
 let ?H="bn_ds_slot_handles s slots + held"
 let ?R="{(x,y). x \<in> N \<and> y \<in> set (edges x)}"
 have FIN: "finite N" and RC: "unat (refcount_C (bn_tree s p)) =
  count ?H p + (\<Sum>x\<in>N. count (mset (edges x)) p)"
  using G PN unfolding bn_ds_graph_def by blast+
 obtain r where ROOT: "r \<in> set_mset ?H" and PATH: "(r,p) \<in> ?R\<^sup>*"
  using G PN unfolding bn_ds_graph_def by blast
 show ?thesis
 proof (cases "r=p")
  case True
  have "0 < count ?H p" using ROOT True by simp
  then show ?thesis using RC by arith
 next
  case False
  obtain q where QN: "q \<in> N" and EDGE: "p \<in> set (edges q)"
   using PATH False by (cases rule: rtrancl.cases) auto
  have C: "0 < count (mset (edges q)) p" using EDGE by simp
  have LE: "count (mset (edges q)) p \<le> (\<Sum>x\<in>N. count (mset (edges x)) p)"
  proof -
   have "(\<Sum>x\<in>{q}. count (mset (edges x)) p) \<le> (\<Sum>x\<in>N. count (mset (edges x)) p)"
    apply (rule sum_mono2[OF FIN]) using QN by auto
   then show ?thesis by simp
  qed
  show ?thesis using C LE RC by arith
 qed
qed

lemma r2_graph_leaf_edges:
 "bn_ds_graph s P N edges slots held pending \<Longrightarrow> p \<in> N \<Longrightarrow>
  order_C (bn_tree s p) = 0 \<Longrightarrow> edges p = []"
 by (auto simp: bn_ds_graph_def)

lemma r2_graph_slots_swap:
 "bn_ds_graph s P N edges (xs @ ys @ zs) held pending =
  bn_ds_graph s P N edges (ys @ xs @ zs) held pending"
 by (auto simp: bn_ds_graph_def bn_ds_slot_handles_def distinct_append add_ac)

lemma r2_graph_storage_slots_swap:
 "bn_r2_graph_storage s N (xs @ ys @ zs) = bn_r2_graph_storage s N (ys @ xs @ zs)"
 by (auto simp: bn_r2_graph_storage_def bn_ds_graph_storage_def bn_r2_slots_supported_def)

ML \<open>
 val facts = @{thms r2_graph_edge_rank r2_graph_path_rank r2_graph_acyclic
   r2_graph_reference_positive r2_graph_leaf_edges r2_graph_slots_swap r2_graph_storage_slots_swap};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "R2_GRAPH_PROGRESS_PASS";
\<close>
end

theory R2_Rollback_Phases imports Repair_Phase_Model Revision_Callsite_Bridges R2_Graph_Progress begin



lemma r3_initial_slots_supported:
 assumes PRE: "bn_r2_merge_pre s h other P F G ext held N edges"
 shows "bn_r2_slots_supported s
  (bn_ds_slots (roots_C (bn_heap s h)) (length F) @ ext) (bn_ds_graph_blocks s N)"
proof -
 let ?a="roots_C (bn_heap s h)"
 let ?B="bn_ds_graph_blocks s N"
 have WF: "allocator_wf (phantom_machine_state_' s)"
  and OUT: "ptr_val ?a\<notin>?B"
  using PRE by (auto simp: bn_r2_merge_pre_def bn_ds_graph_def)
 have AS: "bn_r2_slots_supported s (bn_ds_slots ?a (length F)) ?B"
 proof (cases "?a=NULL")
  case True
  have "F=[]" using PRE True
   by (cases F) (auto simp: bn_r2_merge_pre_def bn_ds_forest_view_def
    bn_review_header_view_def bn_review_root_array_view_def dest: c_guard_NULL)
  then show ?thesis by (simp add: bn_ds_slots_def bn_r2_slots_supported_def)
 next
  case False
  have OA: "bn_ds_owned_array s ?a (length F)"
   using PRE False by (simp add: bn_r2_merge_pre_def)
  show ?thesis by (rule r2_owned_array_slots[OF WF OA OUT])
 qed
 have EXT: "bn_r2_slots_supported s ext ?B"
 proof (unfold bn_r2_slots_supported_def, intro ballI)
  fix q assume Q: "q\<in>set ext"
  have GUARD: "c_guard q" and SUPPORT: "bn_r2_span_supported s (ptr_span q)
    (insert (ptr_val h) (insert (ptr_val ?a) ?B))"
   using PRE Q by (auto simp: bn_r2_merge_pre_def bn_r2_slots_supported_def bn_r2_slot_supported_def)
  have WEAK: "bn_r2_span_supported s (ptr_span q) ?B"
   apply (rule r2_supported_monotone[OF SUPPORT]) by auto
  show "bn_r2_slot_supported s q ?B" using GUARD WEAK by (simp add: bn_r2_slot_supported_def)
 qed
 show ?thesis using AS EXT by (auto simp: bn_r2_slots_supported_def)
qed

lemma r3_rollback_entry_premises:
 assumes ENTRY: "bn_r3_rollback_entry s0 h other P F G ext held N0 e0 a n i bn_carry s N edges"
 shows "unat i < 33 \<and> bn_ds_owned_array s a (unat i+1) \<and>
  bn_ds_graph s P N edges
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext))
    (held + mset (filter (\<lambda>p. p\<noteq>NULL) [bn_carry])) {} \<and>
  bn_r2_graph_storage s N
    (bn_ds_slots a (unat i+1) @ (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)) \<and>
  bn_r2_slots_supported s (bn_ds_slots (roots_C (bn_heap s0 h)) (length F) @ ext)
    (insert (ptr_val a) (bn_ds_graph_blocks s N)) \<and>
  ptr_val a\<notin>bn_ds_graph_blocks s N"
proof -
 let ?old="bn_ds_slots (roots_C (bn_heap s0 h)) (length F)"
 let ?prefix="bn_ds_slots a (unat i+1)"
 let ?B="bn_ds_graph_blocks s N"
 have PRE: "bn_r2_merge_pre s0 h other P F G ext held N0 e0"
  and I: "unat i<n" and NB: "n\<le>33" and OA: "bn_ds_owned_array s a n"
  and GR: "bn_ds_graph s P N edges (?old @ ?prefix @ ext)
    (held + mset (filter (\<lambda>p. p\<noteq>NULL) [bn_carry])) {}"
  and ST: "bn_r2_graph_storage s N (?old @ ?prefix @ ext)"
  and TRANS: "bn_ds_storage_transition s0 (bn_ds_graph_blocks s0 N0) s (insert (ptr_val a) ?B)"
  using ENTRY unfolding bn_r3_rollback_entry_def by blast+
 have WF: "allocator_wf (phantom_machine_state_' s)" using GR by (simp add: bn_ds_graph_def)
 have OAP: "bn_ds_owned_array s a (unat i+1)"
  using OA I by (auto simp: bn_ds_owned_array_def; presburger)
 have SUPPORT: "bn_r2_slots_supported s (?old @ ext) (insert (ptr_val a) ?B)"
  by (rule r2_slots_storage_transition[OF r3_initial_slots_supported[OF PRE] TRANS])
 have OUT: "ptr_val a\<notin>?B"
 proof
  assume IN: "ptr_val a\<in>?B"
  obtain m where LIVE: "live_blocks (phantom_machine_state_' s) (ptr_val a)=Some m"
    and SIZE: "8*n\<le>m" using OA by (auto simp: bn_ds_owned_array_def)
  have BASESLOT: "a\<in>set ?prefix" unfolding bn_ds_slots_def set_map
   apply (rule image_eqI[where x=0]) by (auto simp: set_upt)
  have SLOT: "bn_r2_slot_supported s a ?B"
   using ST BASESLOT by (auto simp: bn_r2_graph_storage_def bn_r2_slots_supported_def)
  have DIS: "ptr_span a \<inter> block_bytes (ptr_val a) m = {}"
   using SLOT r2_supported_disjoint_block[OF WF _ LIVE IN]
   by (simp add: bn_r2_slot_supported_def)
  have SP: "ptr_val a\<in>ptr_span a" by (rule intvl_self) simp
  have BP: "ptr_val a\<in>block_bytes (ptr_val a) m"
   using SIZE I by (simp add: block_bytes_def; arith)
  show False using DIS SP BP by blast
 qed
 show ?thesis using I NB OAP GR ST SUPPORT OUT
  by (simp only: r2_graph_slots_swap[of s P N edges ?old ?prefix ext]
      r2_graph_storage_slots_swap[of s N ?old ?prefix ext]; auto)
qed

context binomial_heap_input_global_addresses begin







lemma r3_actual_carry_failure_cut:
 "bn_r3_carry_loop_step h other n a state = bn_ds_carry_loop_step h other n a state"
 by (simp only: bn_r3_carry_loop_step_def bn_ds_carry_loop_step_def bn_r3_rollback_throw_def)

ML \<open>
 val facts = @{thms r3_initial_slots_supported r3_rollback_entry_premises r3_actual_carry_failure_cut};
 val _ = if Thm_Deps.has_skip_proof facts then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles facts) then () else error "oracle";
 writeln "R3_ROLLBACK_PHASE_INTERFACES_PASS";
\<close>
end
end

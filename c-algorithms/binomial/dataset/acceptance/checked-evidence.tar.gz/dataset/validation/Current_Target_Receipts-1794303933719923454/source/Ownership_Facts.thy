theory Ownership_Facts
 imports Repair_Phase_Model Revised_Ownership_Model
begin

lemma r2_supported_readable:
 assumes support: "bn_r2_span_supported s W B"
 shows "W \<subseteq> readable_bytes (phantom_machine_state_' s)"
proof
 fix a assume member: "a \<in> W"
 show "a \<in> readable_bytes (phantom_machine_state_' s)"
 proof (cases "W \<subseteq> reserved_bytes (phantom_machine_state_' s)")
  case True then show ?thesis using member by (auto simp: readable_bytes_def)
 next
  case False
  obtain b n where live: "live_blocks (phantom_machine_state_' s) b = Some n"
   and sub: "W \<subseteq> block_bytes b n"
   using support False by (auto simp: bn_r2_span_supported_def)
  have dom: "b \<in> dom (live_blocks (phantom_machine_state_' s))" using live by auto
  have block: "a \<in> block_bytes b (the (live_blocks (phantom_machine_state_' s) b))"
   using live sub member by auto
  show ?thesis unfolding readable_bytes_def
   apply (rule UnI2)
   apply (rule UN_I[OF dom])
   apply (rule block)
   done
 qed
qed

lemma r2_supported_disjoint_block:
 assumes wf: "allocator_wf (phantom_machine_state_' s)"
 and supported: "bn_r2_span_supported s W B"
 and live: "live_blocks (phantom_machine_state_' s) p = Some n"
 and released: "p \<in> B"
 shows "W \<inter> block_bytes p n = {}"
proof -
  have reserved: "block_bytes p n \<inter> reserved_bytes (phantom_machine_state_' s) = {}"
    using wf live by (auto simp: allocator_wf_def)
  show ?thesis
  proof (cases "W \<subseteq> reserved_bytes (phantom_machine_state_' s)")
    case True then show ?thesis using reserved by blast
  next
    case False
    obtain b m where bm: "live_blocks (phantom_machine_state_' s) b = Some m"
      and b: "b \<notin> B" and sub: "W \<subseteq> block_bytes b m"
      using supported False by (auto simp: bn_r2_span_supported_def)
    have "b \<noteq> p" using released b by blast
    hence "block_bytes b m \<inter> block_bytes p n = {}"
      using wf bm live by (auto simp: allocator_wf_def)
    then show ?thesis using sub by blast
  qed
qed

lemma r2_supported_disjoint_released_bytes:
 assumes wf: "allocator_wf (phantom_machine_state_' s)"
 and support: "bn_r2_span_supported s W B"
 shows "W \<inter> bn_r2_released_bytes s B = {}"
proof -
 have False if x: "x \<in> W" and gone: "x \<in> bn_r2_released_bytes s B" for x
 proof -
  obtain b n where member: "b \<in> B"
   and live: "live_blocks (phantom_machine_state_' s) b = Some n"
   and block: "x \<in> block_bytes b n"
   using gone by (auto simp: bn_r2_released_bytes_def bn_r2_allocation_bytes_def split: option.splits)
  have "W \<inter> block_bytes b n = {}"
   by (rule r2_supported_disjoint_block[OF wf support live member])
  then show False using x block by blast
 qed
 then show ?thesis by blast
qed

lemma r2_supported_monotone:
 "bn_r2_span_supported s W C \<Longrightarrow> B \<subseteq> C \<Longrightarrow>
  bn_r2_span_supported s W B"
 by (auto simp: bn_r2_span_supported_def)

lemma r2_supported_storage_transition:
 assumes support: "bn_r2_span_supported s W B"
 and transition: "bn_ds_storage_transition s B t C"
 shows "bn_r2_span_supported t W C"
proof (cases "W \<subseteq> reserved_bytes (phantom_machine_state_' s)")
  case True
  then show ?thesis using transition
    by (auto simp: bn_r2_span_supported_def bn_ds_storage_transition_def)
next
  case False
  obtain b n where live: "live_blocks (phantom_machine_state_' s) b = Some n"
    and outside: "b \<notin> B" and span: "W \<subseteq> block_bytes b n"
    using support False by (auto simp: bn_r2_span_supported_def)
  have not_current: "b \<notin> C"
    using transition live outside by (auto simp: bn_ds_storage_transition_def)
  have kept: "live_blocks (phantom_machine_state_' t) b = Some n"
    using transition live outside not_current
    by (auto simp: bn_ds_storage_transition_def)
  show ?thesis using kept not_current span
    by (auto simp: bn_r2_span_supported_def)
qed

lemma r2_slots_storage_transition:
 "bn_r2_slots_supported s qs B \<Longrightarrow>
  bn_ds_storage_transition s B t C \<Longrightarrow>
  bn_r2_slots_supported t qs C"
 unfolding bn_r2_slots_supported_def bn_r2_slot_supported_def
 using r2_supported_storage_transition by blast

lemma r2_stack_slot_support:
 "c_guard q \<Longrightarrow> ptr_span q \<subseteq> S \<Longrightarrow>
  S \<subseteq> reserved_bytes (phantom_machine_state_' s) \<Longrightarrow>
  bn_r2_slot_supported s q B"
 by (auto simp: bn_r2_slot_supported_def bn_r2_span_supported_def)

lemma r2_slot_read_preserved:
 assumes wf: "allocator_wf (phantom_machine_state_' s)"
 and support: "bn_r2_slot_supported s q B"
 and frame: "bytes_frame (bn_r2_released_bytes s B) hp hp'"
 shows "h_val hp' q = h_val hp q"
proof -
  have disjoint: "ptr_span q \<inter> bn_r2_released_bytes s B = {}"
    using r2_supported_disjoint_released_bytes[OF wf] support
    by (simp add: bn_r2_slot_supported_def)
  have equal: "hp' a = hp a" if "a \<in> ptr_span q" for a
    using disjoint frame that by (auto simp: bytes_frame_def)
  have lists: "heap_list hp' (size_of TYPE(StrictC'_BinomialTree_C ptr)) (ptr_val q) =
    heap_list hp (size_of TYPE(StrictC'_BinomialTree_C ptr)) (ptr_val q)"
    apply (rule nth_equalityI)
     apply simp
    apply (simp add: heap_list_nth)
    apply (rule equal)
    apply (auto simp: intvl_def)
    done
  show ?thesis by (simp only: h_val_def lists)
qed

lemma r2_alias_header_excluded:
 assumes wf: "allocator_wf (phantom_machine_state_' s)"
 and live: "live_blocks (phantom_machine_state_' s) 16 = Some 40"
 shows "\<not> bn_r2_slot_supported s (Ptr 32) (insert 16 B)"
proof
  assume supported: "bn_r2_slot_supported s (Ptr 32) (insert 16 B)"
  have disjoint: "ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) \<inter> block_bytes 16 40 = {}"
    using r2_supported_disjoint_block[OF wf _ live, where B="insert 16 B"] supported
    by (auto simp: bn_r2_slot_supported_def)
  have member: "32 \<in> ptr_span (Ptr 32 :: StrictC'_BinomialTree_C ptr ptr) \<inter> block_bytes 16 40"
    by (rule IntI; (rule in_ptr_span_itself)?; simp add: block_bytes_def)
  show False using disjoint member by blast
qed

lemma r2_alias_oversized_array_excluded:
 assumes wf: "allocator_wf (phantom_machine_state_' s)"
 and live: "live_blocks (phantom_machine_state_' s) 16 = Some 16"
 shows "\<not> bn_r2_slot_supported s (Ptr 24) (insert 16 B)"
proof
  assume supported: "bn_r2_slot_supported s (Ptr 24) (insert 16 B)"
  have disjoint: "ptr_span (Ptr 24 :: StrictC'_BinomialTree_C ptr ptr) \<inter> block_bytes 16 16 = {}"
    using r2_supported_disjoint_block[OF wf _ live, where B="insert 16 B"] supported
    by (auto simp: bn_r2_slot_supported_def)
  have member: "24 \<in> ptr_span (Ptr 24 :: StrictC'_BinomialTree_C ptr ptr) \<inter> block_bytes 16 16"
    by (rule IntI; (rule in_ptr_span_itself)?; simp add: block_bytes_def)
  show False using disjoint member by blast
qed

ML \<open>
 val thms = @{thms r2_supported_readable r2_supported_disjoint_block
   r2_supported_disjoint_released_bytes r2_supported_monotone r2_supported_storage_transition
   r2_slots_storage_transition r2_stack_slot_support r2_slot_read_preserved
   r2_alias_header_excluded r2_alias_oversized_array_excluded};
 val _ = if Thm_Deps.has_skip_proof thms then error "skip proof" else ();
 val _ = if null (Thm_Deps.all_oracles thms) then () else error "oracle";
 writeln "R2_OWNERSHIP_FACTS_PASS lemmas=10";
\<close>
end
